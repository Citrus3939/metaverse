import './styles.css'
import { getSave, setSave, EMPTY, type Plot, type Save } from './data'
import { mapPage } from './map'
import { $, icons, logo } from './ui'

const app = $('app')
let saved = getSave()
let dispose: (() => void) | undefined
let active: 'map' | 'editor' = 'map'
let loading = false

app.innerHTML = `
  <header class="topbar">
    <button class="brand" id="brand" aria-label="方寸，返回地图">
      ${logo()}<div><strong>方寸</strong><small>地块工作室</small></div>
    </button>
    <nav class="workflow" aria-label="工作步骤">
      <button id="map-tab">${icons.map}<span>地图选址</span></button>
      <span class="workflow-arrow">${icons.chevron}</span>
      <button id="editor-tab">${icons.box}<span>3D 工作台</span></button>
    </nav>
    <div class="local-status"><i></i><span>本地工作区</span></div>
  </header>
  <main id="page"></main>
  <footer id="map-footer" class="map-footer"><div>${icons.globe}<span>地块和模型保存在此浏览器</span></div><div>地图尺寸为估算值</div></footer>
  <p id="app-message" class="app-message" role="alert" hidden></p>`

function navigation() {
  document.querySelector('.workflow [aria-current]')?.removeAttribute('aria-current')
  $(active === 'map' ? 'map-tab' : 'editor-tab').setAttribute('aria-current', 'step')
  ;($('editor-tab') as HTMLButtonElement).disabled = !saved
  $('map-footer').hidden = active !== 'map'
}
function showMap() {
  dispose?.()
  active = 'map'
  $('page').className = 'map-page'
  navigation()
  dispose = mapPage($('page'), saved, enterEditor)
}
async function enterEditor(plot: Plot) {
  if (active === 'editor' || loading) return
  loading = true
  try {
    if (!saved) {
      const next: Save = { plot, scene: structuredClone(EMPTY) }
      setSave(next)
      saved = next
    }
    const { editorPage } = await import('./editor')
    dispose?.()
    dispose = undefined
    active = 'editor'
    $('page').className = 'editor-page'
    navigation()
    dispose = editorPage($('page'), saved, value => {
      setSave(value)
      saved = value
    })
  } catch (error) {
    console.error(error)
    showMap()
    const message = $('app-message')
    message.textContent = error instanceof DOMException ? '浏览器存储不可用，无法保存地块。' : '无法打开 3D 工作台，请检查浏览器的 WebGL 支持。'
    message.hidden = false
    window.setTimeout(() => { message.hidden = true }, 5000)
  } finally {
    loading = false
  }
}
$('brand').onclick = $('map-tab').onclick = () => { if (active !== 'map') showMap() }
$('editor-tab').onclick = () => { if (saved) enterEditor(saved.plot) }
showMap()
