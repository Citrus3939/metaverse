import * as T from 'three'
import { $, button, escapeHtml, icons } from './ui'
import { area, distance, newItem, putAsset, SHAPES, type Item, type Primitive, type Save, type SceneData, type Vec } from './data'
import { applyItem, boundsOf, buildItem, fits, parseGlb, rememberAsset, World } from './world'
import { previewModel } from './import-preview'

const names = { ...SHAPES, group: '组合模型', glb: 'GLB 模型' }
const shapeIcons = { box: icons.box, sphere: icons.circle, cylinder: icons.cylinder, group: icons.group, glb: icons.package }
const modes = { translate: { name: '移动', icon: icons.move }, rotate: { name: '旋转', icon: icons.rotate }, scale: { name: '缩放', icon: icons.scaling } }
const axes = ['X', 'Y', 'Z']
const format = (n: number) => Number(n.toFixed(5)).toString()
const degrees = 180 / Math.PI
const add = (a: Vec, b: Vec): Vec => [a[0] + b[0], a[1] + b[1], a[2] + b[2]]

export function editorPage(root: HTMLElement, initial: Save, onSave: (value: Save) => void) {
  const plot = initial.plot
  let data: SceneData = structuredClone(initial.scene)
  let ids: string[] = []
  let walking = false
  let grid = true
  let snap = false
  let placing = false
  let closed = false
  let change: { id: string; result: Item; valid: boolean } | undefined
  let mode: keyof typeof modes = 'translate'
  const history: SceneData[] = []
  let toastTimer = 0
  const listeners = new AbortController()
  root.innerHTML = `
    <div class="editor-head">
      <div class="editor-title"><div class="editor-title-icon">${icons.box}</div><div><h1>我的地块</h1><p>${distance(plot.width)} × ${distance(plot.depth)} <span>·</span> ${area(plot.width * plot.depth)}</p></div></div>
      <div class="mode-toggle" aria-label="工作模式">
        <button class="active" id="edit-mode" aria-pressed="true">${icons.cursor} 编辑模式</button>
        <button id="walk-mode" aria-pressed="false">${icons.person} 行走模式</button>
      </div>
    </div>
    <div class="editor-body">
      <aside class="editor-sidebar editor-assets">
        <div class="eyebrow">建造</div>
        <h2>添加形状</h2>
        <div class="shape-list" id="primitives">${(Object.keys(SHAPES) as Primitive[]).map(kind => `<button class="shape" data-shape="${kind}"><span>${shapeIcons[kind]}</span>${SHAPES[kind]}</button>`).join('')}</div>
        <button class="secondary full" id="import-btn">${icons.upload} 导入 GLB</button>
        <input type="file" id="import-file" accept=".glb,model/gltf-binary" hidden>
        <div class="editor-rule"></div>
        <div class="subheading"><h2>场景物件</h2><small id="object-count"></small></div>
        <div id="scene-list" class="item-list"></div>
        <div class="editor-rule"></div>
        <div class="subheading"><h2>我的模型</h2><small id="model-count"></small></div>
        <div id="model-list" class="item-list"></div>
      </aside>
      <section class="viewport" id="viewport" aria-label="地块编辑器">
        <div class="view-top">
          <div class="view-chip"><i></i><span id="view-mode">正交视图</span></div>
          <div class="view-buttons">${button('grid', '辅助网格', 'toggle-grid')}${button('magnet', '网格吸附', 'toggle-snap')}${button('focus', '整块地取景', 'fit-view')}</div>
        </div>
        <div class="view-message" id="view-message" aria-live="polite"></div>
        <div class="view-bottom">
          <div class="axis-mark" aria-label="X 向东，Z 向南">
            <svg viewBox="0 0 62 58" aria-hidden="true">
              <path d="M29 35 48 44" stroke="#ba6d61"/><path d="M29 35 12 46" stroke="#7298b5"/><path d="M29 35V13" stroke="#4d8d6d"/>
              <circle cx="29" cy="35" r="3" fill="#677c70"/>
              <text x="51" y="49" fill="#a35246">X</text><text x="3" y="52" fill="#527a99">Z</text><text x="25" y="10" fill="#3e785a">Y</text>
            </svg>
          </div>
          <div class="view-hint" id="view-hint">${icons.mouse} 右键旋转 <b>·</b> 中键平移 <b>·</b> 滚轮缩放</div>
        </div>
        <div id="toast" class="toast" role="status"></div>
      </section>
      <aside class="editor-sidebar editor-properties">
        <div class="eyebrow">编辑</div>
        <h2>属性面板</h2>
        <div class="edit-tools" id="tool-buttons">${(Object.keys(modes) as (keyof typeof modes)[]).map(key => `<button data-mode="${key}" class="tool-button${key === mode ? ' active' : ''}" title="${modes[key].name}">${modes[key].icon}<span>${modes[key].name}</span></button>`).join('')}</div>
        <div class="inspector" id="inspector"></div>
      </aside>
    </div>
    <footer class="editor-footer"><div class="footer-left">${icons.layers}<span id="editor-status">编辑模式</span></div><div class="footer-tools">${button('undo', '撤销 (Ctrl+Z)', 'undo-btn')}${button('copy', '复制 (Ctrl+D)', 'duplicate-btn')}${button('trash', '删除 (Delete)', 'delete-btn')}</div><div class="footer-right">${icons.keyboard}<span id="editor-location">米制坐标 · X 东 / Z 南</span></div></footer>
    <dialog id="group-dialog" class="app-dialog">
      <form id="group-form">
        <div class="dialog-heading"><span class="dialog-icon">${icons.group}</span><div><h2>保存到我的模型</h2><p>组合后可从模型列表重复放置。</p></div>${button('close', '关闭', 'close-group')}</div>
        <label class="field-label" for="group-name">模型名称</label>
        <input id="group-name" class="text-field" type="text" maxlength="60" required autocomplete="off" placeholder="例如：我的路灯">
        <div class="dialog-actions"><button type="button" class="secondary" id="cancel-group">取消</button><button class="primary" type="submit">保存模型 ${icons.check}</button></div>
      </form>
    </dialog>
    <dialog id="import-dialog" class="app-dialog import-dialog">
      <form id="import-form">
        <div class="dialog-heading"><span class="dialog-icon">${icons.upload}</span><div><h2>预览导入模型</h2><p id="import-name"></p></div>${button('close', '关闭', 'close-import')}</div>
        <div id="import-preview" class="import-preview" aria-label="GLB 三维预览"></div>
        <div class="import-size" id="import-size"></div>
        <div class="import-warning" id="import-warning" aria-live="polite"></div>
        <label class="field-label" for="import-scale">等比缩放</label>
        <div class="scale-row"><input id="import-scale" class="text-field" type="number" min="0" step="any" value="1"><button type="button" id="fit-import" class="secondary">适应地块</button></div>
        <div class="import-options"><label><input id="ground-import" type="checkbox" checked> 底部贴地</label><label><input id="center-import" type="checkbox" checked> 放到地块中心</label></div>
        <div class="dialog-actions"><button type="button" class="secondary" id="cancel-import">取消</button><button class="primary" id="confirm-import" type="submit">确认放置 ${icons.arrow}</button></div>
      </form>
    </dialog>`

  const world = new World($('viewport'), plot, {
    select: (id, multiple) => select(id, multiple),
    preview: (id, values, valid) => {
      const item = find(id)
      if (!item) return
      change = { id, result: { ...item, ...values }, valid }
      message(valid ? '' : '物件占地超出边界，松开将恢复原位。', !valid)
      updateTransformFields(change.result)
    },
    commit: id => { if (change?.id === id) commitTransform() },
    loaded: () => { if (!closed && !walking && ids.length === 1 && !change) renderInspector() },
    error: text => { if (!closed) notify(text, true) },
    walking: (position, edge) => {
      $('editor-location').textContent = `X ${position.x.toFixed(1)} m  ·  Z ${position.z.toFixed(1)} m`
      message(edge ? '已到达地块边界' : '', edge)
    },
  })
  const set = (id: string, disabled: boolean) => { ($(id) as HTMLButtonElement).disabled = disabled }
  const find = (id: string) => data.items.find(item => item.id === id)
  const current = () => ids.length === 1 ? find(ids[0]) : undefined
  type ImportState = { id: string; name: string; bytes: ArrayBuffer; source: T.Object3D; bounds: T.Box3; max: number; proposed: number }
  let pendingImport: ImportState | undefined
  let importPreview: ReturnType<typeof previewModel> | undefined

  function persist() {
    try { onSave({ plot, scene: data }) }
    catch { notify('浏览器存储空间不足，本次修改暂未保存。', true) }
  }
  function record() {
    history.push(structuredClone(data))
    if (history.length > 50) history.shift()
  }
  function notify(text: string, problem = false) {
    const toast = $('toast')
    toast.innerHTML = `${problem ? icons.warning : icons.check}<span>${escapeHtml(text)}</span>`
    toast.classList.toggle('problem', problem)
    toast.classList.add('show')
    window.clearTimeout(toastTimer)
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 3000)
  }
  function message(text: string, warning = false) {
    const element = $('view-message')
    element.textContent = text
    element.classList.toggle('warning', warning)
    element.classList.toggle('show', Boolean(text))
  }
  function select(id: string | undefined, multiple = false) {
    if (walking || placing) return
    ids = id ? (multiple ? ids.includes(id) ? ids.filter(value => value !== id) : [...ids, id] : [id]) : []
    change = undefined
    world.select(ids)
    message('')
    render()
  }
  function sync() {
    world.sync(data.items)
    world.select(ids)
    render()
    persist()
  }
  function render() {
    $('object-count').textContent = String(data.items.length)
    $('model-count').textContent = String(data.models.length)
    $('scene-list').innerHTML = data.items.length ? data.items.map(item => `<button class="list-item${ids.includes(item.id) ? ' selected' : ''}" data-item="${item.id}" title="${escapeHtml(item.name)}" aria-pressed="${ids.includes(item.id)}">${shapeIcons[item.kind]}<span>${escapeHtml(item.name)}</span><i></i></button>`).join('') : '<p class="list-empty">地块还是空的，添加一个形状开始建造。</p>'
    $('model-list').innerHTML = data.models.length ? data.models.map(item => `<button class="list-item" data-model="${item.id}" title="放置 ${escapeHtml(item.name)}">${icons.package}<span>${escapeHtml(item.name)}</span>${icons.plus}</button>`).join('') : '<p class="list-empty">按住 Shift 选择多个物件，组合后可保存到这里。</p>'
    set('undo-btn', walking || placing || !history.length)
    set('duplicate-btn', walking || placing || !current())
    set('delete-btn', walking || placing || !ids.length)
    set('import-btn', walking || placing)
    root.querySelectorAll<HTMLButtonElement>('[data-shape], [data-model], [data-item], [data-mode]').forEach(control => { control.disabled = walking || placing })
    set('fit-view', walking)
    set('walk-mode', placing)
    $('toggle-grid').classList.toggle('active', grid)
    $('toggle-grid').setAttribute('aria-pressed', String(grid))
    $('toggle-snap').classList.toggle('active', snap)
    $('toggle-snap').setAttribute('aria-pressed', String(snap))
    renderInspector()
  }

  function renderInspector() {
    const inspector = $('inspector')
    const item = current()
    if (walking || placing || !ids.length) {
      inspector.innerHTML = `<div class="inspector-empty"><span>${walking ? icons.person : icons.cursor}</span><strong>${walking ? '小人正在地块中' : placing ? '正在放置模型' : '尚未选择物件'}</strong><p>${walking ? '使用 WASD 或方向键移动。' : placing ? '移动鼠标预览，点击确定位置。' : '点击场景中的物件，查看和编辑属性。'}</p></div>`
      return
    }
    if (!item) {
      const canGroup = ids.every(id => find(id)?.kind !== 'glb')
      inspector.innerHTML = `<div class="inspector-empty multi"><span>${icons.group}</span><strong>已选择 ${ids.length} 个物件</strong><p>${canGroup ? '将选中的形状组合成可重复放置的模型。' : '组合功能支持自制形状和自制组合。'}</p></div>${canGroup ? `<button class="secondary full" id="save-group">${icons.group} 组合并保存</button>` : ''}`
      if (canGroup) $('save-group').onclick = openGroup
      return
    }
    const fields = (key: 'position' | 'rotation' | 'scale', label: string, unit: string) => `
      <fieldset class="transform-field"><legend>${label} <small>${unit}</small></legend>
        <div class="axis-fields">${axes.map((axis, i) => `<label class="input-axis axis-${axis.toLowerCase()}"><span>${axis}</span><input aria-label="${label} ${axis}" data-key="${key}" data-axis="${i}" type="number" step="any" value="${format(item[key][i] * (key === 'rotation' ? degrees : 1))}"></label>`).join('')}</div>
      </fieldset>`
    const bounds = world.getBounds(item.id)
    const size = bounds.getSize(new T.Vector3())
    inspector.innerHTML = `
      <div class="selected-title"><span>${shapeIcons[item.kind]}</span><div><strong>${escapeHtml(item.name)}</strong><small>${names[item.kind]}</small></div></div>
      ${fields('position', '位置', 'm')}${fields('rotation', '旋转', '°')}${fields('scale', '缩放', '×')}
      ${item.color ? `<label class="color-row">颜色 <span><input type="color" aria-label="颜色" id="item-color" value="${item.color}">${item.color.toUpperCase()}</span></label>` : ''}
      ${!bounds.isEmpty() ? `<div class="measured">水平占地 <strong id="measured-size">${distance(size.x)} × ${distance(size.z)}</strong></div>` : ''}
      <button class="secondary full" id="ground-item">${icons.layers} 底部贴地</button>
      ${item.kind === 'group' ? `<button class="secondary full" id="save-group">${icons.package} 保存为模型</button>` : ''}`
    const paint = document.getElementById('item-color') as HTMLInputElement | null
    if (paint) paint.onchange = () => {
      const object = world.get(item.id)
      if (!object || item.color === paint.value) return
      record()
      item.color = paint.value
      applyItem(object, item)
      persist()
      render()
    }
    $('ground-item').onclick = () => {
      const object = world.get(item.id)
      const box = world.getBounds(item.id)
      if (!object || box.isEmpty() || Math.abs(box.min.y) < 1e-8) return
      const result = structuredClone(item)
      result.position[1] -= box.min.y
      change = { id: item.id, result, valid: true }
      commitTransform()
    }
    if (item.kind === 'group') $('save-group').onclick = openGroup
    inspector.querySelectorAll<HTMLInputElement>('input[data-key]').forEach(input => {
      let dirty = false
      const preview = () => {
        dirty = true
        const value = input.valueAsNumber
        const object = world.get(item.id)
        if (!object || !Number.isFinite(value)) return
        const key = input.dataset.key as 'position' | 'rotation' | 'scale'
        const result = structuredClone(item)
        result[key][Number(input.dataset.axis)] = value / (key === 'rotation' ? degrees : 1)
        applyItem(object, result)
        const valid = fits(boundsOf(object), plot) && result.scale.every(entry => entry > 0)
        change = { id: item.id, result, valid }
        world.setInvalid(!valid)
        message(valid ? '' : '整个物件必须位于地块边界内，确认时将恢复原值。', !valid)
      }
      input.oninput = preview
      const finish = () => {
        if (!dirty) return
        dirty = false
        if (change && Number.isFinite(input.valueAsNumber)) commitTransform(false)
        else {
          const object = world.get(item.id)
          if (object) applyItem(object, item)
          change = undefined
          world.setInvalid(false)
          message('')
          updateTransformFields(item)
        }
      }
      input.onchange = finish
      input.onblur = finish
      input.onkeydown = event => { if (event.key === 'Enter') { event.preventDefault(); input.blur() } }
    })
  }
  function updateTransformFields(item: Item) {
    $('inspector').querySelectorAll<HTMLInputElement>('input[data-key]').forEach(input => {
      const key = input.dataset.key as 'position' | 'rotation' | 'scale'
      input.value = format(item[key][Number(input.dataset.axis)] * (key === 'rotation' ? degrees : 1))
    })
    const measured = document.getElementById('measured-size')
    if (measured) {
      const size = world.getBounds(item.id).getSize(new T.Vector3())
      measured.textContent = `${distance(size.x)} × ${distance(size.z)}`
    }
  }
  function commitTransform(repaint = true) {
    if (!change) return
    const { id, result, valid } = change
    change = undefined
    const item = find(id), object = world.get(id)
    if (!item || !object) return
    if (valid && JSON.stringify(item) !== JSON.stringify(result)) {
      record()
      Object.assign(item, result)
      persist()
    }
    applyItem(object, item)
    world.setInvalid(false)
    message('')
    if (!valid) notify('物件移出边界，已恢复上一次合法位置。', true)
    if (repaint) render()
    else {
      updateTransformFields(item)
      set('undo-btn', !history.length)
    }
  }

  function addItem(item: Item) {
    record()
    data.items.push(item)
    ids = [item.id]
    sync()
  }
  function initialScale() {
    return Math.min(plot.width, plot.depth) * .09
  }
  function availablePosition(bounds: T.Box3, origin: Vec, keepCenter = false) {
    if (bounds.isEmpty()) return undefined
    const size = bounds.getSize(new T.Vector3())
    const step = Math.max(Math.min(plot.width, plot.depth) * .065, .01)
    const dx = Math.max(step, size.x * 1.28)
    const dz = Math.max(step, size.z * 1.28)
    const options: Vec[] = [[dx, 0, 0], [-dx, 0, 0], [0, 0, dz], [0, 0, -dz], [dx, 0, dz], [-dx, 0, dz], [2 * dx, 0, 0], [0, 0, 0]]
    if (keepCenter) options.unshift([0, 0, 0])
    let fallback: Vec | undefined
    const occupied = data.items.map(item => world.getBounds(item.id)).filter(box => !box.isEmpty())
    for (const option of options) {
      const candidate = bounds.clone().translate(new T.Vector3(...option))
      if (!fits(candidate, plot)) continue
      const location = add(origin, option)
      fallback ??= location
      if (!occupied.some(box => box.intersectsBox(candidate))) return location
    }
    return fallback
  }
  function addPrimitive(kind: Primitive) {
    const item = newItem(kind, SHAPES[kind])
    item.color = { box: '#76a68a', cylinder: '#648d7e', sphere: '#e3b978' }[kind]
    const size = initialScale()
    item.scale = [size, size, size]
    item.position = [0, size / 2, 0]
    const bounds = new T.Box3(new T.Vector3(-size / 2, 0, -size / 2), new T.Vector3(size / 2, size, size / 2))
    item.position = availablePosition(bounds, item.position, true) ?? item.position
    addItem(item)
  }
  function duplicate() {
    const item = current()
    if (!item || walking || placing) return
    const copy = structuredClone(item)
    const location = availablePosition(world.getBounds(item.id), item.position)
    if (!location) { notify('模型还未加载完成，暂时无法复制。', true); return }
    copy.id = crypto.randomUUID()
    copy.name = `${item.name} 副本`
    copy.position = location
    addItem(copy)
  }
  function remove() {
    if (!ids.length || walking || placing) return
    record()
    data.items = data.items.filter(item => !ids.includes(item.id))
    ids = []
    sync()
  }
  function undo() {
    if (walking || placing) return
    const previous = history.pop()
    if (!previous) return
    data = previous
    ids = ids.filter(id => !!find(id))
    sync()
    notify('已撤销上一步。')
  }

  const groupDialog = $('group-dialog') as HTMLDialogElement
  function openGroup() {
    const input = $('group-name') as HTMLInputElement
    input.value = current()?.name ?? ''
    groupDialog.showModal()
    input.focus()
    input.select()
  }
  $('close-group').onclick = $('cancel-group').onclick = () => groupDialog.close()
  $('group-form').onsubmit = event => {
    event.preventDefault()
    const input = $('group-name') as HTMLInputElement
    const name = input.value.trim()
    if (!name) { input.focus(); return }
    const items = data.items.filter(item => ids.includes(item.id))
    if (!items.length || items.some(item => item.kind === 'glb')) return
    record()
    let group: Item
    if (items.length === 1 && items[0].kind === 'group') group = structuredClone(items[0])
    else {
      group = newItem('group', name)
      const bounds = items.reduce((acc, item) => acc.union(world.getBounds(item.id)), new T.Box3())
      const center = bounds.getCenter(new T.Vector3())
      group.position = [center.x, bounds.min.y, center.z]
      group.children = items.map(item => ({
        ...structuredClone(item),
        position: [item.position[0] - center.x, item.position[1] - bounds.min.y, item.position[2] - center.z],
      }))
    }
    group.name = name
    const template = structuredClone(group)
    template.id = crypto.randomUUID()
    template.position = [0, 0, 0]
    data.models.push(template)
    data.items = [...data.items.filter(item => !ids.includes(item.id)), group]
    ids = [group.id]
    groupDialog.close()
    sync()
    notify(`已保存「${name}」。`)
  }
  function placeModel(id: string) {
    const template = data.models.find(item => item.id === id)
    if (!template) return
    const item = structuredClone(template)
    item.id = crypto.randomUUID()
    const object = buildItem(item, () => {}, () => {})
    const box = boundsOf(object)
    object.traverse(node => { if (node instanceof T.Mesh && node.userData.ownMaterial) node.material.dispose() })
    const center = box.getCenter(new T.Vector3())
    item.position = [-center.x, -box.min.y, -center.z]
    box.translate(new T.Vector3(...item.position))
    const location = availablePosition(box, item.position)
    if (!location) { notify('该模型的水平占地无法放入当前地块。', true); return }
    item.position = location
    addItem(item)
  }

  const importDialog = $('import-dialog') as HTMLDialogElement
  const fileInput = $('import-file') as HTMLInputElement
  const scaleField = $('import-scale') as HTMLInputElement
  const groundField = $('ground-import') as HTMLInputElement
  $('import-btn').onclick = () => fileInput.click()
  $('close-import').onclick = $('cancel-import').onclick = () => importDialog.close()
  importDialog.onclose = () => {
    importPreview?.dispose()
    importPreview = undefined
    pendingImport = undefined
  }
  fileInput.onchange = async () => {
    const file = fileInput.files?.[0]
    fileInput.value = ''
    if (!file || walking || placing) return
    try {
      notify('正在读取模型…')
      const bytes = await file.arrayBuffer()
      const source = await parseGlb(bytes)
      if (closed) return
      const bounds = boundsOf(source), size = bounds.getSize(new T.Vector3())
      const max = Math.min(size.x > 0 ? plot.width / size.x : Infinity, size.z > 0 ? plot.depth / size.z : Infinity)
      const proposed = max < 1 ? max * .95 : 1
      pendingImport = { id: crypto.randomUUID(), name: file.name.replace(/\.glb$/i, ''), bytes, source, bounds, max, proposed }
      $('import-name').textContent = file.name
      scaleField.value = String(Number(proposed.toPrecision(8)))
      groundField.checked = true
      ;($('center-import') as HTMLInputElement).checked = true
      importDialog.showModal()
      importPreview = previewModel($('import-preview'), source, plot)
      refreshImport()
    } catch (error) {
      if (importDialog.open) importDialog.close()
      if (!closed) notify(error instanceof Error ? `导入失败。 ${error.message}` : '导入失败，请检查 GLB 文件。', true)
    }
  }
  function refreshImport() {
    if (!pendingImport) return
    const scale = scaleField.valueAsNumber
    const valid = Number.isFinite(scale) && scale > 0 && scale <= pendingImport.max
    const size = pendingImport.bounds.getSize(new T.Vector3())
    $('import-size').textContent = `原始尺寸 ${distance(size.x)} × ${distance(size.y)} × ${distance(size.z)}${valid ? `  ·  水平占地 ${distance(size.x * scale)} × ${distance(size.z * scale)}` : ''}`
    $('import-warning').textContent = valid
      ? (pendingImport.max < 1 ? '原始模型大于地块。当前预览已等比缩小，确认后放置。' : '')
      : '请填写大于零且能放入地块的缩放比例。'
    set('confirm-import', !valid)
    if (Number.isFinite(scale) && scale > 0) importPreview?.render(scale, groundField.checked, valid)
  }
  $('fit-import').onclick = () => {
    if (!pendingImport) return
    scaleField.value = String(pendingImport.proposed)
    refreshImport()
  }
  scaleField.oninput = groundField.onchange = refreshImport
  $('import-form').onsubmit = async event => {
    event.preventDefault()
    if (!pendingImport) return
    const imported = pendingImport
    const scale = scaleField.valueAsNumber
    if (!(scale > 0 && scale <= imported.max)) return
    const item = newItem('glb', imported.name || 'GLB 模型')
    item.asset = imported.id
    item.scale = [scale, scale, scale]
    item.position[1] = groundField.checked ? -imported.bounds.min.y * scale : 0
    const center = ($('center-import') as HTMLInputElement).checked
    set('confirm-import', true)
    try {
      await putAsset(imported.id, imported.bytes)
      if (closed || !importDialog.open) return
      rememberAsset(imported.id, imported.source)
      importDialog.close()
      if (center) {
        addItem(item)
        notify('GLB 已放到地块中心。')
      } else {
        placing = true
        world.beginPlacement(item, imported.source, position => {
          endPlacement()
          item.position = position
          addItem(item)
          notify('GLB 已放置。')
        })
        message('移动鼠标预览，点击放置 · Esc 取消')
        render()
      }
    } catch {
      if (!closed) {
        notify('浏览器无法保存此 GLB 文件。', true)
        refreshImport()
      }
    }
  }
  function endPlacement() {
    if (!placing) return
    placing = false
    world.endPlacement()
    message('')
    render()
  }
  function setWalk(value: boolean) {
    if (walking === value || placing) return
    walking = value
    world.setWalk(value)
    $('edit-mode').classList.toggle('active', !value)
    $('walk-mode').classList.toggle('active', value)
    $('edit-mode').setAttribute('aria-pressed', String(!value))
    $('walk-mode').setAttribute('aria-pressed', String(value))
    $('editor-status').textContent = value ? '行走模式 · Shift 加速' : '编辑模式'
    $('view-mode').textContent = value ? '行走视图' : '正交视图'
    $('view-hint').innerHTML = value ? `${icons.keyboard} WASD 或方向键移动 <b>·</b> Shift 加速` : `${icons.mouse} 右键旋转 <b>·</b> 中键平移 <b>·</b> 滚轮缩放`
    if (!value) {
      message('')
      $('editor-location').textContent = '米制坐标 · X 东 / Z 南'
    }
    render()
  }
  function setTool(next: typeof mode) {
    if (walking || placing) return
    mode = next
    world.setMode(next)
    root.querySelectorAll<HTMLButtonElement>('[data-mode]').forEach(control => {
      control.classList.toggle('active', control.dataset.mode === mode)
      control.setAttribute('aria-pressed', String(control.dataset.mode === mode))
    })
  }

  $('primitives').onclick = event => {
    const shape = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-shape]')?.dataset.shape as Primitive | undefined
    if (shape && !walking && !placing) addPrimitive(shape)
  }
  $('scene-list').onclick = event => {
    const id = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-item]')?.dataset.item
    if (id) select(id, event.shiftKey || event.ctrlKey || event.metaKey)
  }
  $('model-list').onclick = event => {
    const id = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-model]')?.dataset.model
    if (id && !walking && !placing) placeModel(id)
  }
  $('tool-buttons').onclick = event => {
    const next = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-mode]')?.dataset.mode as typeof mode | undefined
    if (next) setTool(next)
  }
  $('toggle-grid').onclick = () => {
    grid = !grid
    world.setGrid(grid)
    $('toggle-grid').classList.toggle('active', grid)
    $('toggle-grid').setAttribute('aria-pressed', String(grid))
  }
  $('toggle-snap').onclick = () => {
    snap = !snap
    world.setSnap(snap)
    $('toggle-snap').classList.toggle('active', snap)
    $('toggle-snap').setAttribute('aria-pressed', String(snap))
    notify(snap ? `网格吸附已开启 · ${distance(world.snapStep)}` : '网格吸附已关闭。')
  }
  $('fit-view').onclick = () => world.fit()
  $('edit-mode').onclick = () => setWalk(false)
  $('walk-mode').onclick = () => setWalk(true)
  $('undo-btn').onclick = undo
  $('duplicate-btn').onclick = duplicate
  $('delete-btn').onclick = remove
  window.addEventListener('keydown', event => {
    if (event.defaultPrevented || groupDialog.open || importDialog.open || (event.target as HTMLElement | null)?.closest('input,textarea,select')) return
    if (placing && event.key === 'Escape') { endPlacement(); return }
    if (walking || placing) return
    if ((event.ctrlKey || event.metaKey) && event.code === 'KeyZ') { event.preventDefault(); undo(); return }
    if ((event.ctrlKey || event.metaKey) && event.code === 'KeyD') { event.preventDefault(); duplicate(); return }
    if (event.ctrlKey || event.metaKey || event.altKey) return
    if (event.key === 'Delete') remove()
    if (event.key === 'Escape') select(undefined)
    if (event.code === 'KeyW') setTool('translate')
    if (event.code === 'KeyE') setTool('rotate')
    if (event.code === 'KeyR') setTool('scale')
  }, { signal: listeners.signal })

  world.sync(data.items)
  setTool(mode)
  render()
  return () => {
    closed = true
    listeners.abort()
    window.clearTimeout(toastTimer)
    importPreview?.dispose()
    world.dispose()
  }
}
