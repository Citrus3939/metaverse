import * as T from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
import { TransformControls } from 'three/addons/controls/TransformControls.js'
import { DRACOLoader, DRACO_GLTF_CONFIG } from 'three/addons/loaders/DRACOLoader.js'
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js'
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js'
import { clone } from 'three/addons/utils/SkeletonUtils.js'
import { getAsset, type Item, type Plot, type Primitive, type Vec } from './data'

const geometry: Record<Primitive, T.BufferGeometry> = {
  box: new T.BoxGeometry(1, 1, 1),
  cylinder: new T.CylinderGeometry(.5, .5, 1, 32),
  sphere: new T.SphereGeometry(.5, 32, 24),
}
const assets = new Map<string, Promise<T.Object3D>>()

export async function parseGlb(data: ArrayBuffer) {
  if (data.byteLength < 20) throw new Error('文件不是有效的 GLB。')
  const header = new DataView(data)
  if (header.getUint32(0, true) !== 0x46546c67 || header.getUint32(4, true) !== 2 || header.getUint32(8, true) !== data.byteLength || header.getUint32(16, true) !== 0x4e4f534a) {
    throw new Error('请选择有效的 GLB 2.0 文件。')
  }
  const json = JSON.parse(new TextDecoder().decode(new Uint8Array(data, 20, header.getUint32(12, true))))
  const resources: { uri?: string }[] = [...(json.buffers ?? []), ...(json.images ?? [])]
  if (resources.some(resource => resource.uri && !/^data:/i.test(resource.uri))) throw new Error('此 GLB 引用了外部资源，请重新导出为自包含文件。')
  const draco = new DRACOLoader().setDecoderPath(DRACO_GLTF_CONFIG)
  const loader = new GLTFLoader().setDRACOLoader(draco).setMeshoptDecoder(MeshoptDecoder)
  const result = await loader.parseAsync(data, '').finally(() => draco.dispose())
  const bounds = new T.Box3().setFromObject(result.scene, true)
  if (bounds.isEmpty() || ![...bounds.min, ...bounds.max].every(Number.isFinite)) throw new Error('GLB 中没有可显示的有效几何体。')
  const center = bounds.getCenter(new T.Vector3())
  const normalized = new T.Group()
  result.scene.position.sub(center)
  normalized.add(result.scene)
  normalized.updateMatrixWorld(true)
  return normalized
}

export function rememberAsset(id: string, object: T.Object3D) {
  assets.set(id, Promise.resolve(object))
}
async function asset(id: string) {
  let result = assets.get(id)
  if (!result) {
    result = getAsset(id).then(data => {
      if (!data) throw new Error('本地 GLB 文件缺失。')
      return parseGlb(data)
    })
    assets.set(id, result)
    result.catch(() => assets.delete(id))
  }
  return result
}

export function applyItem(object: T.Object3D, item: Item) {
  object.position.fromArray(item.position)
  object.rotation.set(...item.rotation)
  object.scale.fromArray(item.scale)
  if (item.color && object instanceof T.Mesh) object.material.color.set(item.color)
  object.updateWorldMatrix(true, true)
}

export function buildItem(item: Item, onLoaded: () => void, onError: (error: unknown) => void): T.Object3D {
  let object: T.Object3D
  if (item.kind === 'group') {
    object = new T.Group()
    object.add(...(item.children ?? []).map(child => buildItem(child, onLoaded, onError)))
  } else if (item.kind === 'glb') {
    const root = new T.Group()
    object = root
    void asset(item.asset!).then(source => {
      root.add(clone(source))
      onLoaded()
    }).catch(onError)
  } else {
    object = new T.Mesh(geometry[item.kind], new T.MeshStandardMaterial({ color: item.color ?? '#6ea98b', roughness: .82 }))
    object.userData.ownMaterial = true
  }
  object.userData.itemId = item.id
  applyItem(object, item)
  return object
}

export function boundsOf(object: T.Object3D) {
  return new T.Box3().setFromObject(object, true)
}
export function fits(bounds: T.Box3, plot: Plot) {
  const tolerance = 1e-6
  return !bounds.isEmpty() && bounds.min.x >= -plot.width / 2 - tolerance && bounds.max.x <= plot.width / 2 + tolerance
    && bounds.min.z >= -plot.depth / 2 - tolerance && bounds.max.z <= plot.depth / 2 + tolerance
}

function avatar(scale: number) {
  const root = new T.Group()
  const white = new T.MeshStandardMaterial({ color: '#ffffff' })
  const gray = new T.MeshStandardMaterial({ color: '#738780' })
  const torso = new T.Mesh(new T.CapsuleGeometry(.22, .45, 6, 12), white)
  torso.position.y = 1.16
  const head = new T.Mesh(new T.SphereGeometry(.218, 20, 12), white)
  head.position.y = 1.74
  root.add(torso, head)
  for (const x of [-.078, .078]) {
    const eye = new T.Mesh(new T.SphereGeometry(.026, 9, 8), gray)
    eye.position.set(x, 1.77, .2)
    root.add(eye)
  }
  const legs = [-.135, .135].map(x => {
    const joint = new T.Group()
    joint.position.set(x, .8, 0)
    const leg = new T.Mesh(new T.CapsuleGeometry(.09, .46, 5, 10), white)
    leg.position.y = -.33
    const foot = new T.Mesh(new T.BoxGeometry(.18, .119, .27), gray)
    foot.position.set(0, -.74, .055)
    joint.add(leg, foot)
    root.add(joint)
    return joint
  })
  for (const x of [-.3, .3]) {
    const arm = new T.Mesh(new T.CapsuleGeometry(.078, .36, 5, 10), white)
    arm.position.set(x, 1.13, 0)
    arm.rotation.z = Math.sign(x) * .13
    root.add(arm)
  }
  const circle = new T.Mesh(new T.RingGeometry(.31, .35, 32), new T.MeshBasicMaterial({ color: '#4a8768', side: T.DoubleSide }))
  circle.rotation.x = -Math.PI / 2
  circle.position.y = .012
  root.add(circle)
  root.scale.setScalar(scale)
  return { root, legs }
}

const MOVEMENT = new Set(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowLeft', 'ArrowDown', 'ArrowRight', 'ShiftLeft', 'ShiftRight'])

type WorldCallbacks = {
  select: (id: string | undefined, multiple: boolean) => void
  preview: (id: string, values: Pick<Item, 'position' | 'rotation' | 'scale'>, valid: boolean) => void
  commit: (id: string) => void
  loaded: () => void
  error: (message: string) => void
  walking: (position: T.Vector3, atEdge: boolean) => void
}

export class World {
  private renderer: T.WebGLRenderer
  private scene = new T.Scene()
  private camera = new T.OrthographicCamera(-1, 1, 1, -1, .001, 1000)
  private orbit: OrbitControls
  private transform: TransformControls
  private boundary: T.LineLoop
  private groundGrid: T.LineSegments
  private models = new T.Group()
  private items = new Map<string, T.Object3D>()
  private selected: string[] = []
  private selectionBox = new T.Box3()
  private outlineDirty = true
  private outline = new T.Box3Helper(this.selectionBox, '#3b8c62')
  private player
  private playerScale
  private keys = new Set<string>()
  private frame = 0
  private time = 0
  private fitSize = 1
  private frustum = 1
  private observer: ResizeObserver
  private listeners = new AbortController()
  private walk = false
  private placement?: { object: T.Object3D; confirm: (position: Vec) => void }
  private ray = new T.Raycaster()
  private direct?: { id: string; x: number; y: number; offset: T.Vector3; pickY: number; moved: boolean }
  private startClick?: { x: number; y: number }
  private savedView?: { camera: T.Vector3; target: T.Vector3; zoom: number }
  private size: number

  constructor(private host: HTMLElement, readonly plot: Plot, private callbacks: WorldCallbacks) {
    this.renderer = new T.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' })
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
    this.renderer.setClearColor(0x000000, 0)
    host.append(this.renderer.domElement)
    this.renderer.domElement.setAttribute('aria-label', '3D 地块视口')
    this.size = Math.max(plot.width, plot.depth)
    this.playerScale = Math.min(1, Math.min(plot.width, plot.depth) / 2.6)
    this.player = avatar(this.playerScale)
    this.player.root.visible = false
    this.scene.add(this.player.root, this.models)
    this.scene.add(new T.HemisphereLight('#fffdf3', '#9aaea0', 2.15))
    const sun = new T.DirectionalLight('#fff6d8', 2.1)
    sun.position.set(4, 9, 5)
    this.scene.add(sun)
    const depth = Math.min(plot.width, plot.depth) * .05
    const base = new T.Mesh(
      new T.BoxGeometry(plot.width, depth, plot.depth),
      new T.MeshStandardMaterial({ color: '#a1bb9f', roughness: 1 }),
    )
    base.position.y = -depth / 2
    this.scene.add(base)

    const x = plot.width / 2, z = plot.depth / 2, lineY = Math.min(x, z) * .00055
    const vertices = [new T.Vector3(-x, lineY, -z), new T.Vector3(x, lineY, -z), new T.Vector3(x, lineY, z), new T.Vector3(-x, lineY, z)]
    this.boundary = new T.LineLoop(new T.BufferGeometry().setFromPoints(vertices), new T.LineBasicMaterial({ color: '#285b45' }))
    this.scene.add(this.boundary)
    const corners = new T.Points(new T.BufferGeometry().setFromPoints(vertices), new T.PointsMaterial({ color: '#285b45', size: 6, sizeAttenuation: false }))
    this.scene.add(corners)
    const step = this.snapStep
    const gridPoints: number[] = []
    const visibleStep = Math.max(step, Math.ceil(this.size / step / 140) * step)
    for (let i = -Math.floor(x / visibleStep); i <= Math.floor(x / visibleStep); i++) gridPoints.push(i * visibleStep, lineY, -z, i * visibleStep, lineY, z)
    for (let i = -Math.floor(z / visibleStep); i <= Math.floor(z / visibleStep); i++) gridPoints.push(-x, lineY, i * visibleStep, x, lineY, i * visibleStep)
    const grid = new T.BufferGeometry().setAttribute('position', new T.Float32BufferAttribute(gridPoints, 3))
    this.groundGrid = new T.LineSegments(grid, new T.LineBasicMaterial({ color: '#567160', transparent: true, opacity: .33 }))
    this.scene.add(this.groundGrid)

    this.outline.visible = false
    this.scene.add(this.outline)
    const canvas = this.renderer.domElement
    this.orbit = new OrbitControls(this.camera, canvas)
    this.orbit.enableDamping = true
    this.orbit.maxPolarAngle = Math.PI * .49
    this.orbit.mouseButtons = { LEFT: null, MIDDLE: T.MOUSE.PAN, RIGHT: T.MOUSE.ROTATE }
    this.orbit.minZoom = .06
    this.orbit.maxZoom = Math.max(60, this.size / Math.max(.05, this.playerScale))
    this.transform = new TransformControls(this.camera, canvas)
    this.transform.setSize(.82)
    this.transform.setSpace('local')
    this.scene.add(this.transform.getHelper())
    this.transform.addEventListener('dragging-changed', event => { this.orbit.enabled = !event.value })
    this.transform.addEventListener('objectChange', () => { if (this.activeId) this.publishPreview(this.activeId) })
    this.transform.addEventListener('mouseUp', () => { if (this.activeId) this.callbacks.commit(this.activeId) })

    const { signal } = this.listeners
    canvas.addEventListener('contextmenu', event => event.preventDefault(), { signal })
    canvas.addEventListener('pointerdown', this.pointerDown, { signal })
    canvas.addEventListener('pointermove', this.pointerMove, { signal })
    canvas.addEventListener('pointerup', this.pointerUp, { signal })
    canvas.addEventListener('pointercancel', this.cancelPointer, { signal })
    window.addEventListener('keydown', this.keyDown, { signal })
    window.addEventListener('keyup', this.keyUp, { signal })
    window.addEventListener('blur', () => this.keys.clear(), { signal })

    this.resize()
    this.observer = new ResizeObserver(() => this.resize())
    this.observer.observe(host)
    this.fit()
    this.frame = requestAnimationFrame(this.tick)
  }

  get snapStep() {
    const target = Math.min(this.plot.width, this.plot.depth) / 12
    const order = 10 ** Math.floor(Math.log10(target))
    return target / order >= 5 ? order * 5 : target / order >= 2 ? order * 2 : order
  }
  private get activeId() { return this.selected.length === 1 ? this.selected[0] : undefined }

  private resize() {
    const width = Math.max(1, this.host.clientWidth), height = Math.max(1, this.host.clientHeight)
    this.renderer.setSize(width, height)
    const aspect = width / height
    this.camera.left = -this.frustum * aspect / 2
    this.camera.right = -this.camera.left
    this.camera.top = this.frustum / 2
    this.camera.bottom = -this.camera.top
    this.camera.updateProjectionMatrix()
  }

  fit() {
    this.camera.position.set(.9, .86, 1.12).multiplyScalar(this.size * 2)
    this.camera.near = Math.max(.00001, this.size * .000002)
    this.camera.far = this.size * 28
    this.camera.zoom = 1
    this.orbit.target.set(0, 0, 0)
    this.orbit.update()
    this.camera.updateMatrixWorld(true)
    const v = new T.Vector3()
    let horizontal = 0, vertical = 0
    for (const x of [-this.plot.width / 2, this.plot.width / 2]) {
      for (const z of [-this.plot.depth / 2, this.plot.depth / 2]) {
        for (const y of [-Math.min(this.plot.width, this.plot.depth) * .05, 0]) {
          v.set(x, y, z).applyMatrix4(this.camera.matrixWorldInverse)
          horizontal = Math.max(horizontal, Math.abs(v.x))
          vertical = Math.max(vertical, Math.abs(v.y))
        }
      }
    }
    const aspect = Math.max(.25, this.host.clientWidth / Math.max(1, this.host.clientHeight))
    this.frustum = 2.65 * Math.max(vertical, horizontal / aspect)
    this.fitSize = this.frustum
    this.resize()
  }

  sync(items: Item[]) {
    this.transform.detach()
    for (const object of this.items.values()) {
      object.traverse(node => { if (node.userData.ownMaterial && node instanceof T.Mesh) node.material.dispose() })
    }
    this.items.clear()
    this.models.clear()
    for (const item of items) {
      const object = buildItem(item, () => { this.outlineDirty = true; this.callbacks.loaded() }, () => this.callbacks.error('有一个 GLB 无法从本地存档读取。'))
      this.items.set(item.id, object)
      this.models.add(object)
    }
    this.select(this.selected)
  }
  select(ids: string[]) {
    this.selected = ids
    const active = this.activeId ? this.items.get(this.activeId) : undefined
    if (active && !this.walk) this.transform.attach(active)
    else this.transform.detach()
    this.setInvalid(false)
  }
  get(id: string) { return this.items.get(id) }
  getBounds(id: string) {
    const object = this.get(id)
    return object ? boundsOf(object) : new T.Box3()
  }
  setGrid(enabled: boolean) { this.groundGrid.visible = enabled }
  setMode(mode: 'translate' | 'rotate' | 'scale') { this.transform.setMode(mode) }
  setSnap(enabled: boolean) {
    this.transform.setTranslationSnap(enabled ? this.snapStep : null)
    this.transform.setRotationSnap(enabled ? Math.PI / 12 : null)
    this.transform.setScaleSnap(enabled ? .1 : null)
  }
  setInvalid(invalid: boolean) {
    this.outlineDirty = true
    const color = invalid ? '#e34b4b' : '#3b8c62'
    ;(this.outline.material as T.LineBasicMaterial).color.set(color)
    ;(this.boundary.material as T.LineBasicMaterial).color.set(invalid ? '#e34b4b' : '#285b45')
    this.host.classList.toggle('invalid', invalid)
  }

  setWalk(enabled: boolean) {
    this.walk = enabled
    this.keys.clear()
    this.player.root.visible = enabled
    if (enabled) {
      this.transform.detach()
      this.setInvalid(false)
      this.savedView = { camera: this.camera.position.clone(), target: this.orbit.target.clone(), zoom: this.camera.zoom }
      this.camera.position.add(this.player.root.position.clone().sub(this.orbit.target))
      this.orbit.target.copy(this.player.root.position)
      this.camera.zoom = Math.max(1, this.fitSize / (this.playerScale * 15))
      this.camera.updateProjectionMatrix()
      this.callbacks.walking(this.player.root.position, false)
    } else if (this.savedView) {
      this.camera.position.copy(this.savedView.camera)
      this.orbit.target.copy(this.savedView.target)
      this.camera.zoom = this.savedView.zoom
      this.camera.updateProjectionMatrix()
      this.select(this.selected)
    }
    this.orbit.update()
  }

  private tick = (now: number) => {
    const dt = this.time ? Math.min(.04, (now - this.time) / 1000) : 0
    this.time = now
    if (this.walk) this.stepPlayer(dt, now)
    this.orbit.update()
    if (this.outlineDirty) {
      this.selectionBox.makeEmpty()
      if (this.placement) this.selectionBox.copy(boundsOf(this.placement.object))
      else if (!this.walk) this.selected.forEach(id => this.selectionBox.union(this.getBounds(id)))
      this.outline.visible = !this.selectionBox.isEmpty()
      this.outlineDirty = false
    }
    this.renderer.render(this.scene, this.camera)
    this.frame = requestAnimationFrame(this.tick)
  }

  private keyDown = (event: KeyboardEvent) => {
    if (!this.walk || !MOVEMENT.has(event.code) || (event.target as HTMLElement | null)?.closest('input,textarea,select,dialog')) return
    this.keys.add(event.code)
    event.preventDefault()
  }
  private keyUp = (event: KeyboardEvent) => { this.keys.delete(event.code) }

  private stepPlayer(dt: number, now: number) {
    const held = (primary: string, alternate: string) => Number(this.keys.has(primary) || this.keys.has(alternate))
    const forward = held('KeyW', 'ArrowUp') - held('KeyS', 'ArrowDown')
    const side = held('KeyD', 'ArrowRight') - held('KeyA', 'ArrowLeft')
    if (!forward && !side) return
    const front = new T.Vector3()
    this.camera.getWorldDirection(front)
    front.y = 0
    front.normalize()
    const right = new T.Vector3(-front.z, 0, front.x)
    const direction = front.multiplyScalar(forward).addScaledVector(right, side).normalize()
    const speed = (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') ? 10 : 4.2) * this.playerScale
    const step = direction.multiplyScalar(speed * dt)
    const { position } = this.player.root
    const limitX = this.plot.width / 2 - .38 * this.playerScale
    const limitZ = this.plot.depth / 2 - .38 * this.playerScale
    const x = T.MathUtils.clamp(position.x + step.x, -limitX, limitX)
    const z = T.MathUtils.clamp(position.z + step.z, -limitZ, limitZ)
    const atEdge = Math.abs(x - position.x - step.x) > 1e-7 || Math.abs(z - position.z - step.z) > 1e-7
    const delta = new T.Vector3(x - position.x, 0, z - position.z)
    position.add(delta)
    this.camera.position.add(delta)
    this.orbit.target.add(delta)
    this.player.root.rotation.y = Math.atan2(step.x, step.z)
    this.player.legs.forEach((leg, index) => { leg.rotation.x = Math.sin(now / 73) * (index ? 1 : -1) * (delta.lengthSq() > 1e-8 ? .4 : 0) })
    this.callbacks.walking(position, atEdge)
  }

  private useRay(event: PointerEvent) {
    const rect = this.renderer.domElement.getBoundingClientRect()
    this.ray.setFromCamera(new T.Vector2((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1), this.camera)
  }
  private pointerDown = (event: PointerEvent) => {
    if (event.button !== 0 || this.walk || this.transform.dragging) return
    if (this.placement) {
      this.updatePlacement(event)
      const { object, confirm } = this.placement
      if (fits(boundsOf(object), this.plot)) confirm(object.position.toArray())
      return
    }
    this.startClick = { x: event.clientX, y: event.clientY }
    this.useRay(event)
    const hits = this.ray.intersectObjects(this.models.children, true)
    if (!hits.length) return
    let target: T.Object3D = hits[0].object
    while (target.parent && target.parent !== this.models) target = target.parent
    const id: string = target.userData.itemId
    this.callbacks.select(id, event.shiftKey)
    this.startClick = undefined
    if (event.shiftKey || this.transform.mode !== 'translate') return
    this.direct = { id, x: event.clientX, y: event.clientY, pickY: hits[0].point.y, offset: target.position.clone().sub(hits[0].point), moved: false }
    this.renderer.domElement.setPointerCapture(event.pointerId)
  }
  private pointerMove = (event: PointerEvent) => {
    if (this.placement) { this.updatePlacement(event); return }
    const drag = this.direct
    if (!drag) return
    if (!drag.moved && Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < 3) return
    const object = this.get(drag.id)
    if (!object) return
    this.useRay(event)
    const point = this.ray.ray.intersectPlane(new T.Plane(new T.Vector3(0, 1, 0), -drag.pickY), new T.Vector3())
    if (!point) return
    drag.moved = true
    const snap = this.transform.translationSnap
    object.position.x = snap ? Math.round((point.x + drag.offset.x) / snap) * snap : point.x + drag.offset.x
    object.position.z = snap ? Math.round((point.z + drag.offset.z) / snap) * snap : point.z + drag.offset.z
    this.publishPreview(drag.id)
  }
  private pointerUp = (event: PointerEvent) => {
    if (event.button !== 0) return
    const drag = this.direct
    this.direct = undefined
    if (drag?.moved) this.callbacks.commit(drag.id)
    if (this.startClick && !this.walk && Math.hypot(event.clientX - this.startClick.x, event.clientY - this.startClick.y) < 4) this.callbacks.select(undefined, false)
    this.startClick = undefined
  }
  private cancelPointer = () => {
    if (this.direct) this.callbacks.commit(this.direct.id)
    this.direct = this.startClick = undefined
  }

  beginPlacement(item: Item, source: T.Object3D, confirm: (position: Vec) => void) {
    this.endPlacement()
    this.transform.detach()
    const object = new T.Group()
    object.add(clone(source))
    applyItem(object, item)
    this.scene.add(object)
    this.placement = { object, confirm }
    this.outlineDirty = true
    this.host.classList.add('placing')
  }
  endPlacement() {
    if (this.placement) this.scene.remove(this.placement.object)
    this.placement = undefined
    this.host.classList.remove('placing')
    this.select(this.selected)
  }
  private updatePlacement(event: PointerEvent) {
    if (!this.placement) return
    this.useRay(event)
    const point = this.ray.ray.intersectPlane(new T.Plane(new T.Vector3(0, 1, 0), 0), new T.Vector3())
    if (!point) return
    const object = this.placement.object
    const snap = this.transform.translationSnap
    object.position.x = snap ? Math.round(point.x / snap) * snap : point.x
    object.position.z = snap ? Math.round(point.z / snap) * snap : point.z
    this.setInvalid(!fits(boundsOf(object), this.plot))
  }

  private publishPreview(id: string) {
    const object = this.get(id)
    if (!object) return
    const valid = fits(boundsOf(object), this.plot) && object.scale.toArray().every(value => Number.isFinite(value) && value > 0)
    this.setInvalid(!valid)
    this.callbacks.preview(id, {
      position: object.position.toArray(),
      rotation: [object.rotation.x, object.rotation.y, object.rotation.z],
      scale: object.scale.toArray() as Vec,
    }, valid)
  }

  dispose() {
    cancelAnimationFrame(this.frame)
    this.listeners.abort()
    this.observer.disconnect()
    this.transform.dispose()
    this.orbit.dispose()
    this.endPlacement()
    this.models.traverse(object => {
      if (object instanceof T.Mesh && object.userData.ownMaterial) object.material.dispose()
    })
    const release = (object: T.Object3D) => {
      if (object === this.models) return
      if (object instanceof T.Mesh || object instanceof T.Line || object instanceof T.Points) {
        object.geometry.dispose()
        object.material.dispose()
      }
      object.children.forEach(release)
    }
    this.scene.children.filter(child => child !== this.transform.getHelper()).forEach(release)
    this.renderer.dispose()
    this.renderer.domElement.remove()
  }
}
