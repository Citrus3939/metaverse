import { clipboardEntry,copyEntry,type WorkspaceMode, type WorkbenchView } from './workbench'
import { mountEstate } from './estate-panel'
import { estateModel } from './estate-models'
import { catalog, blueprints, type Site, type EstateView, type Building } from './estate'
import * as T from 'three'
import { $, button, escapeHtml, icons } from './ui'
import { assetStorageKey, area, distance, EMPTY, getAsset, newId, newItem, putAsset, SHAPES, type CharacterSkin, type Item, type Primitive, type Save, type SceneData, type Vec } from './data'
import { applyItem, boundsOf, buildItem, fits, parseCharacter, parseGlb, prepareItemAssets, rememberAsset, setAssetProvider, World } from './world'
import roadEntries from './street-assets.json'
import { freeAssetIds, libraryMarkup, mountStreetLibrary } from './street-library'
import { previewModel } from './import-preview'
import { blockCharacter } from './character'
import { roleNames, type RoomClient } from './room'
import { plotKey,parseCell,neighborsOf,cellKey,plotForCell,type Plot } from './plot-grid'
import { loadSkin, skinCharacter } from './npc'
import { mountCharacterEditor } from './npc-panel'
import { mountNpcDialogue } from './npc-dialogue'
import { memberList } from './region-controls'
import { landAvailability,claimState,type LandReceipt,type RegionClient } from './region'
import { RoomDraft, type SaveStatus } from './room-draft'
import { sceneChanges, type SceneChange, type PresenceUpdate, type RegionView, type Role, type RoomView } from './collab-types'

const names = { ...SHAPES, group: '组合模型', glb: 'GLB 模型', npc: '方块人 NPC' }
const shapeIcons = { box: icons.box, sphere: icons.circle, cylinder: icons.cylinder, group: icons.group, glb: icons.package, npc: icons.person }
const modes = { translate: { name: '移动', icon: icons.move }, rotate: { name: '旋转', icon: icons.rotate }, scale: { name: '缩放', icon: icons.scaling } }
const axes = ['X', 'Y', 'Z']
const format = (n: number) => Number(n.toFixed(5)).toString()
const degrees = 180 / Math.PI
const add = (a: Vec, b: Vec): Vec => [a[0] + b[0], a[1] + b[1], a[2] + b[2]]

type RoomOptions = {
  claim:(plot:Plot,price:number)=>Promise<void>;receipt?:LandReceipt
  firstEstate?:Promise<EstateView|undefined>
  needsClaim?:boolean
  onRegion?:(view:RegionView)=>void
  client?: RoomClient; sharePlot: (entry?:'room'|'estate'|'shelf'|'claim') => Promise<void>
  region?: RegionClient; overview?: () => void; openCurrentEstate?:boolean; localNeighbors?:Save[]; view?:WorkbenchView; editCell?: (cell: string,view?:WorkbenchView,openEstate?:boolean) => void; guest?: boolean
}

export function editorPage(root: HTMLElement, initial: Save, onSave: (value: Save) => void, options: RoomOptions) {
  const plot = initial.plot
  const tile = plotKey(plot)
  const region = options.region
  let shops:Building[]=[]
  let regionView = region?.latest
  let stopRegion: (() => void) | undefined
  let data: SceneData = structuredClone(initial.scene)
  let ids: string[] = []
  let workspaceMode:WorkspaceMode='view'
  let selectedBusiness:string|undefined
  let walking = false
  let observing = false
  let modeChanging = false
  let room = options.client
  let role: Role = room?.latest?.role ?? 'owner'
  let connected = true
  let sharing = false
  let unsubscribe: (() => void) | undefined
  let roomDraft: RoomDraft | undefined
  let saveStatus: SaveStatus = { pending: 0, sending: false, error: '', conflict: false, durable: true }
  let leveling = false
  const canEdit = () => workspaceMode==='edit' && role !== 'view' && connected && !sharing && !walking && !observing && !modeChanging
  const holdingEdit = () => world.interacting || !!change || !!$('inspector').contains(document.activeElement)
  setAssetProvider(room ? (id, kind) => room!.downloadAsset(id, kind) : undefined)
  let grid = localStorage.getItem('fangcun.show-build-grid') === 'true'
  let snap = localStorage.getItem('fangcun.snap')!=='off'
  let placing = false
  let closed = false
  let change: { id: string; result: Item; valid: boolean } | undefined
  let mode: keyof typeof modes = 'translate'
  type Stroke = {snapshot:SceneData; remote:{room:RoomClient;inverse:SceneChange[]}[]}
  const history: (SceneData | Stroke | {building:string;before:Site;after:Site})[] = []
  let toastTimer = 0
  const listeners = new AbortController()
  root.innerHTML = `
    <div class="editor-head">
      <div class="editor-title"><div class="editor-title-icon">${icons.box}</div><div><h1>${regionView ? escapeHtml(regionView.name) : options.guest ? '受邀地块' : options.needsClaim?'地块预览':'本地存档'}</h1><p>${distance(plot.width)} × ${distance(plot.depth)} <span>·</span> ${area(plot.width * plot.depth)} <span>·</span> 编辑格 ${plotKey(plot)}</p></div></div>
      <div class="editor-head-actions">
      ${region ? `<button class="secondary" id="editor-region-overview">${icons.map} 区域总览</button>` : ''}
      ${region ? '<button class="secondary" id="edit-current-cell" hidden>编辑当前格</button>' : ''}
      <button class="secondary" id="room-btn">${icons.group} <span>${region ? '连接中…' : '共享此格'}</span></button>
      ${region ? '<button class="secondary" id="chat-entry">街坊频道</button>' : ''}
      <div class="mode-toggle" aria-label="工作模式">
        <button class="active" id="edit-mode" aria-pressed="true">${icons.cursor} 编辑模式</button>
        <button id="view-mode-btn" aria-pressed="true">${icons.map} 观看</button>
        <button id="observe-mode" aria-pressed="false">${icons.compass} 拍照</button>
      </div>
      </div>
    </div>
    <div class="editor-body">
      <aside class="editor-sidebar editor-assets">
        <div class="eyebrow">建造</div>
        ${!options.guest?`<section class="claim-panel"><strong id="claim-heading"></strong><p id="claim-receipt" role="status"></p><button class="secondary full" id="expand-land" hidden>继续扩张 · 选择相邻格</button><div id="claim-directions" hidden></div><p id="claim-info" aria-live="polite"></p><button class="primary full" id="claim-plot" hidden>查询中…</button></section>`:''}
        <button class="primary full" id="open-library">${icons.layers} 素材库</button>
        <button class="secondary full estate-entry" id="estate-open" ${options.guest?'hidden':''}>${icons.globe} 街坊经营</button>
        <label>地图像素色 <input type="color" id="plot-pixel" aria-label="地图像素色"></label>
        <details class="street-tools"><summary>街坊边界道路</summary><p>每段 50 米，两侧街坊各占 5 米。西、北边由相邻格管理。</p><div><button class="secondary" id="street-east"></button><button class="secondary" id="street-south"></button></div></details>
        <h2>添加形状</h2>
        <div class="shape-list" id="primitives">${(Object.keys(SHAPES) as Primitive[]).map(kind => `<button class="shape" data-shape="${kind}"><span>${shapeIcons[kind]}</span>${SHAPES[kind]}</button>`).join('')}</div>
        <button class="secondary full" id="import-btn">${icons.upload} 导入 GLB</button>
        <input type="file" id="import-file" accept=".glb,model/gltf-binary" hidden>
        <button class="secondary full" id="create-character">${icons.person} 创建人物</button>
        <div class="editor-rule"></div>
        <div class="subheading"><h2>场景物件</h2><small id="object-count"></small></div>
        <div id="scene-list" class="item-list"></div>
        <div class="editor-rule"></div>
        <div class="subheading"><h2>我的模型</h2><small id="model-count"></small></div>
        <div id="model-list" class="item-list"></div>
      </aside>
      <section class="viewport" id="viewport" aria-label="地块编辑器">
        <div class="view-top">
          <div class="view-chip"><i></i><span id="view-mode">正交视图</span></div>
          <div class="photo-tools"><button id="street-framing" hidden>街景取景</button><select id="photo-atmosphere" aria-label="观赏环境" hidden><option value="dawn">晨光摄影棚</option><option value="dusk">暮色摄影棚</option><option value="map">真实地图</option></select><button id="photo-export">拍照 PNG</button></div>
          <div class="view-buttons">${button('grid', '辅助网格', 'toggle-grid')}${button('magnet', '网格吸附', 'toggle-snap')}${button('focus', '整块地取景', 'fit-view')}</div>
        </div>
        <div class="view-message" id="view-message" aria-live="polite"></div>
        <button class="npc-prompt" id="npc-interact" hidden><kbd>E</kbd> <span></span></button>
        <div class="view-bottom">
          <div class="axis-mark" aria-label="X 向东，Z 向南">
            <svg viewBox="0 0 62 58" aria-hidden="true">
              <path d="M29 35 48 44" stroke="#ba6d61"/><path d="M29 35 12 46" stroke="#7298b5"/><path d="M29 35V13" stroke="#4d8d6d"/>
              <circle cx="29" cy="35" r="3" fill="#677c70"/>
              <text x="51" y="49" fill="#a35246">X</text><text x="3" y="52" fill="#527a99">Z</text><text x="25" y="10" fill="#3e785a">Y</text>
            </svg>
          </div>
          <span id="map-context-source" class="map-context-source">周边地面</span>
          <div class="view-hint" id="view-hint">${icons.mouse} 右键旋转 <b>·</b> 中键平移 <b>·</b> 滚轮缩放</div>
        </div>
        <div id="toast" class="toast" role="status"></div>
      </section>
      <aside class="editor-sidebar editor-properties">
        <div class="eyebrow">编辑</div>
        <h2>属性面板</h2>
        <div class="edit-tools" id="tool-buttons">${(Object.keys(modes) as (keyof typeof modes)[]).map(key => `<button data-mode="${key}" class="tool-button${key === mode ? ' active' : ''}" title="${modes[key].name}">${modes[key].icon}<span>${modes[key].name}</span></button>`).join('')}</div>
        <div class="inspector" id="inspector"></div>
      </aside>
    </div>
    <footer class="editor-footer"><div class="footer-left">${icons.layers}<span id="editor-status">编辑模式</span><span id="save-status" role="status" hidden></span><button class="subtle" id="retry-save" hidden>重试保存</button><button class="subtle" id="resolve-save" hidden>保存我的冲突修改</button></div><div class="footer-tools">${button('undo', '撤销 (Ctrl+Z)', 'undo-btn')}${button('copy', '复制 (Ctrl+C)', 'duplicate-btn')}${button('trash', '删除 (Delete)', 'delete-btn')}</div><div class="footer-right">${icons.keyboard}<span id="editor-location">米制坐标 · X 东 / Z 南</span></div></footer>
    ${libraryMarkup}
    <dialog id="group-dialog" class="app-dialog">
      <form id="group-form">
        <div class="dialog-heading"><span class="dialog-icon">${icons.group}</span><div><h2>组合模型</h2><p>组合基础形状和 GLB，保留各部件。</p></div>${button('close', '关闭', 'close-group')}</div>
        <label class="field-label" for="group-name">模型名称</label>
        <input id="group-name" class="text-field" type="text" maxlength="60" required autocomplete="off" placeholder="例如：我的路灯">
        <label class="import-options"><input type="checkbox" id="group-library" checked> 保存到我的模型</label>
        <div class="dialog-actions"><button type="button" class="secondary" id="cancel-group">取消</button><button class="primary" id="submit-group" type="submit">确认组合 ${icons.check}</button></div>
      </form>
    </dialog>
    <dialog id="import-dialog" class="app-dialog import-dialog">
      <form id="import-form">
        <div class="dialog-heading"><span class="dialog-icon">${icons.upload}</span><div><h2>预览导入模型</h2><p id="import-name"></p></div>${button('close', '关闭', 'close-import')}</div>
        <div id="import-preview" class="import-preview" aria-label="GLB 三维预览"></div>
        <div class="import-size" id="import-size"></div>
        <div class="import-warning" id="import-warning" aria-live="polite"></div>
        <label class="field-label" for="import-scale">等比缩放</label>
        <div class="scale-row"><input id="import-scale" class="text-field" type="number" min="0" step="any" value="1"><button type="button" id="fit-import" class="secondary">适应地块</button></div>
        <div class="import-options"><label><input id="ground-import" type="checkbox" checked> 底部贴地</label><label><input id="center-import" type="checkbox" checked> 放到地块中心</label></div>
        <div class="dialog-actions"><button type="button" class="secondary" id="cancel-import">取消</button><button class="primary" id="confirm-import" type="submit">确认放置 ${icons.arrow}</button></div>
      </form>
    </dialog>
    <dialog id="room-dialog" class="app-dialog">
      <div class="dialog-heading"><span class="dialog-icon">${icons.group}</span><div><h2>${region ? '共建状态' : '地块共建'}</h2><p id="room-info"></p></div>${button('close', '关闭', 'close-room')}</div>
      <ul id="editor-member-list" class="members-list" ${region ? '' : 'hidden'}></ul>
      ${region ? '' : `<label class="field-label" for="builder-name">建造昵称</label><input id="builder-name" class="text-field" maxlength="24" autocomplete="off" placeholder="显示在已公开的编辑记录中">`}
      <div id="room-owner">
        <label class="setting-row"><input type="checkbox" id="room-listing"> 在大地图显示编辑记录</label>
        ${region ? '<label class="setting-row"><input type="checkbox" id="room-cell-write"> 允许其他共建成员编辑此格</label>' : ''}
        <div id="room-local-invite" ${region ? 'hidden' : ''}>
        <div class="room-options">
          <button class="secondary" id="invite-view">${icons.compass} 允许进入</button>
          <button class="primary" id="invite-edit">${icons.move} 允许编辑</button>
        </div>
        <div id="room-link-row" class="scale-row" hidden><input class="text-field" id="room-link" aria-label="邀请链接" readonly><button type="button" class="secondary" id="room-copy">复制</button></div>
        <button class="subtle" id="room-revoke">撤销所有访客编辑权限</button>
        </div>
      </div>
      <div id="room-error" class="import-warning" aria-live="polite"></div>
    </dialog>
    <dialog id="part-dialog" class="app-dialog">
      <form id="part-form">
        <div class="dialog-heading"><span class="dialog-icon">${icons.group}</span><div><h2>编辑组合部件</h2><p>数值沿用组合的局部坐标。</p></div>${button('close', '关闭', 'close-part')}</div>
        <label class="field-label" for="part-picker">选择部件</label>
        <select class="text-field" id="part-picker"></select>
        <div id="part-fields"></div>
        <div class="dialog-actions"><button class="primary" type="submit">应用修改 ${icons.check}</button></div>
      </form>
    </dialog>`

  $('viewport').classList.toggle('unclaimed',!!options.needsClaim)
  const world = new World($('viewport'), plot, {
    select: (id, multiple) => {
      const item=id && find(id)
      if(workspaceMode==='view' && item && item.kind==='npc')npcChat.open(item,room)
      else select(id,multiple)
    },
    business: id=>{const b=shops.find(v=>v.id===id);if(!b||!canEdit())return;select(undefined);selectedBusiness=id;render();notify(blueprints.get(b.kind)!.name+' · 拖动位置或 Ctrl+C 复制')},
    moveItem:(source,item,site)=>void transfer(source,item,{...item,position:[site.x,item.position[1],site.z]},site.cell),
    moveBusiness:(id,x,z)=>{const b=shops.find(v=>v.id===id);if(b?.site)void updateBusiness(b,x,z,b.site.angle,true)},
    cell:key=>switchCell(key),
    preview: (id, values, valid) => {
      if (!canEdit()) return
      const item = find(id)
      if (!item) return
      change = { id, result: { ...item, ...values }, valid }
      message(valid ? leveling ? '水平旋转 · 局部 Z 轴保持水平' : '' : '超出地块，松开将恢复原位。', !valid)
      updateTransformFields(change.result)
    },
    commit: id => { if (change?.id === id) commitTransform() },
    level: value => { leveling = value; message(value ? '水平旋转 · 局部 Z 轴保持水平' : '') },
    mapContext: provider => {
      $('viewport').dataset.ground = provider ?? 'fallback'
      $('map-context-source').innerHTML = provider === 'hot'
        ? '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> · HOT · <a href="https://openstreetmap.fr/" target="_blank" rel="noreferrer">OSM France</a>'
        : provider === 'osm' ? '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a>'
        : provider === 'esri' ? '&copy; Esri · HERE · Garmin · USGS · Intermap and the GIS community' : '连续地面'
    },
    loaded: () => { if (!closed && !walking && ids.length === 1 && !change) renderInspector() },
    error: text => { if (!closed) notify(text, true) },
    walking: (position, edge) => {
      const here = region ? world.walkingPresence() : undefined
      $('editor-location').textContent = `${here ? '所在格 ' + here.cell + ' · ' : ''}X ${(here?.pose?.x ?? position.x).toFixed(1)} m · Z ${(here?.pose?.z ?? position.z).toFixed(1)} m`
      message(edge ? '受到物件或地块边界阻挡' : '', edge)
    },
  })
  const set = (id: string, disabled: boolean) => { ($(id) as HTMLButtonElement).disabled = disabled }
  const find = (id: string) => data.items.find(item => item.id === id)
  const current = () => ids.length === 1 ? find(ids[0]) : undefined
  const characterKey = 'fangcun.character'
  let characterRevision = 0
  function currentMe(): CharacterSkin | undefined {
    try {
      const stored = JSON.parse(localStorage.getItem(characterKey) ?? 'null')
      if (typeof stored?.asset === 'string' && ['classic', 'slim'].includes(stored.body)) return stored
    } catch { /* Older character saves store a GLB ID directly. */ }
  }
  function saveMe(skin: CharacterSkin, image: ImageBitmap) {
    localStorage.setItem(characterKey, JSON.stringify(skin))
    characterRevision++
    world.setCharacter(skinCharacter(skin.body, image))
    $('character-reset').hidden = false
    void syncWalkSkin(skin)
  }
  async function syncWalkSkin(skin?: CharacterSkin) {
    try { await region?.setAvatar(skin) }
    catch { if (!closed) notify('行走角色已保存，暂时无法同步皮肤。', true) }
  }
  async function adoptNpc(item: Item, source?: RoomClient) {
    if (!item.asset || !item.npc) return
    const revision = ++characterRevision
    try {
      const skin = { asset: item.asset, body: item.npc.body }
      const key = assetStorageKey(skin.asset, 'png')
      const bytes = await getAsset(key) ?? await source?.downloadAsset(skin.asset, 'png')
      if (!bytes) throw new Error('找不到这个 NPC 的皮肤文件。')
      await putAsset(key, bytes)
      const image = await loadSkin(skin.asset)
      if (closed || revision !== characterRevision) return
      saveMe(skin, image)
      npcChat.close()
      characterEditor.close()
      void switchMode('view')
      notify('已保存角色外观。')
    } catch (error) {
      if (!closed) notify(error instanceof Error ? error.message : '无法读取这个 NPC 的皮肤。', true)
    }
  }
  const characterEditor = mountCharacterEditor(root, plot, {
    canEdit: () => !closed && canEdit() && !placing,
    loadNpc: id => loadSkin(id, room ? () => room!.downloadAsset(id, 'png') : undefined),
    currentMe,
    saveMe,
    onUsedMe: () => { void switchMode('view'); notify('行走角色已保存。') },
    saveNpc: (item, visual, editing) => {
      const bounds = boundsOf(visual).applyMatrix4(new T.Matrix4().compose(
        new T.Vector3(...item.position),
        new T.Quaternion().setFromEuler(new T.Euler(...item.rotation)),
        new T.Vector3(...item.scale),
      ))
      if (editing) {
        const index = data.items.findIndex(existing => existing.id === item.id)
        if (index < 0 || !fits(bounds, plot)) return false
        record()
        data.items[index] = item
        sync()
        notify('NPC 已更新。')
      } else {
        const position = availablePosition(bounds, item.position, true)
        if (!position) return false
        item.position = position
        addItem(item)
        notify('NPC 已放置。')
      }
      return true
    },
  })
  const npcChat = mountNpcDialogue(root)
  const interact = () => {
    const npc = world.nearbyNpc()
    if (!npc || npcChat.dialog.open) return
    npc.greet()
    npcChat.open(npc.item, npc.cell === tile ? room : region?.room(npc.cell))
  }
  $('npc-interact').onclick = interact
  $('create-character').onclick = () => characterEditor.open()
  const promptTimer = window.setInterval(() => {
    const nearby = walking ? world.nearbyNpc() : undefined
    refreshWalkingCell()
    const prompt = $('npc-interact')
    prompt.hidden = !nearby
    const label = nearby ? `与 ${nearby.item.name} 对话` : ''
    if (prompt.lastElementChild!.textContent !== label) prompt.lastElementChild!.textContent = label
  }, 180)
  type ImportState = { id: string; name: string; bytes: ArrayBuffer; source: T.Object3D; bounds: T.Box3; max: number; proposed: number }
  let pendingImport: ImportState | undefined
  let importPreview: ReturnType<typeof previewModel> | undefined

  function saveLocal() {
    try { onSave({ plot, scene: data }) }
    catch { notify('浏览器存储空间不足，本次修改暂未保存到本机。', true) }
  }
  function persist() {
    if (!roomDraft) { saveLocal(); return }
    roomDraft.queue(data)
  }
  function showSaveStatus() {
    const box = $('save-status')
    box.hidden = !roomDraft
    box.textContent = saveStatus.sending ? '正在保存…' : saveStatus.error
      ? `${saveStatus.error}${saveStatus.durable ? ' 草稿已保留。' : ' 草稿还在当前页面，浏览器存储失败。'}`
      : saveStatus.pending ? '有修改待保存' : '已保存'
    $('retry-save').hidden = !saveStatus.error || !saveStatus.pending
    $('resolve-save').hidden = !saveStatus.conflict
    set('retry-save', role === 'view')
    set('resolve-save', role === 'view')
  }
  $('retry-save').onclick = () => void roomDraft?.send(true)
  $('resolve-save').onclick = () => {
    if (window.confirm('用本机草稿替换双方都修改过的物件？其他人的独立修改会保留。')) void roomDraft?.send(true, true)
  }
  function receiveRoom(value: RoomView | undefined) {
    if (closed) return
    const previous = role
    const wasConnected = connected
    connected = !!value
    role = value?.role ?? role
    updateRoomStatus(value)
    if (previous !== role || wasConnected !== connected) {
      if (!canEdit()) {
        if (change) {
          const original = find(change.id)
          const object = world.get(change.id)
          if (original && object) applyItem(object, original)
        }
        change = undefined
        if (placing) endPlacement()
        if (groupDialog.open) groupDialog.close()
        if (importDialog.open) importDialog.close()
        if (partDialog.open) partDialog.close()
        if (characterEditor.editingNpc()) characterEditor.close()
        if (!walking && !observing && role === 'view') void switchMode('view')
      }
      if (previous !== 'view' && role === 'view') notify('编辑权限已撤销，仍可观看。', true)
      if (previous === 'view' && role !== 'view') notify('已获得编辑权限，可切换至编辑模式。')
      world.setEditable(canEdit())
      render()
    }
    if (!value || roomDraft?.pending || (canEdit() && (holdingEdit() || groupDialog.open || partDialog.open || characterEditor.editingNpc()))) return
    const remote = value.save.scene
    roomDraft?.updateServerScene(remote)
    if (sceneChanges(data, remote).length) {
      history.length = 0
      data = structuredClone(remote)
      ids = ids.filter(id => !!find(id))
      change = undefined
      world.sync(data.items, data.streets)
      world.select(ids)
      render()
    }
    if (role === 'owner' && value.version !== savedVersion) {
      savedVersion = value.version
      saveLocal()
    }
  }
  let savedVersion = -1

  function record() {
    history.push(structuredClone(data))
    if (history.length > 50) history.shift()
  }
  function notify(text: string, problem = false) {
    const toast = $('toast')
    toast.innerHTML = `${problem ? icons.warning : icons.check}<span>${escapeHtml(text)}</span>`
    toast.classList.toggle('problem', problem)
    toast.classList.add('show')
    window.clearTimeout(toastTimer)
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 3000)
  }
  function message(text: string, warning = false) {
    const element = $('view-message')
    element.textContent = text
    element.classList.toggle('warning', warning)
    element.classList.toggle('show', Boolean(text))
  }
  function select(id: string | undefined, multiple = false) {
    if (!canEdit() || placing) return
    selectedBusiness=undefined
    ids = id ? (multiple ? ids.includes(id) ? ids.filter(value => value !== id) : [...ids, id] : [id]) : []
    change = undefined
    world.select(ids)
    message('')
    render()
  }
  function sync() {
    world.sync(data.items, data.streets)
    world.select(ids)
    render()
    persist()
  }
  function renderObjects() {
    $('object-count').textContent=String(data.items.length+shops.filter(b=>b.site?.cell===tile).length)
    const decorations=data.items.map(item=>`<button class="list-item${ids.includes(item.id)?' selected':''}" data-item="${item.id}" title="${escapeHtml(item.name)}" aria-pressed="${ids.includes(item.id)}">${shapeIcons[item.kind]}<span>${escapeHtml(item.name)}</span><i></i></button>`)
    const businesses=shops.filter(b=>b.site?.cell===tile).map(b=>`<button class="list-item${selectedBusiness===b.id?' selected':''}" data-business="${b.id}" aria-pressed="${selectedBusiness===b.id}">${icons.globe}<span>${blueprints.get(b.kind)!.name}</span><small>${b.site!.active===false?'陈列':'营业'}</small></button>`)
    $('scene-list').innerHTML=[...decorations,...businesses].join('') || '<p class="list-empty">选一座建筑或添加物件，开始搭建街区。</p>'
  }
  function render() {
    renderObjects()
    $('model-count').textContent=String(data.models.length)
    $('model-list').innerHTML = data.models.length ? data.models.map(item => `<button class="list-item" data-model="${item.id}" title="放置 ${escapeHtml(item.name)}">${icons.package}<span>${escapeHtml(item.name)}</span>${icons.plus}</button>`).join('') : '<p class="list-empty">按住 Shift 选择多个物件，组合后可保存到这里。</p>'
    const locked = !canEdit() || placing
    const pixel=$('plot-pixel') as HTMLInputElement
    pixel.value=data.pixel??'#60a9b4';pixel.disabled=locked
    set('undo-btn', locked || !history.length)
    set('duplicate-btn', locked || !current() && !selectedBusiness)
    set('delete-btn', locked || !ids.length)
    set('import-btn', locked)
    for (const side of ['east','south'] as const) {
      const active = data.streets?.includes(side) ?? false
      const control = $('street-' + side) as HTMLButtonElement
      control.textContent = (active ? '移除' : '开通') + (side === 'east' ? '东侧' : '南侧')
      control.disabled = locked
      control.setAttribute('aria-pressed', String(active))
    }
    set('create-character', locked)
    if (characterEditor.dialog.open) characterEditor.refreshStatus()
    root.querySelectorAll<HTMLButtonElement>('[data-shape], [data-model], [data-item], [data-mode]').forEach(control => { control.disabled = locked })
    set('fit-view', walking)
    set('view-mode-btn', placing || modeChanging)
    set('observe-mode', placing || modeChanging)
    set('edit-mode', role === 'view' && !nearbyEditCell() || placing || modeChanging)
    updateRoomStatus(room?.latest)
    showSaveStatus()
    $('toggle-grid').classList.toggle('active', grid)
    $('toggle-grid').setAttribute('aria-pressed', String(grid))
    $('toggle-snap').classList.toggle('active', snap)
    $('toggle-snap').setAttribute('aria-pressed', String(snap))
    renderInspector()
  }

  function renderInspector() {
    const inspector = $('inspector')
    const item = current()
    const business=shops.find(b=>b.id===selectedBusiness)
    if(canEdit() && !placing && business?.site){
      const {x,z,angle}=business.site
      inspector.innerHTML=`<div class="selected-title"><strong>${escapeHtml(blueprints.get(business.kind)!.name)}</strong></div><p>X ${format(x)} m · Z ${format(z)} m · ${angle}°</p><button class="secondary full" id="turn-shop">旋转 90°</button>`
      $('turn-shop').onclick=()=>void updateBusiness(business,x,z,(angle+90)%360)
      return
    }
    if (!canEdit() || placing || !ids.length) {
      inspector.innerHTML = `<div class="inspector-empty"><span>${walking ? icons.person : icons.cursor}</span><strong>${walking ? '小人正在地块中' : placing ? '正在放置模型' : observing ? '30° 观赏模式' : role === 'view' ? '访客只读' : '尚未选择物件'}</strong><p>${walking ? '使用 WASD 或方向键移动。' : placing ? '移动鼠标预览，点击确定位置。' : observing ? '以 30° 俯视为中心，左右、上下各可拖动 10°。' : role === 'view' ? '左键拖动观看街区。' : workspaceMode==='view'?'左键拖动平移，点击编辑模式开始摆放。':'点击场景中的物件，查看和编辑属性。'}</p></div>`
      return
    }
    if (!item) {
      const includesNpc = ids.some(id => find(id)?.kind === 'npc')
      inspector.innerHTML = `<div class="inspector-empty multi"><span>${icons.group}</span><strong>已选择 ${ids.length} 个物件</strong><p>${includesNpc ? '请单独编辑 NPC。' : '组合基础形状和导入的 GLB。'}</p></div>${includesNpc ? '' : `<button class="secondary full" id="save-group">${icons.group} 组合物件</button>`}`
      if (!includesNpc) $('save-group').onclick = openGroup
      return
    }
    const fields = (key: 'position' | 'rotation' | 'scale', label: string, unit: string) => `
      <fieldset class="transform-field"><legend>${label} <small>${unit}</small></legend>
        <div class="axis-fields">${axes.map((axis, i) => (key==='rotation'?i!==1:i===1)?'':`<label class="input-axis axis-${axis.toLowerCase()}"><span>${axis}</span><input aria-label="${label} ${axis}" data-key="${key}" data-axis="${i}" type="number" step="any" value="${format(item[key][i] * (key === 'rotation' ? degrees : 1))}"></label>`).join('')}</div>
      </fieldset>`
    const bounds = world.getBounds(item.id)
    const size = bounds.getSize(new T.Vector3())
    inspector.innerHTML = `
      <div class="selected-title"><span>${shapeIcons[item.kind]}</span><div><strong>${escapeHtml(item.name)}</strong><small>${names[item.kind]}</small></div></div>
      ${fields('position', '位置', 'm')}${fields('rotation', '旋转', '°')}${fields('scale', '缩放', '×')}
      ${item.color ? `<label class="color-row">颜色 <span><input type="color" aria-label="颜色" id="item-color" value="${item.color}">${item.color.toUpperCase()}</span></label>` : ''}
      ${!bounds.isEmpty() ? `<div class="measured">水平占地 <strong id="measured-size">${distance(size.x)} × ${distance(size.z)}</strong></div>` : ''}
      <button class="secondary full" id="ground-item">${icons.layers} 底部贴地</button>
      ${item.kind === 'npc' ? `<button class="secondary full" id="edit-npc">${icons.person} 换肤与对话设置</button>
        <button class="secondary full" id="npc-use-appearance">${icons.person} 与 NPC 对话</button>` : ''}
      ${item.kind === 'group' ? `<button class="secondary full" id="edit-parts">${icons.move} 编辑部件</button>
      <button class="secondary full" id="ungroup">${icons.layers} 拆组</button>
      <button class="secondary full" id="save-group">${icons.package} 保存为模型</button>` : ''}`
    const paint = document.getElementById('item-color') as HTMLInputElement | null
    if (paint) paint.onchange = () => {
      const object = world.get(item.id)
      if (!object || item.color === paint.value) return
      record()
      item.color = paint.value
      applyItem(object, item)
      persist()
      render()
    }
    $('ground-item').onclick = () => {
      const object = world.get(item.id)
      const box = world.getBounds(item.id)
      if (!object || box.isEmpty() || Math.abs(box.min.y) < 1e-8) return
      const result = structuredClone(item)
      result.position[1] -= box.min.y
      change = { id: item.id, result, valid: true }
      commitTransform()
    }
    if (item.kind === 'group') {
      $('save-group').onclick = openGroup
      $('ungroup').onclick = () => ungroup(item)
      $('edit-parts').onclick = () => editParts(item)
    }
    if (item.kind === 'npc') {
      $('edit-npc').onclick = () => characterEditor.open(item)
      $('npc-use-appearance').onclick = () => npcChat.open(item,room)
    }
    inspector.querySelectorAll<HTMLInputElement>('input[data-key]').forEach(input => {
      let dirty = false
      const preview = () => {
        dirty = true
        const value = input.valueAsNumber
        const object = world.get(item.id)
        if (!object || !Number.isFinite(value)) return
        const key = input.dataset.key as 'position' | 'rotation' | 'scale'
        const result = structuredClone(item)
        result[key][Number(input.dataset.axis)] = value / (key === 'rotation' ? degrees : 1)
        applyItem(object, result)
        const valid = fits(boundsOf(object), plot) && result.scale.every(entry => entry > 0)
        change = { id: item.id, result, valid }
        world.setInvalid(!valid)
        message(valid ? '' : '超出地块，确认时将恢复原值。', !valid)
      }
      input.oninput = preview
      const finish = () => {
        if (!dirty) return
        dirty = false
        if (change && Number.isFinite(input.valueAsNumber)) commitTransform(false)
        else {
          const object = world.get(item.id)
          if (object) applyItem(object, item)
          change = undefined
          world.setInvalid(false)
          message('')
          updateTransformFields(item)
        }
      }
      input.onchange = finish
      input.onblur = finish
      input.onkeydown = event => { if (event.key === 'Enter') { event.preventDefault(); input.blur() } }
    })
  }
  function updateTransformFields(item: Item) {
    $('inspector').querySelectorAll<HTMLInputElement>('input[data-key]').forEach(input => {
      const key = input.dataset.key as 'position' | 'rotation' | 'scale'
      input.value = format(item[key][Number(input.dataset.axis)] * (key === 'rotation' ? degrees : 1))
    })
    const measured = document.getElementById('measured-size')
    if (measured) {
      const size = world.getBounds(item.id).getSize(new T.Vector3())
      measured.textContent = `${distance(size.x)} × ${distance(size.z)}`
    }
  }
  async function transfer(source:string,before:Item,after:Item,target:string){
    const from=region?.room(source),to=region?.room(target)
    if(!from || !to || !canEdit())return
    try{
      const changed=await from.moveItem(to.access.room,before,after)
      if(closed)return
      if(source===tile)receiveRoom(changed)
      else if(target===tile && room)receiveRoom(await room.read())
    }catch(error){if(!closed)notify(error instanceof Error?error.message:'跨格移动失败。',true)}
  }
  function commitTransform(repaint = true) {
    if (!change || !canEdit()) return
    const { id, result, valid } = change
    change = undefined
    const item = find(id), object = world.get(id)
    if (!item || !object) return
    const site=world.parcelPosition(result.position[0],result.position[2])
    if(valid && site.cell!==tile && region){
      applyItem(object,item)
      void transfer(tile,item,{...result,position:[site.x,result.position[1],site.z]},site.cell)
      return
    }
    if (valid && JSON.stringify(item) !== JSON.stringify(result)) {
      record()
      Object.assign(item, result)
      persist()
    }
    applyItem(object, item)
    world.setInvalid(false)
    message('')
    if (!valid) notify('物件移出边界，已恢复上一次合法位置。', true)
    if (repaint) render()
    else {
      updateTransformFields(item)
      set('undo-btn', !history.length)
    }
  }

  function addItem(item: Item) {
    if (!canEdit()) return
    record()
    data.items.push(item)
    ids = [item.id]
    sync()
  }
  function initialScale() {
    return Math.min(plot.width, plot.depth) * .09
  }
  function availablePosition(bounds: T.Box3, origin: Vec, keepCenter = false) {
    if (bounds.isEmpty()) return undefined
    const size = bounds.getSize(new T.Vector3())
    const step = Math.max(Math.min(plot.width, plot.depth) * .065, .01)
    const dx = Math.max(step, size.x * 1.28)
    const dz = Math.max(step, size.z * 1.28)
    const options: Vec[] = [[dx, 0, 0], [-dx, 0, 0], [0, 0, dz], [0, 0, -dz], [dx, 0, dz], [-dx, 0, dz], [2 * dx, 0, 0], [0, 0, 0]]
    if (keepCenter) options.unshift([0, 0, 0])
    let fallback: Vec | undefined
    const occupied = data.items.map(item => world.getBounds(item.id)).filter(box => !box.isEmpty())
    for (const option of options) {
      const candidate = bounds.clone().translate(new T.Vector3(...option))
      if (!fits(candidate, plot)) continue
      const location = add(origin, option)
      fallback ??= location
      if (!occupied.some(box => box.intersectsBox(candidate))) return location
    }
    return fallback
  }
  function addPrimitive(kind: Primitive) {
    const item = newItem(kind, SHAPES[kind])
    item.color = { box: '#76a68a', cylinder: '#648d7e', sphere: '#e3b978' }[kind]
    const size = initialScale()
    item.scale = [size, size, size]
    item.position = [0, size / 2, 0]
    const bounds = new T.Box3(new T.Vector3(-size / 2, 0, -size / 2), new T.Vector3(size / 2, size, size / 2))
    item.position = availablePosition(bounds, item.position, true) ?? item.position
    addItem(item)
  }
  function copySelected(){
    const shop=shops.find(b=>b.id===selectedBusiness)
    if(shop)copyEntry({type:'building',kind:shop.kind})
    else {
      const item=current();if(!item)return
      copyEntry({type:'scene',item,source:room?.access.room??tile})
    }
    notify('已复制，Ctrl+V 开始连续放置。')
  }
  let paintQueue=Promise.resolve()
  function stampNeighbor(cell:string,copy:Item,paving:boolean,stroke:Stroke){
    const dest=region?.room(cell)
    if(!dest)return
    paintQueue=paintQueue.then(async()=>{
      const {save}=await dest.read(false)
      const next=structuredClone(save.scene)
      if(paving){
        const onSpot=(i:Item)=>i.position[0]===copy.position[0] && i.position[2]===copy.position[2] && roadEntries.some(e=>e.assetId===i.asset&&!e.tags.includes('路面贴花'))
        if(next.items.some(i=>onSpot(i)&&i.asset===copy.asset&&i.rotation[1]===copy.rotation[1]))return
        next.items=next.items.filter(i=>!onSpot(i))
      }
      next.items.push(copy)
      await dest.publish(sceneChanges(save.scene,next))
      stroke.remote.push({room:dest,inverse:sceneChanges(next,save.scene)})
    }).catch(error=>{if(!closed)notify(error instanceof Error?error.message:'相邻格保存失败。',true)})
  }
  function stamp(item:Item,source:T.Object3D,paving=false){
    placing=true
    let stroke:Stroke|undefined
    world.beginPlacement(item,source,(position,yaw,first)=>{
      if(first || !paving)stroke=undefined
      const copy=structuredClone(item)
      copy.id=newId();copy.position=position;copy.rotation[1]=yaw
      const site=world.parcelPosition(position[0],position[2])
      if(site.cell!==tile){
        if(!stroke){stroke={snapshot:structuredClone(data),remote:[]};history.push(stroke)}
        copy.position=[site.x,position[1],site.z];stampNeighbor(site.cell,copy,paving,stroke);return
      }
      if(paving && data.items.some(i=>i.asset===copy.asset && i.position[0]===position[0] && i.position[2]===position[2] && i.rotation[1]===yaw))return
      if(paving){
        if(!stroke){stroke={snapshot:structuredClone(data),remote:[]};history.push(stroke)}
        data.items=data.items.filter(i=>!(i.position[0]===position[0] && i.position[2]===position[2] && roadEntries.some(e=>e.assetId===i.asset&&!e.tags.includes('路面贴花'))))
        data.items.push(copy);ids=[copy.id];sync()
      } else addItem(copy)
    },paving,true,true)
    message(paving?'按住左键连续铺路 · R 转向 · Esc 结束':'点击连续放置 · R 转向 · Esc 结束');render()
  }
  async function paste(){
    if(!canEdit())return
    const entry=clipboardEntry();if(!entry)return
    if(entry.type==='building'){
      if(!region)return
      const inventory=await region.estate()
      const b=inventory.inventory.find(b=>b.kind===entry.kind && !inventory.offers.some(o=>o.type==='asset'&&o.ref===b.id))
      if(closed||!canEdit())return
      if(!b){notify('仓库没有可放置的同款建筑。');return}
      placeBusiness(b);return
    }
    const item=entry.item
    const privateAsset=(part:Item):boolean=>!!part.asset&&!freeAssetIds.has(part.asset)||!!part.children?.some(privateAsset)
    if(entry.source!==(room?.access.room??tile) && privateAsset(item)){notify('请从自己的素材库取用此模型。');return}
    await prepareItemAssets(item)
    if(closed||!canEdit())return
    const visual=buildItem(item,()=>{},()=>{})
    visual.position.set(0,0,0);visual.rotation.set(0,0,0);visual.scale.setScalar(1)
    stamp(item,visual,roadEntries.some(e=>e.assetId===item.asset&&!e.tags.includes('路面贴花')))
  }
  function duplicate(){copySelected()}
  function remove() {
    if (!ids.length || !canEdit() || placing) return
    record()
    data.items = data.items.filter(item => !ids.includes(item.id))
    ids = []
    sync()
  }
  async function undo() {
    if (!canEdit() || placing) return
    const previous = history.pop()
    if (!previous) return
    if('building' in previous){
      if(!region)return
      try{
        const {before,after}=previous
        const result=await region.transact({type:'position',id:previous.building,cell:before.cell,x:before.x,z:before.z,angle:before.angle,before:after})
        if(!closed){world.setEstate(result.estate);void estate?.refresh(result.estate.revision,true);render()}
      }catch(error){if(!closed)notify(error instanceof Error?error.message:'撤销失败。',true)}
      return
    }
    if('snapshot' in previous){
      await paintQueue
      try{
        while(previous.remote.length){
          const last=previous.remote[previous.remote.length-1]
          await last.room.publish(last.inverse)
          previous.remote.pop()
        }
      }catch(error){history.push(previous);if(!closed)notify('附近地块已变化，撤销未完成。',true);return}
      if(closed)return
      data=previous.snapshot
    }else data = previous
    ids = ids.filter(id => !!find(id))
    sync()
    notify('已撤销上一步。')
  }

  const groupDialog = $('group-dialog') as HTMLDialogElement
  function openGroup() {
    const input = $('group-name') as HTMLInputElement
    input.value = current()?.name ?? '新组合'
    const library = $('group-library') as HTMLInputElement
    library.checked = true
    library.disabled = current()?.kind === 'group'
    groupDialog.showModal()
    input.focus()
    input.select()
  }
  $('close-group').onclick = $('cancel-group').onclick = () => groupDialog.close()
  $('group-form').onsubmit = async event => {
    event.preventDefault()
    const input = $('group-name') as HTMLInputElement
    const name = input.value.trim()
    if (!name) { input.focus(); return }
    const items = data.items.filter(item => ids.includes(item.id))
    if (!items.length || !canEdit() || items.some(item => item.kind === 'npc')) return
    try { await Promise.all(items.map(item => prepareItemAssets(item))) }
    catch { notify('组合中有无法读取的 GLB。', true); return }
    if (closed || !canEdit() || !groupDialog.open) return
    let group: Item
    if (items.length === 1 && items[0].kind === 'group') group = structuredClone(items[0])
    else {
      group = newItem('group', name)
      const bounds = items.reduce((acc, item) => acc.union(world.getBounds(item.id)), new T.Box3())
      if (bounds.isEmpty()) { notify('选中的物件还未加载完成。', true); return }
      const center = bounds.getCenter(new T.Vector3())
      group.position = [center.x, bounds.min.y, center.z]
      group.children = items.map(item => ({
        ...structuredClone(item),
        position: [item.position[0] - center.x, item.position[1] - bounds.min.y, item.position[2] - center.z],
      }))
    }
    group.name = name
    record()
    const keep = ($('group-library') as HTMLInputElement).checked
    if (keep) {
      const template = structuredClone(group)
      template.id = newId()
      template.position = [0, 0, 0]
      data.models.push(template)
    }
    data.items = [...data.items.filter(item => !ids.includes(item.id)), group]
    ids = [group.id]
    groupDialog.close()
    sync()
    notify(keep ? `已保存「${name}」。` : `已组合「${name}」。`)
  }
  async function placeModel(id: string) {
    const template = data.models.find(item => item.id === id)
    if (!template) return
    const item = structuredClone(template)
    item.id = newId()
    try { await prepareItemAssets(item) }
    catch { notify('模型引用的 GLB 无法读取。', true); return }
    if (closed || !canEdit()) return
    const object = buildItem(item, () => {}, () => {})
    const box = boundsOf(object)
    object.traverse(node => { if (node instanceof T.Mesh && node.userData.ownMaterial) node.material.dispose() })
    const center = box.getCenter(new T.Vector3())
    item.position = [-center.x, -box.min.y, -center.z]
    box.translate(new T.Vector3(...item.position))
    const location = availablePosition(box, item.position)
    if (!location) { notify('该模型的水平占地无法放入当前地块。', true); return }
    item.position = location
    addItem(item)
  }

  function ungroup(item: Item) {
    const object = world.get(item.id)
    if (!object || !item.children?.length || !canEdit()) return
    object.updateWorldMatrix(true, true)
    const restored: Item[] = []
    for (const [i, child] of item.children.entries()) {
      const matrix = object.children[i].matrixWorld
      const position = new T.Vector3()
      const scale = new T.Vector3()
      const quaternion = new T.Quaternion()
      matrix.decompose(position, quaternion, scale)
      const reconstructed = new T.Matrix4().compose(position, quaternion, scale)
      if (matrix.elements.some((value, index) => Math.abs(value - reconstructed.elements[index]) > 1e-6)) {
        notify('当前组合发生了剪切变形。请改为等比缩放再拆组。', true)
        return
      }
      const { x, y, z } = new T.Euler().setFromQuaternion(quaternion)
      restored.push({ ...structuredClone(child), id: newId(), position: position.toArray(), rotation: [x, y, z], scale: scale.toArray() })
    }
    record()
    data.items = [...data.items.filter(candidate => candidate.id !== item.id), ...restored]
    ids = restored.map(child => child.id)
    sync()
  }

  const partDialog = $('part-dialog') as HTMLDialogElement
  const partPicker = $('part-picker') as HTMLSelectElement
  const partKeys = ['position', 'rotation', 'scale'] as const
  let partGroup: string | undefined
  $('close-part').onclick = () => partDialog.close()
  function editParts(item: Item) {
    if (!canEdit() || !item.children?.length) return
    partGroup = item.id
    partPicker.innerHTML = item.children.map((child, index) => `<option value="${index}">${escapeHtml(child.name)}</option>`).join('')
    partDialog.showModal()
    renderPart()
  }
  function renderPart() {
    const child = partGroup ? find(partGroup)?.children?.[Number(partPicker.value)] : undefined
    if (!child) return
    $('part-fields').innerHTML = partKeys.map((key, index) => {
      const label = ['局部位置', '局部旋转', '局部缩放'][index]
      return `<fieldset class="transform-field"><legend>${label}</legend><div class="axis-fields">${axes.map((axis, i) => `<label class="input-axis"><span>${axis}</span><input type="number" step="any" required aria-label="${label} ${axis}" data-part="${key}-${i}" value="${format(child[key][i] * (key === 'rotation' ? degrees : 1))}"></label>`).join('')}</div></fieldset>`
    }).join('')
  }
  partPicker.onchange = renderPart
  $('part-form').onsubmit = event => {
    event.preventDefault()
    if (!canEdit() || !partGroup) return
    const group = find(partGroup)
    const index = Number(partPicker.value)
    const child = group?.children?.[index]
    const object = world.get(partGroup)
    if (!child || !group || !object) return
    const result = structuredClone(child)
    $('part-fields').querySelectorAll<HTMLInputElement>('input').forEach(input => {
      const [key, axis] = input.dataset.part!.split('-') as [typeof partKeys[number], string]
      result[key][Number(axis)] = input.valueAsNumber / (key === 'rotation' ? degrees : 1)
    })
    if (result.scale.some(value => !(value > 0))) {
      notify('缩放数值需大于 0。', true)
      return
    }
    applyItem(object.children[index], result)
    if (!fits(boundsOf(object), plot)) {
      applyItem(object.children[index], child)
      partDialog.close()
      notify('部件超出地块边界，已恢复原值。', true)
      return
    }
    record()
    group.children![index] = result
    partDialog.close()
    sync()
    notify('已更新组合部件。')
  }

  const importDialog = $('import-dialog') as HTMLDialogElement
  const fileInput = $('import-file') as HTMLInputElement
  const scaleField = $('import-scale') as HTMLInputElement
  const groundField = $('ground-import') as HTMLInputElement
  $('import-btn').onclick = () => fileInput.click()
  $('close-import').onclick = $('cancel-import').onclick = () => importDialog.close()
  importDialog.onclose = () => {
    importPreview?.dispose()
    importPreview = undefined
    pendingImport = undefined
  }
  const libraryDialog = $('street-library') as HTMLDialogElement
  fileInput.onchange = () => {
    const file = fileInput.files?.[0]
    fileInput.value = ''
    if (file) void previewFile(file)
  }
  async function previewFile(file: File, assetId = newId()) {
    if (closed || !canEdit() || placing || importDialog.open) return
    try {
      notify('正在读取模型…')
      const bytes = await file.arrayBuffer()
      const source = await parseGlb(bytes)
      if (closed || !canEdit() || placing || importDialog.open || root.querySelector('dialog[open]')) return
      const bounds = boundsOf(source), size = bounds.getSize(new T.Vector3())
      const max = Math.min(size.x > 0 ? plot.width / size.x : Infinity, size.z > 0 ? plot.depth / size.z : Infinity)
      const proposed = max < 1 ? max * .95 : 1
      pendingImport = { id: assetId, name: file.name.replace(/\.glb$/i, ''), bytes, source, bounds, max, proposed }
      $('import-name').textContent = file.name
      scaleField.value = String(Number(proposed.toPrecision(8)))
      groundField.checked = true
      ;($('center-import') as HTMLInputElement).checked = !roadEntries.some(entry => entry.assetId === assetId)
      importDialog.showModal()
      importPreview = previewModel($('import-preview'), source, plot)
      refreshImport()
    } catch (error) {
      if (importDialog.open) importDialog.close()
      if (!closed) notify(error instanceof Error ? `导入失败。 ${error.message}` : '导入失败，请检查 GLB 文件。', true)
    }
  }
  function refreshImport() {
    if (!pendingImport) return
    const scale = scaleField.valueAsNumber
    const valid = Number.isFinite(scale) && scale > 0 && scale <= pendingImport.max
    const size = pendingImport.bounds.getSize(new T.Vector3())
    $('import-size').textContent = `原始尺寸 ${distance(size.x)} × ${distance(size.y)} × ${distance(size.z)}${valid ? `  ·  水平占地 ${distance(size.x * scale)} × ${distance(size.z * scale)}` : ''}`
    $('import-warning').textContent = valid
      ? (pendingImport.max < 1 ? '原始模型大于地块。当前预览已等比缩小，确认后放置。' : '')
      : '请填写大于零且能放入地块的缩放比例。'
    set('confirm-import', !valid)
    if (Number.isFinite(scale) && scale > 0) importPreview?.render(scale, groundField.checked, valid)
  }
  $('fit-import').onclick = () => {
    if (!pendingImport) return
    scaleField.value = String(pendingImport.proposed)
    refreshImport()
  }
  scaleField.oninput = groundField.onchange = refreshImport
  $('import-form').onsubmit = async event => {
    event.preventDefault()
    if (!pendingImport || !canEdit()) return
    const imported = pendingImport
    const scale = scaleField.valueAsNumber
    if (!(scale > 0 && scale <= imported.max)) return
    const item = newItem('glb', imported.name || 'GLB 模型')
    const road = roadEntries.find(entry => entry.assetId === imported.id)
    const paving = !!road && !road.tags.includes('路面贴花') && scale === 1
    item.asset = imported.id
    item.scale = [scale, scale, scale]
    item.position[1] = groundField.checked ? -imported.bounds.min.y * scale : 0
    if (road && groundField.checked) item.position[1] += road.tags.includes('路面贴花') ? .012 : .006
    const center = ($('center-import') as HTMLInputElement).checked
    set('confirm-import', true)
    try {
      await putAsset(imported.id, imported.bytes)
      if (closed || !canEdit() || !importDialog.open) return
      rememberAsset(imported.id, imported.source)
      importDialog.close()
      if (center) {
        addItem(item)
        notify('GLB 已放到地块中心。')
      } else {
        placing = true
        world.beginPlacement(item, imported.source, (position, yaw) => {
          endPlacement()
          item.position = position
          item.rotation[1] = yaw
          addItem(item)
          notify('GLB 已放置。')
        }, paving)
        message(paving ? '10 米吸附 · R 旋转 90° · 点击铺设 · Esc 取消' : '移动鼠标预览，点击放置 · Esc 取消')
        render()
      }
    } catch {
      if (!closed) {
        notify('浏览器无法保存此 GLB 文件。', true)
        refreshImport()
      }
    }
  }
  function endPlacement() {
    if (!placing) return
    placing = false
    world.endPlacement()
    message('')
    render()
  }
  function nearbyEditCell() {
    if (!walking || !regionView) return undefined
    const cell = world.walkingPresence().cell
    const target = regionView.tiles.find(entry => entry.key === cell && entry.key !== tile)
    if (target && (regionView.role === 'owner' || regionView.role === 'edit' && (target.write || target.owner === regionView.member))) return target.key
  }
  function refreshWalkingCell() {
    if (!region) return
    const destination = nearbyEditCell()
    $('edit-current-cell').hidden = !destination
    set('edit-mode', role === 'view' && !destination || placing || modeChanging)
  }
  if (region) $('edit-current-cell').onclick = () => {
    const destination = nearbyEditCell()
    if (destination) options.editCell?.(destination)
  }
  function switchCell(key:string,openEstate=false) {
    const coordinate=parseCell(key)
    if(!coordinate || key===tile || !(region?.tile(key) || options.localNeighbors?.some(s=>plotKey(s.plot)===key)))return
    options.editCell?.(key,world.viewAt(coordinate,workspaceMode),openEstate)
  }
  function switchMode(next:WorkspaceMode) {
    if(next==='edit' && options.needsClaim){notify('先领取此格，即可编辑。');document.getElementById('claim-plot')?.focus();return}
    if(next==='edit' && role==='view')return
    if(placing)endPlacement()
    if(change)commitTransform()
    workspaceMode=next
    observing=next==='photo'
    world.setObserve(observing)
    if(!observing)world.setPlan(next==='edit')
    world.setEditable(canEdit())
    renderModes()
    render()
  }
  function renderModes() {
    const editing=workspaceMode==='edit'
    $('viewport').classList.toggle('observing',observing)
    for(const id of ['photo-atmosphere','street-framing','photo-export'])$(id).hidden=!observing
    for(const [id,active] of [['edit-mode',editing],['view-mode-btn',workspaceMode==='view'],['observe-mode',observing]] as const){
      $(id).classList.toggle('active',active);$(id).setAttribute('aria-pressed',String(active))
    }
    $('editor-status').textContent=editing?'3D 编辑':observing?'街景拍照':'街道观看'
    $('view-mode').textContent=$('editor-status').textContent
    $('view-hint').textContent=observing?'拖动调整构图 · 滚轮缩放':'左键平移 · 右键旋转 · 滚轮缩放'+(editing?' · 点选后拖动物件':'')
  }
  function setTool(next: typeof mode) {
    if (!canEdit() || placing) return
    mode = next
    world.setMode(next)
    root.querySelectorAll<HTMLButtonElement>('[data-mode]').forEach(control => {
      control.classList.toggle('active', control.dataset.mode === mode)
      control.setAttribute('aria-pressed', String(control.dataset.mode === mode))
    })
  }

  for (const side of ['east','south'] as const) {
    $('street-' + side).onclick = () => {
      if (!canEdit() || placing) return
      const sides = data.streets ?? []
      const active = sides.includes(side)
      const conflict = active ? '' : world.streetConflict(side)
      if (conflict) { notify(conflict, true); return }
      record()
      data.streets = active ? sides.filter(s => s !== side) : [...sides, side]
      sync()
    }
  }
  $('primitives').onclick = event => {
    const shape = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-shape]')?.dataset.shape as Primitive | undefined
    if (shape && canEdit() && !placing) addPrimitive(shape)
  }
  $('scene-list').onclick = event => {
    const business=(event.target as HTMLElement).closest<HTMLElement>('[data-business]')?.dataset.business
    if(business && canEdit()){select(undefined);selectedBusiness=business;world.selectBusiness(business);render();notify('已选中建筑，可复制或在画布上拖动。');return}
    const id = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-item]')?.dataset.item
    if (id) select(id, event.shiftKey || event.ctrlKey || event.metaKey)
  }
  $('model-list').onclick = event => {
    const id = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-model]')?.dataset.model
    if (id && canEdit() && !placing) void placeModel(id)
  }
  $('tool-buttons').onclick = event => {
    const next = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-mode]')?.dataset.mode as typeof mode | undefined
    if (next) setTool(next)
  }
  $('toggle-grid').onclick = () => {
    grid = !grid
    localStorage.setItem('fangcun.show-build-grid', String(grid))
    world.setGrid(grid)
    $('toggle-grid').classList.toggle('active', grid)
    $('toggle-grid').setAttribute('aria-pressed', String(grid))
  }
  $('toggle-snap').onclick = () => {
    snap = !snap
    localStorage.setItem('fangcun.snap',snap?'on':'off')
    world.setSnap(snap)
    $('toggle-snap').classList.toggle('active', snap)
    $('toggle-snap').setAttribute('aria-pressed', String(snap))
    notify(snap ? `网格吸附已开启 · ${distance(world.snapStep)}` : '网格吸附已关闭。')
  }
  $('fit-view').onclick = () => world.fit()
  $('edit-mode').onclick = () => void switchMode('edit')
  $('view-mode-btn').onclick = () => void switchMode('view')
  $('observe-mode').onclick = () => switchMode('photo')
  $('plot-pixel').onchange=e=>{
    if(!canEdit())return
    record(); data.pixel=(e.target as HTMLInputElement).value;sync()
  }
  $('undo-btn').onclick = undo
  $('duplicate-btn').onclick = duplicate
  $('delete-btn').onclick = remove
  window.addEventListener('keydown', event => {
    if (event.defaultPrevented || root.querySelector('#estate-dialog[open]:not(.building-shelf)') || libraryDialog.open || groupDialog.open || importDialog.open || partDialog.open || roomDialog.open ||
      characterEditor.dialog.open || npcChat.dialog.open || (event.target as HTMLElement | null)?.closest('input,textarea,select')) return
    if (walking && event.code === 'KeyE' && !event.repeat && !event.ctrlKey && !event.metaKey && !event.altKey) {
      event.preventDefault()
      interact()
      return
    }
    if (placing && event.code === 'KeyR' && !event.repeat && world.rotatePaving()) { event.preventDefault(); return }
    if (placing && (event.ctrlKey||event.metaKey) && event.code==='KeyZ'){event.preventDefault();endPlacement();undo();return}
    if (placing && event.key === 'Escape') { endPlacement(); return }
    if (!canEdit() || placing) return
    if ((event.ctrlKey || event.metaKey) && event.code === 'KeyZ') { event.preventDefault(); undo(); return }
    if ((event.ctrlKey || event.metaKey) && event.code === 'KeyC') { event.preventDefault(); copySelected(); return }
    if ((event.ctrlKey || event.metaKey) && event.code==='KeyV'){event.preventDefault();void paste().catch(()=>notify('素材尚未就绪。',true));return}
    if (event.ctrlKey || event.metaKey || event.altKey) return
    if (event.key === 'Delete') remove()
    if (event.key === 'Escape') select(undefined)
    if (event.code === 'KeyG') $('toggle-grid').click()
    if (event.code === 'KeyW') setTool('translate')
    if (event.code === 'KeyE') setTool('rotate')
    if (event.code === 'KeyR') setTool('scale')
  }, { signal: listeners.signal })

  const roomDialog = $('room-dialog') as HTMLDialogElement
  const linkField = $('room-link') as HTMLInputElement
  let listingBusy = false
  let policyBusy = false
  function updateRoomStatus(value: RoomView | undefined) {
    const label = $('room-btn').querySelector('span')!
    const state = region ? regionView : value
    const online = region ? regionView?.people.length : value?.online
    label.textContent = sharing ? '正在开启…' : room ? connected && state ? `${online ?? 0} 人在线` : '房间离线' : '共享此格'
    $('room-info').textContent = room ? `${roleNames[role]} · ${connected && state ? `${online ?? 0} 人在线` : '连接中断'}` : '邀请好友一起进入这块地。'
    $('room-local-invite').hidden = !!region && regionView?.role !== 'owner'
    $('room-owner').hidden = role !== 'owner' && regionView?.role !== 'owner'
    const publicField = $('room-listing') as HTMLInputElement
    publicField.disabled = !connected || listingBusy || role !== 'owner'
    if (!listingBusy) publicField.checked = !!value?.listed
    const policy = region ? $('room-cell-write') as HTMLInputElement : undefined
    if (policy) {
      policy.disabled = !regionView || role !== 'owner' || policyBusy
      if (!policyBusy) policy.checked = !!region?.tile(tile)?.write
    }
    set('room-btn', sharing)
    set('invite-view', !connected || sharing)
    set('invite-edit', !connected || sharing)
    set('room-revoke', !connected || sharing)
  }
  $('room-listing').onchange = async event => {
    if (!room) return
    const enabled = (event.currentTarget as HTMLInputElement).checked
    listingBusy = true
    updateRoomStatus(room.latest)
    try {
      await room.listing(enabled)
      if (!closed) $('room-error').textContent = enabled ? '成功保存的编辑将显示在大地图。' : '已关闭大地图标记。'
    } catch (error) {
      if (!closed) $('room-error').textContent = error instanceof Error ? error.message : '地图标记更新失败。'
    } finally {
      listingBusy = false
      if (!closed) updateRoomStatus(room.latest)
    }
  }
  if (region) {
    $('editor-region-overview').onclick = () => options.overview?.()
    $('room-cell-write').onchange = async event => {
      const enabled = (event.currentTarget as HTMLInputElement).checked
      policyBusy = true
      updateRoomStatus(room?.latest)
      try { regionView = await region.allowEditing(tile, enabled) }
      catch (error) { if (!closed) $('room-error').textContent = error instanceof Error ? error.message : '权限修改失败。' }
      finally {
        policyBusy = false
        if (!closed) updateRoomStatus(room?.latest)
      }
    }
  } else {
    const name = $('builder-name') as HTMLInputElement
    name.value = localStorage.getItem('fangcun.builder-name') ?? ''
    name.onchange = () => localStorage.setItem('fangcun.builder-name', name.value.trim())
  }
  function attachRoom(client: RoomClient) {
    room = client
    if (!region) world.setSharedGround()
    setAssetProvider((id, kind) => client.downloadAsset(id, kind))
    unsubscribe?.()
    roomDraft?.stop()
    roomDraft = new RoomDraft(client, data, state => { saveStatus = state; showSaveStatus() }, () => receiveRoom(client.latest))
    if (roomDraft.pending) {
      data = roomDraft.scene
      world.sync(data.items, data.streets)
      render()
    }
    roomDraft.report()
    unsubscribe = client.observe(receiveRoom)
  }
  $('room-btn').onclick = async () => {
    if(options.needsClaim){notify('先领取此格，即可邀请朋友。');return}
    $('room-error').textContent = ''
    if (!room) {
      sharing = true
      world.setEditable(false)
      render()
      try {
        onSave({ plot, scene: data })
        await options.sharePlot()
        return
      } catch (error) {
        if (!closed) notify(error instanceof Error ? error.message : '无法开启共建。', true)
        return
      } finally {
        sharing = false
        if (!closed) { world.setEditable(canEdit()); render() }
      }
    }
    if (!closed) roomDialog.showModal()
  }
  $('close-room').onclick = () => roomDialog.close()
  async function issueInvite(grant: 'view' | 'edit') {
    try {
      if (!room) return
      linkField.value = await (region ?? room).invite(grant)
      $('room-link-row').hidden = false
      $('room-error').textContent = ''
      linkField.select()
    } catch (error) { $('room-error').textContent = error instanceof Error ? error.message : '无法生成邀请。' }
  }
  $('invite-view').onclick = () => void issueInvite('view')
  $('invite-edit').onclick = () => void issueInvite('edit')
  $('room-copy').onclick = async () => {
    try {
      await navigator.clipboard.writeText(linkField.value)
      $('room-error').textContent = '已复制邀请链接。'
    } catch {
      linkField.select()
      $('room-error').textContent = '请按 Ctrl/Cmd+C 复制链接。'
    }
  }
  $('room-revoke').onclick = async () => {
    try {
      await (region ?? room)?.revokeEditing()
      $('room-link-row').hidden = true
      $('room-error').textContent = '所有访客现为只读，原编辑邀请已失效。'
    } catch (error) { $('room-error').textContent = error instanceof Error ? error.message : '无法撤销权限。' }
  }

  const characterFile = $('character-file') as HTMLInputElement
  $('character-btn').onclick = () => characterFile.click()
  $('character-btn').title = '导入带骨骼 GLB。已有 Idle/Walk 则直接使用，可识别的人形骨骼可自动生成基础动画。'
  characterFile.onchange = async () => {
    const file = characterFile.files?.[0]
    characterFile.value = ''
    if (!file) return
    const revision = ++characterRevision
    try {
      const bytes = await file.arrayBuffer()
      const character = await parseCharacter(bytes)
      if (closed || revision !== characterRevision) return
      const id = newId()
      await putAsset(id, bytes)
      if (closed || revision !== characterRevision) return
      localStorage.setItem(characterKey, id)
      world.setCharacter(character)
      void syncWalkSkin()
      $('character-reset').hidden = false
      characterEditor.refreshMe()
      notify('角色已替换，行走时可查看动画。')
    } catch (error) {
      if (!closed) notify(error instanceof Error ? error.message : '角色导入失败。', true)
    }
  }
  $('character-reset').onclick = () => {
    characterRevision++
    localStorage.removeItem(characterKey)
    world.setCharacter(blockCharacter())
    void syncWalkSkin()
    $('character-reset').hidden = true
    characterEditor.refreshMe()
    notify('已恢复默认角色。')
  }
  const characterId = localStorage.getItem(characterKey)
  if (characterId) void (async () => {
    const skin = currentMe()
    if (skin) {
      const image = await loadSkin(skin.asset)
      if (closed || characterRevision) return
      world.setCharacter(skinCharacter(skin.body, image))
      void syncWalkSkin(skin)
    } else {
      const bytes = await getAsset(characterId)
      if (!bytes || closed || characterRevision) return
      const character = await parseCharacter(bytes)
      if (closed || characterRevision) return
      world.setCharacter(character)
    }
    $('character-reset').hidden = false
  })().catch(() => { if (!closed && !characterRevision) notify('上次使用的角色无法读取，已使用默认角色。', true) })

  async function updateBusiness(b:Building,x:number,z:number,angle:number,worldCoordinates=false){
    if(!region || !canEdit())return
    try {
      const raw=worldCoordinates?world.parcelPosition(x,z):{cell:b.site?.cell??tile,x,z}
      const site=world.resolveSite(raw,b.kind,angle,b.id)?.site
      if(!site)return
      const result=await region.transact({type:'position',id:b.id,...site,angle,before:b.site??null})
      if(closed)return
      const after=result.estate.buildings.find(shop=>shop.id===b.id)?.site
      if(b.site && after)history.push({building:b.id,before:b.site,after})
      world.setEstate(result.estate)
      shops=result.estate.buildings
      render()
      void estate?.refresh(result.estate.revision,true)
    } catch(error){
      if(!closed){notify(error instanceof Error?error.message:'放置失败。',true);void estate?.refresh(0,true)}
    }
  }
  function placeBusiness(b:Building){
    const preview=newItem('glb',blueprints.get(b.kind)!.name)
    placing=true;world.beginPlacement(preview,estateModel(b.kind),(pos,yaw)=>{endPlacement();void updateBusiness(b,pos[0],pos[2],Math.round(yaw*2/Math.PI)*90)},false,true)
    render()
  }
  const estate = region ? mountEstate(root,region,tile,e=>{
    world.setEstate(e)
    const next=e.buildings
    if(JSON.stringify(shops)!==JSON.stringify(next)){shops=next;renderObjects()}
  },(building,complete)=>{
    switchMode('edit');if(!canEdit())return
    const def=blueprints.get(building.kind)!
    const preview=newItem('glb',def.name)
    preview.position=[0,0,0]
    if(building.site)preview.rotation[1]=T.MathUtils.degToRad(building.site.angle)
    placing=true
    world.beginPlacement(preview,estateModel(building.kind),(position,yaw)=>{
      endPlacement();complete(position[0],position[2],Math.round(T.MathUtils.radToDeg(yaw)/90)*90)
    },false,true)
    message('点击地面放置 · R 旋转 90° · Esc 取消');render()
  },notify,()=>data.items.filter(i=>i.kind==='npc'),key=>switchCell(key,true),options.firstEstate) : undefined
  if(region)$('chat-entry').onclick=()=>estate?.open('chat')
  const claim=document.querySelector<HTMLButtonElement>('#claim-plot')
  if(claim){
    const owned=region?.tile(tile)?.owner===region?.latest?.member && !!region
    const expand=$('expand-land') as HTMLButtonElement, directions=$('claim-directions')
    const receipt=options.receipt
    $('claim-heading').textContent=(owned?'自有地块 ':region?'共建地块 ':'正在预览 ')+tile
    $('claim-receipt').textContent=receipt?(receipt.already?'你已拥有':'已领取')+' '+receipt.cell+' · 本次支付 '+receipt.charged+' 方币 · 余额 '+receipt.balance+' 方币':''
    world.highlightClaim(tile)
    expand.hidden=!owned
    let revision=0,submitting=false
    async function choose(key:string,description:string){
      const current=++revision
      world.highlightClaim(key)
      const info=$('claim-info')
      info.textContent=description+' '+key+' · 正在查询…'
      claim!.hidden=false;claim!.disabled=true;claim!.textContent='查询中…'
      for(const el of directions.querySelectorAll('button'))el.setAttribute('aria-pressed',String(el.dataset.cell===key))
      try{
        const q=await landAvailability(key)
        if(closed||revision!==current)return
        const state=claimState(q)
        info.textContent=description+' '+key+' · 余额 '+q.balance+' 方币'
        claim!.textContent=state.label;claim!.disabled=!state.enabled
        claim!.onclick=async()=>{
          if(submitting||current!==revision)return
          submitting=true;claim!.disabled=expand.disabled=true
          for(const el of directions.querySelectorAll('button'))el.disabled=true
          claim!.textContent='正在提交 '+key+'…'
          try{await options.claim(plotForCell(parseCell(key)!),q.seedPrice)}
          catch(error){
            if(!closed){await choose(key,description);info.textContent+=' · '+(error instanceof Error?error.message:'提交失败')}
          }finally{
            submitting=false
            if(!closed){expand.disabled=false;for(const el of directions.querySelectorAll('button'))el.disabled=false}
          }
        }
      }catch{if(!closed && current===revision){info.textContent=description+' '+key+' · 地籍查询失败';claim!.disabled=false;claim!.textContent='重新查询';claim!.onclick=()=>void choose(key,description)}}
    }
    expand.onclick=()=>{
      directions.hidden=!directions.hidden
      if(directions.hidden){++revision;world.highlightClaim(tile);claim!.hidden=true;$('claim-info').textContent='';return}
      $('claim-info').textContent='选择方向查看地块和价格'
      directions.replaceChildren()
      for(const [i,c] of neighborsOf(plot.cell!).entries()){
        const key=cellKey(c),direction=['西','东','北','南'][i]
        const btn=document.createElement('button')
        btn.type='button';btn.className='secondary';btn.textContent=direction+'侧';btn.dataset.cell=key
        btn.onclick=()=>void choose(key,direction+'侧目标')
        directions.append(btn)
      }
    }
    if(!region)void choose(tile,'当前格')
  }
  let dragVersion=0
  const streetSources=new Map<string,Promise<T.Object3D>>()
  $('open-library').onclick=mountStreetLibrary(libraryDialog,$('viewport').querySelector('canvas')!,{
    describe:a=>options.needsClaim?'认领后可摆放':a.kind?estate?.describe(a.kind)??'需要经营权限':a.file?'免费 · 可重复摆放':'待制作',
    async start(a){
      const version=++dragVersion
      if(options.needsClaim || role==='view' || (!a.file && !a.kind))return false
      if(a.kind && !estate?.canDrop(a.kind))return false
      switchMode('edit')
      if(!canEdit())return false
      if(a.kind)return true
      const id=a.assetId!
      let source=streetSources.get(id)
      if(!source){
        source=(async()=>{
          const bytes=await getAsset(id)??await fetch('/street/'+a.file+'.glb').then(r=>{if(!r.ok)throw Error();return r.arrayBuffer()})
          if(!bytes)throw Error()
          const object=await parseGlb(bytes)
          await putAsset(id,bytes);rememberAsset(id,object);return object
        })()
        streetSources.set(id,source);source.catch(()=>streetSources.delete(id))
      }
      const object=await source
      if(closed || dragVersion!==version || !canEdit())return false
      const item=newItem('glb',a.name);item.asset=id;item.position[1]=-boundsOf(object).min.y+.008
      stamp(item,object,roadEntries.some(e=>e.assetId===id&&!e.tags.includes('路面贴花')))
      return true
    },
    move:(a,e)=>{if(a.kind)world.dropPosition(e,a.kind);else world.updatePlacement(e)},
    finish:(a,e)=>{
      if(a.kind){
        const site=world.dropPosition(e,a.kind)
        if(site && estate)void estate.drop(a.kind,site).finally(()=>world.clearDropGuide())
        else world.clearDropGuide()
      }else{world.dropStreet(e);endPlacement()}
    },
    cancel:()=>{++dragVersion;world.clearDropGuide();endPlacement()}
  },listeners.signal)
  $('estate-open').onclick=async()=>{
    if(options.needsClaim){notify('先领取此格，即可经营。');return}
    if(estate){estate.open(options.openCurrentEstate?'plot':undefined);options.openCurrentEstate=false;return}
    if(sharing)return
    sharing=true
    try{onSave({plot,scene:data});await options.sharePlot('estate')}
    catch(error){if(!closed)notify(error instanceof Error?error.message:'无法开启经营。',true)}
    finally{sharing=false}
  }
  $('street-framing').onclick=()=>world.frameStreet()
  const atmosphere=$('photo-atmosphere') as HTMLSelectElement
  atmosphere.onchange=()=>world.setAtmosphere(atmosphere.value as 'dawn'|'dusk'|'map')
  $('photo-export').onclick=async()=>{
    try{
      const blob=await world.photograph($('map-context-source').textContent??'')
      const link=document.createElement('a'),address=URL.createObjectURL(blob)
      link.href=address;link.download='方寸街景-'+tile.replace(':','_')+'.png';document.body.append(link);link.click();link.remove()
      window.setTimeout(()=>URL.revokeObjectURL(address),15000)
      notify('街景照片已生成。')
    }catch(error){notify(error instanceof Error?error.message:'照片导出失败。',true)}
  }
  world.sync(data.items, data.streets)
  if(options.localNeighbors)world.setLocalNeighbors(options.localNeighbors)
  world.setSnap(snap)
  $('toggle-snap').setAttribute('aria-pressed',String(snap))
  world.setGrid(grid)
  world.setEditable(canEdit())
  setTool(mode)
  renderModes()
  render()
  if (room) attachRoom(room)
  if (region) {
    const location = (): PresenceUpdate => walking ? { ...world.walkingPresence(), mode: 'walk' }
      : { cell: tile, mode: canEdit() ? 'edit' : 'view', selection: ids.length === 1 ? ids[0] : undefined }
    const display = (view?: RegionView) => {
      if (closed) return
      if(view && !view.tiles.some(t=>t.key===tile)){options.overview?.();return}
      regionView = view
      if (view) { options.onRegion?.(view);world.setRegion(region, view); void estate?.refresh(view.estateRevision) }
      $('editor-member-list').innerHTML = memberList(view)
      updateRoomStatus(room?.latest)
    }
    display(regionView)
    if(!options.view)world.fit()
    stopRegion = region.watch(location, display)
  }
  if (options.view) {
    switchMode(options.view.mode === 'edit' && role === 'view' ? 'view' : options.view.mode)
    world.restoreView(options.view)
  } else if (role === 'view') switchMode('view')
  return () => {
    closed = true
    listeners.abort()
    unsubscribe?.()
    roomDraft?.stop()
    stopRegion?.()
    setAssetProvider()
    window.clearTimeout(toastTimer)
    window.clearInterval(promptTimer)
    estate?.dispose()
    characterEditor.dispose()
    npcChat.dispose()
    importPreview?.dispose()
    world.dispose()
  }
}
