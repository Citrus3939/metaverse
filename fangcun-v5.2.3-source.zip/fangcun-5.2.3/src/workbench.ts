import type { Item } from './data'

export type WorkspaceMode = 'view' | 'edit' | 'photo'
export type ClipboardEntry = { type:'scene'; item:Item; source:string } | {type:'building';kind:string}
let contents:ClipboardEntry|undefined
export function copyEntry(entry:ClipboardEntry) { contents=structuredClone(entry) }
export function clipboardEntry() { return contents && structuredClone(contents) }

export type WorkbenchView = {
  mode: WorkspaceMode
  camera: [number,number,number]
  target: [number,number,number]
  zoom: number
  frustum: number
}
