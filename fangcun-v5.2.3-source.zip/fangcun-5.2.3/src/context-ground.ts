import * as T from 'three'
import { cellKey, gridLatitude, gridLongitude, PLOT_SIZE, type PlotCell } from './plot-grid'

const tileSize = 256
const radius = 3
const gridWidth = radius * 2 + 1
type Provider = 'hot' | 'esri' | 'osm'
const tileCache = new Map<string, Promise<HTMLImageElement>>()
const mapX = (longitude: number, tiles: number) => (longitude + 180) / 360 * tiles * tileSize
const mapY = (latitude: number, tiles: number) => (.5 - Math.asinh(Math.tan(latitude * Math.PI / 180)) / (2 * Math.PI)) * tiles * tileSize

function imageFor(provider: Provider, x: number, y: number, zoom: number) {
  const tiles = 2 ** zoom
  const col = (x % tiles + tiles) % tiles
  const url = `/map-tiles/${provider}/${zoom}/${col}/${y}`
  const known = tileCache.get(url)
  if (known) return known
  const loader = new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image()
    img.fetchPriority = 'low'
    img.onload = () => resolve(img)
    img.onerror = () => reject(new Error('地图瓦片无法加载'))
    img.src = url
  })
  tileCache.set(url, loader)
  loader.catch(() => tileCache.delete(url))
  if (tileCache.size > 256) tileCache.delete(tileCache.keys().next().value!)
  return loader
}

async function crop(cell: PlotCell, provider: Provider, zoom: number, current:()=>boolean) {
  const tiles = 2 ** zoom
  const x = mapX(gridLongitude(cell.column - radius), tiles)
  const y = mapY(gridLatitude(cell.row - radius), tiles)
  const width = mapX(gridLongitude(cell.column + radius + 1), tiles) - x
  const height = mapY(gridLatitude(cell.row + radius + 1), tiles) - y
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = gridWidth * (zoom === 19 ? 384 : 256)
  const ctx = canvas.getContext('2d')!
  ctx.imageSmoothingQuality = 'high'
  const work: Array<()=>Promise<void>> = []
  for (let col = Math.floor(x / tileSize); col < Math.ceil((x + width) / tileSize); col++) {
    for (let row = Math.floor(y / tileSize); row < Math.ceil((y + height) / tileSize); row++) {
      if (row < 0 || row >= tiles) throw new Error('已到地图范围边缘')
      work.push(async()=>{
        const img=await imageFor(provider,col,row,zoom)
        ctx.setTransform(canvas.width / width, 0, 0, canvas.height / height, -x * canvas.width / width, -y * canvas.height / height)
        ctx.drawImage(img, col * tileSize, row * tileSize)
      })
    }
  }
  let next=0,failed=false
  async function worker(){
    try{while(!failed && current() && next<work.length)await work[next++]()}
    catch(error){failed=true;throw error}
  }
  await Promise.all([worker(),worker()])
  ctx.resetTransform()
  ctx.filter = 'none'
  return canvas
}

export class ContextGround {
  private staticTexture?: HTMLCanvasElement
  private activeMap?: T.CanvasTexture
  private zoom = 18
  private revision = 0
  private tint = '#bedce7'
  private cell?: PlotCell
  private regionCells = new Set<string>()
  private buildCells: number[] = []
  private surface: T.Mesh<T.PlaneGeometry, T.MeshBasicMaterial>
  private nearLines: T.LineSegments<T.BufferGeometry, T.LineBasicMaterial>
  readonly object = new T.Group()

  constructor(private status: (provider?: Provider) => void, private anisotropy: number) {
    const size = PLOT_SIZE * gridWidth
    this.surface = new T.Mesh(new T.PlaneGeometry(size, size), new T.MeshBasicMaterial({ transparent: true }))
    this.surface.rotation.x = -Math.PI / 2
    this.surface.position.y = -.012
    const positions: number[] = []
    for (let split = .5 - radius; split < radius; split++) {
      positions.push(split * PLOT_SIZE, -.004, -size / 2, split * PLOT_SIZE, -.004, size / 2)
      positions.push(-size / 2, -.004, split * PLOT_SIZE, size / 2, -.004, split * PLOT_SIZE)
    }
    const geo = new T.BufferGeometry().setAttribute('position', new T.Float32BufferAttribute(positions, 3))
    this.nearLines = new T.LineSegments(geo, new T.LineBasicMaterial({ transparent: true, opacity: .39 }))
    this.object.add(this.surface, this.nearLines)
  }

  theme(ground: string, line: string) {
    this.tint = ground
    this.nearLines.material.color.set(line)
    this.paint()
  }

  setRegionCells(keys: string[]) {
    this.regionCells = new Set(keys)
    const cells = this.visibleBuildCells()
    if (cells.length === this.buildCells.length && cells.every((cell, i) => cell === this.buildCells[i])) return
    this.buildCells = cells
    this.paint()
  }

  private visibleBuildCells() {
    const cells: number[] = []
    if (!this.cell || !this.regionCells.size) return cells
    for (let row = 0; row < gridWidth; row++) {
      for (let column = 0; column < gridWidth; column++) {
        const key = cellKey({ column: this.cell.column + column - radius, row: this.cell.row + row - radius })
        if (this.regionCells.has(key)) cells.push(row * gridWidth + column)
      }
    }
    return cells
  }

  private paint() {
    const canvas = document.createElement('canvas')
    canvas.width = canvas.height = this.staticTexture?.width ?? gridWidth * 64
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = this.tint
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    if (this.staticTexture) ctx.drawImage(this.staticTexture, 0, 0)
    const cellSize = canvas.width / gridWidth
    for (const index of this.buildCells) {
      ctx.fillRect(index % gridWidth * cellSize, Math.floor(index / gridWidth) * cellSize, cellSize, cellSize)
    }
    const texture = new T.CanvasTexture(canvas)
    texture.anisotropy = this.anisotropy
    texture.colorSpace = T.SRGBColorSpace
    this.activeMap?.dispose()
    this.activeMap = texture
    this.surface.material.map = texture
    this.surface.material.needsUpdate = true
  }

  detail(pixelsPerMeter: number) {
    const zoom = pixelsPerMeter > 2 ? 19 : 18
    if (zoom === this.zoom) return
    this.zoom = zoom
    if (this.cell) void this.show(this.cell, this.object.position.x, this.object.position.z)
  }

  async show(cell: PlotCell, x: number, z: number) {
    const rev = ++this.revision
    if (this.cell !== cell) this.staticTexture = undefined
    this.cell = cell
    this.buildCells = this.visibleBuildCells()
    this.object.position.set(x, 0, z)
    this.paint()
    this.status()
    const sources: [Provider, number][] = [['hot', 18], ['osm', 18], ['esri', 18]]
    if (this.zoom === 19) sources.unshift(['osm', 19])
    for (const [provider, zoom] of sources) {
      try {
        const asset = await crop(cell, provider, zoom,()=>rev===this.revision)
        if (rev !== this.revision) return
        this.staticTexture = asset
        this.paint()
        this.status(provider)
        return
      } catch {
        if (rev !== this.revision) return
      }
    }
  }
  dispose() {
    this.revision++
    this.activeMap?.dispose()
    this.surface.material.dispose()
    this.surface.geometry.dispose()
    this.nearLines.material.dispose()
    this.nearLines.geometry.dispose()
    this.staticTexture = undefined
  }
}
