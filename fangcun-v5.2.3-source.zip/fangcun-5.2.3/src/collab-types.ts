import type { AssetKind, CharacterSkin, Item, Save, SceneData, StreetSide } from './data'

export type Role = 'owner' | 'edit' | 'view'
export type RoomAccess = { room: string; token: string }
export type RoomView = { role: Role; save: Save; version: number; online: number; listed?: boolean }
export type SceneChange = { collection: 'items' | 'models'; id: string; before: Item | null; after: Item | null }
  | { collection:'pixel'; id:'color'; before:string|null; after:string|null }
  | { collection: 'streets'; id: StreetSide; before: boolean; after: boolean }

export function sceneChanges(before: SceneData, after: SceneData): SceneChange[] {
  const changes: SceneChange[] = []
  for (const collection of ['items', 'models'] as const) {
    const old = new Map(before[collection].map(item => [item.id, item]))
    const next = new Map(after[collection].map(item => [item.id, item]))
    for (const id of new Set([...old.keys(), ...next.keys()])) {
      const previous = old.get(id) ?? null
      const value = next.get(id) ?? null
      if (JSON.stringify(previous) !== JSON.stringify(value)) changes.push({ collection, id, before: previous, after: value })
    }
  }
  for (const id of ['east','south'] as const) {
    const had = before.streets?.includes(id) ?? false
    const has = after.streets?.includes(id) ?? false
    if (had !== has) changes.push({ collection: 'streets', id, before: had, after: has })
  }
  if(before.pixel!==after.pixel)changes.push({collection:'pixel',id:'color',before:before.pixel??null,after:after.pixel??null})
  return changes
}

export function applyChanges(scene: SceneData, changes: SceneChange[]) {
  const result = structuredClone(scene)
  for (const { collection, id, before, after } of changes) {
    if(collection==='pixel'){
      if((result.pixel??null)!==before)return undefined
      if(after)result.pixel=after
      else delete result.pixel
      continue
    }
    if (collection === 'streets') {
      const sides = result.streets ?? []
      if (sides.includes(id) !== before) return undefined
      result.streets = after ? [...sides, id] : sides.filter(side => side !== id)
      continue
    }
    const list = result[collection]
    const index = list.findIndex(item => item.id === id)
    if (JSON.stringify(list[index] ?? null) !== JSON.stringify(before)) return undefined
    if (index === -1 && after) list.push(after)
    else if (after) list[index] = after
    else if (index !== -1) list.splice(index, 1)
  }
  return result
}

export function sceneAssets(scene: SceneData) {
  const assets = new Map<string, { id: string; kind: AssetKind }>()
  function visit(item: Item) {
    if (item.asset && (item.kind === 'glb' || item.kind === 'npc')) {
      const kind = item.kind === 'glb' ? 'glb' : 'png'
      assets.set(`${kind}:${item.asset}`, { id: item.asset, kind })
    }
    item.children?.forEach(visit)
  }
  scene.items.forEach(visit)
  scene.models.forEach(visit)
  return assets.values()
}

export type MemberRole = 'owner' | 'edit' | 'view'
export type RegionTile = { pixel?:string; key: string; room: string; owner: string; write: boolean; version: number; listed: boolean }
export type Presence = {
  id: string; name: string; role: Role; cell?: string; mode: 'overview' | 'edit' | 'walk' | 'view'
  selection?: string; pose?: { x: number; z: number; yaw: number }
  skin?: CharacterSkin
}
export type PresenceUpdate = Omit<Presence, 'id' | 'name' | 'role'>
export type RegionView = { estateRevision: number; id: string; name: string; member: string; role: MemberRole; tiles: RegionTile[]; people: Presence[] }
export type ActivityDestination = { room: string; region?: string; name: string; latest: string; last: number }
export type PublicActivity = { pixel?:string;
  key: string; latitude: number; longitude: number; plots: number; builders: number
  last: number; latest: string; names: string[]
  destinations?: ActivityDestination[]
}
