// Candidate centres come from the pointer, parcel edges and obstacle faces.
// Combining these axes also finds gaps at the intersection of two obstacles.
export function nearestBuildingSite(x:number,z:number,width:number,depth:number,size:number,step:number,
  obstacles:{x:number;z:number;width:number;depth:number}[]) {
  const limitX=(size-width)/2,limitZ=(size-depth)/2
  if(limitX<0 || limitZ<0)return
  function candidates(value:number,limit:number,edges:number[]){
    const snapped=step?Math.round(value/step)*step:value
    const near=edges.filter(v=>Math.abs(v-value)<=Math.min(step/2,1))
    near.sort((a,b)=>Math.abs(a-value)-Math.abs(b-value))
    return [...new Set([near[0]??snapped,...edges].map(v=>Math.max(-limit,Math.min(limit,v))))]
  }
  const xs=candidates(x,limitX,[-limitX,limitX,...obstacles.flatMap(o=>[o.x-(width+o.width)/2,o.x+(width+o.width)/2])])
  const zs=candidates(z,limitZ,[-limitZ,limitZ,...obstacles.flatMap(o=>[o.z-(depth+o.depth)/2,o.z+(depth+o.depth)/2])])
  let best:{x:number;z:number}|undefined,dist=Infinity
  for(const xx of xs)for(const zz of zs){
    const d=(xx-x)**2+(zz-z)**2
    if(d>=dist || obstacles.some(o=>Math.abs(xx-o.x)<(width+o.width)/2 && Math.abs(zz-o.z)<(depth+o.depth)/2))continue
    if(xx===xs[0] && zz===zs[0])return {x:xx,z:zz}
    best={x:xx,z:zz};dist=d
  }
  return best
}
