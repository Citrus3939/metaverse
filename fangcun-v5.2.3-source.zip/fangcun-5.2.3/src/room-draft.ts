import { newId, type SceneData } from './data'
import { sceneChanges, type SceneChange } from './collab-types'
import { RoomRequestError, type RoomClient } from './room'

type PendingDraft = { scene: SceneData; batches: SceneChange[][] }
export type SaveStatus = { pending: number; sending: boolean; error: string; conflict: boolean; durable: boolean }

export class RoomDraft {
  private readonly key: string
  private proposed: SceneData
  private draft: PendingDraft
  private status: SaveStatus = { pending: 0, sending: false, error: '', conflict: false, durable: true }
  private stopped = false

  constructor(private room: RoomClient, initial: SceneData, private changed: (status: SaveStatus) => void, private settled: () => void) {
    const tabKey = 'fangcun.draft-tab'
    const tab = sessionStorage.getItem(tabKey) ?? newId()
    sessionStorage.setItem(tabKey, tab)
    this.key = `fangcun.draft.${room.access.room}.${tab}`
    try {
      const stored = JSON.parse(localStorage.getItem(this.key) ?? 'null')
      this.draft = stored?.batches?.length && stored?.scene ? stored : { scene: initial, batches: [] }
    } catch { this.draft = { scene: initial, batches: [] } }
    this.proposed = structuredClone(this.draft.scene)
    if (this.draft.batches.length) this.status.error = '已恢复本机草稿。'
  }

  get scene() { return structuredClone(this.draft.scene) }
  get pending() { return this.draft.batches.length > 0 }
  updateServerScene(scene: SceneData) { this.proposed = structuredClone(scene) }
  stop() { this.stopped = true }
  report() {
    this.status.pending = this.draft.batches.length
    if (!this.stopped) this.changed({ ...this.status })
  }
  private store() {
    try {
      if (this.pending) localStorage.setItem(this.key, JSON.stringify(this.draft))
      else localStorage.removeItem(this.key)
      this.status.durable = true
    } catch { this.status.durable = false }
    this.report()
  }
  queue(scene: SceneData) {
    const changes = sceneChanges(this.proposed, scene)
    if (!changes.length) return
    this.proposed = structuredClone(scene)
    this.draft.scene = this.proposed
    this.draft.batches.push(changes)
    this.store()
    if (!this.status.error) void this.send()
  }
  async send(retry = false, resolveConflict = false) {
    if (!this.pending || this.status.sending || this.stopped) return
    this.status.sending = true
    this.status.error = ''
    this.status.conflict = false
    this.report()
    try {
      if (retry) await this.room.read()
      while (this.pending && !this.stopped) {
        if (this.room.latest?.role === 'view') throw new RoomRequestError('目前没有编辑权限。', 403)
        const latest = this.room.latest?.save.scene
        const changes: SceneChange[] = []
        for (const change of this.draft.batches[0]) {
          if(change.collection==='pixel'){
            const current=latest?.pixel??null
            if(current===change.after)continue
            if(!resolveConflict && current!==change.before)throw new RoomRequestError('地块颜色已被修改。',409)
            changes.push({...change,before:current})
            continue
          }
          if (change.collection === 'streets') {
            const current = latest ? latest.streets?.includes(change.id) ?? false : change.before
            if (current !== change.after) changes.push({ ...change, before: current })
            continue
          }
          const remote = latest ? latest[change.collection].find(item => item.id === change.id) ?? null : change.before
          if (JSON.stringify(remote) === JSON.stringify(change.after)) continue
          if (!resolveConflict && JSON.stringify(remote) !== JSON.stringify(change.before)) throw new RoomRequestError('同一个物件在共建区里也被修改了。', 409)
          changes.push({ ...change, before: remote })
        }
        await this.room.publish(changes)
        if (this.stopped) return
        this.draft.batches.shift()
        this.store()
      }
    } catch (error) {
      this.status.conflict = error instanceof RoomRequestError && error.status === 409
      this.status.error = this.status.conflict ? '同一个物件在共建区里也被修改了。'
        : error instanceof Error ? error.message : '暂时无法保存。'
    } finally {
      this.status.sending = false
      this.report()
      if (!this.stopped && !this.pending) this.settled()
    }
  }
}
