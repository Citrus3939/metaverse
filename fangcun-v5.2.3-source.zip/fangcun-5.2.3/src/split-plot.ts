import type { Save } from './data'
import { PLOT_SIZE, plotForCell, type PlotCell } from './plot-grid.ts'

export function childIndex(x: number, z: number) {
  return Number(x >= 0) + 2 * Number(z >= 0)
}
export function childOffset(index: number): [number, number] {
  return [(index % 2 - .5) * PLOT_SIZE, (Math.floor(index / 2) - .5) * PLOT_SIZE]
}
export function splitPlot(parent: PlotCell, scene: Save['scene']): Save[] {
  return Array.from({ length: 4 }, (_, i) => {
    const east = i % 2, south = Math.floor(i / 2)
    const [dx, dz] = childOffset(i)
    const items = structuredClone(scene.items.filter(item => childIndex(item.position[0], item.position[2]) === i))
    for (const item of items) {
      item.position[0] -= dx
      item.position[2] -= dz
    }
    return {
      plot: plotForCell({ column: 2 * parent.column + east, row: 2 * parent.row + south }),
      kept: true,
      scene: { items, models: structuredClone(scene.models), streets: scene.streets?.filter(side => side === 'east' ? east : south) },
    }
  })
}
