import roadEntries from './street-assets.json'
import { catalog } from './estate'
import { escapeHtml, icons } from './ui'

const categories = ['小摆件', '地板底图', '整体建筑', '功能性道具'] as const
type Entry = { name: string; category: typeof categories[number]; tags: string[]; file?: string; assetId?: string }

const entries: Entry[] = [
  { name: '夜町便利店', category: '整体建筑', tags: ['商店', '带内装', '独立建筑'], file: 'mart', assetId: '439629f2-b466-5b77-b5c3-49b1d433c526' },
  { name: '通勤自行车', category: '小摆件', tags: ['街边', '交通', '金属'], file: 'bicycle', assetId: '4d844284-75a7-5840-aa19-d44bc8232d2a' },
  { name: '分类垃圾桶', category: '小摆件', tags: ['店前', '环卫'], file: 'bins', assetId: '19b07bb1-8c5c-5493-b5ae-2659bc0b2797' },
  { name: '门口伞架', category: '小摆件', tags: ['店前', '金属'], file: 'umbrellas', assetId: 'a1560efb-42bf-5ec1-92c1-1b4e1813a8ce' },
  { name: '社区公告栏', category: '小摆件', tags: ['街边', '标识'], file: 'board', assetId: '671fc8b4-470f-54db-bfd7-ff6f4d5fa8f5' },
  ...roadEntries.map(entry => ({ ...entry, category: '地板底图' as const })),
  { name: '街角路灯', category: '功能性道具', tags: ['街边', '可开关', '照明'] },
  { name: '饮料售货机', category: '功能性道具', tags: ['店前', '购买饮料'] },
]

export const freeAssetIds = new Set(entries.map(entry => entry.assetId).filter(Boolean))
export const streetFiles = new Map(entries.filter(e=>e.assetId && e.file).map(e=>[e.assetId!, e.file!]))
export type LibraryAsset = {name:string;section:string;tags:string[];image?:string;kind?:string;file?:string;assetId?:string}
const library:LibraryAsset[]=[
  ...catalog.map(d=>({name:d.name,section:'经营建筑',tags:[d.theme],kind:d.id,image:'/estate/'+d.id+'.webp'})),
  ...entries.map(e=>({...e,section:e.category,image:e.file?'/street/'+e.file+'.webp':undefined}))
]
export const libraryMarkup = `<dialog id="street-library" class="app-dialog asset-palette" aria-label="素材库">
<header><h2>素材库</h2><button class="icon-button" data-close aria-label="关闭素材库">${icons.close}</button></header>
<input type="search" placeholder="搜索素材或标签" aria-label="搜索素材或标签">
<nav aria-label="素材分类">${['全部','经营建筑',...categories].map(c=>`<button data-category="${c}" aria-pressed="${c==='全部'}">${c}</button>`).join('')}</nav>
<div class="asset-symbols"></div><p class="asset-hint" role="status"></p></dialog>`

type Hooks = {
  describe:(a:LibraryAsset)=>string
  start:(a:LibraryAsset)=>Promise<boolean>
  move:(a:LibraryAsset,e:PointerEvent)=>void
  finish:(a:LibraryAsset,e:PointerEvent)=>void
  cancel:()=>void
}
export function mountStreetLibrary(dialog:HTMLDialogElement,canvas:HTMLCanvasElement,hooks:Hooks,signal:AbortSignal){
  const grid=dialog.querySelector<HTMLElement>('.asset-symbols')!,input=dialog.querySelector('input')!
  const hint=dialog.querySelector<HTMLElement>('.asset-hint')!
  let section='全部'
  type Drag={asset:LibraryAsset;pointer:number;last:PointerEvent;ready:boolean;released:boolean}
  let drag:Drag|undefined
  function render(){
    const words=input.value.trim().toLowerCase().split(/\s+/)
    grid.innerHTML=library.map((a,i)=>{
      if(section!=='全部' && section!==a.section || !words.every(w=>[a.name,a.section,...a.tags].join(' ').toLowerCase().includes(w)))return ''
      return `<button type="button" class="asset-symbol" data-index="${i}" aria-label="${escapeHtml(a.name)}" title="${escapeHtml(a.name+' · '+a.tags.join(' · ')+' · '+hooks.describe(a))}">${a.image?`<img src="${a.image}" alt="" draggable="false" loading="lazy">`:icons.box}</button>`
    }).join('') || '没有匹配的素材'
  }
  function target(e:Event){const el=(e.target as Element).closest<HTMLElement>('[data-index]');return el?library[Number(el.dataset.index)]:undefined}
  function inspect(e:Event){const a=target(e);if(a)hint.textContent=[a.name,...a.tags,hooks.describe(a)].join(' · ')}
  grid.addEventListener('pointerover',inspect);grid.addEventListener('focusin',inspect)
  function cancel(){if(drag){drag=undefined;hooks.cancel()}}
  function onCanvas(e:PointerEvent){return document.elementFromPoint(e.clientX,e.clientY)===canvas}
  function apply(d:Drag){
    if(drag!==d || !d.ready)return
    if(d.released){
      drag=undefined
      if(onCanvas(d.last))hooks.finish(d.asset,d.last)
      else hooks.cancel()
    }else if(onCanvas(d.last))hooks.move(d.asset,d.last)
  }
  grid.onpointerdown=async e=>{
    const asset=target(e)
    if(!asset || e.button!==0 || drag)return
    e.preventDefault();grid.setPointerCapture(e.pointerId)
    const d:Drag={asset,pointer:e.pointerId,last:e,ready:false,released:false};drag=d
    hint.textContent=asset.name+' · '+hooks.describe(asset)
    try{d.ready=await hooks.start(asset);if(!d.ready && drag===d)cancel();else apply(d)}
    catch{if(drag===d){cancel();hint.textContent='素材读取失败，请重新拖动。'}}
  }
  grid.onpointermove=e=>{if(drag?.pointer===e.pointerId){drag.last=e;apply(drag)}}
  grid.onpointerup=e=>{if(drag?.pointer===e.pointerId){drag.last=e;drag.released=true;apply(drag)}}
  grid.onpointercancel=cancel
  grid.onlostpointercapture=()=>{if(!drag?.released)cancel()}
  window.addEventListener('blur',cancel,{signal})
  dialog.onclose=cancel
  dialog.querySelector<HTMLElement>('[data-close]')!.onclick=()=>dialog.close()
  dialog.querySelectorAll<HTMLButtonElement>('[data-category]').forEach(button=>button.onclick=()=>{
    section=button.dataset.category!
    dialog.querySelectorAll('[data-category]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)))
    render()
  })
  input.oninput=render
  signal.addEventListener('abort',cancel,{once:true})
  return ()=>{render();hint.textContent='悬浮查看详情，拖入地块放置';if(!dialog.open)dialog.show()}
}
