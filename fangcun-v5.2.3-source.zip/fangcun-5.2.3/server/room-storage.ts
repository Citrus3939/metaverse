import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { database } from './estate-store.ts'
import { base, HttpError } from './collab-http.ts'

// Older rooms live in individual files. New writes share the same SQLite
// transaction as the parcel index, allowing a move to commit both rooms.
export function roomData(id:string):string {
  const stored=database().prepare('SELECT data FROM room_state WHERE room=?').get(id)
  if(stored)return String(stored.data)
  const file=join(base,id,'room.json')
  if(!existsSync(file))throw new HttpError(404,'找不到这个地块。')
  return readFileSync(file,'utf8')
}
export function storeRoom(id:string,room:unknown){
  database().prepare('INSERT INTO room_state VALUES(?,?) ON CONFLICT(room) DO UPDATE SET data=excluded.data').run(id,JSON.stringify(room))
}
