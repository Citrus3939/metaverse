import type { DatabaseSync } from 'node:sqlite'
import { createHash } from 'node:crypto'
import { copyFileSync, existsSync, readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { base, writeJson } from './collab-http.ts'
import type { Region } from './estate-store.ts'
import type { Save } from '../src/data.ts'
import type { Building, Offer } from '../src/estate.ts'
import { parseCell, plotKey } from '../src/plot-grid.ts'
import { splitPlot, childIndex, childOffset } from '../src/split-plot.ts'

// Files get deterministic new names. SQLite publishes the new addresses at commit.
export function migrateGrid(db: DatabaseSync) {
  if (db.prepare('PRAGMA user_version').get()?.user_version) return
  const addresses = new Map<string, {room: string; cell: string}[]>()
  for (const row of db.prepare('SELECT id,data FROM regions').all()) {
    const region: Region = JSON.parse(String(row.data))
    const parents = Object.values(region.tiles)
    region.tiles = {}
    for (const parent of parents) {
      const cell = parseCell(parent.key)
      if (!cell) throw Error('无效的旧地块坐标 ' + parent.key)
      const source = join(base, parent.room)
      const file = join(source, 'room.json')
      const room = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : {owner:'', members:{}, invites:{}, version:parent.version}
      const children = splitPlot(cell, (room.save as Save | undefined)?.scene ?? {items:[],models:[]})
      const refs = []
      for (const [index,save] of children.entries()) {
        const id = createHash('sha256').update('grid50/' + parent.room + '/' + index).digest('hex').slice(0,24)
        const key = plotKey(save.plot), dir = join(base,id)
        writeJson(dir,'room.json',{...room,region:row.id,save})
        if (existsSync(source)) for (const name of readdirSync(source)) {
          if (/\.(glb|png)$/.test(name)) copyFileSync(join(source,name),join(dir,name))
        }
        region.tiles[key] = {...parent,key,room:id}
        db.prepare('INSERT INTO plots VALUES(?,?,?)').run(id,key,row.id)
        db.prepare('INSERT INTO business_edits SELECT ?,player,name,time FROM business_edits WHERE room=?').run(id,parent.room)
        if (parent.listed && room.activity) writeJson(join(base,'activity'),id+'.json',{...room.activity,cell:key,region:row.id,name:region.name})
        refs.push({room:id,cell:key})
      }
      addresses.set(parent.room,refs)
      db.prepare('DELETE FROM plots WHERE room=?').run(parent.room)
    }
    db.prepare('UPDATE regions SET data=? WHERE id=?').run(JSON.stringify(region),row.id)
  }
  const row = db.prepare('SELECT data FROM economy WHERE id=1').get()
  if (row) {
    const game = JSON.parse(String(row.data)) as {buildings:Building[];offers:Offer[];revision:number}
    for (const building of game.buildings) {
      const site=building.site, children=site && addresses.get(site.room)
      if (!site || !children) continue
      const index=childIndex(site.x,site.z), [dx,dz]=childOffset(index)
      Object.assign(site,children[index]); site.x-=dx; site.z-=dz
    }
    game.offers=game.offers.filter(offer => offer.type!=='land' || !addresses.has(offer.ref))
    game.revision++
    db.prepare('UPDATE economy SET data=? WHERE id=1').run(JSON.stringify(game))
  }
  db.exec('PRAGMA user_version=1')
}
