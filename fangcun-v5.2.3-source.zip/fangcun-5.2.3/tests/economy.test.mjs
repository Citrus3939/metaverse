import assert from 'node:assert/strict'
import { randomBytes, randomUUID } from 'node:crypto'
import { test } from 'node:test'
import { mkdtempSync, readFileSync, rmSync, mkdirSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createServer } from 'node:http'
import { createServer as viteServer } from 'vite'
import { DatabaseSync } from 'node:sqlite'

test('共建地块与街坊经营的授权、结算和重试', async (context) => {
  const folder = mkdtempSync(join(tmpdir(), 'fangcun-economy-'))
  process.env.FANGCUN_ROOM_DIR = folder
  const vite = await viteServer({ server: { middlewareMode: true, hmr: false }, logLevel: 'error' })
  const http = createServer(vite.middlewares)
  await new Promise((resolve) => http.listen(0, '127.0.0.1', resolve))
  context.after(async () => {
    http.closeAllConnections()
    await new Promise((resolve) => http.close(resolve))
    await vite.close()
    // On Windows the temporary SQLite database is released when the test process ends.
    try {
      rmSync(folder, { recursive: true, force: true })
    } catch {}
  })
  const origin = 'http://127.0.0.1:' + http.address().port

  const base = origin + '/collab/',
    cellR = -1350,
    col = 2000 + Math.floor(Math.random() * 70000),
    cell = col + ':' + cellR,
    east = col + 1 + ':' + cellR
  const passport = () => randomBytes(32).toString('hex')
  const player = () => ({ passport: passport() })
  const legacyRegion='f'.repeat(24), legacyToken='d'.repeat(64),legacyRoom='e'.repeat(24),legacyCell='700:300'
  const legacy={passport:passport(),room:legacyRegion,token:legacyToken}
  const legacyPath=join(folder,'regions',legacyRegion)
  mkdirSync(legacyPath,{recursive:true})
  writeFileSync(join(legacyPath,'region.json'),JSON.stringify({
    name:'老街',members:{[legacyToken]:{id:'d'.repeat(16),name:'原住民',role:'owner'}},invites:{},
    tiles:{[legacyCell]:{key:legacyCell,room:legacyRoom,owner:'d'.repeat(16),write:true,version:8,listed:false}}
  }))
  const oldItem={id:randomUUID(),name:'旧模型',kind:'box',position:[32,1,-4],scale:[1,1,1],rotation:[0,0,0]}
  mkdirSync(join(folder,legacyRoom))
  writeFileSync(join(folder,legacyRoom,'room.json'),JSON.stringify({region:legacyRegion,version:8,owner:legacyToken,members:{},invites:{},save:{scene:{items:[oldItem],models:[],streets:['east']}}}))
  const rareFarms = await (await fetch(base + 'catalog?sector=farming&rarity=rare')).json()
  assert.deepEqual(
    rareFarms.map((b) => b.id),
    ['windmill']
  )
  const A = player(),
    B = player(),
    V = player(),
    C = player()
  async function call(a, path, body, expected = 200) {
    const r = await fetch(base + path, {
      method: body === undefined ? 'GET' : 'POST',
      headers: {
        Authorization: 'Bearer ' + (a.token ?? ''),
        'X-Fangcun-Passport': a.passport,
        'Content-Type': 'application/json',
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    })
    const value = await r.json()
    if (r.status !== expected)
      throw Error(path + ' ' + r.status + ' wanted ' + expected + ': ' + JSON.stringify(value).slice(0, 200))
    return value
  }
  const path = (a, action) => 'region/' + a.room + '/' + action
  const cmd = async (a, command, status = 200, nonce = randomUUID()) =>
    call(a, path(a, 'estate'), { command, nonce }, status)
  const state = (a) => call(a, path(a, 'estate'))
  const create = async (a, cell, name) =>
    Object.assign(a, await call(a, 'region/create', { cell, name, nickname: name }, 201))
  const old=await call(legacy,'region/'+legacyRegion+'/state')
  assert.equal(old.tiles.length,4)
  const eastChild=old.tiles.find(t=>t.key==='1401:600')
  const migrated=await call(legacy,eastChild.room+'/state')
  assert.deepEqual(migrated.save.scene.items[0].position,[7,1,21])
  assert.deepEqual(migrated.save.scene.streets,['east'])
  assert.equal(migrated.save.plot.width,50)
  await call(legacy,legacyRoom+'/state',undefined,410)
  assert.equal(old.tiles[0].version,8)
  assert.equal(old.tiles[0].owner,old.member)
  assert.equal((await state(legacy)).coins,800)
  assert.equal((await call(legacy,'region/availability',{cell:old.tiles[0].key})).occupied,true)
  await create(A, cell, '灯街主人')
  const RV = () => call(A, path(A, 'state'))
  let av = await RV(),
    title = av.tiles[0],
    aId = av.member
  async function invite(a, b, name, grant = 'edit') {
    const { invite } = await call(a, path(a, 'invite'), { grant }, 201)
    Object.assign(b, await call(b, path(a, 'join'), { invite, nickname: name }, 201))
  }
  await invite(A, B, '访市友人')
  await invite(A, V, '旁观客', 'view')
  await invite(A, C, '买家')
  const color={collection:'pixel',id:'color',before:null,after:'#ab1243'}
  await call(V,title.room+'/state',{changes:[color]},403)
  await call(A,title.room+'/state',{changes:[color]})
  assert.equal((await call(B,title.room+'/state')).save.scene.pixel,color.after)
  assert.equal((await RV()).tiles.find(t=>t.room===title.room).pixel,color.after)
  await call(B,title.room+'/state',{changes:[{...color,after:'#aaaaaa'}]},409)
  const bId = (await call(B, path(B, 'state'))).member
  assert.equal((await state(A)).coins, 800)
  await call(B, 'region/create', { cell, name: '重复地', nickname: '乙' }, 409)
  await call(B, path(B, 'add'), { cell: col + 5 + ':' + cellR }, 409)
  await call(B, path(B, 'add'), { cell: east })
  assert.equal((await state(B)).coins, 560)
  const peerPlot = (await RV()).tiles.find((t) => t.key === east)
  const holdings=await call(A,'region/holdings')
  assert.equal(holdings.find(t=>t.cell===cell).pixel,color.after)
  assert.ok(!(await call(V,'region/holdings')).some(t=>t.cell===cell))
  const buyDrop={type:'buy-place',kind:'kissaten',cell,x:25,z:0,angle:0}
  await cmd(A,buyDrop,409)
  assert.equal((await state(A)).coins,800)
  assert.equal((await state(A)).inventory.length,0)
  await cmd(V,{...buyDrop,x:0},403)
  const movable={...oldItem,id:randomUUID(),position:[0,1,0]}
  await call(A,title.room+'/state',{changes:[{collection:'items',id:movable.id,before:null,after:movable}]})
  const transfer={before:movable,after:{...movable,position:[4,1,3]},target:peerPlot.room}
  await call(V,title.room+'/move-item',transfer,403)
  await call(A,title.room+'/move-item',transfer)
  await call(A,title.room+'/move-item',transfer,409)
  assert.ok(!(await call(A,title.room+'/state')).save.scene.items.some(i=>i.id===movable.id))
  assert.deepEqual((await call(B,peerPlot.room+'/state')).save.scene.items.find(i=>i.id===movable.id),transfer.after)
  await cmd(V, { type: 'buy', kind: 'kissaten' }, 403)
  await cmd(B, { type: 'list', assetType: 'land', ref: title.room, price: 1 }, 409)
  const nonce = randomUUID()
  const buy = { type: 'buy', kind: 'kissaten' }
  const [b1, b2] = await Promise.all([cmd(A, buy, 200, nonce), cmd(A, buy, 200, nonce)])
  assert.equal(b1.estate.coins, b2.estate.coins)
  assert.equal((await state(A)).inventory.length, 1)
  const id = b1.estate.inventory[0].id
  await cmd(A, { type: 'place', id, cell, x: 47, z: 0, angle: 90 }, 409)
  const position={type:'position',id,cell,x:-18,z:-10,angle:90,before:null}
  await cmd(B,position,403)
  const placed=await cmd(A,position)
  assert.equal(placed.estate.buildings.find(b=>b.id===id).site.active,false)
  await cmd(A,position,409)
  await cmd(A,{type:'operate',id,cell,active:true})
  const moved=await cmd(B,{...position,x:-17,before:position})
  assert.equal(moved.estate.buildings.find(b=>b.id===id).site.active,true)
  const buyPlace = async (actor, kind, x, z, where = cell) => {
    const i = await cmd(actor, { type: 'buy', kind })
    const b = i.estate.inventory.at(-1)
    await cmd(actor, { type: 'place', id: b.id, cell: where, x, z, angle: 0 })
    return b.id
  }
  await buyPlace(A, 'kissaten', 0, -10)
  await buyPlace(A, 'teagarden', 16, 3)
  const before = await cmd(A, { type: 'buy', kind: 'atelier' })
  const extra = before.estate.inventory.at(-1).id
  await cmd(A, { type: 'place', id: extra, cell, x: 1, z: 16, angle: 0 }, 409)
  await cmd(A, { type: 'place', id: extra, cell, x: 1, z: 16, angle: 0, active: false })
  await cmd(A, { type: 'place', id: extra, cell, x: 1, z: 16, angle: 0, active: true }, 409)
  await cmd(A, { type: 'store', id: extra })
  // Piggyback on the existing room asset API to test recruitment from a real PNG NPC.
  const npcSkin = randomUUID(),
    npcId = randomUUID()
  const png = readFileSync(new URL('../src/assets/steve.png', import.meta.url))
  const uploaded = await fetch(base + title.room + '/skin/' + npcSkin, {
    method: 'PUT',
    headers: { Authorization: 'Bearer ' + A.token },
    body: png,
  })
  assert.equal(uploaded.status, 200)
  const npc = {
    id: npcId,
    kind: 'npc',
    name: '巡街师傅',
    position: [0, 0, 0],
    rotation: [0, 0, 0],
    scale: [1, 1, 1],
    asset: npcSkin,
    npc: { body: 'classic', greeting: '你好', persona: '街边的店长', knowledge: '', ai: true },
  }
  await call(A, title.room + '/state', { changes: [{ collection: 'items', id: npcId, before: null, after: npc }] })
  const group = await state(A),
    crew = group.crew.filter((c) => c.owner === aId)
  const recruitment = await cmd(A, { type: 'recruit', staff: crew[0].id, cell, npc: npcId })
  const hire = recruitment.estate.crew.find((w) => w.id === crew[0].id)
  assert.equal(hire.name, '巡街师傅')
  const picture = await fetch(base + path(A, 'worker-skin/' + hire.appearance.skin), {
    headers: { Authorization: 'Bearer ' + A.token },
  })
  assert.equal(picture.status, 200)
  assert.deepEqual(Buffer.from(await picture.arrayBuffer()), png)
  await cmd(A, { type: 'chat', text: '请去上班', cell, staff: crew[0].id, work: id })
  await cmd(A, { type: 'work', staff: crew[1].id, building: id })
  await cmd(B, { type: 'work', staff: (await state(B)).crew.find((c) => c.owner === bId).id, building: id }, 409)
  await cmd(B, { type: 'work', staff: crew[0].id, building: id }, 403)
  const clue = await cmd(A, { type: 'chat', text: '查看地图', cell, staff: crew[0].id })
  assert.match(clue.result, /相邻已接入 1 格/)
  assert.equal((await state(B)).chat.at(-1).text, clue.result)
  await cmd(A, { type: 'profile', tags: ['商人', '摄影师'] })
  assert.deepEqual((await state(B)).profiles.find((p) => p.id === aId).tags, ['商人', '摄影师'])
  await cmd(A, { type: 'pay', to: bId, amount: 13 })
  assert.equal((await state(B)).coins, 573)
  const offer = (await cmd(A, { type: 'list', assetType: 'asset', ref: extra, price: 50 })).estate.offers.find(
    (o) => o.ref === extra
  )
  await cmd(A, { type: 'place', id: extra, cell, x: 25, z: 17, angle: 0 }, 409)
  const result = await Promise.allSettled([
    cmd(B, { type: 'take', id: offer.id }),
    cmd(C, { type: 'take', id: offer.id }),
  ])
  assert.equal(result.filter((r) => r.status === 'fulfilled').length, 1)
  const land = (await cmd(A, { type: 'list', assetType: 'land', ref: title.room, price: 100000 })).estate.offers.find(
    (o) => o.ref === title.room
  )
  await cmd(B, { type: 'take', id: land.id }, 409)
  assert.equal((await RV()).tiles.find((t) => t.key === cell).owner, aId)
  await cmd(A, { type: 'cancel', id: land.id })
  const actual = (await cmd(A, { type: 'list', assetType: 'land', ref: title.room, price: 70 })).estate.offers.find(
    (o) => o.ref === title.room
  )
  await cmd(B, { type: 'take', id: actual.id })
  assert.equal((await RV()).tiles.find((t) => t.key === cell).owner, bId)
  assert.equal((await call(A, title.room + '/state')).role, 'view')
  assert.equal((await call(B, title.room + '/state')).role, 'owner')
  assert.equal(
    (await state(A)).inventory.filter((b) => [id, ...group.buildings.map((x) => x.id)].includes(b.id)).length,
    3
  )
  await call(B, path(B, 'write'), { cell, enabled: true })
  assert.equal((await call(A, title.room + '/state')).role, 'edit')
  await cmd(B, { type: 'draw' })
  await cmd(B, { type: 'draw' })
  const neighbor = col + 2 + ':' + cellR
  const orig = { passport: B.passport }
  await create(orig, neighbor, '第二街坊')
  const cid = (await call(orig, path(orig, 'state'))).tiles[0].room
  assert.ok((await state(B)).coins <= 573 - 200)
  assert.equal((await call(B, path(B, 'quote'), { cell: neighbor })).kind, 'mine')
  await call(B, path(B, 'attach'), { cell: neighbor })
  assert.equal((await call(orig, path(orig, 'state'))).tiles.length, 0)
  assert.equal((await call(B, cid + '/state')).role, 'owner')
  await call(orig, cid + '/state', undefined, 403)
  await call(C, path(C, 'write'), { cell: east, enabled: false }, 403)
  const target = (await state(B)).inventory.at(-1)
  await cmd(B, { type: 'place', id: target.id, cell: east, x: 0, z: 0, angle: 0 })

  // Advance only the fixture's persisted clock. The next real HTTP operation settles production.
  const db = new DatabaseSync(join(folder, 'world.sqlite'))
  const fixture = JSON.parse(db.prepare('SELECT data FROM economy').get().data)
  fixture.at -= 600000
  fixture.players[bId].misses = 9
  db.prepare('UPDATE economy SET data=?').run(JSON.stringify(fixture))
  db.close()
  const grown = await state(B)
  const kind = Object.keys(grown.goods).find((k) => grown.goods[k] >= 2)
  assert.ok(kind)
  const sale = await cmd(B, { type: 'list', assetType: 'goods', ref: kind, qty: 2, price: 11 })
  const listing = sale.estate.offers.find((o) => o.type === 'goods' && o.seller === bId)
  await cmd(A, { type: 'take', id: listing.id })
  const deliveries = await cmd(A, { type: 'redeem', kind, qty: 2 })
  assert.ok(deliveries.estate.coins >= 16)
  await cmd(A, { type: 'pay', to: bId, amount: 100 })
  const guaranteed = await cmd(B, { type: 'draw' })
  assert.match(guaranteed.result, /稀有建筑/)
  assert.equal(guaranteed.estate.misses, 0)
  const claimant = player()
  const claim = (cell, price, status = 200) => call(claimant, 'region/claim', { cell, price }, status)
  const first = await claim('400:21', 0)
  assert.equal(first.charged, 0)
  await claim('402:21', 240, 409)
  await claim('401:21', 0, 409)
  const retries = await Promise.all([claim('401:21', 240), claim('401:21', 240)])
  assert.deepEqual(retries.map(r => r.charged).sort((a,b) => a-b), [0, 240])
  assert.ok(retries.every(r => r.balance === first.balance - 240 && r.room === first.room))

})
