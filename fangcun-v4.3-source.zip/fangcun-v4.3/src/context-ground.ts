import * as T from 'three'
import { cellKey, gridLatitude, gridLongitude, PLOT_SIZE, type PlotCell } from './plot-grid'

const zoom = 18
const tiles = 2 ** zoom
const tileSize = 256
type Provider = 'hot' | 'esri'
const tileCache = new Map<string, Promise<HTMLImageElement>>()
const mapX = (longitude: number) => (longitude + 180) / 360 * tiles * tileSize
const mapY = (latitude: number) => (.5 - Math.asinh(Math.tan(latitude * Math.PI / 180)) / (2 * Math.PI)) * tiles * tileSize

function imageFor(provider: Provider, x: number, y: number) {
  const col = (x % tiles + tiles) % tiles
  const url = `/map-tiles/${provider}/${zoom}/${col}/${y}`
  const known = tileCache.get(url)
  if (known) return known
  const loader = new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = () => reject(new Error('地图瓦片无法加载'))
    img.src = url
  })
  tileCache.set(url, loader)
  loader.catch(() => tileCache.delete(url))
  if (tileCache.size > 96) tileCache.delete(tileCache.keys().next().value!)
  return loader
}

async function crop(cell: PlotCell, provider: Provider) {
  const x = mapX(gridLongitude(cell.column - 1))
  const y = mapY(gridLatitude(cell.row - 1))
  const width = mapX(gridLongitude(cell.column + 2)) - x
  const height = mapY(gridLatitude(cell.row + 2)) - y
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = 768
  const ctx = canvas.getContext('2d')!
  ctx.filter = 'saturate(.56)'
  const work = []
  for (let col = Math.floor(x / tileSize); col < Math.ceil((x + width) / tileSize); col++) {
    for (let row = Math.floor(y / tileSize); row < Math.ceil((y + height) / tileSize); row++) {
      if (row < 0 || row >= tiles) throw new Error('已到地图范围边缘')
      work.push(imageFor(provider, col, row).then(img => {
        ctx.setTransform(canvas.width / width, 0, 0, canvas.height / height, -x * canvas.width / width, -y * canvas.height / height)
        ctx.drawImage(img, col * tileSize, row * tileSize)
      }))
    }
  }
  await Promise.all(work)
  ctx.resetTransform()
  ctx.filter = 'none'
  return canvas
}

export class ContextGround {
  private staticTexture?: HTMLCanvasElement
  private activeMap?: T.CanvasTexture
  private revision = 0
  private tint = '#bedce7'
  private cell?: PlotCell
  private regionCells = new Set<string>()
  private buildCells: number[] = []
  private surface: T.Mesh<T.PlaneGeometry, T.MeshBasicMaterial>
  private nearLines: T.LineSegments<T.BufferGeometry, T.LineBasicMaterial>
  readonly object = new T.Group()

  constructor(private status: (provider?: Provider) => void) {
    const size = PLOT_SIZE * 3
    this.surface = new T.Mesh(new T.PlaneGeometry(size, size), new T.MeshBasicMaterial({ transparent: true }))
    this.surface.rotation.x = -Math.PI / 2
    this.surface.position.y = -.012
    const positions: number[] = []
    for (const split of [-.5, .5]) {
      positions.push(split * PLOT_SIZE, -.004, -size / 2, split * PLOT_SIZE, -.004, size / 2)
      positions.push(-size / 2, -.004, split * PLOT_SIZE, size / 2, -.004, split * PLOT_SIZE)
    }
    const geo = new T.BufferGeometry().setAttribute('position', new T.Float32BufferAttribute(positions, 3))
    this.nearLines = new T.LineSegments(geo, new T.LineBasicMaterial({ transparent: true, opacity: .39 }))
    this.object.add(this.surface, this.nearLines)
  }

  theme(ground: string, line: string) {
    this.tint = ground
    this.nearLines.material.color.set(line)
    this.paint()
  }

  setRegionCells(keys: string[]) {
    this.regionCells = new Set(keys)
    const cells = this.visibleBuildCells()
    if (cells.length === this.buildCells.length && cells.every((cell, i) => cell === this.buildCells[i])) return
    this.buildCells = cells
    this.paint()
  }

  private visibleBuildCells() {
    const cells: number[] = []
    if (!this.cell || !this.regionCells.size) return cells
    for (let row = 0; row < 3; row++) {
      for (let column = 0; column < 3; column++) {
        const key = cellKey({ column: this.cell.column + column - 1, row: this.cell.row + row - 1 })
        if (this.regionCells.has(key)) cells.push(row * 3 + column)
      }
    }
    return cells
  }

  private paint() {
    const canvas = document.createElement('canvas')
    canvas.width = canvas.height = 768
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = this.tint
    ctx.fillRect(0, 0, 768, 768)
    if (this.staticTexture) {
      ctx.globalAlpha = .53
      ctx.drawImage(this.staticTexture, 0, 0)
      ctx.globalAlpha = 1
    }
    // Feather the far edges into the viewport, keeping adjoining cells level.
    ctx.globalCompositeOperation = 'destination-in'
    for (const [x, y] of [[768, 0], [0, 768]]) {
      const edge = ctx.createLinearGradient(0, 0, x, y)
      edge.addColorStop(0, '#0000')
      edge.addColorStop(.13, '#000')
      edge.addColorStop(.87, '#000')
      edge.addColorStop(1, '#0000')
      ctx.fillStyle = edge
      ctx.fillRect(0, 0, 768, 768)
    }
    // Connected cells share the map plane but remain opaque, even at the feathered edge.
    ctx.globalCompositeOperation = 'source-over'
    ctx.fillStyle = this.tint
    const cellSize = canvas.width / 3
    for (const index of this.buildCells) {
      ctx.fillRect(index % 3 * cellSize, Math.floor(index / 3) * cellSize, cellSize, cellSize)
    }
    const texture = new T.CanvasTexture(canvas)
    texture.colorSpace = T.SRGBColorSpace
    this.activeMap?.dispose()
    this.activeMap = texture
    this.surface.material.map = texture
    this.surface.material.needsUpdate = true
  }

  async show(cell: PlotCell, x: number, z: number) {
    const rev = ++this.revision
    this.cell = cell
    this.buildCells = this.visibleBuildCells()
    this.object.position.set(x, 0, z)
    this.staticTexture = undefined
    this.paint()
    this.status()
    for (const provider of ['hot', 'esri'] as const) {
      try {
        const asset = await crop(cell, provider)
        if (rev !== this.revision) return
        this.staticTexture = asset
        this.paint()
        this.status(provider)
        return
      } catch {
        if (rev !== this.revision) return
      }
    }
  }
  dispose() {
    this.revision++
    this.activeMap?.dispose()
    this.surface.material.dispose()
    this.surface.geometry.dispose()
    this.nearLines.material.dispose()
    this.nearLines.geometry.dispose()
    this.staticTexture = undefined
  }
}
