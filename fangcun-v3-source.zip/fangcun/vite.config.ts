import { defineConfig, type Connect } from 'vite'
import { collaboration } from './server/collab.ts'
import { EnvHttpProxyAgent, fetch } from 'undici'

const dispatcher = new EnvHttpProxyAgent()
const templates = {
  hot: (z: number, x: number, y: number) => `https://a.tile.openstreetmap.fr/hot/${z}/${x}/${y}.png`,
  esri: (z: number, x: number, y: number) => `https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/${z}/${y}/${x}`,
}
type Tile = { content: Buffer; type: string; control: string; expires: number }
const cache = new Map<string, Promise<Tile>>()
const tiles: Connect.NextHandleFunction = async (request, response, next) => {
  const route = request.url?.match(/^\/map-tiles\/(hot|esri)\/(\d{1,2})\/(\d{1,7})\/(\d{1,7})$/)
  if (!route || request.method !== 'GET') { next(); return }
  const [, style, rawZ, rawX, rawY] = route
  const [z, x, y] = [Number(rawZ), Number(rawX), Number(rawY)]
  if (z > 19 || x >= 2 ** z || y >= 2 ** z) { response.writeHead(400).end(); return }
  const url = templates[style as keyof typeof templates](z, x, y)
  let entry = cache.get(url)
  if (entry) {
    const tile = await entry.catch(() => undefined)
    if (!tile || tile.expires <= Date.now()) {
      cache.delete(url)
      entry = undefined
    }
  }
  if (!entry) {
    entry = fetch(url, {
      dispatcher, signal: AbortSignal.timeout(8000),
      headers: { 'User-Agent': 'FangcunLandStudio/1.0 (local interactive map)' },
    }).then(async upstream => {
      const type = upstream.headers.get('content-type') ?? ''
      if (!upstream.ok || !type.startsWith('image/')) throw new Error('Tile unavailable')
      const control = upstream.headers.get('cache-control') ?? 'public, max-age=86400'
      const maxAge = Number(control.match(/max-age=(\d+)/)?.[1] ?? 86400)
      return { content: Buffer.from(await upstream.arrayBuffer()), type, control, expires: Date.now() + maxAge * 1000 }
    })
    if (cache.size >= 384) cache.delete(cache.keys().next().value!)
    cache.set(url, entry)
  }
  try {
    const tile = await entry
    response.writeHead(200, { 'Content-Type': tile.type, 'Cache-Control': tile.control }).end(tile.content)
  } catch {
    cache.delete(url)
    response.writeHead(502).end()
  }
}

export default defineConfig({
  server: { fs: { deny: ['.env', '.env.*', '*.{crt,pem}', '**/.git/**', '**/.fangcun-rooms/**', ...(process.env.FANGCUN_ROOM_DIR ? [`${process.env.FANGCUN_ROOM_DIR}/**`] : [])] } },
  plugins: [{
    name: 'same-origin-map-tiles',
    configureServer(server) { server.middlewares.use(collaboration); server.middlewares.use(tiles) },
    configurePreviewServer(server) { server.middlewares.use(collaboration); server.middlewares.use(tiles) },
  }],
})
