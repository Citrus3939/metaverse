import * as T from 'three'
import { $, button, escapeHtml, icons } from './ui'
import { area, distance, EMPTY, getAsset, newId, newItem, putAsset, SHAPES, type Item, type Primitive, type Save, type SceneData, type Vec } from './data'
import { applyItem, boundsOf, buildItem, fits, parseCharacter, parseGlb, prepareItemAssets, rememberAsset, setAssetProvider, World } from './world'
import { previewModel } from './import-preview'
import { blockCharacter } from './character'
import { createRoom, roleNames, RoomRequestError, type RoomClient } from './room'
import { plotKey } from './plot-grid'
import { sceneChanges, type Role, type RoomView } from './collab-types'

const names = { ...SHAPES, group: '组合模型', glb: 'GLB 模型' }
const shapeIcons = { box: icons.box, sphere: icons.circle, cylinder: icons.cylinder, group: icons.group, glb: icons.package }
const modes = { translate: { name: '移动', icon: icons.move }, rotate: { name: '旋转', icon: icons.rotate }, scale: { name: '缩放', icon: icons.scaling } }
const axes = ['X', 'Y', 'Z']
const format = (n: number) => Number(n.toFixed(5)).toString()
const degrees = 180 / Math.PI
const add = (a: Vec, b: Vec): Vec => [a[0] + b[0], a[1] + b[1], a[2] + b[2]]

type RoomOptions = { client?: RoomClient; ownerRoom: (client: RoomClient) => void }

export function editorPage(root: HTMLElement, initial: Save, onSave: (value: Save) => void, options: RoomOptions) {
  const plot = initial.plot
  let data: SceneData = structuredClone(initial.scene)
  let ids: string[] = []
  let walking = false
  let observing = false
  let modeChanging = false
  let room = options.client
  let role: Role = room?.latest?.role ?? 'owner'
  let connected = true
  let sharing = false
  let unsubscribe: (() => void) | undefined
  let proposed = structuredClone(data)
  let queued = 0
  let epoch = 0
  let queue = Promise.resolve()
  let leveling = false
  const canEdit = () => role !== 'view' && connected && !sharing && !walking && !observing && !modeChanging
  const holdingEdit = () => world.interacting || !!change || !!$('inspector').contains(document.activeElement)
  setAssetProvider(room ? id => room!.downloadAsset(id) : undefined)
  let grid = true
  let snap = false
  let placing = false
  let closed = false
  let change: { id: string; result: Item; valid: boolean } | undefined
  let mode: keyof typeof modes = 'translate'
  const history: SceneData[] = []
  let toastTimer = 0
  const listeners = new AbortController()
  root.innerHTML = `
    <div class="editor-head">
      <div class="editor-title"><div class="editor-title-icon">${icons.box}</div><div><h1>我的地块</h1><p>${distance(plot.width)} × ${distance(plot.depth)} <span>·</span> ${area(plot.width * plot.depth)} <span>·</span> 地块 ${plotKey(plot)}</p></div></div>
      <div class="editor-head-actions">
      <button class="secondary" id="room-btn">${icons.group} <span>邀请共建</span></button>
      <div class="mode-toggle" aria-label="工作模式">
        <button class="active" id="edit-mode" aria-pressed="true">${icons.cursor} 编辑模式</button>
        <button id="walk-mode" aria-pressed="false">${icons.person} 行走模式</button>
        <button id="observe-mode" aria-pressed="false">${icons.compass} 45° 观赏</button>
      </div>
      </div>
    </div>
    <div class="editor-body">
      <aside class="editor-sidebar editor-assets">
        <div class="eyebrow">建造</div>
        <h2>添加形状</h2>
        <div class="shape-list" id="primitives">${(Object.keys(SHAPES) as Primitive[]).map(kind => `<button class="shape" data-shape="${kind}"><span>${shapeIcons[kind]}</span>${SHAPES[kind]}</button>`).join('')}</div>
        <button class="secondary full" id="import-btn">${icons.upload} 导入 GLB</button>
        <input type="file" id="import-file" accept=".glb,model/gltf-binary" hidden>
        <div class="character-buttons">
          <button class="secondary full" id="character-btn">${icons.person} 导入行走角色</button>
          <button class="subtle" id="character-reset" hidden>恢复默认角色</button>
          <input type="file" id="character-file" accept=".glb,model/gltf-binary" hidden>
        </div>
        <div class="editor-rule"></div>
        <div class="subheading"><h2>场景物件</h2><small id="object-count"></small></div>
        <div id="scene-list" class="item-list"></div>
        <div class="editor-rule"></div>
        <div class="subheading"><h2>我的模型</h2><small id="model-count"></small></div>
        <div id="model-list" class="item-list"></div>
      </aside>
      <section class="viewport" id="viewport" aria-label="地块编辑器">
        <div class="view-top">
          <div class="view-chip"><i></i><span id="view-mode">正交视图</span></div>
          <div class="view-buttons">${button('grid', '辅助网格', 'toggle-grid')}${button('magnet', '网格吸附', 'toggle-snap')}${button('focus', '整块地取景', 'fit-view')}</div>
        </div>
        <div class="view-message" id="view-message" aria-live="polite"></div>
        <div class="view-bottom">
          <div class="axis-mark" aria-label="X 向东，Z 向南">
            <svg viewBox="0 0 62 58" aria-hidden="true">
              <path d="M29 35 48 44" stroke="#ba6d61"/><path d="M29 35 12 46" stroke="#7298b5"/><path d="M29 35V13" stroke="#4d8d6d"/>
              <circle cx="29" cy="35" r="3" fill="#677c70"/>
              <text x="51" y="49" fill="#a35246">X</text><text x="3" y="52" fill="#527a99">Z</text><text x="25" y="10" fill="#3e785a">Y</text>
            </svg>
          </div>
          <div class="view-hint" id="view-hint">${icons.mouse} 右键旋转 <b>·</b> 中键平移 <b>·</b> 滚轮缩放</div>
        </div>
        <div id="toast" class="toast" role="status"></div>
      </section>
      <aside class="editor-sidebar editor-properties">
        <div class="eyebrow">编辑</div>
        <h2>属性面板</h2>
        <div class="edit-tools" id="tool-buttons">${(Object.keys(modes) as (keyof typeof modes)[]).map(key => `<button data-mode="${key}" class="tool-button${key === mode ? ' active' : ''}" title="${modes[key].name}">${modes[key].icon}<span>${modes[key].name}</span></button>`).join('')}</div>
        <div class="inspector" id="inspector"></div>
      </aside>
    </div>
    <footer class="editor-footer"><div class="footer-left">${icons.layers}<span id="editor-status">编辑模式</span></div><div class="footer-tools">${button('undo', '撤销 (Ctrl+Z)', 'undo-btn')}${button('copy', '复制 (Ctrl+D)', 'duplicate-btn')}${button('trash', '删除 (Delete)', 'delete-btn')}</div><div class="footer-right">${icons.keyboard}<span id="editor-location">米制坐标 · X 东 / Z 南</span></div></footer>
    <dialog id="group-dialog" class="app-dialog">
      <form id="group-form">
        <div class="dialog-heading"><span class="dialog-icon">${icons.group}</span><div><h2>组合模型</h2><p>组合基础形状和 GLB，保留各部件。</p></div>${button('close', '关闭', 'close-group')}</div>
        <label class="field-label" for="group-name">模型名称</label>
        <input id="group-name" class="text-field" type="text" maxlength="60" required autocomplete="off" placeholder="例如：我的路灯">
        <label class="import-options"><input type="checkbox" id="group-library" checked> 保存到我的模型</label>
        <div class="dialog-actions"><button type="button" class="secondary" id="cancel-group">取消</button><button class="primary" id="submit-group" type="submit">确认组合 ${icons.check}</button></div>
      </form>
    </dialog>
    <dialog id="import-dialog" class="app-dialog import-dialog">
      <form id="import-form">
        <div class="dialog-heading"><span class="dialog-icon">${icons.upload}</span><div><h2>预览导入模型</h2><p id="import-name"></p></div>${button('close', '关闭', 'close-import')}</div>
        <div id="import-preview" class="import-preview" aria-label="GLB 三维预览"></div>
        <div class="import-size" id="import-size"></div>
        <div class="import-warning" id="import-warning" aria-live="polite"></div>
        <label class="field-label" for="import-scale">等比缩放</label>
        <div class="scale-row"><input id="import-scale" class="text-field" type="number" min="0" step="any" value="1"><button type="button" id="fit-import" class="secondary">适应地块</button></div>
        <div class="import-options"><label><input id="ground-import" type="checkbox" checked> 底部贴地</label><label><input id="center-import" type="checkbox" checked> 放到地块中心</label></div>
        <div class="dialog-actions"><button type="button" class="secondary" id="cancel-import">取消</button><button class="primary" id="confirm-import" type="submit">确认放置 ${icons.arrow}</button></div>
      </form>
    </dialog>
    <dialog id="room-dialog" class="app-dialog">
      <div class="dialog-heading"><span class="dialog-icon">${icons.group}</span><div><h2>地块共建</h2><p id="room-info"></p></div>${button('close', '关闭', 'close-room')}</div>
      <div id="room-owner">
        <div class="room-options">
          <button class="secondary" id="invite-view">${icons.compass} 允许进入</button>
          <button class="primary" id="invite-edit">${icons.move} 允许编辑</button>
        </div>
        <div id="room-link-row" class="scale-row" hidden><input class="text-field" id="room-link" aria-label="邀请链接" readonly><button type="button" class="secondary" id="room-copy">复制</button></div>
        <button class="subtle" id="room-revoke">撤销所有访客编辑权限</button>
      </div>
      <div id="room-error" class="import-warning" aria-live="polite"></div>
    </dialog>
    <dialog id="part-dialog" class="app-dialog">
      <form id="part-form">
        <div class="dialog-heading"><span class="dialog-icon">${icons.group}</span><div><h2>编辑组合部件</h2><p>数值沿用组合的局部坐标。</p></div>${button('close', '关闭', 'close-part')}</div>
        <label class="field-label" for="part-picker">选择部件</label>
        <select class="text-field" id="part-picker"></select>
        <div id="part-fields"></div>
        <div class="dialog-actions"><button class="primary" type="submit">应用修改 ${icons.check}</button></div>
      </form>
    </dialog>`

  const world = new World($('viewport'), plot, {
    select: (id, multiple) => select(id, multiple),
    preview: (id, values, valid) => {
      if (!canEdit()) return
      const item = find(id)
      if (!item) return
      change = { id, result: { ...item, ...values }, valid }
      message(valid ? leveling ? '水平旋转 · 局部 Z 轴保持水平' : '' : '超出地块，松开将恢复原位。', !valid)
      updateTransformFields(change.result)
    },
    commit: id => { if (change?.id === id) commitTransform() },
    level: value => { leveling = value; message(value ? '水平旋转 · 局部 Z 轴保持水平' : '') },
    loaded: () => { if (!closed && !walking && ids.length === 1 && !change) renderInspector() },
    error: text => { if (!closed) notify(text, true) },
    walking: (position, edge) => {
      $('editor-location').textContent = `X ${position.x.toFixed(1)} m  ·  Z ${position.z.toFixed(1)} m`
      message(edge ? '受到物件或地块边界阻挡' : '', edge)
    },
  })
  const set = (id: string, disabled: boolean) => { ($(id) as HTMLButtonElement).disabled = disabled }
  const find = (id: string) => data.items.find(item => item.id === id)
  const current = () => ids.length === 1 ? find(ids[0]) : undefined
  type ImportState = { id: string; name: string; bytes: ArrayBuffer; source: T.Object3D; bounds: T.Box3; max: number; proposed: number }
  let pendingImport: ImportState | undefined
  let importPreview: ReturnType<typeof previewModel> | undefined

  function saveLocal() {
    try { onSave({ plot, scene: data }) }
    catch { notify('浏览器存储空间不足，本次修改暂未保存到本机。', true) }
  }
  function persist() {
    if (!room) { saveLocal(); return }
    const target = room
    const next = structuredClone(data)
    const changes = sceneChanges(proposed, next)
    if (!changes.length) return
    proposed = next
    const generation = epoch
    queued++
    queue = queue.then(async () => {
      if (generation !== epoch) return
      await target.publish(changes)
    }).catch(async error => {
      epoch++
      if (!closed) notify(error instanceof RoomRequestError && error.status === 409
        ? '该物件已被另一位成员修改，已载入房间版本。'
        : error instanceof Error ? error.message : '房间提交失败。', true)
      try { await target.read() } catch { /* The next heartbeat retries the connection. */ }
    }).finally(() => {
      queued--
      if (!closed && !queued && target.latest) receiveRoom(target.latest)
    })
  }
  function receiveRoom(value: RoomView | undefined) {
    if (closed) return
    const previous = role
    const wasConnected = connected
    connected = !!value
    role = value?.role ?? role
    updateRoomStatus(value)
    if (previous !== role || wasConnected !== connected) {
      if (!canEdit()) {
        if (change) {
          const original = find(change.id)
          const object = world.get(change.id)
          if (original && object) applyItem(object, original)
        }
        change = undefined
        if (placing) endPlacement()
        if (groupDialog.open) groupDialog.close()
        if (importDialog.open) importDialog.close()
        if (partDialog.open) partDialog.close()
        if (!walking && !observing && role === 'view') void switchMode('observe')
        if (previous !== role) notify('编辑权限已撤销，仍可观赏和行走。', true)
      }
      world.setEditable(canEdit())
      render()
    }
    if (!value || queued || (canEdit() && (holdingEdit() || groupDialog.open || partDialog.open))) return
    const remote = value.save.scene
    proposed = structuredClone(remote)
    if (sceneChanges(data, remote).length) {
      history.length = 0
      data = structuredClone(remote)
      ids = ids.filter(id => !!find(id))
      change = undefined
      world.sync(data.items)
      world.select(ids)
      render()
    }
    if (role === 'owner' && value.version !== savedVersion) {
      savedVersion = value.version
      saveLocal()
    }
  }
  let savedVersion = -1

  function record() {
    history.push(structuredClone(data))
    if (history.length > 50) history.shift()
  }
  function notify(text: string, problem = false) {
    const toast = $('toast')
    toast.innerHTML = `${problem ? icons.warning : icons.check}<span>${escapeHtml(text)}</span>`
    toast.classList.toggle('problem', problem)
    toast.classList.add('show')
    window.clearTimeout(toastTimer)
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 3000)
  }
  function message(text: string, warning = false) {
    const element = $('view-message')
    element.textContent = text
    element.classList.toggle('warning', warning)
    element.classList.toggle('show', Boolean(text))
  }
  function select(id: string | undefined, multiple = false) {
    if (!canEdit() || placing) return
    ids = id ? (multiple ? ids.includes(id) ? ids.filter(value => value !== id) : [...ids, id] : [id]) : []
    change = undefined
    world.select(ids)
    message('')
    render()
  }
  function sync() {
    world.sync(data.items)
    world.select(ids)
    render()
    persist()
  }
  function render() {
    $('object-count').textContent = String(data.items.length)
    $('model-count').textContent = String(data.models.length)
    $('scene-list').innerHTML = data.items.length ? data.items.map(item => `<button class="list-item${ids.includes(item.id) ? ' selected' : ''}" data-item="${item.id}" title="${escapeHtml(item.name)}" aria-pressed="${ids.includes(item.id)}">${shapeIcons[item.kind]}<span>${escapeHtml(item.name)}</span><i></i></button>`).join('') : '<p class="list-empty">地块还是空的，添加一个形状开始建造。</p>'
    $('model-list').innerHTML = data.models.length ? data.models.map(item => `<button class="list-item" data-model="${item.id}" title="放置 ${escapeHtml(item.name)}">${icons.package}<span>${escapeHtml(item.name)}</span>${icons.plus}</button>`).join('') : '<p class="list-empty">按住 Shift 选择多个物件，组合后可保存到这里。</p>'
    const locked = !canEdit() || placing
    set('undo-btn', locked || !history.length)
    set('duplicate-btn', locked || !current())
    set('delete-btn', locked || !ids.length)
    set('import-btn', locked)
    root.querySelectorAll<HTMLButtonElement>('[data-shape], [data-model], [data-item], [data-mode]').forEach(control => { control.disabled = locked })
    set('fit-view', walking)
    set('walk-mode', placing || modeChanging)
    set('observe-mode', placing || modeChanging)
    set('edit-mode', role === 'view' || placing || modeChanging)
    updateRoomStatus(room?.latest)
    $('toggle-grid').classList.toggle('active', grid)
    $('toggle-grid').setAttribute('aria-pressed', String(grid))
    $('toggle-snap').classList.toggle('active', snap)
    $('toggle-snap').setAttribute('aria-pressed', String(snap))
    renderInspector()
  }

  function renderInspector() {
    const inspector = $('inspector')
    const item = current()
    if (!canEdit() || placing || !ids.length) {
      inspector.innerHTML = `<div class="inspector-empty"><span>${walking ? icons.person : icons.cursor}</span><strong>${walking ? '小人正在地块中' : placing ? '正在放置模型' : observing ? '45° 观赏模式' : role === 'view' ? '访客只读' : '尚未选择物件'}</strong><p>${walking ? '使用 WASD 或方向键移动。' : placing ? '移动鼠标预览，点击确定位置。' : observing ? '保持 45° 俯角，左右拖动可轻微转动。' : role === 'view' ? '可观赏和行走，编辑需要主人邀请。' : '点击场景中的物件，查看和编辑属性。'}</p></div>`
      return
    }
    if (!item) {
      inspector.innerHTML = `<div class="inspector-empty multi"><span>${icons.group}</span><strong>已选择 ${ids.length} 个物件</strong><p>组合基础形状和导入的 GLB。</p></div><button class="secondary full" id="save-group">${icons.group} 组合物件</button>`
      $('save-group').onclick = openGroup
      return
    }
    const fields = (key: 'position' | 'rotation' | 'scale', label: string, unit: string) => `
      <fieldset class="transform-field"><legend>${label} <small>${unit}</small></legend>
        <div class="axis-fields">${axes.map((axis, i) => `<label class="input-axis axis-${axis.toLowerCase()}"><span>${axis}</span><input aria-label="${label} ${axis}" data-key="${key}" data-axis="${i}" type="number" step="any" value="${format(item[key][i] * (key === 'rotation' ? degrees : 1))}"></label>`).join('')}</div>
      </fieldset>`
    const bounds = world.getBounds(item.id)
    const size = bounds.getSize(new T.Vector3())
    inspector.innerHTML = `
      <div class="selected-title"><span>${shapeIcons[item.kind]}</span><div><strong>${escapeHtml(item.name)}</strong><small>${names[item.kind]}</small></div></div>
      ${fields('position', '位置', 'm')}${fields('rotation', '旋转', '°')}${fields('scale', '缩放', '×')}
      ${item.color ? `<label class="color-row">颜色 <span><input type="color" aria-label="颜色" id="item-color" value="${item.color}">${item.color.toUpperCase()}</span></label>` : ''}
      ${!bounds.isEmpty() ? `<div class="measured">水平占地 <strong id="measured-size">${distance(size.x)} × ${distance(size.z)}</strong></div>` : ''}
      <button class="secondary full" id="ground-item">${icons.layers} 底部贴地</button>
      ${item.kind === 'group' ? `<button class="secondary full" id="edit-parts">${icons.move} 编辑部件</button>
      <button class="secondary full" id="ungroup">${icons.layers} 拆组</button>
      <button class="secondary full" id="save-group">${icons.package} 保存为模型</button>` : ''}`
    const paint = document.getElementById('item-color') as HTMLInputElement | null
    if (paint) paint.onchange = () => {
      const object = world.get(item.id)
      if (!object || item.color === paint.value) return
      record()
      item.color = paint.value
      applyItem(object, item)
      persist()
      render()
    }
    $('ground-item').onclick = () => {
      const object = world.get(item.id)
      const box = world.getBounds(item.id)
      if (!object || box.isEmpty() || Math.abs(box.min.y) < 1e-8) return
      const result = structuredClone(item)
      result.position[1] -= box.min.y
      change = { id: item.id, result, valid: true }
      commitTransform()
    }
    if (item.kind === 'group') {
      $('save-group').onclick = openGroup
      $('ungroup').onclick = () => ungroup(item)
      $('edit-parts').onclick = () => editParts(item)
    }
    inspector.querySelectorAll<HTMLInputElement>('input[data-key]').forEach(input => {
      let dirty = false
      const preview = () => {
        dirty = true
        const value = input.valueAsNumber
        const object = world.get(item.id)
        if (!object || !Number.isFinite(value)) return
        const key = input.dataset.key as 'position' | 'rotation' | 'scale'
        const result = structuredClone(item)
        result[key][Number(input.dataset.axis)] = value / (key === 'rotation' ? degrees : 1)
        applyItem(object, result)
        const valid = fits(boundsOf(object), plot) && result.scale.every(entry => entry > 0)
        change = { id: item.id, result, valid }
        world.setInvalid(!valid)
        message(valid ? '' : '超出地块，确认时将恢复原值。', !valid)
      }
      input.oninput = preview
      const finish = () => {
        if (!dirty) return
        dirty = false
        if (change && Number.isFinite(input.valueAsNumber)) commitTransform(false)
        else {
          const object = world.get(item.id)
          if (object) applyItem(object, item)
          change = undefined
          world.setInvalid(false)
          message('')
          updateTransformFields(item)
        }
      }
      input.onchange = finish
      input.onblur = finish
      input.onkeydown = event => { if (event.key === 'Enter') { event.preventDefault(); input.blur() } }
    })
  }
  function updateTransformFields(item: Item) {
    $('inspector').querySelectorAll<HTMLInputElement>('input[data-key]').forEach(input => {
      const key = input.dataset.key as 'position' | 'rotation' | 'scale'
      input.value = format(item[key][Number(input.dataset.axis)] * (key === 'rotation' ? degrees : 1))
    })
    const measured = document.getElementById('measured-size')
    if (measured) {
      const size = world.getBounds(item.id).getSize(new T.Vector3())
      measured.textContent = `${distance(size.x)} × ${distance(size.z)}`
    }
  }
  function commitTransform(repaint = true) {
    if (!change || !canEdit()) return
    const { id, result, valid } = change
    change = undefined
    const item = find(id), object = world.get(id)
    if (!item || !object) return
    if (valid && JSON.stringify(item) !== JSON.stringify(result)) {
      record()
      Object.assign(item, result)
      persist()
    }
    applyItem(object, item)
    world.setInvalid(false)
    message('')
    if (!valid) notify('物件移出边界，已恢复上一次合法位置。', true)
    if (repaint) render()
    else {
      updateTransformFields(item)
      set('undo-btn', !history.length)
    }
  }

  function addItem(item: Item) {
    if (!canEdit()) return
    record()
    data.items.push(item)
    ids = [item.id]
    sync()
  }
  function initialScale() {
    return Math.min(plot.width, plot.depth) * .09
  }
  function availablePosition(bounds: T.Box3, origin: Vec, keepCenter = false) {
    if (bounds.isEmpty()) return undefined
    const size = bounds.getSize(new T.Vector3())
    const step = Math.max(Math.min(plot.width, plot.depth) * .065, .01)
    const dx = Math.max(step, size.x * 1.28)
    const dz = Math.max(step, size.z * 1.28)
    const options: Vec[] = [[dx, 0, 0], [-dx, 0, 0], [0, 0, dz], [0, 0, -dz], [dx, 0, dz], [-dx, 0, dz], [2 * dx, 0, 0], [0, 0, 0]]
    if (keepCenter) options.unshift([0, 0, 0])
    let fallback: Vec | undefined
    const occupied = data.items.map(item => world.getBounds(item.id)).filter(box => !box.isEmpty())
    for (const option of options) {
      const candidate = bounds.clone().translate(new T.Vector3(...option))
      if (!fits(candidate, plot)) continue
      const location = add(origin, option)
      fallback ??= location
      if (!occupied.some(box => box.intersectsBox(candidate))) return location
    }
    return fallback
  }
  function addPrimitive(kind: Primitive) {
    const item = newItem(kind, SHAPES[kind])
    item.color = { box: '#76a68a', cylinder: '#648d7e', sphere: '#e3b978' }[kind]
    const size = initialScale()
    item.scale = [size, size, size]
    item.position = [0, size / 2, 0]
    const bounds = new T.Box3(new T.Vector3(-size / 2, 0, -size / 2), new T.Vector3(size / 2, size, size / 2))
    item.position = availablePosition(bounds, item.position, true) ?? item.position
    addItem(item)
  }
  function duplicate() {
    const item = current()
    if (!item || !canEdit() || placing) return
    const copy = structuredClone(item)
    const location = availablePosition(world.getBounds(item.id), item.position)
    if (!location) { notify('模型还未加载完成，暂时无法复制。', true); return }
    copy.id = newId()
    copy.name = `${item.name} 副本`
    copy.position = location
    addItem(copy)
  }
  function remove() {
    if (!ids.length || !canEdit() || placing) return
    record()
    data.items = data.items.filter(item => !ids.includes(item.id))
    ids = []
    sync()
  }
  function undo() {
    if (!canEdit() || placing) return
    const previous = history.pop()
    if (!previous) return
    data = previous
    ids = ids.filter(id => !!find(id))
    sync()
    notify('已撤销上一步。')
  }

  const groupDialog = $('group-dialog') as HTMLDialogElement
  function openGroup() {
    const input = $('group-name') as HTMLInputElement
    input.value = current()?.name ?? '新组合'
    const library = $('group-library') as HTMLInputElement
    library.checked = true
    library.disabled = current()?.kind === 'group'
    groupDialog.showModal()
    input.focus()
    input.select()
  }
  $('close-group').onclick = $('cancel-group').onclick = () => groupDialog.close()
  $('group-form').onsubmit = async event => {
    event.preventDefault()
    const input = $('group-name') as HTMLInputElement
    const name = input.value.trim()
    if (!name) { input.focus(); return }
    const items = data.items.filter(item => ids.includes(item.id))
    if (!items.length || !canEdit()) return
    try { await Promise.all(items.map(prepareItemAssets)) }
    catch { notify('组合中有无法读取的 GLB。', true); return }
    if (closed || !canEdit() || !groupDialog.open) return
    let group: Item
    if (items.length === 1 && items[0].kind === 'group') group = structuredClone(items[0])
    else {
      group = newItem('group', name)
      const bounds = items.reduce((acc, item) => acc.union(world.getBounds(item.id)), new T.Box3())
      if (bounds.isEmpty()) { notify('选中的物件还未加载完成。', true); return }
      const center = bounds.getCenter(new T.Vector3())
      group.position = [center.x, bounds.min.y, center.z]
      group.children = items.map(item => ({
        ...structuredClone(item),
        position: [item.position[0] - center.x, item.position[1] - bounds.min.y, item.position[2] - center.z],
      }))
    }
    group.name = name
    record()
    const keep = ($('group-library') as HTMLInputElement).checked
    if (keep) {
      const template = structuredClone(group)
      template.id = newId()
      template.position = [0, 0, 0]
      data.models.push(template)
    }
    data.items = [...data.items.filter(item => !ids.includes(item.id)), group]
    ids = [group.id]
    groupDialog.close()
    sync()
    notify(keep ? `已保存「${name}」。` : `已组合「${name}」。`)
  }
  async function placeModel(id: string) {
    const template = data.models.find(item => item.id === id)
    if (!template) return
    const item = structuredClone(template)
    item.id = newId()
    try { await prepareItemAssets(item) }
    catch { notify('模型引用的 GLB 无法读取。', true); return }
    if (closed || !canEdit()) return
    const object = buildItem(item, () => {}, () => {})
    const box = boundsOf(object)
    object.traverse(node => { if (node instanceof T.Mesh && node.userData.ownMaterial) node.material.dispose() })
    const center = box.getCenter(new T.Vector3())
    item.position = [-center.x, -box.min.y, -center.z]
    box.translate(new T.Vector3(...item.position))
    const location = availablePosition(box, item.position)
    if (!location) { notify('该模型的水平占地无法放入当前地块。', true); return }
    item.position = location
    addItem(item)
  }

  function ungroup(item: Item) {
    const object = world.get(item.id)
    if (!object || !item.children?.length || !canEdit()) return
    object.updateWorldMatrix(true, true)
    const restored: Item[] = []
    for (const [i, child] of item.children.entries()) {
      const matrix = object.children[i].matrixWorld
      const position = new T.Vector3()
      const scale = new T.Vector3()
      const quaternion = new T.Quaternion()
      matrix.decompose(position, quaternion, scale)
      const reconstructed = new T.Matrix4().compose(position, quaternion, scale)
      if (matrix.elements.some((value, index) => Math.abs(value - reconstructed.elements[index]) > 1e-6)) {
        notify('当前组合发生了剪切变形。请改为等比缩放再拆组。', true)
        return
      }
      const { x, y, z } = new T.Euler().setFromQuaternion(quaternion)
      restored.push({ ...structuredClone(child), id: newId(), position: position.toArray(), rotation: [x, y, z], scale: scale.toArray() })
    }
    record()
    data.items = [...data.items.filter(candidate => candidate.id !== item.id), ...restored]
    ids = restored.map(child => child.id)
    sync()
  }

  const partDialog = $('part-dialog') as HTMLDialogElement
  const partPicker = $('part-picker') as HTMLSelectElement
  const partKeys = ['position', 'rotation', 'scale'] as const
  let partGroup: string | undefined
  $('close-part').onclick = () => partDialog.close()
  function editParts(item: Item) {
    if (!canEdit() || !item.children?.length) return
    partGroup = item.id
    partPicker.innerHTML = item.children.map((child, index) => `<option value="${index}">${escapeHtml(child.name)}</option>`).join('')
    partDialog.showModal()
    renderPart()
  }
  function renderPart() {
    const child = partGroup ? find(partGroup)?.children?.[Number(partPicker.value)] : undefined
    if (!child) return
    $('part-fields').innerHTML = partKeys.map((key, index) => {
      const label = ['局部位置', '局部旋转', '局部缩放'][index]
      return `<fieldset class="transform-field"><legend>${label}</legend><div class="axis-fields">${axes.map((axis, i) => `<label class="input-axis"><span>${axis}</span><input type="number" step="any" required aria-label="${label} ${axis}" data-part="${key}-${i}" value="${format(child[key][i] * (key === 'rotation' ? degrees : 1))}"></label>`).join('')}</div></fieldset>`
    }).join('')
  }
  partPicker.onchange = renderPart
  $('part-form').onsubmit = event => {
    event.preventDefault()
    if (!canEdit() || !partGroup) return
    const group = find(partGroup)
    const index = Number(partPicker.value)
    const child = group?.children?.[index]
    const object = world.get(partGroup)
    if (!child || !group || !object) return
    const result = structuredClone(child)
    $('part-fields').querySelectorAll<HTMLInputElement>('input').forEach(input => {
      const [key, axis] = input.dataset.part!.split('-') as [typeof partKeys[number], string]
      result[key][Number(axis)] = input.valueAsNumber / (key === 'rotation' ? degrees : 1)
    })
    if (result.scale.some(value => !(value > 0))) {
      notify('缩放数值需大于 0。', true)
      return
    }
    applyItem(object.children[index], result)
    if (!fits(boundsOf(object), plot)) {
      applyItem(object.children[index], child)
      partDialog.close()
      notify('部件超出地块边界，已恢复原值。', true)
      return
    }
    record()
    group.children![index] = result
    partDialog.close()
    sync()
    notify('已更新组合部件。')
  }

  const importDialog = $('import-dialog') as HTMLDialogElement
  const fileInput = $('import-file') as HTMLInputElement
  const scaleField = $('import-scale') as HTMLInputElement
  const groundField = $('ground-import') as HTMLInputElement
  $('import-btn').onclick = () => fileInput.click()
  $('close-import').onclick = $('cancel-import').onclick = () => importDialog.close()
  importDialog.onclose = () => {
    importPreview?.dispose()
    importPreview = undefined
    pendingImport = undefined
  }
  fileInput.onchange = async () => {
    const file = fileInput.files?.[0]
    fileInput.value = ''
    if (!file || !canEdit() || placing) return
    try {
      notify('正在读取模型…')
      const bytes = await file.arrayBuffer()
      const source = await parseGlb(bytes)
      if (closed || !canEdit()) return
      const bounds = boundsOf(source), size = bounds.getSize(new T.Vector3())
      const max = Math.min(size.x > 0 ? plot.width / size.x : Infinity, size.z > 0 ? plot.depth / size.z : Infinity)
      const proposed = max < 1 ? max * .95 : 1
      pendingImport = { id: newId(), name: file.name.replace(/\.glb$/i, ''), bytes, source, bounds, max, proposed }
      $('import-name').textContent = file.name
      scaleField.value = String(Number(proposed.toPrecision(8)))
      groundField.checked = true
      ;($('center-import') as HTMLInputElement).checked = true
      importDialog.showModal()
      importPreview = previewModel($('import-preview'), source, plot)
      refreshImport()
    } catch (error) {
      if (importDialog.open) importDialog.close()
      if (!closed) notify(error instanceof Error ? `导入失败。 ${error.message}` : '导入失败，请检查 GLB 文件。', true)
    }
  }
  function refreshImport() {
    if (!pendingImport) return
    const scale = scaleField.valueAsNumber
    const valid = Number.isFinite(scale) && scale > 0 && scale <= pendingImport.max
    const size = pendingImport.bounds.getSize(new T.Vector3())
    $('import-size').textContent = `原始尺寸 ${distance(size.x)} × ${distance(size.y)} × ${distance(size.z)}${valid ? `  ·  水平占地 ${distance(size.x * scale)} × ${distance(size.z * scale)}` : ''}`
    $('import-warning').textContent = valid
      ? (pendingImport.max < 1 ? '原始模型大于地块。当前预览已等比缩小，确认后放置。' : '')
      : '请填写大于零且能放入地块的缩放比例。'
    set('confirm-import', !valid)
    if (Number.isFinite(scale) && scale > 0) importPreview?.render(scale, groundField.checked, valid)
  }
  $('fit-import').onclick = () => {
    if (!pendingImport) return
    scaleField.value = String(pendingImport.proposed)
    refreshImport()
  }
  scaleField.oninput = groundField.onchange = refreshImport
  $('import-form').onsubmit = async event => {
    event.preventDefault()
    if (!pendingImport || !canEdit()) return
    const imported = pendingImport
    const scale = scaleField.valueAsNumber
    if (!(scale > 0 && scale <= imported.max)) return
    const item = newItem('glb', imported.name || 'GLB 模型')
    item.asset = imported.id
    item.scale = [scale, scale, scale]
    item.position[1] = groundField.checked ? -imported.bounds.min.y * scale : 0
    const center = ($('center-import') as HTMLInputElement).checked
    set('confirm-import', true)
    try {
      await putAsset(imported.id, imported.bytes)
      if (closed || !canEdit() || !importDialog.open) return
      rememberAsset(imported.id, imported.source)
      importDialog.close()
      if (center) {
        addItem(item)
        notify('GLB 已放到地块中心。')
      } else {
        placing = true
        world.beginPlacement(item, imported.source, position => {
          endPlacement()
          item.position = position
          addItem(item)
          notify('GLB 已放置。')
        })
        message('移动鼠标预览，点击放置 · Esc 取消')
        render()
      }
    } catch {
      if (!closed) {
        notify('浏览器无法保存此 GLB 文件。', true)
        refreshImport()
      }
    }
  }
  function endPlacement() {
    if (!placing) return
    placing = false
    world.endPlacement()
    message('')
    render()
  }
  async function switchMode(next: 'edit' | 'walk' | 'observe') {
    if (placing || modeChanging || (next === 'edit' && role === 'view')) return
    if ((walking && next === 'walk') || (observing && next === 'observe') || (!walking && !observing && next === 'edit')) return
    modeChanging = true
    world.setEditable(false)
    render()
    try {
      if (walking) await world.setWalk(false)
      if (observing) world.setObserve(false)
      walking = observing = false
      if (next === 'walk') walking = await world.setWalk(true)
      if (closed) return
      if (next === 'observe' || (role === 'view' && !walking)) {
        observing = true
        world.setObserve(true)
      }
    } catch (error) {
      if (!closed) notify(error instanceof Error ? error.message : '行走模式暂时不可用。', true)
    } finally {
      modeChanging = false
      if (!closed) {
        world.setEditable(canEdit())
        renderModes()
        render()
      }
    }
  }
  function renderModes() {
    $('viewport').classList.toggle('observing', observing)
    const active = walking ? 'walk' : observing ? 'observe' : 'edit'
    for (const key of ['edit', 'walk', 'observe']) {
      const control = $(`${key}-mode`)
      control.classList.toggle('active', key === active)
      control.setAttribute('aria-pressed', String(key === active))
    }
    $('editor-status').textContent = walking ? '行走模式 · Shift 加速' : observing ? '观赏模式' : '编辑模式'
    $('view-mode').textContent = walking ? '行走视图' : observing ? '正面 45° 俯视' : '正交视图'
    $('view-hint').innerHTML = walking
      ? `${icons.keyboard} WASD 或方向键移动 <b>·</b> Shift 加速`
      : observing ? `${icons.mouse} 左右拖动 ±10° <b>·</b> 滚轮缩放` : `${icons.mouse} 右键旋转 <b>·</b> 左键＋中键锁平 Z`
    if (!walking) {
      message('')
      $('editor-location').textContent = '米制坐标 · X 东 / Z 南'
    }
  }
  function setTool(next: typeof mode) {
    if (!canEdit() || placing) return
    mode = next
    world.setMode(next)
    root.querySelectorAll<HTMLButtonElement>('[data-mode]').forEach(control => {
      control.classList.toggle('active', control.dataset.mode === mode)
      control.setAttribute('aria-pressed', String(control.dataset.mode === mode))
    })
  }

  $('primitives').onclick = event => {
    const shape = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-shape]')?.dataset.shape as Primitive | undefined
    if (shape && canEdit() && !placing) addPrimitive(shape)
  }
  $('scene-list').onclick = event => {
    const id = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-item]')?.dataset.item
    if (id) select(id, event.shiftKey || event.ctrlKey || event.metaKey)
  }
  $('model-list').onclick = event => {
    const id = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-model]')?.dataset.model
    if (id && canEdit() && !placing) void placeModel(id)
  }
  $('tool-buttons').onclick = event => {
    const next = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-mode]')?.dataset.mode as typeof mode | undefined
    if (next) setTool(next)
  }
  $('toggle-grid').onclick = () => {
    grid = !grid
    world.setGrid(grid)
    $('toggle-grid').classList.toggle('active', grid)
    $('toggle-grid').setAttribute('aria-pressed', String(grid))
  }
  $('toggle-snap').onclick = () => {
    snap = !snap
    world.setSnap(snap)
    $('toggle-snap').classList.toggle('active', snap)
    $('toggle-snap').setAttribute('aria-pressed', String(snap))
    notify(snap ? `网格吸附已开启 · ${distance(world.snapStep)}` : '网格吸附已关闭。')
  }
  $('fit-view').onclick = () => world.fit()
  $('edit-mode').onclick = () => void switchMode('edit')
  $('walk-mode').onclick = () => void switchMode('walk')
  $('observe-mode').onclick = () => void switchMode('observe')
  $('undo-btn').onclick = undo
  $('duplicate-btn').onclick = duplicate
  $('delete-btn').onclick = remove
  window.addEventListener('keydown', event => {
    if (event.defaultPrevented || groupDialog.open || importDialog.open || partDialog.open || roomDialog.open || (event.target as HTMLElement | null)?.closest('input,textarea,select')) return
    if (placing && event.key === 'Escape') { endPlacement(); return }
    if (!canEdit() || placing) return
    if ((event.ctrlKey || event.metaKey) && event.code === 'KeyZ') { event.preventDefault(); undo(); return }
    if ((event.ctrlKey || event.metaKey) && event.code === 'KeyD') { event.preventDefault(); duplicate(); return }
    if (event.ctrlKey || event.metaKey || event.altKey) return
    if (event.key === 'Delete') remove()
    if (event.key === 'Escape') select(undefined)
    if (event.code === 'KeyW') setTool('translate')
    if (event.code === 'KeyE') setTool('rotate')
    if (event.code === 'KeyR') setTool('scale')
  }, { signal: listeners.signal })

  const roomDialog = $('room-dialog') as HTMLDialogElement
  const linkField = $('room-link') as HTMLInputElement
  function updateRoomStatus(value: RoomView | undefined) {
    const label = $('room-btn').querySelector('span')!
    label.textContent = sharing ? '正在开启…' : room ? connected && value ? `${value.online} 人在线` : '房间离线' : '邀请共建'
    $('room-info').textContent = room ? `${roleNames[role]} · ${connected && value ? `${value.online} 人在线` : '连接中断'}` : '创建房间并邀请朋友进入这块地。'
    $('room-owner').hidden = role !== 'owner'
    set('room-btn', sharing)
    set('invite-view', !connected || sharing)
    set('invite-edit', !connected || sharing)
    set('room-revoke', !connected || sharing)
  }
  function attachRoom(client: RoomClient) {
    room = client
    setAssetProvider(id => client.downloadAsset(id))
    unsubscribe?.()
    unsubscribe = client.observe(receiveRoom)
  }
  $('room-btn').onclick = async () => {
    $('room-error').textContent = ''
    if (!room) {
      sharing = true
      world.setEditable(false)
      render()
      try {
        const client = await createRoom(plot)
        await client.publish(sceneChanges(EMPTY, data))
        if (closed) return
        options.ownerRoom(client)
        attachRoom(client)
      } catch (error) {
        if (!closed) notify(error instanceof Error ? error.message : '无法开启共建。', true)
        return
      } finally {
        sharing = false
        if (!closed) { world.setEditable(canEdit()); render() }
      }
    }
    if (!closed) roomDialog.showModal()
  }
  $('close-room').onclick = () => roomDialog.close()
  async function issueInvite(grant: 'view' | 'edit') {
    try {
      if (!room) return
      linkField.value = await room.invite(grant)
      $('room-link-row').hidden = false
      $('room-error').textContent = ''
      linkField.select()
    } catch (error) { $('room-error').textContent = error instanceof Error ? error.message : '无法生成邀请。' }
  }
  $('invite-view').onclick = () => void issueInvite('view')
  $('invite-edit').onclick = () => void issueInvite('edit')
  $('room-copy').onclick = async () => {
    try {
      await navigator.clipboard.writeText(linkField.value)
      $('room-error').textContent = '已复制邀请链接。'
    } catch {
      linkField.select()
      $('room-error').textContent = '请按 Ctrl/Cmd+C 复制链接。'
    }
  }
  $('room-revoke').onclick = async () => {
    try {
      await room?.revokeEditing()
      $('room-link-row').hidden = true
      $('room-error').textContent = '所有访客现为只读，原编辑邀请已失效。'
    } catch (error) { $('room-error').textContent = error instanceof Error ? error.message : '无法撤销权限。' }
  }

  const characterKey = 'fangcun.character'
  const characterFile = $('character-file') as HTMLInputElement
  $('character-btn').onclick = () => characterFile.click()
  $('character-btn').title = '导入带骨骼 GLB。已有 Idle/Walk 则直接使用，可识别的人形骨骼可自动生成基础动画。'
  characterFile.onchange = async () => {
    const file = characterFile.files?.[0]
    characterFile.value = ''
    if (!file) return
    try {
      const bytes = await file.arrayBuffer()
      const character = await parseCharacter(bytes)
      if (closed) return
      const id = newId()
      await putAsset(id, bytes)
      if (closed) return
      localStorage.setItem(characterKey, id)
      world.setCharacter(character)
      $('character-reset').hidden = false
      notify('角色已替换，行走时可查看动画。')
    } catch (error) {
      if (!closed) notify(error instanceof Error ? error.message : '角色导入失败。', true)
    }
  }
  $('character-reset').onclick = () => {
    localStorage.removeItem(characterKey)
    world.setCharacter(blockCharacter())
    $('character-reset').hidden = true
    notify('已恢复默认角色。')
  }
  const characterId = localStorage.getItem(characterKey)
  if (characterId) void getAsset(characterId).then(async bytes => {
    if (!bytes) return
    const character = await parseCharacter(bytes)
    if (!closed && localStorage.getItem(characterKey) === characterId) {
      world.setCharacter(character)
      $('character-reset').hidden = false
    }
  }).catch(() => { if (!closed) notify('上次使用的角色无法读取，已使用默认角色。', true) })

  world.sync(data.items)
  world.setEditable(canEdit())
  setTool(mode)
  renderModes()
  render()
  if (room) attachRoom(room)
  if (role === 'view') void switchMode('observe')
  return () => {
    closed = true
    listeners.abort()
    unsubscribe?.()
    setAssetProvider()
    window.clearTimeout(toastTimer)
    importPreview?.dispose()
    world.dispose()
  }
}
