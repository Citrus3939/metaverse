import * as T from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
import { TransformControls } from 'three/addons/controls/TransformControls.js'
import { DRACOLoader, DRACO_GLTF_CONFIG } from 'three/addons/loaders/DRACOLoader.js'
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js'
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js'
import { clone } from 'three/addons/utils/SkeletonUtils.js'
import { getAsset, type Item, type Plot, type Primitive, type Vec } from './data'
import { WalkCollision, loadPhysics } from './collision'
import { addDefaultHumanoidClips, animationPair, blockCharacter, CharacterAnimation, type Character } from './character'

import { BUILD_GRID_STEP } from './plot-grid'

const FRONT_ELEVATION = Math.PI / 4
const FRONT_SWAY = Math.PI / 18

const geometry: Record<Primitive, T.BufferGeometry> = {
  box: new T.BoxGeometry(1, 1, 1),
  cylinder: new T.CylinderGeometry(.5, .5, 1, 32),
  sphere: new T.SphereGeometry(.5, 32, 24),
}
const assets = new Map<string, Promise<T.Object3D>>()
const resolvedAssets = new Map<string, T.Object3D>()
let remoteAsset: ((id: string) => Promise<ArrayBuffer | undefined>) | undefined
export function setAssetProvider(provider?: typeof remoteAsset) { remoteAsset = provider }

export async function prepareItemAssets(item: Item): Promise<void> {
  if (item.kind === 'glb') { await asset(item.asset!); return }
  if (item.children) await Promise.all(item.children.map(prepareItemAssets))
}

async function readGlb(data: ArrayBuffer) {
  if (data.byteLength < 20) throw new Error('文件不是有效的 GLB。')
  const header = new DataView(data)
  if (header.getUint32(0, true) !== 0x46546c67 || header.getUint32(4, true) !== 2 || header.getUint32(8, true) !== data.byteLength || header.getUint32(16, true) !== 0x4e4f534a) {
    throw new Error('请选择有效的 GLB 2.0 文件。')
  }
  const json = JSON.parse(new TextDecoder().decode(new Uint8Array(data, 20, header.getUint32(12, true))))
  const resources: { uri?: string }[] = [...(json.buffers ?? []), ...(json.images ?? [])]
  if (resources.some(resource => resource.uri && !/^data:/i.test(resource.uri))) throw new Error('此 GLB 引用了外部资源，请重新导出为自包含文件。')
  const draco = new DRACOLoader().setDecoderPath(DRACO_GLTF_CONFIG)
  const loader = new GLTFLoader().setDRACOLoader(draco).setMeshoptDecoder(MeshoptDecoder)
  const result = await loader.parseAsync(data, '').finally(() => draco.dispose())
  const bounds = new T.Box3().setFromObject(result.scene, true)
  if (bounds.isEmpty() || ![...bounds.min, ...bounds.max].every(Number.isFinite)) throw new Error('GLB 中没有可显示的有效几何体。')
  const center = bounds.getCenter(new T.Vector3())
  const normalized = new T.Group()
  const offset = new T.Group()
  offset.position.copy(center).negate()
  offset.add(result.scene)
  normalized.add(offset)
  normalized.updateMatrixWorld(true)
  return { object: normalized, clips: result.animations }
}

export async function parseGlb(data: ArrayBuffer) {
  return (await readGlb(data)).object
}

export async function parseCharacter(data: ArrayBuffer): Promise<Character> {
  const character = await readGlb(data)
  let skinned = false
  character.object.traverse(node => { if (node instanceof T.SkinnedMesh && node.skeleton.bones.length) skinned = true })
  if (!skinned) throw new Error('角色 GLB 需要绑定骨骼与蒙皮。')
  addDefaultHumanoidClips(character)
  if (!animationPair(character.clips)) throw new Error('未识别出左右腿骨。请添加 Idle 和 Walk 原地动画后再导入。')
  const bounds = boundsOf(character.object)
  const height = bounds.max.y - bounds.min.y
  if (height <= .001) throw new Error('角色模型高度无效。')
  const scale = 1.86 / height
  character.object.scale.setScalar(scale)
  character.object.position.y = -bounds.min.y * scale
  return character
}

export function rememberAsset(id: string, object: T.Object3D) {
  resolvedAssets.set(id, object)
  assets.set(id, Promise.resolve(object))
}
async function asset(id: string) {
  let result = assets.get(id)
  if (!result) {
    const provider = remoteAsset
    result = getAsset(id).then(local => local ?? provider?.(id)).then(async data => {
      if (!data) throw new Error('GLB 文件缺失。')
      const object = await parseGlb(data)
      resolvedAssets.set(id, object)
      return object
    })
    assets.set(id, result)
    result.catch(() => assets.delete(id))
  }
  return result
}

export function applyItem(object: T.Object3D, item: Item) {
  object.position.fromArray(item.position)
  object.rotation.set(...item.rotation)
  object.scale.fromArray(item.scale)
  if (item.color && object instanceof T.Mesh) object.material.color.set(item.color)
  object.updateWorldMatrix(true, true)
}

export function buildItem(item: Item, onLoaded: () => void, onError: (error: unknown) => void): T.Object3D {
  let object: T.Object3D
  if (item.kind === 'group') {
    object = new T.Group()
    object.add(...(item.children ?? []).map(child => buildItem(child, onLoaded, onError)))
  } else if (item.kind === 'glb') {
    const root = new T.Group()
    object = root
    const cached = resolvedAssets.get(item.asset!)
    if (cached) root.add(clone(cached))
    else void asset(item.asset!).then(source => {
      root.add(clone(source))
      onLoaded()
    }).catch(onError)
  } else {
    object = new T.Mesh(geometry[item.kind], new T.MeshStandardMaterial({ color: item.color ?? '#6ea98b', roughness: .82 }))
    object.userData.ownMaterial = true
  }
  object.userData.itemId = item.id
  applyItem(object, item)
  return object
}

export function boundsOf(object: T.Object3D) {
  return new T.Box3().setFromObject(object, true)
}
export function fits(bounds: T.Box3, plot: Plot) {
  const tolerance = 1e-6
  return !bounds.isEmpty() && bounds.min.x >= -plot.width / 2 - tolerance && bounds.max.x <= plot.width / 2 + tolerance
    && bounds.min.z >= -plot.depth / 2 - tolerance && bounds.max.z <= plot.depth / 2 + tolerance
}

const MOVEMENT = new Set(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowLeft', 'ArrowDown', 'ArrowRight', 'ShiftLeft', 'ShiftRight'])

type WorldCallbacks = {
  select: (id: string | undefined, multiple: boolean) => void
  preview: (id: string, values: Pick<Item, 'position' | 'rotation' | 'scale'>, valid: boolean) => void
  commit: (id: string) => void
  loaded: () => void
  error: (message: string) => void
  walking: (position: T.Vector3, blocked: boolean) => void
  level: (enabled: boolean) => void
}

export class World {
  private renderer: T.WebGLRenderer
  private scene = new T.Scene()
  private camera = new T.OrthographicCamera(-1, 1, 1, -1, .001, 1000)
  private orbit: OrbitControls
  private transform: TransformControls
  private boundary: T.LineLoop<T.BufferGeometry, T.LineBasicMaterial>
  private groundGrid: T.LineSegments<T.BufferGeometry, T.LineBasicMaterial>
  private models = new T.Group()
  private items = new Map<string, T.Object3D>()
  private selected: string[] = []
  private selectionBox = new T.Box3()
  private outlineDirty = true
  private outline = new T.Box3Helper(this.selectionBox, '#3b8c62')
  private player = new T.Group()
  private character = blockCharacter()
  private animator = new CharacterAnimation(this.character)
  private collision?: WalkCollision
  private collisionDirty = true
  private closed = false
  private observe = false
  private editable = true
  private groundMaterial = new T.MeshBasicMaterial()
  private groundSide = new T.MeshBasicMaterial()
  private corners: T.Points<T.BufferGeometry, T.PointsMaterial>
  private level?: { id: string; yaw: number; bank: number; x: number; y: number }
  private viewBeforeObserve?: { camera: T.Vector3; target: T.Vector3; zoom: number; frustum: number }
  private playerScale
  private keys = new Set<string>()
  private frame = 0
  private time = 0
  private fitSize = 1
  private frustum = 1
  private observer: ResizeObserver
  private listeners = new AbortController()
  private walk = false
  private placement?: { object: T.Object3D; confirm: (position: Vec) => void }
  private ray = new T.Raycaster()
  private direct?: { id: string; x: number; y: number; offset: T.Vector3; pickY: number; moved: boolean }
  private startClick?: { x: number; y: number }
  private savedView?: { camera: T.Vector3; target: T.Vector3; zoom: number }
  private size: number

  constructor(private host: HTMLElement, readonly plot: Plot, private callbacks: WorldCallbacks) {
    this.renderer = new T.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' })
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
    this.renderer.setClearColor(0x000000, 0)
    host.append(this.renderer.domElement)
    this.renderer.domElement.setAttribute('aria-label', '3D 地块视口')
    this.size = Math.max(plot.width, plot.depth)
    this.playerScale = Math.min(1, Math.min(plot.width, plot.depth) / 2.6)
    this.player.scale.setScalar(this.playerScale)
    this.player.add(this.character.object)
    this.player.visible = false
    this.scene.add(this.player, this.models)
    this.scene.add(new T.HemisphereLight('#fffdf3', '#9aaea0', 2.15))
    const sun = new T.DirectionalLight('#fff6d8', 2.1)
    sun.position.set(4, 9, 5)
    this.scene.add(sun)
    const depth = Math.min(plot.width, plot.depth) * .05
    const base = new T.Mesh(
      new T.BoxGeometry(plot.width, depth, plot.depth),
      [this.groundSide, this.groundSide, this.groundMaterial, this.groundSide, this.groundSide, this.groundSide],
    )
    base.position.y = -depth / 2
    this.scene.add(base)

    const x = plot.width / 2, z = plot.depth / 2, lineY = Math.min(x, z) * .00055
    const vertices = [new T.Vector3(-x, lineY, -z), new T.Vector3(x, lineY, -z), new T.Vector3(x, lineY, z), new T.Vector3(-x, lineY, z)]
    this.boundary = new T.LineLoop(new T.BufferGeometry().setFromPoints(vertices), new T.LineBasicMaterial({ color: '#285b45' }))
    this.scene.add(this.boundary)
    this.corners = new T.Points(new T.BufferGeometry().setFromPoints(vertices), new T.PointsMaterial({ color: '#285b45', size: 5, sizeAttenuation: false }))
    this.scene.add(this.corners)
    const gridPoints: number[] = []
    for (let i = -x + BUILD_GRID_STEP; i < x; i += BUILD_GRID_STEP) gridPoints.push(i, lineY, -z, i, lineY, z)
    for (let i = -z + BUILD_GRID_STEP; i < z; i += BUILD_GRID_STEP) gridPoints.push(-x, lineY, i, x, lineY, i)
    const grid = new T.BufferGeometry().setAttribute('position', new T.Float32BufferAttribute(gridPoints, 3))
    this.groundGrid = new T.LineSegments(grid, new T.LineBasicMaterial({ color: '#567160' }))
    this.scene.add(this.groundGrid)
    this.applyTheme()

    this.outline.visible = false
    this.scene.add(this.outline)
    const canvas = this.renderer.domElement
    this.orbit = new OrbitControls(this.camera, canvas)
    this.orbit.enableDamping = true
    this.orbit.maxPolarAngle = Math.PI * .49
    this.orbit.mouseButtons = { LEFT: null, MIDDLE: T.MOUSE.PAN, RIGHT: T.MOUSE.ROTATE }
    this.orbit.minZoom = .06
    this.orbit.maxZoom = Math.max(60, this.size / Math.max(.05, this.playerScale))
    this.transform = new TransformControls(this.camera, canvas)
    this.transform.setSize(.82)
    this.transform.setSpace('local')
    this.scene.add(this.transform.getHelper())
    this.transform.addEventListener('dragging-changed', event => { this.orbit.enabled = !event.value })
    this.transform.addEventListener('objectChange', () => { if (this.activeId) this.publishPreview(this.activeId) })
    this.transform.addEventListener('mouseUp', () => { if (this.activeId) this.callbacks.commit(this.activeId) })

    const { signal } = this.listeners
    canvas.addEventListener('mousedown', this.levelDown, { signal })
    window.addEventListener('mouseup', this.levelUp, { signal })
    window.addEventListener('fangcun-theme', () => this.applyTheme(), { signal })
    canvas.addEventListener('contextmenu', event => event.preventDefault(), { signal })
    canvas.addEventListener('pointerdown', this.pointerDown, { signal })
    canvas.addEventListener('pointermove', this.pointerMove, { signal })
    canvas.addEventListener('pointerup', this.pointerUp, { signal })
    canvas.addEventListener('pointercancel', this.cancelPointer, { signal })
    window.addEventListener('keydown', this.keyDown, { signal })
    window.addEventListener('keyup', this.keyUp, { signal })
    window.addEventListener('blur', () => { this.keys.clear(); this.finishLevel() }, { signal })

    this.resize()
    this.observer = new ResizeObserver(() => this.resize())
    this.observer.observe(host)
    this.fit()
    this.frame = requestAnimationFrame(this.tick)
  }

  get snapStep() { return BUILD_GRID_STEP }
  private get activeId() { return this.selected.length === 1 ? this.selected[0] : undefined }

  private resize() {
    const width = Math.max(1, this.host.clientWidth), height = Math.max(1, this.host.clientHeight)
    this.renderer.setSize(width, height)
    const aspect = width / height
    this.camera.left = -this.frustum * aspect / 2
    this.camera.right = -this.camera.left
    this.camera.top = this.frustum / 2
    this.camera.bottom = -this.camera.top
    this.camera.updateProjectionMatrix()
  }

  fit() {
    this.resetOrbitDamping()
    const bottom = -Math.min(this.plot.width, this.plot.depth) * .05
    const content = this.observe ? boundsOf(this.models) : undefined
    const top = content ? Math.max(0, content.max.y) : 0
    this.orbit.target.set(0, content ? (bottom + top) / 2 : 0, 0)
    if (this.observe) this.camera.position.set(0, 1, 1).multiplyScalar(this.size * 2)
    else this.camera.position.set(.9, .86, 1.12).multiplyScalar(this.size * 2)
    this.camera.position.add(this.orbit.target)
    this.camera.near = Math.max(.00001, this.size * .000002)
    this.camera.far = this.size * 28
    this.camera.zoom = 1
    this.orbit.update()
    this.camera.updateMatrixWorld(true)
    const v = new T.Vector3()
    let horizontal = 0, vertical = 0
    for (const x of [-this.plot.width / 2, this.plot.width / 2]) {
      for (const z of [-this.plot.depth / 2, this.plot.depth / 2]) {
        for (const y of [bottom, top]) {
          v.set(x, y, z).applyMatrix4(this.camera.matrixWorldInverse)
          horizontal = Math.max(horizontal, Math.abs(v.x))
          vertical = Math.max(vertical, Math.abs(v.y))
        }
      }
    }
    const aspect = Math.max(.25, this.host.clientWidth / Math.max(1, this.host.clientHeight))
    this.frustum = 2.65 * Math.max(vertical, horizontal / aspect)
    this.fitSize = this.frustum
    this.resize()
  }

  sync(items: Item[]) {
    this.collisionDirty = true
    this.transform.detach()
    for (const object of this.items.values()) {
      object.traverse(node => { if (node.userData.ownMaterial && node instanceof T.Mesh) node.material.dispose() })
    }
    this.items.clear()
    this.models.clear()
    for (const item of items) {
      const object = buildItem(item, () => { this.outlineDirty = true; this.collisionDirty = true; this.callbacks.loaded() }, () => this.callbacks.error('有一个 GLB 无法从本地存档读取。'))
      this.items.set(item.id, object)
      this.models.add(object)
    }
    this.select(this.selected)
  }
  select(ids: string[]) {
    this.selected = ids
    const active = this.activeId ? this.items.get(this.activeId) : undefined
    if (active && !this.walk && !this.observe && this.editable) this.transform.attach(active)
    else this.transform.detach()
    this.setInvalid(false)
  }
  get(id: string) { return this.items.get(id) }
  getBounds(id: string) {
    const object = this.get(id)
    return object ? boundsOf(object) : new T.Box3()
  }
  setGrid(enabled: boolean) { this.groundGrid.visible = enabled }
  setMode(mode: 'translate' | 'rotate' | 'scale') { this.transform.setMode(mode) }
  setSnap(enabled: boolean) {
    this.transform.setTranslationSnap(enabled ? this.snapStep : null)
    this.transform.setRotationSnap(enabled ? Math.PI / 12 : null)
    this.transform.setScaleSnap(enabled ? .1 : null)
  }
  private themeColor(name: string, fallback: string) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback
  }
  private applyTheme() {
    this.groundMaterial.color.set(this.themeColor('--ground', '#a1bb9f'))
    this.groundSide.color.set(this.themeColor('--ground-side', '#819e81'))
    this.groundGrid.material.color.set(this.themeColor('--grid-color', '#90a88e'))
    this.corners.material.color.set(this.themeColor('--ground-edge', '#285b45'))
    this.setInvalid(this.host.classList.contains('invalid'))
  }
  setInvalid(invalid: boolean) {
    this.outlineDirty = true
    const danger = invalid ? this.themeColor('--warning', '#b42318') : undefined
    ;(this.outline.material as T.LineBasicMaterial).color.set(danger ?? this.themeColor('--green', '#3b8c62'))
    this.boundary.material.color.set(danger ?? this.themeColor('--ground-edge', '#285b45'))
    this.host.classList.toggle('invalid', invalid)
  }

  setEditable(enabled: boolean) {
    this.editable = enabled
    this.transform.enabled = enabled
    if (!enabled) {
      if (this.transform.dragging) { this.transform.dragging = false; this.transform.axis = null }
      this.finishLevel(false)
      this.direct = this.startClick = undefined
      this.endPlacement()
    }
    this.select(this.selected)
  }
  get interacting() { return !!(this.direct || this.level || this.transform.dragging || this.placement) }

  private resetOrbitDamping() {
    const damping = this.orbit.enableDamping
    this.orbit.enableDamping = false
    this.orbit.update()
    this.orbit.enableDamping = damping
  }

  setObserve(enabled: boolean) {
    if (enabled === this.observe) return
    this.resetOrbitDamping()
    this.observe = enabled
    this.orbit.minPolarAngle = enabled ? FRONT_ELEVATION : 0
    this.orbit.maxPolarAngle = enabled ? FRONT_ELEVATION : Math.PI * .49
    this.orbit.minAzimuthAngle = enabled ? -FRONT_SWAY : -Infinity
    this.orbit.maxAzimuthAngle = enabled ? FRONT_SWAY : Infinity
    this.orbit.enablePan = !enabled
    this.orbit.mouseButtons.LEFT = enabled ? T.MOUSE.ROTATE : null
    if (enabled) {
      this.viewBeforeObserve = { camera: this.camera.position.clone(), target: this.orbit.target.clone(), zoom: this.camera.zoom, frustum: this.frustum }
      this.setInvalid(false)
      this.fit()
    } else if (this.viewBeforeObserve) {
      const view = this.viewBeforeObserve
      this.camera.position.copy(view.camera)
      this.orbit.target.copy(view.target)
      this.camera.zoom = view.zoom
      this.frustum = this.fitSize = view.frustum
      this.orbit.update()
      this.resize()
      this.viewBeforeObserve = undefined
    }
    this.select(this.selected)
  }

  setCharacter(character: Character) {
    this.animator.dispose()
    this.player.remove(this.character.object)
    this.releaseCharacter(this.character)
    this.character = character
    this.player.add(character.object)
    this.animator = new CharacterAnimation(character)
  }
  private releaseCharacter(character: Character) {
    character.object.traverse(node => {
      if (!(node instanceof T.Mesh)) return
      node.geometry.dispose()
      const materials = Array.isArray(node.material) ? node.material : [node.material]
      for (const material of materials) material.dispose()
      if (node instanceof T.SkinnedMesh) node.skeleton.dispose()
    })
  }

  async setWalk(enabled: boolean) {
    if (enabled) {
      const engine = await loadPhysics()
      if (this.closed) return false
      this.collision ??= new WalkCollision(engine, this.plot, this.playerScale)
      this.collision.rebuild(this.models)
      this.collisionDirty = false
      const spawn = this.collision.spawn(this.player.position)
      if (!spawn) throw new Error('地块内没有可用的行走起点。')
      this.player.position.copy(spawn)
    }
    this.walk = enabled
    this.keys.clear()
    this.player.visible = enabled
    if (enabled) {
      this.transform.detach()
      this.setInvalid(false)
      this.savedView = { camera: this.camera.position.clone(), target: this.orbit.target.clone(), zoom: this.camera.zoom }
      this.camera.position.add(this.player.position.clone().sub(this.orbit.target))
      this.orbit.target.copy(this.player.position)
      this.camera.zoom = Math.max(1, this.fitSize / (this.playerScale * 15))
      this.camera.updateProjectionMatrix()
      this.callbacks.walking(this.player.position, false)
    } else if (this.savedView) {
      this.camera.position.copy(this.savedView.camera)
      this.orbit.target.copy(this.savedView.target)
      this.camera.zoom = this.savedView.zoom
      this.camera.updateProjectionMatrix()
      this.select(this.selected)
    }
    this.orbit.update()
    return true
  }

  private tick = (now: number) => {
    const dt = this.time ? Math.min(.04, (now - this.time) / 1000) : 0
    this.time = now
    if (this.walk) this.stepPlayer(dt)
    this.orbit.update()
    if (this.outlineDirty) {
      this.selectionBox.makeEmpty()
      if (this.placement) this.selectionBox.copy(boundsOf(this.placement.object))
      else if (!this.walk && !this.observe && this.editable) this.selected.forEach(id => this.selectionBox.union(this.getBounds(id)))
      this.outline.visible = !this.selectionBox.isEmpty()
      this.outlineDirty = false
    }
    this.renderer.render(this.scene, this.camera)
    this.frame = requestAnimationFrame(this.tick)
  }

  private keyDown = (event: KeyboardEvent) => {
    if (!this.walk || !MOVEMENT.has(event.code) || (event.target as HTMLElement | null)?.closest('input,textarea,select,dialog')) return
    this.keys.add(event.code)
    event.preventDefault()
  }
  private keyUp = (event: KeyboardEvent) => { this.keys.delete(event.code) }

  private stepPlayer(dt: number) {
    const position = this.player.position
    if (this.collisionDirty && this.collision) {
      this.collision.rebuild(this.models)
      const spawn = this.collision.spawn(position)
      if (spawn) this.translatePlayer(spawn.sub(position))
      this.collisionDirty = false
    }
    const held = (primary: string, alternate: string) => Number(this.keys.has(primary) || this.keys.has(alternate))
    const forward = held('KeyW', 'ArrowUp') - held('KeyS', 'ArrowDown')
    const side = held('KeyD', 'ArrowRight') - held('KeyA', 'ArrowLeft')
    if ((!forward && !side) || !this.collision) {
      this.animator.update(dt, false, 0)
      return
    }
    const front = new T.Vector3()
    this.camera.getWorldDirection(front)
    front.y = 0
    front.normalize()
    const right = new T.Vector3(-front.z, 0, front.x)
    const direction = front.multiplyScalar(forward).addScaledVector(right, side).normalize()
    const speed = (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') ? 10 : 4.2) * this.playerScale
    const step = direction.multiplyScalar(speed * dt)
    const delta = this.collision.move(position, step)
    const limitX = this.plot.width / 2 - .36 * this.playerScale
    const limitZ = this.plot.depth / 2 - .36 * this.playerScale
    delta.x = T.MathUtils.clamp(position.x + delta.x, -limitX, limitX) - position.x
    delta.z = T.MathUtils.clamp(position.z + delta.z, -limitZ, limitZ) - position.z
    const blocked = delta.distanceToSquared(step) > 1e-7
    this.translatePlayer(delta)
    const motionSpeed = delta.length() / Math.max(dt, .001)
    if (motionSpeed > .08) this.player.rotation.y = Math.atan2(delta.x, delta.z)
    this.animator.update(dt, motionSpeed > .08, motionSpeed / this.playerScale)
    this.callbacks.walking(position, blocked)
  }

  private translatePlayer(delta: T.Vector3) {
    this.player.position.add(delta)
    this.camera.position.add(delta)
    this.orbit.target.add(delta)
  }

  private levelDown = (event: MouseEvent) => {
    const id = this.activeId
    if (event.button !== 1 || !(event.buttons & 1) || !id || !this.editable || this.observe || this.walk || this.placement || this.transform.dragging) return
    const object = this.get(id)
    if (!object) return
    event.preventDefault()
    if (this.direct?.moved) this.callbacks.commit(id)
    this.direct = this.startClick = undefined
    const z = new T.Vector3(0, 0, 1).applyQuaternion(object.quaternion)
    const yaw = Math.atan2(z.x, z.z)
    const x = new T.Vector3(1, 0, 0).applyQuaternion(object.quaternion)
      .applyAxisAngle(new T.Vector3(0, 1, 0), -yaw)
    this.level = { id, yaw, bank: Math.atan2(x.y, x.x), x: event.clientX, y: event.clientY }
    this.orbit.enabled = false
    this.callbacks.level(true)
    this.updateLevel(event)
  }
  private updateLevel(event: MouseEvent) {
    const level = this.level
    if (!level) return
    const object = this.get(level.id)
    if (!object) return
    const yaw = level.yaw + (event.clientX - level.x) * .012
    const bank = level.bank + (event.clientY - level.y) * .012
    object.quaternion.setFromEuler(new T.Euler(0, yaw, bank, 'YZX'))
    this.publishPreview(level.id)
  }
  private levelUp = (event: MouseEvent) => {
    if (event.button === 0 || event.button === 1) this.finishLevel()
  }
  private finishLevel(commit = true) {
    const gesture = this.level
    if (!gesture) return
    this.level = undefined
    this.orbit.enabled = true
    this.callbacks.level(false)
    if (commit) this.callbacks.commit(gesture.id)
  }

  private useRay(event: PointerEvent) {
    const rect = this.renderer.domElement.getBoundingClientRect()
    this.ray.setFromCamera(new T.Vector2((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1), this.camera)
  }
  private pointerDown = (event: PointerEvent) => {
    if (event.button !== 0 || !this.editable || this.observe || this.walk || this.transform.dragging) return
    if (this.placement) {
      this.updatePlacement(event)
      const { object, confirm } = this.placement
      if (fits(boundsOf(object), this.plot)) confirm(object.position.toArray())
      return
    }
    this.startClick = { x: event.clientX, y: event.clientY }
    this.useRay(event)
    const hits = this.ray.intersectObjects(this.models.children, true)
    if (!hits.length) return
    let target: T.Object3D = hits[0].object
    while (target.parent && target.parent !== this.models) target = target.parent
    const id: string = target.userData.itemId
    this.callbacks.select(id, event.shiftKey)
    this.startClick = undefined
    if (event.shiftKey || this.transform.mode !== 'translate') return
    this.direct = { id, x: event.clientX, y: event.clientY, pickY: hits[0].point.y, offset: target.position.clone().sub(hits[0].point), moved: false }
    this.renderer.domElement.setPointerCapture(event.pointerId)
  }
  private pointerMove = (event: PointerEvent) => {
    if (this.level) { this.updateLevel(event); return }
    if (this.placement) { this.updatePlacement(event); return }
    const drag = this.direct
    if (!drag) return
    if (!drag.moved && Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < 3) return
    const object = this.get(drag.id)
    if (!object) return
    this.useRay(event)
    const point = this.ray.ray.intersectPlane(new T.Plane(new T.Vector3(0, 1, 0), -drag.pickY), new T.Vector3())
    if (!point) return
    drag.moved = true
    const snap = this.transform.translationSnap
    object.position.x = snap ? Math.round((point.x + drag.offset.x) / snap) * snap : point.x + drag.offset.x
    object.position.z = snap ? Math.round((point.z + drag.offset.z) / snap) * snap : point.z + drag.offset.z
    this.publishPreview(drag.id)
  }
  private pointerUp = (event: PointerEvent) => {
    if (event.button !== 0) return
    const drag = this.direct
    this.direct = undefined
    if (drag?.moved) this.callbacks.commit(drag.id)
    if (this.startClick && !this.walk && Math.hypot(event.clientX - this.startClick.x, event.clientY - this.startClick.y) < 4) this.callbacks.select(undefined, false)
    this.startClick = undefined
  }
  private cancelPointer = () => {
    this.finishLevel()
    if (this.direct) this.callbacks.commit(this.direct.id)
    this.direct = this.startClick = undefined
  }

  beginPlacement(item: Item, source: T.Object3D, confirm: (position: Vec) => void) {
    this.endPlacement()
    this.transform.detach()
    const object = new T.Group()
    object.add(clone(source))
    applyItem(object, item)
    this.scene.add(object)
    this.placement = { object, confirm }
    this.outlineDirty = true
    this.host.classList.add('placing')
  }
  endPlacement() {
    if (this.placement) this.scene.remove(this.placement.object)
    this.placement = undefined
    this.host.classList.remove('placing')
    this.select(this.selected)
  }
  private updatePlacement(event: PointerEvent) {
    if (!this.placement) return
    this.useRay(event)
    const point = this.ray.ray.intersectPlane(new T.Plane(new T.Vector3(0, 1, 0), 0), new T.Vector3())
    if (!point) return
    const object = this.placement.object
    const snap = this.transform.translationSnap
    object.position.x = snap ? Math.round(point.x / snap) * snap : point.x
    object.position.z = snap ? Math.round(point.z / snap) * snap : point.z
    this.setInvalid(!fits(boundsOf(object), this.plot))
  }

  private publishPreview(id: string) {
    const object = this.get(id)
    if (!object) return
    const valid = fits(boundsOf(object), this.plot) && object.scale.toArray().every(value => Number.isFinite(value) && value > 0)
    this.setInvalid(!valid)
    this.callbacks.preview(id, {
      position: object.position.toArray(),
      rotation: [object.rotation.x, object.rotation.y, object.rotation.z],
      scale: object.scale.toArray() as Vec,
    }, valid)
  }

  dispose() {
    this.closed = true
    this.collision?.dispose()
    this.animator.dispose()
    this.player.remove(this.character.object)
    this.releaseCharacter(this.character)
    cancelAnimationFrame(this.frame)
    this.listeners.abort()
    this.observer.disconnect()
    this.transform.dispose()
    this.orbit.dispose()
    this.endPlacement()
    this.models.traverse(object => {
      if (object instanceof T.Mesh && object.userData.ownMaterial) object.material.dispose()
    })
    const release = (object: T.Object3D) => {
      if (object === this.models) return
      if (object instanceof T.Mesh || object instanceof T.Line || object instanceof T.Points) {
        object.geometry.dispose()
        const materials = Array.isArray(object.material) ? new Set(object.material) : [object.material]
        for (const material of materials) material.dispose()
      }
      object.children.forEach(release)
    }
    this.scene.children.filter(child => child !== this.transform.getHelper()).forEach(release)
    this.renderer.dispose()
    this.renderer.domElement.remove()
  }
}
