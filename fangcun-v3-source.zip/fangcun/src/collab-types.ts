import type { Item, Save, SceneData } from './data'

export type Role = 'owner' | 'edit' | 'view'
export type RoomAccess = { room: string; token: string }
export type RoomView = { role: Role; save: Save; version: number; online: number }
export type SceneChange = { collection: keyof SceneData; id: string; before: Item | null; after: Item | null }

export function sceneChanges(before: SceneData, after: SceneData): SceneChange[] {
  const changes: SceneChange[] = []
  for (const collection of ['items', 'models'] as const) {
    const old = new Map(before[collection].map(item => [item.id, item]))
    const next = new Map(after[collection].map(item => [item.id, item]))
    for (const id of new Set([...old.keys(), ...next.keys()])) {
      const previous = old.get(id) ?? null
      const value = next.get(id) ?? null
      if (JSON.stringify(previous) !== JSON.stringify(value)) changes.push({ collection, id, before: previous, after: value })
    }
  }
  return changes
}

export function applyChanges(scene: SceneData, changes: SceneChange[]) {
  const result = structuredClone(scene)
  for (const { collection, id, before, after } of changes) {
    const list = result[collection]
    const index = list.findIndex(item => item.id === id)
    if (JSON.stringify(list[index] ?? null) !== JSON.stringify(before)) return undefined
    if (index === -1 && after) list.push(after)
    else if (after) list[index] = after
    else if (index !== -1) list.splice(index, 1)
  }
  return result
}

export function assetIds(scene: SceneData) {
  const ids = new Set<string>()
  function visit(item: Item) {
    if (item.kind === 'glb' && item.asset) ids.add(item.asset)
    item.children?.forEach(visit)
  }
  scene.items.forEach(visit)
  scene.models.forEach(visit)
  return ids
}
