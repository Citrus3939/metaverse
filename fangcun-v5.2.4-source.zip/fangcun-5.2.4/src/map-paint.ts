import L from 'leaflet'
import {cellAt,cellKey,parseCell,plotForCell,plotCenter} from './plot-grid'
import {paintableCells,savePaint,type PaintCell,type PaintChange} from './region'

export const paintMarkup=`<section class="map-paint"><button id="paint-toggle" class="secondary full" aria-pressed="false">地图画笔</button>
<div id="paint-tools" hidden><label>画笔颜色 <input id="paint-color" type="color" value="#00aeec"></label>
<button id="paint-undo" class="secondary" disabled>撤销上一笔</button></div><small id="paint-note" role="status"></small></section>`

export function mountPaint(root:HTMLElement,map:L.Map,signal:AbortSignal,gridZoom:number,allowed:(cell:string)=>boolean,onColor:(rows:PaintCell[])=>void){
  const toggle=root.querySelector<HTMLButtonElement>('#paint-toggle')!,tools=root.querySelector<HTMLElement>('#paint-tools')!
  const color=root.querySelector<HTMLInputElement>('#paint-color')!,undo=root.querySelector<HTMLButtonElement>('#paint-undo')!
  const note=root.querySelector<HTMLElement>('#paint-note')!,surface=map.getContainer()
  let enabled=false,busy=false,ready=false,pointer:number|undefined,previous:L.Point|undefined
  let cells=new Map<string,PaintCell>(),last:PaintChange[]=[]
  const stroke=new Map<string,PaintChange>(),layers=new Map<string,L.Rectangle>()
  const pane=map.createPane('paintPixels');pane.style.zIndex='440';pane.style.pointerEvents='none'
  function draw(row:PaintCell,value:string|null){
    const old=layers.get(row.cell)
    if(!value || map.getZoom()<13){old?.remove();layers.delete(row.cell);return}
    const plot=plotForCell(parseCell(row.cell)!),offset=360*Math.round((map.getCenter().lng-plotCenter(plot)[1])/360)
    const bounds:L.LatLngBoundsExpression=[[plot.south,plot.west+offset],[plot.north,plot.east+offset]]
    if(!map.getBounds().intersects(bounds)){old?.remove();layers.delete(row.cell);return}
    if(old){old.setBounds(bounds);old.setStyle({fillColor:value});return}
    layers.set(row.cell,L.rectangle(bounds,{pane:'paintPixels',interactive:false,stroke:false,fillColor:value,fillOpacity:.85}).addTo(map))
  }
  function redraw(){for(const row of cells.values())draw(row,stroke.get(row.room)?.after??row.pixel)}
  let revision=0
  async function load(background=false){
    const request=++revision
    if(!background)ready=false
    try{
      const rows=await paintableCells()
      if(signal.aborted || revision!==request || background && (busy || pointer!==undefined))return
      const next=new Map(rows.filter(r=>allowed(r.cell)).map(r=>[r.cell,r]))
      const changed=[...next.values()].filter(r=>!cells.has(r.cell) || cells.get(r.cell)?.pixel!==r.pixel)
      for(const key of cells.keys())if(!next.has(key)){layers.get(key)?.remove();layers.delete(key)}
      cells=next;ready=true
      if(changed.length){onColor(changed);redraw()}
    }catch{if(!signal.aborted && !background)note.textContent='地籍读取失败，请重新开启画笔。'}
  }
  function mode(value:boolean){
    enabled=value;toggle.setAttribute('aria-pressed',String(value));toggle.textContent=value?'退出画笔（Esc）':'地图画笔'
    tools.hidden=!value;surface.classList.toggle('painting',value)
    if(value){map.dragging.disable();if(map.getZoom()<gridZoom)map.setZoom(gridZoom);void load()}
    else map.dragging.enable()
    note.textContent=value?'点击或拖过可编辑地块，松手保存。':''
  }
  toggle.onclick=()=>{if(!busy && pointer===undefined)mode(!enabled)}
  function cancel(){pointer=undefined;previous=undefined;stroke.clear();redraw()}
  async function commit(changes:PaintChange[],reversing=false){
    if(!changes.length)return
    busy=true;undo.disabled=toggle.disabled=true
    try{
      await savePaint(changes)
      if(signal.aborted)return
      const byRoom=new Map([...cells.values()].map(row=>[row.room,row]))
      const updated:PaintCell[]=[]
      for(const c of changes){const row=byRoom.get(c.room);if(row){row.pixel=c.after;updated.push(row)}}
      onColor(updated)
      last=reversing?[]:changes
      note.textContent=(reversing?'已撤销':'已保存')+' · '+changes.length+' 格'
    }catch(e){if(!signal.aborted){await load();note.textContent=e instanceof Error?e.message:'保存失败，请重试。'}}
    finally{busy=false;if(!signal.aborted){cancel();toggle.disabled=false;undo.disabled=!last.length}}
  }
  undo.onclick=()=>{if(!busy && pointer===undefined)void commit(last.map(c=>({room:c.room,before:c.after,after:c.before})),true)}
  function mark(point:L.Point){
    const ll=map.containerPointToLatLng(point),row=cells.get(cellKey(cellAt(ll.lat,ll.lng)))
    if(!row || row.pixel===color.value || stroke.has(row.room) || stroke.size>=1024)return
    stroke.set(row.room,{room:row.room,before:row.pixel,after:color.value});draw(row,color.value)
  }
  function trace(e:PointerEvent){
    const point=map.mouseEventToContainerPoint(e),start=previous??point
    const steps=Math.max(1,Math.ceil(start.distanceTo(point)/3))
    for(let i=1;i<=steps;i++)mark(start.add(point.subtract(start).multiplyBy(i/steps)))
    previous=point
  }
  const opts={capture:true,signal}
  surface.addEventListener('pointerdown',e=>{
    if(!enabled || e.button!==0)return
    e.preventDefault();e.stopImmediatePropagation()
    if(!ready || busy || pointer!==undefined || map.getZoom()<gridZoom)return
    pointer=e.pointerId;surface.setPointerCapture(pointer);trace(e)
  },opts)
  surface.addEventListener('pointermove',e=>{if(pointer===e.pointerId){e.stopImmediatePropagation();trace(e)}},opts)
  surface.addEventListener('pointerup',e=>{
    if(pointer!==e.pointerId)return
    e.stopImmediatePropagation();trace(e);pointer=undefined;previous=undefined
    if(stroke.size)void commit([...stroke.values()])
    else note.textContent='可在自有或已授权编辑的格子上色。'
  },opts)
  for(const name of ['click','dblclick','mousedown','mouseup'])surface.addEventListener(name,e=>{if(enabled){e.preventDefault();e.stopImmediatePropagation()}},opts)
  surface.addEventListener('lostpointercapture',()=>{if(pointer!==undefined)cancel()},opts)
  window.addEventListener('keydown',e=>{if(enabled && e.key==='Escape' && !busy){cancel();mode(false)}},{signal})
  map.on('moveend zoomend',redraw)
  void load()
  const timer=window.setInterval(()=>{if(!document.hidden && ready && !busy && pointer===undefined)void load(true)},5000)
  signal.addEventListener('abort',()=>clearInterval(timer),{once:true})
  return ()=>enabled
}
