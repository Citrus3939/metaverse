import type { WorkbenchView } from './workbench'
import './styles.css'
import { version } from '../package.json'
import { getPlotSave, lastPlot, migratePreviousSave, ownerRoomKey, savedPlots, setSave, newId, EMPTY, type Save } from './data'
import { parseCell, plotForCell, plotKey, type Plot } from './plot-grid'
import { mapPage } from './map'
import { setupTheme } from './theme'
import { joinRoom, RoomClient, RoomRequestError } from './room'
import { landAvailability, createRegion, joinRegion, RegionClient } from './region'
import { sceneChanges, type RoomAccess } from './collab-types'
import { $, icons, logo, escapeHtml } from './ui'

const app = $('app')
document.title = `方寸 ${version} · 3D 地块工作室`
migratePreviousSave()
let recent = lastPlot()
let regionRecent: Plot | undefined
let dispose: (() => void) | undefined
let active: 'map' | 'editor' | 'lobby' = 'map'
let section: 'solo' | 'multi' = 'solo'
let loading = false
let guest: RoomClient | undefined
let region: RegionClient | undefined
let seed: { name: string; nickname: string } | undefined
type RegionInvite = { id: string; invite: string }
const guestKey = 'fangcun.guest-room'
const guestOpenKey = 'fangcun.guest-open'
const regionOwnerKey = 'fangcun.region-owner'
const regionGuestKey = 'fangcun.region-guest'
const sectionKey = 'fangcun.world'
const previousSection = sessionStorage.getItem(sectionKey)
const activeRegionKey = 'fangcun.active-region'
const regionsKey = 'fangcun.regions'
type SavedRegion = { access: RoomAccess; name: string; lastCell?: string; cells?: string[] }
function loadRegions(): Record<string, SavedRegion> {
  try { return JSON.parse(localStorage.getItem(regionsKey) ?? 'null') ?? {} }
  catch { return {} }
}
const savedRegions = loadRegions()
const formerAccess = restoreAccess(sessionStorage, regionGuestKey) ?? restoreAccess(localStorage, regionOwnerKey)
for (const access of [restoreAccess(localStorage, regionOwnerKey), restoreAccess(sessionStorage, regionGuestKey)]) {
  if (access && !savedRegions[access.room]) savedRegions[access.room] = { access, name: '上次的共建区' }
}
localStorage.setItem(regionsKey, JSON.stringify(savedRegions))
const rememberedActive = sessionStorage.getItem(activeRegionKey) ?? formerAccess?.room

function rememberRegion(client: RegionClient, lastCell?: string) {
  Object.assign(savedRegions, loadRegions())
  const { access, latest } = client
  const previous = savedRegions[access.room]
  savedRegions[access.room] = { access, cells: latest?.tiles.map(tile => tile.key) ?? previous?.cells, name: latest?.name ?? previous?.name ?? '共建区', lastCell: lastCell ?? previous?.lastCell }
  localStorage.setItem(regionsKey, JSON.stringify(savedRegions))
}
function adoptRegion(client: RegionClient) {
  region = client
  rememberRegion(client)
  const cells = client.latest?.tiles ?? []
  const selected = cells.find(tile => tile.key === savedRegions[client.access.room].lastCell) ?? cells[0]
  regionRecent = selected ? plotForCell(parseCell(selected.key)!) : undefined
  sessionStorage.setItem(activeRegionKey, client.access.room)
}

function restoreAccess(storage: Storage, key: string) {
  try {
    const raw = storage.getItem(key)
    return raw ? JSON.parse(raw) as RoomAccess : undefined
  } catch { return undefined }
}
let announceTimer = 0
function announce(text: string) {
  const message = $('app-message')
  message.textContent = text
  message.hidden = false
  window.clearTimeout(announceTimer)
  announceTimer = window.setTimeout(() => { message.hidden = true }, 5500)
}

app.innerHTML = `
  <header class="topbar">
    <button class="brand" id="brand" aria-label="方寸，返回地图" title="方寸 ${version}">
      ${logo()}<div><strong>方寸</strong><small>地块工作室 · ${version}</small></div>
    </button>
    <nav class="workflow" aria-label="世界入口">
      <button id="map-tab">${icons.map}<span>世界地图</span></button>
      <button id="multiplayer-tab">${icons.group}<span>多人共建</span></button>
      <span class="workflow-arrow">${icons.chevron}</span>
      <button id="editor-tab">${icons.box}<span>3D 工作台</span></button>
    </nav>
    <div class="header-actions"><button class="secondary" id="leave-region" hidden>退出共建</button><label for="theme-picker" class="theme-control">主题 <select id="theme-picker"><option value="sky">天蓝白</option><option value="github-light">GitHub Light</option><option value="vscode-dark">VS Code Dark+</option><option value="nord">Nord</option><option value="pine">松绿</option><option value="night">深海夜色</option></select></label></div>
  </header>
  <main id="page"></main>
  <footer id="map-footer" class="map-footer"><div>${icons.globe}<span id="map-storage">本地地块保存在浏览器，已接入地块与共建区同步</span></div><div>地图格网按成都纬度校准</div></footer>
  <p id="app-message" class="app-message" role="alert" hidden></p>`

function navigation() {
  sessionStorage.setItem(sectionKey, section)
  $('leave-region').hidden = section !== 'multi' || !region || active === 'lobby'
  document.querySelector('.workflow [aria-current]')?.removeAttribute('aria-current')
  $(active === 'editor' ? 'editor-tab' : section === 'multi' ? 'multiplayer-tab' : 'map-tab').setAttribute('aria-current', 'step')
  ;($('editor-tab') as HTMLButtonElement).disabled = section === 'multi' ? !regionRecent : !recent
  $('map-footer').hidden = active !== 'map'
  $('map-storage').textContent = section === 'multi' ? '建造内容保存在共建服务' : '本地地块保存在浏览器，已接入地块与共建区同步'
}

function clearPage() {
  dispose?.()
  dispose = undefined
}
function showMap() {
  clearPage()
  active = 'map'
  $('page').className = 'map-page'
  navigation()
  const solo = section === 'solo'
  const plots = new Map(savedPlots().map(plot => [plotKey(plot), plot]))
  for (const saved of Object.values(loadRegions())) {
    for (const key of saved.cells ?? []) {
      const cell = parseCell(key)
      if (cell) plots.set(key, plotForCell(cell))
    }
  }
  dispose = mapPage($('page'), {
    saved: solo ? [...plots.values()] : [],
    recent: solo ? lastPlot() : regionRecent,
    guest: solo ? guest?.latest?.save.plot : undefined,
    onGuest: () => { if (guest?.latest) void enterEditor(guest.latest.save.plot, { guest }) },
    region: solo ? undefined : region,
    seed: solo ? undefined : seed?.name,
    onEnter: plot => { void selectPlot(plot) },
    canOpenActivity: (target, plot) => !seed && (target.region
      ? !!savedRegions[target.region]
      : solo && (guest?.access.room === target.room || restoreAccess(localStorage, ownerRoomKey(plot))?.room === target.room)),
    openActivity: (target, plot) => {
      if (target.region) {
        const saved = savedRegions[target.region]
        if (saved) void openSavedRegion(saved.access, plot)
      } else if (guest?.access.room === target.room) void enterEditor(plot, { guest })
      else void enterEditor(plot)
    },
  })
}
async function selectPlot(plot: Plot) {
  if (loading) return
  if (!seed || section === 'solo') {
    await enterEditor(plot);return
  }
  const draft = seed
  loading = true
  try {
    const quote=await landAvailability(plotKey(plot))
    if(quote.occupied)throw new Error('这格已有主人，请选择空地。')
    if(!quote.canSeed)throw new Error('请从已有自有地的边缘扩展，或到朋友的共建区拼地。')
    if(quote.seedPrice && !confirm('花 '+quote.seedPrice+' 方币购入这一格，创建新共建区？'))return
    const client = await createRegion(draft.name, draft.nickname, plotKey(plot))
    await client.read()
    adoptRegion(client)
    seed = undefined
    sessionStorage.removeItem(regionGuestKey)
    localStorage.setItem(regionOwnerKey, JSON.stringify(client.access))
    localStorage.setItem('fangcun.builder-name', draft.nickname)
  } catch (error) {
    announce(error instanceof Error ? error.message : '共建区创建失败。')
    return
  } finally { loading = false }
  await enterEditor(plot)
}

async function sharedRegionFor(key: string) {
  // The server knows which region owns this coordinate. A browser can retain
  // membership from an older database served at the same localhost address.
  let quote: Awaited<ReturnType<typeof landAvailability>> | undefined
  try {
    quote = await landAvailability(key)
  } catch (error) {
    if (error instanceof RoomRequestError && error.status < 500) throw error
  }
  if (quote && !quote.occupied) return undefined

  const matches: RegionClient[] = []
  const cached = Object.values(loadRegions())
  const candidates = quote?.joined.length
    ? quote.joined.map(access => ({ access, relevant: true }))
    : cached.map(saved => ({
        access: saved.access,
        relevant: !saved.cells || saved.cells.includes(key) || saved.lastCell === key,
      }))
  for (const {access, relevant} of candidates) {
    const member = new RegionClient(access)
    try {
      await member.read()
    } catch (error) {
      if (error instanceof RoomRequestError && [403, 404, 410].includes(error.status)) continue
      if (relevant) throw error
      continue
    }
    rememberRegion(member)
    if (member.tile(key)) matches.push(member)
  }
  if (quote?.occupied && !matches.length) throw new Error('这格已有主人。请通过共建邀请进入。')
  if (matches.length <= 1) return matches[0]
  const answer = prompt('这个位置有多个已加入的共建区，请输入编号：\n' + matches.map((m,i) => (i+1) + '. ' + m.latest!.name).join('\n'))
  const selected = matches[Number(answer)-1]
  if (!selected) throw new Error('请选择共建区后再打开此格。')
  return selected
}

async function migratePlot(client: RoomClient, plot: Plot) {
  const key = 'fangcun.unified.' + client.access.room
  const view = client.latest!
  if (view.role !== 'owner' || localStorage.getItem(key) === 'done') return
  const local = getPlotSave(plot)?.scene
  if (local) {
    const remote = view.save.scene
    const merged = structuredClone(remote)
    let differs = false
    const ids = JSON.parse(localStorage.getItem(key) ?? '{}') as Record<string,string>
    for (const collection of ['items','models'] as const) {
      for (const item of local[collection]) {
        const previous = remote[collection].find(entry => entry.id === item.id)
        if (JSON.stringify(previous) === JSON.stringify(item)) continue
        differs = true
        const id = previous ? (ids[collection + item.id] ??= newId()) : item.id
        if (!merged[collection].some(entry => entry.id === id)) merged[collection].push({ ...item, id })
      }
    }
    if(local.pixel && !merged.pixel){merged.pixel=local.pixel;differs=true}
    for (const side of local.streets ?? []) {
      if (!merged.streets?.includes(side)) { (merged.streets ??= []).push(side); differs = true }
    }
    if (differs && (remote.items.length || remote.models.length || remote.streets?.length) &&
        !confirm('此格有两份旧存档。确定合并并保留双方物件？同一物件的不同版本会分别保留。取消将仅打开共建存档，下次再处理。')) return
    localStorage.setItem(key, JSON.stringify(ids))
    await client.publish(sceneChanges(remote, merged), !remote.items.length && !remote.models.length && !remote.streets?.length)
  }
  localStorage.setItem(key, 'done')
}

async function enterEditor(plot: Plot, choice: { guest?: RoomClient; switchCell?: boolean; view?:WorkbenchView; openEstate?:boolean } = {}) {
  if ((active === 'editor' && !choice.switchCell) || loading) return
  loading = true
  let cleared = false
  try {
    const key = plotKey(plot)
    let currentRegion = section === 'multi' ? region : choice.guest ? undefined : await sharedRegionFor(key)
    let client = currentRegion?.room(key) ?? choice.guest
    if (currentRegion && !client) throw new Error('请选择共建区内已经接入的地块。')
    if (client) {
      try {
        await client.read()
      } catch (error) {
        if (!currentRegion || !(error instanceof RoomRequestError) || ![403,404,410].includes(error.status)) throw error
        const refreshed = await sharedRegionFor(key)
        if (refreshed?.access.room === currentRegion.access.room && refreshed.room(key)?.access.room === client.access.room) throw error
        currentRegion = refreshed
        client = refreshed?.room(key)
        if (client) await client.read()
        else { region = undefined; regionRecent = undefined; section = 'solo' }
      }
    }
    if (currentRegion) {
      adoptRegion(currentRegion)
      section = 'multi'
      if (client) await migratePlot(client, plot)
    }
    const ownerKey = ownerRoomKey(plot)
    const existing = currentRegion ? null : getPlotSave(plot)
    const inGuestRoom = !!choice.guest
    if (!client && existing) {
      const access = restoreAccess(localStorage, ownerKey)
      if (access) {
        client = new RoomClient(access)
        try { await client.read() }
        catch (error) {
          if (!(error instanceof RoomRequestError) || ![403, 404].includes(error.status)) throw error
          localStorage.removeItem(ownerKey)
          client = undefined
          announce('共建房间已失效，已打开此浏览器内的存档。')
        }
      }
    }
    const initial: Save = client?.latest?.save ?? existing ?? { plot, scene: structuredClone(EMPTY) }
    sessionStorage.setItem(guestOpenKey, String(inGuestRoom))
    const { editorPage } = await import('./editor')
    clearPage()
    cleared = true
    active = 'editor'
    if (currentRegion) {
      regionRecent = initial.plot
      rememberRegion(currentRegion, plotKey(initial.plot))
    } else if (!inGuestRoom) recent = initial.plot
    $('page').className = 'editor-page'
    navigation()
    dispose = editorPage($('page'), initial, value => {
      if (inGuestRoom || currentRegion) return
      setSave(value)
      recent = value.plot
    }, {
      client, region: currentRegion, overview: showMap, guest: inGuestRoom,
      localNeighbors: currentRegion || inGuestRoom ? undefined : savedPlots().map(getPlotSave).filter((s):s is Save=>!!s),
      view:choice.view,openCurrentEstate:choice.openEstate,
      editCell: (key,view,openEstate) => {
        const cell = parseCell(key)
        if (cell) void enterEditor(plotForCell(cell), { switchCell: true,view,openEstate })
      },
      sharePlot: async (entry = 'room') => {
        const cell=plotKey(plot)
        let shared=await sharedRegionFor(cell)
        if(!shared){
          const quote=await landAvailability(cell)
          if(quote.joined[0])shared=new RegionClient(quote.joined[0])
          else if(quote.occupied)throw new Error('这格已有主人，请通过邀请加入。')
          else if(quote.adjacent.length){
            const index=quote.adjacent.length===1 ? 0 : Number(prompt('选择要扩展的共建区，输入编号\n'+quote.adjacent.map((a,i)=>(i+1)+'. '+a.name).join('\n')))-1
            const target=quote.adjacent[index]
            if(!target || !confirm('花 240 方币，将此格接入「'+target.name+'」？'))return
            shared=new RegionClient(target);await shared.add(cell)
          } else {
            if(!quote.canSeed)throw new Error('请到已有地块的相邻位置经营，或使用邀请加入好友的街坊。')
            if(quote.seedPrice && !confirm('花 '+quote.seedPrice+' 方币购入这块地？'))return
            shared=await createRegion('我的共建区',localStorage.getItem('fangcun.builder-name')||'建造者',cell)
          }
        }
        await shared.read()
        adoptRegion(shared)
        section = 'multi'
        await enterEditor(plot, { switchCell: true })
        if (active === 'editor' && section==='multi' && document.getElementById(entry==='estate'?'estate-open':'room-btn')) $(entry==='estate'?'estate-open':'room-btn').click()
      },
    })
    if(choice.openEstate)$('estate-open').click()
  } catch (error) {
    if (!choice.switchCell || cleared) showMap()
    const message = error instanceof Error ? error.message : ''
    announce(/WebGL/i.test(message)
      ? '当前浏览器无法启动 WebGL。请用支持 WebGL 2 的本机浏览器进入 3D 工作台。'
      : message || '无法打开 3D 工作台。')
  } finally {
    loading = false
  }
}

function invitedRegion(hash: URLSearchParams): RegionInvite | undefined {
  const id = hash.get('region'), invite = hash.get('invite')
  return id && /^[a-f0-9]{24}$/.test(id) && invite && /^[a-f0-9]{64}$/.test(invite) ? { id, invite } : undefined
}
function invitationFromInput(value: string) {
  try {
    const url = new URL(value.trim(), location.href)
    return url.origin === location.origin ? invitedRegion(new URLSearchParams(url.hash.slice(1))) : undefined
  } catch { return undefined }
}
function showLobby(invitation?: RegionInvite) {
  Object.assign(savedRegions, loadRegions())
  clearPage()
  seed = undefined
  region = undefined
  regionRecent = undefined
  sessionStorage.setItem(activeRegionKey, '')
  active = 'lobby'
  section = 'multi'
  const nickname = escapeHtml(localStorage.getItem('fangcun.builder-name') ?? '')
  $('page').className = 'region-landing'
  $('page').innerHTML = `<section class="region-entry${invitation ? ' invite-only' : ''}">
    <header><h1>多人共建</h1><p>第一块自有地免费，此后购地每格 240 方币。加入朋友的共建区可拼入相邻的自有地。</p></header>
    ${!invitation && Object.keys(savedRegions).length ? `<section class="saved-regions"><h2>我的共建区</h2>
      ${Object.values(savedRegions).map(({ access, name }) => `<button type="button" class="secondary" data-open-region="${escapeHtml(access.room)}">${escapeHtml(name)} ${icons.arrow}</button>`).join('')}
    </section>` : ''}
    ${invitation ? '' : `<form id="create-region-form">
      <h2>创建共建区</h2>
      <label class="field-label" for="region-title">共建区名称</label><input class="text-field" id="region-title" required maxlength="50">
      <label class="field-label" for="region-owner-nickname">建造昵称</label><input class="text-field" id="region-owner-nickname" required maxlength="24" value="${nickname}">
      <button class="primary full" type="submit">选择起始地块 ${icons.arrow}</button>
    </form>`}
    <form id="join-region-form">
      <h2>加入共建区</h2>
      ${invitation ? '' : '<label class="field-label" for="region-join-link">邀请链接</label><input class="text-field" id="region-join-link" required>'}
      <label class="field-label" for="region-guest-nickname">建造昵称</label><input class="text-field" id="region-guest-nickname" required maxlength="24" value="${nickname}">
      <button class="primary full" id="join-region-submit" type="submit">进入共建区 ${icons.arrow}</button>
    </form>
  </section>`
  navigation()
  $('page').querySelectorAll<HTMLButtonElement>('[data-open-region]').forEach(button => {
    button.onclick = () => { const saved = savedRegions[button.dataset.openRegion!]; if (saved) void openSavedRegion(saved.access) }
  })
  if (!invitation) $('create-region-form').onsubmit = event => {
    event.preventDefault()
    const name = ($('region-title') as HTMLInputElement).value.trim()
    const nickname = ($('region-owner-nickname') as HTMLInputElement).value.trim()
    if (!name || !nickname) { announce('请填写共建区名称和建造昵称。'); return }
    region = undefined
    regionRecent = undefined
    seed = { name, nickname }
    showMap()
  }
  $('join-region-form').onsubmit = async event => {
    event.preventDefault()
    if (loading) return
    const target = invitation ?? invitationFromInput(($('region-join-link') as HTMLInputElement).value)
    const nickname = ($('region-guest-nickname') as HTMLInputElement).value.trim()
    if (!target || !nickname) { announce('请填写有效的同站邀请链接和建造昵称。'); return }
    loading = true
    ;($('join-region-submit') as HTMLButtonElement).disabled = true
    try {
      const client = await joinRegion(target.id, target.invite, nickname, savedRegions[target.id]?.access.token)
      await client.read()
      adoptRegion(client)
      sessionStorage.setItem(regionGuestKey, JSON.stringify(client.access))
      localStorage.setItem('fangcun.builder-name', nickname)
      history.replaceState(null, '', location.pathname + location.search)
      showMap()
    } catch (error) {
      announce(error instanceof Error ? error.message : '无法加入共建区。')
      ;(document.getElementById('join-region-submit') as HTMLButtonElement | null)?.removeAttribute('disabled')
    } finally { loading = false }
  }
}

function openSolo() {
  if (loading) return
  const leaving = section === 'multi' ? region : undefined
  sessionStorage.setItem(guestOpenKey, 'false')
  section = 'solo'
  showMap()
  void leaving?.leave().catch(() => {})
}
async function openSavedRegion(access: RoomAccess, plot?: Plot) {
  if (loading) return
  loading = true
  try {
    const client = new RegionClient(access)
    await client.read()
    const leaving = region
    adoptRegion(client)
    section = 'multi'
    showMap()
    if (leaving) void leaving.leave().catch(() => {})
  } catch (error) {
    showLobby()
    announce(error instanceof Error ? error.message : '无法读取共建区。')
  } finally { loading = false }
  if (plot && region?.access.room === access.room) await enterEditor(plot)
}
function openMultiplayer() {
  if (loading) return
  section = 'multi'
  if (region || seed) { showMap(); return }
  showLobby()
}
function leaveRegion() {
  if (loading) return
  const leaving = region
  history.replaceState(null, '', location.pathname + location.search)
  showLobby()
  void leaving?.leave().catch(() => {})
}
$('leave-region').onclick = leaveRegion
$('brand').onclick = () => { if (!loading) section === 'multi' ? void openMultiplayer() : openSolo() }
$('map-tab').onclick = openSolo
$('multiplayer-tab').onclick = () => void openMultiplayer()
$('editor-tab').onclick = () => {
  const plot = section === 'multi' ? regionRecent : recent
  if (plot) void enterEditor(plot)
}

async function readInvitation(restore: boolean) {
  const hash = new URLSearchParams(location.hash.slice(1))
  const regionInvite = invitedRegion(hash)
  if (regionInvite) {
    if (region) void region.leave().catch(() => {})
    showLobby(regionInvite)
    return
  }
  const room = hash.get('room'), invite = hash.get('invite')
  if (!room && !invite && !restore) return
  try {
    const access = restoreAccess(sessionStorage, guestKey)
    const client = room && invite ? await joinRoom(room, invite) : access ? new RoomClient(access) : undefined
    if (!client) return
    const view = await client.read()
    sessionStorage.setItem(guestKey, JSON.stringify(client.access))
    if (room && invite) history.replaceState(null, '', location.pathname + location.search)
    guest = client
    if (!invite && sessionStorage.getItem(guestOpenKey) === 'false') {
      if (active === 'map' && section === 'solo') showMap()
      return
    }
    openSolo()
    await enterEditor(view.save.plot, { guest: client })
  } catch (error) { announce(error instanceof Error ? error.message : '无法加入地块。') }
}

setupTheme()
showMap()
if (!location.hash && previousSection === 'multi') {
  const saved = rememberedActive ? savedRegions[rememberedActive] : undefined
  if (saved) void openSavedRegion(saved.access)
  else showLobby()
}
else void readInvitation(true)
window.addEventListener('hashchange', () => void readInvitation(false))
