import { payload, request, RoomClient } from './room'
import type { PresenceUpdate, RegionTile, RegionView, RoomAccess } from './collab-types'
import { assetStorageKey, getAsset, newId, putAsset, type CharacterSkin } from './data'

export async function createRegion(name: string, nickname: string, cell: string) {
  return new RegionClient(await request<RoomAccess>('region/create', payload({ name, nickname, cell })))
}
export async function joinRegion(region: string, invite: string, nickname: string, token?: string) {
  const init = payload({ invite, nickname })
  const headers = new Headers(init.headers)
  if (token) headers.set('Authorization', `Bearer ${token}`)
  return new RegionClient(await request<RoomAccess>(`region/${region}/join`, { ...init, headers }))
}

export class RegionClient {
  latest?: RegionView
  private byCell = new Map<string, RegionTile>()
  private heartbeat?: Promise<RegionView>
  private readonly peer = newId()
  private mutation = 0
  private avatar?: CharacterSkin
  private avatarRevision = 0

  constructor(readonly access: RoomAccess) {}

  private async call<T>(action: string, init: RequestInit = {}) {
    const headers = new Headers(init.headers)
    headers.set('Authorization', `Bearer ${this.access.token}`)
    headers.set('X-Fangcun-Peer', this.peer)
    return request<T>(`region/${this.access.room}/${action}`, { ...init, headers })
  }

  private apply(view: RegionView) {
    this.latest = view
    this.byCell = new Map(view.tiles.map(tile => [tile.key, tile]))
    return view
  }
  async read(presence?: PresenceUpdate) {
    const mutation = this.mutation
    const input = presence?.mode === 'walk' ? { ...presence, skin: this.avatar } : presence
    const view = await this.call<RegionView>('state', input ? payload(input) : undefined)
    return mutation !== this.mutation && this.latest ? this.latest : this.apply(view)
  }
  tile(cell: string) { return this.byCell.get(cell) }
  room(cell: string) {
    const tile = this.tile(cell)
    return tile ? new RoomClient({ room: tile.room, token: this.access.token }) : undefined
  }
  private async change(action: string, init: RequestInit) {
    const view = await this.call<RegionView>(action, init)
    this.mutation++
    return this.apply(view)
  }
  async add(cell: string) { return this.change('add', payload({ cell })) }
  async allowEditing(cell: string, enabled: boolean) {
    return this.change('write', payload({ cell, enabled }))
  }
  async invite(grant: 'view' | 'edit') {
    const { invite } = await this.call<{ invite: string }>('invite', payload({ grant }))
    const url = new URL(location.pathname, location.origin)
    url.hash = new URLSearchParams({ region: this.access.room, invite }).toString()
    return url.href
  }
  async revokeEditing() { return this.change('revoke-edit', { method: 'POST' }) }
  async leave() {
    await this.heartbeat?.catch(() => {})
    await this.call('leave', { method: 'POST' })
  }

  async setAvatar(skin?: CharacterSkin) {
    const revision = ++this.avatarRevision
    this.avatar = undefined
    if (!skin) return
    const data = await getAsset(assetStorageKey(skin.asset, 'png'))
    if (!data) return
    await this.call(`avatar/${skin.asset}`, { method: 'PUT', body: data })
    if (revision === this.avatarRevision) this.avatar = skin
  }
  async downloadAvatar(id: string) {
    const response = await fetch(`/collab/region/${this.access.room}/avatar/${id}`, {
      headers: { Authorization: `Bearer ${this.access.token}` },
    })
    if (!response.ok) return undefined
    const data = await response.arrayBuffer()
    try { await putAsset(assetStorageKey(id, 'png'), data) } catch { /* Can still render the downloaded image. */ }
    return data
  }

  watch(presence: () => PresenceUpdate, listener: (view?: RegionView) => void) {
    let cancelled = false
    let timer = 0
    const tick = async () => {
      const pending = this.read(presence())
      this.heartbeat = pending
      try {
        const view = await pending
        if (!cancelled) listener(view)
      } catch {
        if (!cancelled) listener()
      } finally {
        if (this.heartbeat === pending) this.heartbeat = undefined
        if (!cancelled) timer = window.setTimeout(tick, 430)
      }
    }
    void tick()
    return () => { cancelled = true; window.clearTimeout(timer) }
  }
}
