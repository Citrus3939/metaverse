import { placeOnGrid, plotKey, PLOT_SIZE, type Plot } from './plot-grid'
export type { Plot } from './plot-grid'

export type Vec = [number, number, number]
export type Corner = [number, number]
export type Primitive = 'box' | 'cylinder' | 'sphere'
export type NpcBody = 'classic' | 'slim'
export type CharacterSkin = { asset: string; body: NpcBody }
export type NpcSettings = { body: NpcBody; greeting: string; persona: string; knowledge: string; ai: boolean }
export type AssetKind = 'glb' | 'png'
export const assetStorageKey = (id: string, kind: AssetKind) => kind === 'png' ? `png:${id}` : id
export type Item = {
  id: string
  name: string
  kind: Primitive | 'group' | 'glb' | 'npc'
  position: Vec
  rotation: Vec
  scale: Vec
  color?: string
  children?: Item[]
  asset?: string
  npc?: NpcSettings
}
export type SceneData = { items: Item[]; models: Item[] }
export type Save = { plot: Plot; scene: SceneData; kept?: boolean }
export const SHAPES: Record<Primitive, string> = { box: '立方体', cylinder: '圆柱体', sphere: '球体' }
export const EMPTY: SceneData = { items: [], models: [] }
const PREVIOUS_SAVE = 'fangcun.v1'
const PREVIOUS_ROOM = 'fangcun.owner-room'
const PLOT_SAVE = 'fangcun.plot.'
const LAST_PLOT = 'fangcun.last-plot'
const LEGACY_SAVE = 'fangcun.legacy.v1'

export function ownerRoomKey(plot: Plot) {
  return `fangcun.owner-room.${plotKey(plot)}`
}

export function distance(meters: number) {
  return meters >= 1000
    ? `${(meters / 1000).toLocaleString('zh-CN', { maximumFractionDigits: 2 })} km`
    : `${meters.toLocaleString('zh-CN', { maximumFractionDigits: 1 })} m`
}

export function area(squareMeters: number) {
  const km = squareMeters >= 1e6
  return `${(km ? squareMeters / 1e6 : squareMeters).toLocaleString('zh-CN', { maximumFractionDigits: 1 })} ${km ? 'km²' : 'm²'}`
}

export function migratePreviousSave() {
  try {
    const raw = localStorage.getItem(PREVIOUS_SAVE)
    if (!raw) return
    const save: Save = JSON.parse(raw)
    if (save.plot.width !== PLOT_SIZE || save.plot.depth !== PLOT_SIZE) {
      localStorage.setItem(LEGACY_SAVE, raw)
    } else {
      const plot = placeOnGrid(save.plot)
      if (!getPlotSave(plot)) setSave({ ...save, plot })
      const room = localStorage.getItem(PREVIOUS_ROOM)
      if (room && !localStorage.getItem(ownerRoomKey(plot))) localStorage.setItem(ownerRoomKey(plot), room)
      localStorage.removeItem(PREVIOUS_ROOM)
    }
    localStorage.removeItem(PREVIOUS_SAVE)
  } catch { /* Keep the source save if migration cannot complete. */ }
}

function readSave(key: string): Save | null {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : null
  } catch { return null }
}
export function getPlotSave(plot: Plot) {
  return readSave(PLOT_SAVE + plotKey(plot))
}
export function savedPlots(): Plot[] {
  const plots: Plot[] = []
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i)
    if (key?.startsWith(PLOT_SAVE)) {
      const save = readSave(key)
      if (save?.plot && (save.kept || save.scene.items.length || save.scene.models.length || localStorage.getItem(ownerRoomKey(save.plot)))) plots.push(save.plot)
    }
  }
  return plots
}
export function lastPlot() {
  const key = localStorage.getItem(LAST_PLOT)
  return key ? readSave(PLOT_SAVE + key)?.plot : undefined
}
export function exportLegacySave() { return localStorage.getItem(LEGACY_SAVE) }

export function setSave(save: Save) {
  const key = plotKey(save.plot)
  localStorage.setItem(PLOT_SAVE + key, JSON.stringify({ ...save, kept: true }))
  localStorage.setItem(LAST_PLOT, key)
}

export function newId() {
  const bytes = crypto.getRandomValues(new Uint8Array(16))
  bytes[6] = bytes[6] & 15 | 64
  bytes[8] = bytes[8] & 63 | 128
  const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('')
  return [hex.slice(0, 8), hex.slice(8, 12), hex.slice(12, 16), hex.slice(16, 20), hex.slice(20)].join('-')
}

export function newItem(kind: Item['kind'], name: string): Item {
  return { id: newId(), kind, name, position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] }
}

function openAssets(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('fangcun-assets', 1)
    request.onupgradeneeded = () => request.result.createObjectStore('glb')
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

export async function putAsset(id: string, data: ArrayBuffer) {
  const db = await openAssets()
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction('glb', 'readwrite')
      transaction.objectStore('glb').put(data, id)
      transaction.oncomplete = () => resolve()
      transaction.onabort = () => reject(transaction.error)
    })
  } finally {
    db.close()
  }
}

export async function getAsset(id: string): Promise<ArrayBuffer | undefined> {
  const db = await openAssets()
  try {
    return await new Promise((resolve, reject) => {
      const request = db.transaction('glb').objectStore('glb').get(id)
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error)
    })
  } finally {
    db.close()
  }
}
