import type { Item } from './data'
import { payload, request, type RoomClient } from './room'
import { $, button, icons } from './ui'

type Line = { role: 'assistant' | 'user'; content: string }

export function mountNpcDialogue(root: HTMLElement, adopt?: (npc: Item, room?: RoomClient) => void) {
  root.insertAdjacentHTML('beforeend', `<dialog id="npc-chat-dialog" class="app-dialog npc-chat">
    <div class="dialog-heading"><span class="dialog-icon">${icons.person}</span><div><h2 id="npc-chat-name"></h2><p id="npc-chat-mode"></p></div>${button('close', '关闭对话', 'close-npc-chat')}</div>
    <ol class="npc-messages" id="npc-messages" aria-live="polite"></ol>
    <button type="button" class="subtle npc-chat-appearance" id="npc-chat-appearance" ${adopt ? '' : 'hidden'}>用此外观行走</button>
    <form id="npc-chat-form" class="npc-chat-form">
      <input id="npc-chat-message" class="text-field" maxlength="600" placeholder="和 NPC 聊一聊" aria-label="对话消息" required autocomplete="off">
      <button type="submit" id="npc-chat-send" class="primary">发送</button>
    </form>
  </dialog>`)
  const dialog = $('npc-chat-dialog') as HTMLDialogElement
  const input = $('npc-chat-message') as HTMLInputElement
  const send = $('npc-chat-send') as HTMLButtonElement
  const chats = new Map<string, Line[]>()
  let active: { npc: Item; room?: RoomClient; lines: Line[] } | undefined
  let controller: AbortController | undefined

  function append(line: Line) {
    const node = document.createElement('li')
    node.dataset.role = line.role
    node.textContent = line.content
    const list = $('npc-messages')
    list.append(node)
    list.scrollTop = list.scrollHeight
  }
  function open(npc: Item, room?: RoomClient) {
    if (!npc.npc || dialog.open) return
    const key = (room?.access.room ?? 'solo') + ':' + npc.id
    const lines = chats.get(key) ?? []
    chats.set(key, lines)
    active = { npc, room, lines }
    $('npc-chat-name').textContent = npc.name
    $('npc-chat-mode').textContent = npc.npc.ai ? 'AI 对话' : '预设对白'
    $('npc-messages').replaceChildren()
    if (!lines.length) lines.push({ role: 'assistant', content: npc.npc.greeting || '你好！' })
    lines.forEach(append)
    send.disabled = false
    input.value = ''
    dialog.showModal()
    input.focus()
  }
  function reset() {
    controller?.abort()
    controller = undefined
    active = undefined
  }
  $('close-npc-chat').onclick = () => dialog.close()
  $('npc-chat-appearance').onclick = () => { if (active) adopt?.(active.npc, active.room) }
  dialog.onclose = reset
  $('npc-chat-form').onsubmit = async event => {
    event.preventDefault()
    if (!active || send.disabled || !input.value.trim()) return
    const { npc, room, lines } = active
    const settings = npc.npc!
    const line: Line = { role: 'user', content: input.value.trim() }
    lines.push(line)
    append(line)
    input.value = ''
    const offline = settings.knowledge ? settings.knowledge.slice(0, 600) : (settings.greeting || '欢迎来这里看看。')
    let reply = offline
    if (settings.ai) {
      send.disabled = true
      const control = new AbortController()
      controller = control
      $('npc-chat-mode').textContent = '正在等待回复…'
      try {
        const init = payload({ id: npc.id, name: npc.name, npc: settings, messages: lines.slice(-10) })
        const headers = new Headers(init.headers)
        if (room) headers.set('Authorization', 'Bearer ' + room.access.token)
        const result = await request<{ available: boolean; reply?: string }>(room ? room.access.room + '/npc-chat' : 'npc-chat',
          { ...init, headers, signal: control.signal })
        if (control.signal.aborted) return
        if (result.available && result.reply) reply = result.reply
        $('npc-chat-mode').textContent = result.available ? 'AI 对话' : 'AI 未配置，使用预设对白'
      } catch {
        if (control.signal.aborted) return
        $('npc-chat-mode').textContent = 'AI 暂时不可用，使用预设对白'
      } finally {
        if (controller === control) { send.disabled = false; controller = undefined }
      }
    }
    const answer: Line = { role: 'assistant', content: reply }
    lines.push(answer)
    if (lines.length > 40) lines.splice(0, lines.length - 40)
    append(answer)
    input.focus()
  }
  return { dialog, open, close: () => { if (dialog.open) dialog.close() }, dispose: reset }
}
