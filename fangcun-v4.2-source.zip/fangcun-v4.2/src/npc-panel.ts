import { assetStorageKey, newId, newItem, putAsset, type CharacterSkin, type Item, type NpcBody, type NpcSettings, type Plot } from './data'
import { previewModel } from './import-preview'
import { cacheSkin, decodeSkin, loadSkin, npcVisual, type NpcVisual } from './npc'
import { npcTextLimits, skinFileLimit } from './skin-format'
import { $, button, icons } from './ui'

type Skin = { id: string; image: ImageBitmap; bytes?: ArrayBuffer; label: string }
type Target = 'me' | 'npc'
type Draft = { body: NpcBody; skin?: Skin; loading: boolean; error: string; revision: number }
const emptyDraft = (body: NpcBody = 'classic'): Draft => ({ body, loading: false, error: '', revision: 0 })

export function mountCharacterEditor(root: HTMLElement, plot: Plot, options: {
  canEdit: () => boolean
  loadNpc: (id: string) => Promise<ImageBitmap>
  currentMe: () => CharacterSkin | undefined
  saveMe: (skin: CharacterSkin, image: ImageBitmap) => void
  onUsedMe: () => void
  saveNpc: (item: Item, source: NpcVisual['object'], editing: boolean) => boolean
}) {
  root.insertAdjacentHTML('beforeend', `<dialog id="npc-dialog" class="app-dialog npc-editor">
    <form id="npc-form">
      <div class="dialog-heading"><span class="dialog-icon">${icons.person}</span><div><h2 id="npc-heading">创建人物</h2></div>${button('close', '关闭', 'close-npc')}</div>
      <div class="character-targets" id="character-targets" role="group" aria-label="人物用途">
        <button type="button" class="secondary" id="character-me">我</button>
        <button type="button" class="secondary" id="character-npc">NPC</button>
      </div>
      <div class="npc-layout">
        <div>
          <div id="npc-preview" class="import-preview" aria-label="人物三维预览"></div>
          <span class="field-label" id="npc-skin-label">Minecraft 皮肤 (64 × 64 PNG)</span>
          <button id="npc-pick-skin" type="button" class="secondary full">${icons.upload} 选择 PNG 文件</button>
          <input id="npc-skin" type="file" aria-labelledby="npc-skin-label" accept="image/png,.png" hidden>
          <p id="npc-skin-status" class="npc-skin-status" aria-live="polite"></p>
          <label class="field-label" for="npc-body">体型</label>
          <select class="text-field" id="npc-body"><option value="classic">Classic 宽臂</option><option value="slim">Slim 细臂</option></select>
        </div>
        <div class="character-me-options" id="character-me-options">
          <h3>我的行走角色</h3>
          <p>保存后用 WASD 或方向键移动。</p>
          <button type="button" class="subtle" id="character-reset" hidden>恢复默认角色</button>
          <details><summary>GLB 角色</summary>
            <button type="button" class="secondary full" id="character-btn">${icons.upload} 导入行走角色</button>
            <input type="file" id="character-file" accept=".glb,model/gltf-binary" hidden>
          </details>
        </div>
        <div id="character-npc-options" hidden>
          <label class="field-label" for="npc-name">NPC 名称</label>
          <input id="npc-name" class="text-field" maxlength="60" required>
          <label class="field-label" for="npc-greeting">开场白</label>
          <input id="npc-greeting" class="text-field" maxlength="${npcTextLimits.greeting}">
          <label class="setting-row npc-ai-setting"><input type="checkbox" id="npc-ai"> 使用服务端 AI 对话</label>
          <div id="npc-ai-fields" hidden>
            <label class="field-label" for="npc-persona">角色设定</label>
            <textarea id="npc-persona" class="text-field" rows="2" maxlength="${npcTextLimits.persona}" placeholder="例如：爱讲故事的导览员"></textarea>
            <label class="field-label" for="npc-knowledge">地块资料</label>
            <textarea id="npc-knowledge" class="text-field" rows="3" maxlength="${npcTextLimits.knowledge}" placeholder="例如：入口旁的红色屋顶是访客中心"></textarea>
          </div>
        </div>
      </div>
      <p id="npc-error" class="import-warning" aria-live="polite"></p>
      <div class="dialog-actions"><button type="button" id="cancel-npc" class="secondary">取消</button><button id="submit-npc" type="submit" class="primary">放置 NPC ${icons.check}</button></div>
    </form>
  </dialog>`)
  const dialog = $('npc-dialog') as HTMLDialogElement
  const field = (key: string) => $(`npc-${key}`) as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
  const skinInput = $('npc-skin') as HTMLInputElement
  const pick = $('npc-pick-skin') as HTMLButtonElement
  const ai = $('npc-ai') as HTMLInputElement
  const submit = $('submit-npc') as HTMLButtonElement
  const meButton = $('character-me') as HTMLButtonElement
  const npcButton = $('character-npc') as HTMLButtonElement
  let npc: Item | undefined
  let drafts = { me: emptyDraft(), npc: emptyDraft() }
  let target: Target = 'me'
  let editing = false
  let saving = false
  let visual: NpcVisual | undefined
  let preview: ReturnType<typeof previewModel> | undefined

  function releasePreview() {
    preview?.dispose()
    visual?.dispose()
    preview = visual = undefined
  }
  function releaseDraft(draft: Draft) {
    draft.revision++
    if (draft.skin?.bytes) draft.skin.image.close()
  }
  function cleanup() {
    releasePreview()
    releaseDraft(drafts.me)
    releaseDraft(drafts.npc)
    npc = undefined
    saving = false
  }
  function refreshStatus() {
    const draft = drafts[target]
    $('npc-error').textContent = draft.error
    $('npc-skin-status').textContent = draft.loading ? '正在读取皮肤…' : draft.skin?.label ?? '请选择一张皮肤。'
    submit.disabled = draft.loading || saving || !draft.skin || (target === 'npc' && !options.canEdit())
    pick.disabled = saving
    field('body').disabled = saving
    meButton.disabled = saving
    npcButton.disabled = saving || !options.canEdit()
    npcButton.title = options.canEdit() ? '' : '有编辑权限时，在编辑模式下创建 NPC。'
  }
  function refreshPreview() {
    releasePreview()
    const draft = drafts[target]
    visual = npcVisual(draft.body)
    if (draft.skin) visual.setSkin(draft.skin.image)
    preview = previewModel($('npc-preview'), visual.object, plot, 'portrait')
    preview.render(1, true, true)
    refreshStatus()
  }
  function updateAiFields() { $('npc-ai-fields').hidden = !ai.checked }
  function close() { if (dialog.open) dialog.close() }
  function showTarget(next: Target) {
    target = next
    const me = next === 'me'
    meButton.setAttribute('aria-pressed', String(me))
    npcButton.setAttribute('aria-pressed', String(!me))
    $('character-me-options').hidden = !me
    $('character-npc-options').hidden = me
    field('name').required = !me
    field('body').value = drafts[next].body
    skinInput.value = ''
    submit.textContent = me ? '保存并行走' : editing ? '保存修改' : '放置 NPC'
    refreshPreview()
  }
  async function loadExisting(kind: Target, id: string) {
    const draft = drafts[kind]
    const revision = ++draft.revision
    draft.loading = true
    if (kind === target) refreshStatus()
    try {
      const image = await (kind === 'me' ? loadSkin(id) : options.loadNpc(id))
      if (draft.revision === revision) draft.skin = { id, image, label: '当前皮肤' }
    } catch {
      if (draft.revision === revision) draft.error = '当前皮肤无法读取，请重新选择 PNG。'
    } finally {
      if (draft.revision === revision) {
        draft.loading = false
        if (kind === target && dialog.open) refreshPreview()
      }
    }
  }
  function open(item?: Item) {
    if (dialog.open || (item && !options.canEdit())) return
    cleanup()
    const me = options.currentMe()
    editing = !!item
    npc = item ? structuredClone(item) : newItem('npc', '新 NPC')
    const settings = npc.npc
    drafts = { me: emptyDraft(me?.body), npc: emptyDraft(settings?.body) }
    field('name').value = npc.name
    field('greeting').value = settings?.greeting ?? '你好，欢迎来到这里！'
    field('persona').value = settings?.persona ?? ''
    field('knowledge').value = settings?.knowledge ?? ''
    ai.checked = settings?.ai ?? false
    $('npc-heading').textContent = editing ? '编辑 NPC' : '创建人物'
    $('character-targets').hidden = editing
    updateAiFields()
    dialog.showModal()
    showTarget(editing ? 'npc' : 'me')
    if (item?.asset) void loadExisting('npc', item.asset)
    if (!editing && me) void loadExisting('me', me.asset)
  }
  function refreshMe() {
    if (!dialog.open || editing) return
    releaseDraft(drafts.me)
    const me = options.currentMe()
    drafts.me = emptyDraft(me?.body)
    if (target === 'me') showTarget('me')
    if (me) void loadExisting('me', me.asset)
  }
  meButton.onclick = () => { if (target !== 'me') showTarget('me') }
  npcButton.onclick = () => { if (target !== 'npc' && options.canEdit()) showTarget('npc') }
  field('body').onchange = () => { drafts[target].body = field('body').value as NpcBody; refreshPreview() }
  ai.onchange = updateAiFields
  pick.onclick = () => skinInput.click()
  skinInput.onchange = async () => {
    const file = skinInput.files?.[0]
    skinInput.value = ''
    if (!file || !dialog.open || saving) return
    const kind = target
    const draft = drafts[kind]
    const revision = ++draft.revision
    draft.loading = true
    draft.error = ''
    refreshStatus()
    try {
      if (file.size > skinFileLimit) throw new Error('皮肤文件超过 128 KB。')
      const bytes = await file.arrayBuffer()
      const image = await decodeSkin(bytes)
      if (draft.revision !== revision) { image.close(); return }
      if (draft.skin?.bytes) draft.skin.image.close()
      draft.skin = { id: newId(), image, bytes, label: file.name }
    } catch (error) {
      if (draft.revision === revision) draft.error = error instanceof Error ? error.message : '无法读取这张皮肤。'
    } finally {
      if (draft.revision === revision) {
        draft.loading = false
        if (kind === target && dialog.open) refreshPreview()
      }
    }
  }
  $('npc-form').onsubmit = async event => {
    event.preventDefault()
    const kind = target
    const draft = drafts[kind]
    const skin = draft.skin
    if (!skin || !visual || saving || draft.loading || (kind === 'npc' && !options.canEdit())) return
    const name = field('name').value.trim()
    if (kind === 'npc' && !name) { field('name').focus(); return }
    const settings: NpcSettings = { body: draft.body, greeting: field('greeting').value.trim(),
      persona: field('persona').value.trim(), knowledge: field('knowledge').value.trim(), ai: ai.checked }
    const revision = draft.revision
    saving = true
    refreshStatus()
    try {
      if (skin.bytes) await putAsset(assetStorageKey(skin.id, 'png'), skin.bytes)
      if (draft.revision !== revision || !dialog.open || !visual) return
      if (kind === 'me') options.saveMe({ asset: skin.id, body: draft.body }, skin.image)
      else {
        if (!npc || !options.canEdit()) return
        if (!options.saveNpc({ ...npc, name, asset: skin.id, npc: settings }, visual.object, editing)) {
          draft.error = '当前位置放不下这个 NPC。请把它移到地块内再试。'
          return
        }
      }
      if (skin.bytes) cacheSkin(skin.id, Promise.resolve(skin.image))
      skin.bytes = undefined
      close()
      if (kind === 'me') options.onUsedMe()
    } catch {
      if (draft.revision === revision) draft.error = '浏览器无法保存这张皮肤。'
    } finally {
      if (draft.revision === revision) {
        saving = false
        if (dialog.open) refreshStatus()
      }
    }
  }
  $('close-npc').onclick = $('cancel-npc').onclick = close
  dialog.onclose = cleanup
  return { dialog, open, close, refreshMe, refreshStatus, editingNpc: () => dialog.open && target === 'npc', dispose: cleanup }
}
