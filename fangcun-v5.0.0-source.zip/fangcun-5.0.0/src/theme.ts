import { $ } from './ui'

export function setupTheme() {
  const select = $('theme-picker') as HTMLSelectElement
  const apply = () => {
    document.documentElement.dataset.theme = select.value
    localStorage.setItem('fangcun.theme', select.value)
    window.dispatchEvent(new Event('fangcun-theme'))
  }
  const current = localStorage.getItem('fangcun.theme')
  if (current && [...select.options].some(option => option.value === current)) select.value = current
  apply()
  select.onchange = apply
}
