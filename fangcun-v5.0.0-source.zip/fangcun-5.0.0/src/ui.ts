import layers from 'lucide-static/icons/layers-3.svg?raw'
import map from 'lucide-static/icons/map.svg?raw'
import box from 'lucide-static/icons/box.svg?raw'
import arrow from 'lucide-static/icons/arrow-right.svg?raw'
import back from 'lucide-static/icons/arrow-left.svg?raw'
import chevron from 'lucide-static/icons/chevron-right.svg?raw'
import pin from 'lucide-static/icons/map-pin.svg?raw'
import scan from 'lucide-static/icons/scan.svg?raw'
import plus from 'lucide-static/icons/plus.svg?raw'
import minus from 'lucide-static/icons/minus.svg?raw'
import locate from 'lucide-static/icons/locate-fixed.svg?raw'
import mouse from 'lucide-static/icons/mouse.svg?raw'
import cursor from 'lucide-static/icons/mouse-pointer-2.svg?raw'
import globe from 'lucide-static/icons/globe-2.svg?raw'
import circle from 'lucide-static/icons/circle.svg?raw'
import cylinder from 'lucide-static/icons/cylinder.svg?raw'
import move from 'lucide-static/icons/move.svg?raw'
import rotate from 'lucide-static/icons/rotate-cw.svg?raw'
import scaling from 'lucide-static/icons/scaling.svg?raw'
import undo from 'lucide-static/icons/undo-2.svg?raw'
import copy from 'lucide-static/icons/copy.svg?raw'
import trash from 'lucide-static/icons/trash-2.svg?raw'
import grid from 'lucide-static/icons/grid-3x3.svg?raw'
import person from 'lucide-static/icons/footprints.svg?raw'
import upload from 'lucide-static/icons/upload.svg?raw'
import packageIcon from 'lucide-static/icons/package.svg?raw'
import focus from 'lucide-static/icons/maximize.svg?raw'
import keyboard from 'lucide-static/icons/keyboard.svg?raw'
import check from 'lucide-static/icons/check.svg?raw'
import close from 'lucide-static/icons/x.svg?raw'
import magnet from 'lucide-static/icons/magnet.svg?raw'
import group from 'lucide-static/icons/group.svg?raw'
import warning from 'lucide-static/icons/triangle-alert.svg?raw'
import compass from 'lucide-static/icons/compass.svg?raw'

export const icons = { layers, map, box, arrow, back, chevron, pin, scan, plus, minus, locate, mouse, cursor, globe, circle, cylinder, move, rotate, scaling, undo, copy, trash, grid, person, upload, package: packageIcon, focus, keyboard, check, close, magnet, group, warning, compass }
export type Icon = keyof typeof icons
export function button(icon: Icon, label: string, id: string, cls = 'icon-button') {
  return `<button type="button" class="${cls}" id="${id}" title="${label}" aria-label="${label}">${icons[icon]}</button>`
}
export function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!)
}
export function $(id: string) {
  return document.getElementById(id)!
}
export function logo() {
  return `<div class="brand-icon" aria-hidden="true"><svg viewBox="0 0 36 36" fill="none"><path d="M18 7.5 28.5 13.5 18 19.6 7.5 13.5 18 7.5Z" fill="currentColor"/><path d="m7.5 17.5 10.5 6 10.5-6M7.5 22l10.5 6 10.5-6" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/></svg></div>`
}
