export const PLOT_SIZE = 100
export const BUILD_GRID_STEP = 5
export const DEFAULT_LOCATION: [number, number] = [30.657, 104.066]

export type PlotCell = { column: number; row: number }
export type Plot = {
  south: number; west: number; north: number; east: number
  width: number; depth: number
  cell?: PlotCell
}

// Use a single Mercator lattice calibrated at Chengdu. Whole columns span the
// longitude wrap so the last and first columns share the antimeridian.
const radians = Math.PI / 180
const columns = Math.round(2 * Math.PI * 6378137 * Math.cos(DEFAULT_LOCATION[0] * radians) / PLOT_SIZE)
const radius = columns * PLOT_SIZE / (2 * Math.PI)
const maxLatitude = 85.0511287798

export function cellAt(lat: number, lng: number): PlotCell {
  const latitude = Math.max(-maxLatitude, Math.min(maxLatitude, lat)) * radians
  const southing = -radius * Math.asinh(Math.tan(latitude))
  return {
    column: Math.floor((lng + 180) / 360 * columns + 1e-9),
    row: Math.floor(southing / PLOT_SIZE + 1e-9),
  }
}

export function gridLongitude(columnEdge: number) {
  return columnEdge / columns * 360 - 180
}
export function gridLatitude(rowEdge: number) {
  return Math.atan(Math.sinh(-rowEdge * PLOT_SIZE / radius)) / radians
}
export function canonicalCell(cell: PlotCell): PlotCell {
  return { column: ((cell.column % columns) + columns) % columns, row: cell.row }
}
export function plotForCell(input: PlotCell): Plot {
  const cell = canonicalCell(input)
  return {
    south: gridLatitude(cell.row + 1), north: gridLatitude(cell.row),
    west: gridLongitude(cell.column), east: gridLongitude(cell.column + 1),
    width: PLOT_SIZE, depth: PLOT_SIZE, cell,
  }
}
export function plotCenter(plot: Plot): [number, number] {
  if (plot.cell) return [gridLatitude(plot.cell.row + .5), gridLongitude(plot.cell.column + .5)]
  return [(plot.north + plot.south) / 2, (plot.west + plot.east) / 2]
}
export function placeOnGrid(plot: Plot) {
  return plotForCell(plot.cell ?? cellAt(...plotCenter(plot)))
}
export function plotKey(plot: Plot) {
  const cell = canonicalCell(plot.cell ?? cellAt(...plotCenter(plot)))
  return `${cell.column}:${cell.row}`
}

export function cellKey(cell: PlotCell) {
  const fixed = canonicalCell(cell)
  return `${fixed.column}:${fixed.row}`
}

export function parseCell(value: unknown): PlotCell | undefined {
  if (typeof value !== 'string' || !/^\d{1,6}:-?\d{1,6}$/.test(value)) return
  const [column, row] = value.split(':').map(Number)
  const maximumRow = cellAt(-maxLatitude, 0).row
  if (column >= columns || row < -maximumRow - 1 || row > maximumRow) return
  return { column, row }
}

export function neighborsOf(cell: PlotCell) {
  return [
    canonicalCell({ column: cell.column - 1, row: cell.row }),
    canonicalCell({ column: cell.column + 1, row: cell.row }),
    { column: cell.column, row: cell.row - 1 },
    { column: cell.column, row: cell.row + 1 },
  ]
}

export function cellOffset(from: PlotCell, to: PlotCell): [number, number] {
  let dx = to.column - from.column
  if (dx > columns / 2) dx -= columns
  if (dx < -columns / 2) dx += columns
  return [dx * PLOT_SIZE, (to.row - from.row) * PLOT_SIZE]
}

export function cellAtLocal(origin: PlotCell, x: number, z: number) {
  return canonicalCell({
    column: origin.column + Math.floor((x + PLOT_SIZE / 2) / PLOT_SIZE),
    row: origin.row + Math.floor((z + PLOT_SIZE / 2) / PLOT_SIZE),
  })
}
