import * as T from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import { blueprints } from './estate'

const models = new Map<string, T.Group>()
const materials = new Map<string, T.MeshStandardMaterial>()
const timber = '#654c43',
  cream = '#f5dfb7',
  slate = '#44565e',
  brass = '#cfac63',
  stone = '#acaaa1'
const glass = '#76a6a6',
  leaves = '#64865f',
  darkLeaf = '#456d5c',
  brick = '#ab6958'
const material = (color: string) => {
  let result = materials.get(color)
  if (!result) {
    result = new T.MeshStandardMaterial({ color, roughness: 0.87, flatShading: true })
    materials.set(color, result)
  }
  return result
}
function build(kind: string) {
  const spec = blueprints.get(kind)!
  const root = new T.Group()
  const mesh = (g: T.BufferGeometry, c: string, x: number, y: number, z: number) => {
    const o = new T.Mesh(g, material(c))
    o.position.set(x, y, z)
    root.add(o)
    return o
  }
  const box = (x: number, y: number, z: number, w: number, h: number, d: number, c: string) =>
    mesh(new T.BoxGeometry(w, h, d), c, x, y, z)
  const pole = (x: number, y: number, z: number, r: number, h: number, c: string, top = r, sides = 10) =>
    mesh(new T.CylinderGeometry(top, r, h, sides), c, x, y, z)
  const bush = (x: number, y: number, z: number, r: number, c: string) =>
    mesh(new T.IcosahedronGeometry(r, 0), c, x, y, z)
  function beam(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number, r: number, c: string) {
    const a = new T.Vector3(x1, y1, z1),
      b = new T.Vector3(x2, y2, z2),
      v = b.clone().sub(a)
    const t = pole((x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2, r, v.length(), c, r, 6)
    t.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), v.normalize())
  }
  function sign(text: string, x: number, y: number, z: number, width: number, height: number, bg: string, fg: string) {
    const canvas = document.createElement('canvas')
    canvas.width = 768
    canvas.height = 192
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = bg
    ctx.fillRect(0, 0, 768, 192)
    ctx.strokeStyle = fg
    ctx.lineWidth = 5
    ctx.strokeRect(12, 12, 744, 168)
    ctx.font = 'bold 86px Georgia, "Noto Serif CJK SC", serif'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillStyle = fg
    ctx.fillText(text, 384, 102, 700)
    const tex = new T.CanvasTexture(canvas)
    tex.colorSpace = T.SRGBColorSpace
    tex.anisotropy = 4
    const face = new T.Mesh(new T.PlaneGeometry(width, height), new T.MeshBasicMaterial({ map: tex }))
    face.position.set(x, y, z)
    root.add(face)
  }
  function gable(x: number, y: number, z: number, w: number, d: number, h: number, c: string) {
    const shape = new T.Shape()
    shape.moveTo(-w / 2, 0)
    shape.lineTo(0, h)
    shape.lineTo(w / 2, 0)
    shape.closePath()
    const geo = new T.ExtrudeGeometry(shape, { depth: d, bevelEnabled: false })
    geo.translate(0, 0, -d / 2)
    mesh(geo, c, x, y, z)
    for (const s of [-1, 1]) {
      const plate = box(x + (s * w) / 4, y + h / 2 + 0.1, z, Math.hypot(w / 2, h) + 0.45, 0.24, d + 0.45, c)
      plate.rotation.z = -s * Math.atan2(h, w / 2)
    }
  }
  function hipped(x: number, y: number, z: number, w: number, d: number, h: number, c: string) {
    const lower = [
      [-w / 2, 0, -d / 2],
      [w / 2, 0, -d / 2],
      [w / 2, 0, d / 2],
      [-w / 2, 0, d / 2],
    ]
    const upper = lower.map(([a, , b]) => [a * 0.54, h, b * 0.23])
    const vertices: number[] = []
    for (let i = 0; i < 4; i++) {
      const n = (i + 1) % 4
      vertices.push(...lower[i], ...upper[i], ...lower[n], ...lower[n], ...upper[i], ...upper[n])
    }
    vertices.push(...upper[0], ...upper[2], ...upper[1], ...upper[0], ...upper[3], ...upper[2])
    const geo = new T.BufferGeometry().setAttribute('position', new T.Float32BufferAttribute(vertices, 3))
    geo.computeVertexNormals()
    mesh(geo, c, x, y, z)
    box(x, y - 0.03, z, w, 0.18, d, c)
    box(x, y + h + 0.1, z, w * 0.56, 0.24, d * 0.25, c)
    for (const i of [0, 1, 2, 3])
      beam(x + lower[i][0], y + 0.04, z + lower[i][2], x + upper[i][0], y + h + 0.09, z + upper[i][2], 0.11, slate)
  }
  function window(x: number, y: number, z: number, w: number, h: number, lit = true) {
    box(x, y, z, w + 0.18, h + 0.18, 0.16, timber)
    box(x, y, z + 0.11, w, h, 0.09, lit ? '#edc889' : glass)
    box(x, y, z + 0.18, 0.1, h, 0.08, timber)
    box(x, y + h * 0.12, z + 0.18, w, 0.1, 0.08, timber)
  }
  function pot(x: number, z: number) {
    pole(x, 0.49, z, 0.38, 0.8, brick, 0.51)
    bush(x, 0.99, z, 0.62, darkLeaf)
    bush(x + 0.18, 1.32, z, 0.4, leaves)
  }
  function lantern(x: number, y: number, z: number) {
    pole(x, y + 0.54, z, 0.035, 0.5, timber)
    pole(x, y, z, 0.32, 0.64, '#e99b62', 0.32)
    pole(x, y + 0.34, z, 0.25, 0.08, timber)
    pole(x, y - 0.35, z, 0.23, 0.08, timber)
  }
  function teaRows() {
    for (let row = 0; row < 3; row++) {
      box(1.35, 0.12, -2.5 + row * 2.25, 7.4, 0.16, 1.45, '#986f50')
      for (let i = 0; i < 8; i++) {
        const x = -1.65 + i * 0.87,
          z = -2.45 + row * 2.25
        bush(x, 0.53, z, 0.82, darkLeaf)
        bush(x + 0.14, 0.94, z + 0.06, 0.61, (i + row) % 2 ? leaves : '#89a671')
      }
    }
    for (let i = 0; i < 7; i++) box(-3.35, 0.12, -2.9 + i * 1.05, 0.88, 0.14, 0.7, stone)
  }
  if (kind === 'kissaten' || kind === 'onsen') {
    const bath = kind === 'onsen',
      w = bath ? 9.5 : 8.5,
      h = bath ? 4.1 : 3.45,
      d = 5.8
    box(0, h / 2, 0, w, h, d, bath ? '#bd8367' : cream)
    for (const x of [-w / 2, 0.45, w / 2]) box(x, h / 2, 3, 0.16, h, 0.24, timber)
    window(-w * 0.23, 1.75, 3, w * 0.39, 2.18)
    window(w * 0.33, 1.7, 3, w * 0.22, 2.08)
    box(0.79, 1.27, 3.12, 1.23, 2.55, 0.14, timber)
    box(0.79, 1.65, 3.22, 0.92, 1.35, 0.08, glass)
    for (let i = 0; i < 6; i++) box(-w / 2 + 0.32 + i * 0.54, 1.32, 3.28, 0.065, 1.9, 0.06, timber)
    if (bath) {
      hipped(0, h, 0, w + 1.5, d + 1.55, 1.65, '#426169')
      box(-0.7, h + 1.64, -0.3, 5.3, 1.95, 3.5, '#ecd5ad')
      window(-0.7, h + 1.8, 1.5, 3.4, 1)
      hipped(-0.7, h + 2.66, -0.3, 6.5, 4.7, 1.42, '#425b67')
      pole(4.25, 4.55, -1.9, 0.46, 9.1, brick)
      pole(4.25, 9.03, -1.9, 0.53, 0.25, timber)
      for (let i = 0; i < 4; i++) box(-0.24 + i * 0.52, 2.5, 3.57, 0.48, 0.82, 0.09, '#596080')
      sign('月 見 湯', -0.8, 3.63, 3.16, 3.5, 0.74, cream, timber)
    } else {
      gable(0, h, 0, w + 0.55, d + 0.45, 1.42, '#586f70')
      for (let i = 0; i < 8; i++) {
        const col = i % 2 ? '#ead8ac' : '#74948b'
        box(-3.74 + i * 1.07, 2.99, 3.61, 1.07, 0.19, 1.26, col).rotation.x = 0.17
        box(-3.74 + i * 1.07, 2.76, 4.2, 1.07, 0.31, 0.1, col)
      }
      sign('KISSA   灯', 0, 3.73, 3.19, 3.6, 0.76, timber, cream)
      box(3.6, 0.73, 4.08, 0.98, 1.45, 0.17, timber)
      sign('COFFEE', 3.6, 0.81, 4.19, 0.81, 0.42, slate, cream)
    }
    lantern(-3.85, 2.4, 3.67)
    pot(-4.2, 3.9)
    box(-1.2, 0.55, 4.03, 2.7, 0.16, 0.52, timber)
    for (const x of [-2.2, -0.2]) box(x, 0.25, 4.03, 0.16, 0.5, 0.33, slate)
  } else if (kind === 'teagarden') {
    teaRows()
    box(-4.75, 1.03, -0.35, 2.35, 2.05, 3.2, '#e7d0aa')
    hipped(-4.75, 2.09, -0.35, 3.5, 4.2, 1.1, '#506d70')
    window(-4.75, 1.15, 1.29, 1.45, 0.98)
    pot(-4.5, 2.2)
    for (let i = 0; i < 8; i++) box(-5.5 + i * 1.48, 0.48, -3.84, 0.17, 0.96, 0.17, timber)
    box(-0.3, 0.6, -3.84, 10.7, 0.13, 0.13, timber)
    pole(4.46, 0.8, 3.65, 0.48, 1.48, '#ab875f', 0.6)
    sign('南 山 茶', -4.75, 1.91, 1.44, 2.1, 0.47, slate, cream)
  } else if (kind === 'pavilion') {
    box(-0.65, 1.6, 0, 8.4, 3.2, 5.5, '#ebd9b9')
    hipped(-0.65, 3.23, 0, 10.1, 7.2, 1.65, '#54746f')
    for (const x of [-4.5, -2.15, 0.55, 3.25]) {
      pole(x, 1.54, 3.05, 0.14, 3.04, '#945e47')
      box(x, 0.16, 3.05, 0.48, 0.3, 0.48, stone)
    }
    window(-2.55, 1.77, 2.81, 2.4, 1.53)
    window(1.35, 1.68, 2.81, 2.22, 1.49)
    sign('青 瓷 窑', -0.6, 2.91, 2.97, 2.5, 0.56, timber, cream)
    pole(4.65, 1.2, -0.3, 1.5, 2.3, brick, 1.16)
    pole(4.65, 3.03, -0.3, 0.78, 1.52, brick, 0.55)
    pole(4.65, 4.18, -0.3, 0.48, 0.9, timber)
    box(0.1, 0.91, 3.77, 4.1, 0.22, 0.88, timber)
    for (const x of [-1.35, 1.51]) box(x, 0.4, 3.77, 0.22, 0.8, 0.45, timber)
    for (let i = 0; i < 4; i++) {
      pole(-1.2 + i * 0.84, 1.32, 3.75, 0.23, 0.61, i % 2 ? '#7cb3a3' : '#c3d6ba', 0.31)
      pole(-1.2 + i * 0.84, 1.66, 3.75, 0.19, 0.17, '#74a699')
    }
  } else if (kind === 'atelier') {
    box(0, 2.25, 0, 7.8, 4.5, 5.6, '#dcc3a4')
    gable(0, 4.5, 0, 8.4, 6.2, 2.55, '#546979')
    for (const x of [-3.68, 0, 3.68]) box(x, 2.17, 2.86, 0.21, 4.34, 0.2, timber)
    box(0, 2.7, 2.9, 7.86, 0.2, 0.24, timber)
    for (const x of [-2.59, 2.38]) {
      window(x, 1.6, 2.91, 1.47, 1.62)
      window(x, 3.49, 2.91, 1.14, 0.95)
    }
    box(0.07, 1.1, 2.95, 1.17, 2.22, 0.17, slate)
    sign('ATELIER', 0, 2.61, 3.07, 2.2, 0.47, slate, cream)
    pole(-2.55, 4.64, -1.38, 0.45, 4, brick)
    box(-2.55, 6.65, -1.38, 1.11, 0.29, 0.95, brick)
    const clock = pole(0, 5.49, 3.2, 0.64, 0.21, brass, 0.64, 24)
    clock.rotation.x = Math.PI / 2
    box(-0.12, 5.55, 3.35, 0.32, 0.065, 0.06, timber)
    box(0, 5.7, 3.36, 0.055, 0.39, 0.055, timber)
    pot(3.88, 3.2)
    box(-3.35, 0.68, 3.59, 1.73, 1.3, 0.85, brick)
  } else {
    pole(0, 2.53, -0.08, 3.04, 5.1, '#ead7b4', 2.02, 8)
    pole(0, 6.05, -0.08, 2.81, 2.24, '#895a55', 0.25, 8)
    box(0, 1.06, 2.78, 1.22, 2.08, 0.19, timber)
    window(0, 3.45, 2.46, 1.29, 1.27)
    const cx = 0,
      cy = 5.05,
      cz = 3.26
    for (let i = 0; i < 4; i++) {
      const a = 0.52 + (i * Math.PI) / 2,
        dx = Math.cos(a),
        dy = Math.sin(a),
        nx = -dy,
        ny = dx
      beam(cx, cy, cz, cx + dx * 4, cy + dy * 4, cz, 0.11, timber)
      for (let j = 0; j < 6; j++) {
        const r = 1.15 + j * 0.49
        beam(cx + dx * r, cy + dy * r, cz, cx + dx * r + nx * 0.76, cy + dy * r + ny * 0.76, cz, 0.1, cream)
      }
      beam(
        cx + dx * 1.15 + nx * 0.76,
        cy + dy * 1.15 + ny * 0.76,
        cz,
        cx + dx * 3.65 + nx * 0.76,
        cy + dy * 3.65 + ny * 0.76,
        cz,
        0.075,
        brass
      )
    }
    bush(0, cy, cz, 0.33, brass)
    for (let i = 0; i < 3; i++) {
      box(-3.35, 0.53 + i * 0.05, -1.5 + i * 1.17, 1.77, 1.06, 1.17, '#ceaa59')
      box(-3.35, 0.55 + i * 0.05, -1.5 + i * 1.17, 0.14, 1.12, 1.21, timber)
    }
  }
  // Give each facade a second readable side when the player orbits the miniature.
  if (kind === 'kissaten' || kind === 'onsen' || kind === 'atelier' || kind === 'pavilion') {
    const bath = kind === 'onsen',
      western = kind === 'atelier',
      kiln = kind === 'pavilion'
    const edge = bath ? 4.75 : western ? 3.9 : kiln ? 3.55 : 4.25
    const facade = bath ? '#a36e57' : western ? '#cfb59a' : kiln ? '#c8bca3' : '#e9cfa8'
    for (const z of [-1.63, 0.87]) {
      box(edge + 0.05, 1.74, z, 0.19, 1.69, 1.72, timber)
      box(edge + 0.16, 1.74, z, 0.08, 1.42, 1.49, western ? '#91a9ab' : '#e4bd88')
      box(edge + 0.21, 1.74, z, 0.07, 1.52, 0.08, timber)
      box(edge + 0.21, 1.88, z, 0.07, 0.09, 1.55, timber)
      box(edge + 0.19, 0.88, z, 0.44, 0.14, 1.96, stone)
    }
    for (let i = 0; i < 8; i++) box(edge + 0.022, 0.31 + i * 0.078, 0, 0.09, 0.035, 5.45, facade)
    if (western) {
      for (const side of [-1, 1]) {
        beam(0, 6.78, 3.13, side * 3.64, 4.57, 3.13, 0.11, timber)
        beam(side * 2.68, 4.62, 3.1, side * 0.72, 5.87, 3.1, 0.085, timber)
        beam(side * 3.86, 0.15, -2.49, side * 3.86, 0.15, 2.4, 0.16, stone)
      }
      box(1.8, 0.65, 3.79, 1.44, 0.62, 0.55, timber)
      for (let j = 0; j < 5; j++) {
        bush(1.19 + j * 0.3, 1.08, 3.77, 0.26, leaves)
        bush(1.17 + j * 0.28, 1.23, 3.79, 0.14, j % 2 ? '#d89a80' : '#ead4a1')
      }
    } else if (!kiln) {
      for (let i = 0; i < 6; i++) box(-4.22 + i * 0.83, 0.07, 4.62, 0.77, 0.08, 0.48, '#b6aca1')
      box(edge + 0.34, 2.61, -2.15, 0.52, 0.74, 1.08, '#a09e91')
      for (let i = 0; i < 5; i++) box(edge + 0.62, 2.4 + i * 0.09, -2.15, 0.04, 0.025, 0.84, slate)
    }
  }
  if (kind === 'teagarden') {
    const px = 4.14,
      pz = -3.52
    pole(px, 0.64, pz, 0.62, 1.22, '#ad8b60', 0.71)
    pole(px, 0.29, pz, 0.64, 0.1, slate)
    pole(px, 0.92, pz, 0.69, 0.09, slate)
    for (let i = 0; i < 4; i++) beam(-5.76 + i * 0.63, 2.78, -0.79, -6.38 + i * 0.68, 2.16, 1.68, 0.042, '#748784')
  }
  // Batch by material so repeated storefront details cost one draw call per swatch.
  const batches = new Map<T.Material, T.BufferGeometry[]>()
  root.updateMatrixWorld(true)
  for (const child of [...root.children]) {
    if (!(child instanceof T.Mesh) || !(child.material instanceof T.MeshStandardMaterial)) continue
    const source = child.geometry
    const g = source.index ? source.toNonIndexed() : source.clone()
    if (!g.hasAttribute('uv'))
      g.setAttribute('uv', new T.Float32BufferAttribute(new Float32Array(g.getAttribute('position').count * 2), 2))
    g.applyMatrix4(child.matrixWorld)
    const list = batches.get(child.material) ?? []
    list.push(g)
    batches.set(child.material, list)
    root.remove(child)
    source.dispose()
  }
  for (const [mat, geos] of batches) {
    const geo = mergeGeometries(geos)
    geos.forEach((g) => g.dispose())
    root.add(new T.Mesh(geo, mat))
  }
  const bound = new T.Box3().setFromObject(root),
    size = bound.getSize(new T.Vector3()),
    center = bound.getCenter(new T.Vector3())
  // Keep every piece, including the windmill sails, inside its declared footprint.
  const scale = Math.min(spec.width / size.x, spec.depth / size.z)
  root.scale.setScalar(scale)
  root.position.set(-center.x * scale, -bound.min.y * scale, -center.z * scale)
  const anchor = new T.Group()
  anchor.add(root)
  return anchor
}
export function estateModel(kind: string) {
  let source = models.get(kind)
  if (!source) {
    source = build(kind)
    models.set(kind, source)
  }
  return source.clone(true)
}
