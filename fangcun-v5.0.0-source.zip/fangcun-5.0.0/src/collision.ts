import type * as R from '@dimforge/rapier3d-compat'
import * as T from 'three'
import type { Plot } from './data'

let engine: Promise<typeof R> | undefined
export function loadPhysics() {
  return engine ??= import('@dimforge/rapier3d-compat').then(async module => {
    await module.init()
    return module
  }).catch(error => {
    engine = undefined
    throw error
  })
}

export class WalkCollision {
  private world: R.World
  private capsule: R.Collider
  private controller: R.KinematicCharacterController
  private obstacles: R.Collider[] = []
  private cells: [number, number][] = [[0, 0]]
  private radius: number
  private center: number
  private bounds: { x: number; z: number }

  constructor(private engine: typeof R, plot: Plot, scale: number) {
    this.world = new engine.World({ x: 0, y: 0, z: 0 })
    this.radius = .36 * scale
    this.center = .93 * scale
    this.bounds = { x: plot.width / 2, z: plot.depth / 2 }
    this.capsule = this.world.createCollider(engine.ColliderDesc.capsule(this.center - this.radius, this.radius))
    this.controller = this.world.createCharacterController(.018 * scale)
    this.controller.setSlideEnabled(true)
  }

  rebuild(objects: T.Object3D[], cells: [number, number][] = [[0, 0]]) {
    for (const collider of this.obstacles) this.world.removeCollider(collider, false)
    this.obstacles = []
    this.cells = cells
    const wall = (x: number, z: number, w: number, d: number) =>
      this.obstacles.push(this.world.createCollider(this.engine.ColliderDesc.cuboid(w, 3, d).setTranslation(x, 1, z)))
    const { x: halfX, z: halfZ } = this.bounds
    const covered = new Set(cells.map(cell => cell.join(':')))
    for (const [x, z] of cells) {
      for (const sign of [-1, 1]) {
        if (!covered.has(`${x + sign * halfX * 2}:${z}`)) wall(x + sign * (halfX + .5), z, .5, halfZ + .01)
        if (!covered.has(`${x}:${z + sign * halfZ * 2}`)) wall(x, z + sign * (halfZ + .5), halfX + .01, .5)
      }
    }
    for (const root of objects) root.updateWorldMatrix(true, true)
    const vertex = new T.Vector3()
    const matrix = new T.Matrix4()
    for (const root of objects) root.traverse(object => {
      if (!(object instanceof T.Mesh) || object.userData.skipCollision) return
      const attribute = object.geometry.getAttribute('position')
      if (!attribute || attribute.count < 3) return
      const index = object.geometry.index
      const indexCount = index?.count ?? attribute.count
      const indices = new Uint32Array(indexCount - indexCount % 3)
      for (let i = 0; i < indices.length; i++) indices[i] = index ? index.getX(i) : i
      const instance = object instanceof T.InstancedMesh ? object : undefined
      for (let n = 0; n < (instance?.count ?? 1); n++) {
        matrix.copy(object.matrixWorld)
        if (instance) {
          const local = new T.Matrix4()
          instance.getMatrixAt(n, local)
          matrix.multiply(local)
        }
        const points = new Float32Array(attribute.count * 3)
        for (let i = 0; i < attribute.count; i++) {
          object.getVertexPosition(i, vertex).applyMatrix4(matrix).toArray(points, i * 3)
        }
        const desc = object.userData.ownMaterial
          ? this.engine.ColliderDesc.convexHull(points)
          : this.engine.ColliderDesc.trimesh(points, indices)
        if (desc) this.obstacles.push(this.world.createCollider(desc))
      }
    })
    this.world.step()
  }

  clearAt(x: number, z: number) {
    if (!this.cells.some(([cx, cz]) => Math.abs(x - cx) <= this.bounds.x && Math.abs(z - cz) <= this.bounds.z)) return false
    let clear = true
    this.world.intersectionsWithShape({ x, y: this.center, z }, { x: 0, y: 0, z: 0, w: 1 }, this.capsule.shape, () => {
      clear = false
      return false
    }, undefined, undefined, this.capsule)
    return clear
  }

  spawn(position: T.Vector3) {
    if (this.clearAt(position.x, position.z)) return position.clone()
    for (let ring = 1; ring <= 10; ring++) {
      for (let slot = 0; slot < 24; slot++) {
        const angle = slot * Math.PI / 12
        const x = position.x + ring * .85 * Math.cos(angle)
        const z = position.z + ring * .85 * Math.sin(angle)
        if (this.clearAt(x, z)) return new T.Vector3(x, 0, z)
      }
    }
    for (let x = -this.bounds.x + 1; x < this.bounds.x; x += 2) {
      for (let z = -this.bounds.z + 1; z < this.bounds.z; z += 2) {
        if (this.clearAt(x, z)) return new T.Vector3(x, 0, z)
      }
    }
    return undefined
  }

  move(position: T.Vector3, step: T.Vector3) {
    this.capsule.setTranslation({ x: position.x, y: this.center, z: position.z })
    this.controller.computeColliderMovement(this.capsule, step)
    const movement = this.controller.computedMovement()
    return new T.Vector3(movement.x, 0, movement.z)
  }

  dispose() { this.world.free() }
}
