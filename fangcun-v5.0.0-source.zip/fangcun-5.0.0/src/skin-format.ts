import type { NpcSettings } from './data'

export const skinFileLimit = 128 * 1024
export const npcTextLimits = { greeting: 180, persona: 600, knowledge: 1200 }

export function isSkinPng(bytes: Uint8Array) {
  if (bytes.length < 45 || bytes.length > skinFileLimit) return false
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
  if (view.getUint32(0) !== 0x89504e47 || view.getUint32(4) !== 0x0d0a1a0a ||
      view.getUint32(8) !== 13 || view.getUint32(12) !== 0x49484452 ||
      view.getUint32(16) !== 64 || view.getUint32(20) !== 64) return false
  let imageData = false
  for (let offset = 33; offset + 12 <= bytes.length;) {
    const size = view.getUint32(offset)
    const kind = view.getUint32(offset + 4)
    offset += size + 12
    if (offset > bytes.length) return false
    if (kind === 0x49444154 && size > 0) imageData = true
    if (kind === 0x49454e44) return imageData && size === 0 && offset === bytes.length
  }
  return false
}

export function validNpc(value: unknown): value is NpcSettings {
  if (!value || typeof value !== 'object') return false
  const npc = value as NpcSettings
  return (npc.body === 'classic' || npc.body === 'slim') && typeof npc.ai === 'boolean' &&
    Object.entries(npcTextLimits).every(([field, limit]) => {
      const text = npc[field as keyof typeof npcTextLimits]
      return typeof text === 'string' && text.length <= limit
    })
}
