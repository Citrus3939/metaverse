import * as T from 'three'
import type { StreetSide } from './data'

export type StreetBlock = { x: number; z: number; streets?: StreetSide[] }
type Tile = { x: number; z: number; slug: string; turn: number }
const junctions = [
  { mask: 1, slug: 'end' }, { mask: 5, slug: 'straight' }, { mask: 3, slug: 'bend' },
  { mask: 11, slug: 'tee' }, { mask: 15, slug: 'cross' },
]
function junction(mask: number) {
  for (const type of junctions) {
    let rotated = type.mask
    for (let turn = 0; turn < 4; turn++) {
      if (rotated === mask) return { slug: type.slug, turn }
      rotated = ((rotated << 1) & 15) | (rotated >> 3)
    }
  }
  throw new Error('无效道路连接')
}

export function streetTiles(blocks: StreetBlock[]) {
  const nodes = new Map<string, { x: number; z: number; mask: number }>()
  const tiles: Tile[] = []
  function port(x: number, z: number, mask: number) {
    const key = x + ',' + z
    const node = nodes.get(key) ?? { x, z, mask: 0 }
    node.mask |= mask
    nodes.set(key, node)
  }
  for (const block of blocks) for (const side of block.streets ?? []) {
    const east = side === 'east'
    const x = block.x + (east ? 50 : -50), z = block.z + (east ? -50 : 50)
    port(x, z, east ? 4 : 2)
    port(x + (east ? 0 : 100), z + (east ? 100 : 0), east ? 1 : 8)
    for (let n = 10; n < 100; n += 10) tiles.push({
      x: x + (east ? 0 : n), z: z + (east ? n : 0), slug: 'straight', turn: east ? 0 : 1,
    })
  }
  for (const node of nodes.values()) tiles.push({ ...node, ...junction(node.mask) })
  return tiles
}

// Clip each module to resident build plots. Unclaimed land keeps its real map.
export class StreetNetwork {
  readonly root = new T.Group()
  private signature = ''
  private materials = new Map<string, T.MeshBasicMaterial>()
  refresh(blocks: StreetBlock[]) {
    const signature = JSON.stringify(blocks)
    if (signature === this.signature) return
    this.signature = signature
    this.clear()
    const occupied = new Set(blocks.map(b => b.x + ',' + b.z))
    const batches = new Map<string, { positions: number[]; uvs: number[] }>()
    for (const tile of streetTiles(blocks)) {
      const batch = batches.get(tile.slug) ?? { positions: [], uvs: [] }
      batches.set(tile.slug, batch)
      for (const dx of [-5,0]) for (const dz of [-5,0]) {
        const cx = Math.round((tile.x + dx + 2.5) / 100) * 100
        const cz = Math.round((tile.z + dz + 2.5) / 100) * 100
        if (!occupied.has(cx + ',' + cz)) continue
        for (const [i,j] of [[0,0],[0,5],[5,0],[5,0],[0,5],[5,5]]) {
          const x = dx + i, z = dz + j
          batch.positions.push(tile.x + x, .002, tile.z + z)
          let u = x, v = z
          for (let turn = 0; turn < tile.turn; turn++) [u,v] = [v,-u]
          batch.uvs.push(.5 + u/10, .5 - v/10)
        }
      }
    }
    for (const [slug, batch] of batches) {
      let material = this.materials.get(slug)
      if (!material) {
        const map = new T.TextureLoader().load(import.meta.env.BASE_URL + 'street/road-' + slug + '.png')
        map.colorSpace = T.SRGBColorSpace
        material = new T.MeshBasicMaterial({ map })
        this.materials.set(slug, material)
      }
      const geo = new T.BufferGeometry()
      geo.setAttribute('position', new T.Float32BufferAttribute(batch.positions, 3))
      geo.setAttribute('uv', new T.Float32BufferAttribute(batch.uvs, 2))
      this.root.add(new T.Mesh(geo, material))
    }
  }
  private clear() {
    for (const child of this.root.children) (child as T.Mesh).geometry.dispose()
    this.root.clear()
  }
  dispose() {
    this.clear()
    for (const mat of this.materials.values()) { mat.map?.dispose(); mat.dispose() }
  }
}
