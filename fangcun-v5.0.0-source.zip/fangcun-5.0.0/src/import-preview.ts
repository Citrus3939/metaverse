import * as T from 'three'
import { clone } from 'three/addons/utils/SkeletonUtils.js'
import { boundsOf } from './world'
import type { Plot } from './data'

export function previewModel(host: HTMLElement, source: T.Object3D, plot: Plot, framing: 'plot' | 'portrait' = 'plot') {
  const renderer = new T.WebGLRenderer({ alpha: true, antialias: true })
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
  host.append(renderer.domElement)
  const scene = new T.Scene()
  const model = clone(source)
  const ground = new T.Mesh(new T.BoxGeometry(plot.width, 1, plot.depth), new T.MeshStandardMaterial({ color: '#a3bfa7' }))
  const groundEdge = new T.LineSegments(new T.EdgesGeometry(ground.geometry), new T.LineBasicMaterial({ color: '#426952' }))
  ground.add(groundEdge)
  const box = new T.BoxHelper(model, '#da5147')
  box.visible = false
  const sun = new T.DirectionalLight('#fff6dd', 2.2)
  sun.position.set(3, 9, 6)
  scene.add(ground, model, box, sun, new T.HemisphereLight('#ffffff', '#97af9c', 2))
  const camera = new T.OrthographicCamera()
  const render = (scale: number, grounded: boolean, valid: boolean) => {
    model.scale.setScalar(scale)
    model.position.y = 0
    const bounds = boundsOf(model)
    if (grounded) model.position.y = -bounds.min.y
    const dimensions = bounds.getSize(new T.Vector3())
    const size = Math.max(.01, dimensions.x, dimensions.y, dimensions.z)
    const portrait = framing === 'portrait'
    const limit = size * (portrait ? 1.15 : 2.8)
    ground.scale.set(Math.min(1, limit / plot.width), size * .04, Math.min(1, limit / plot.depth))
    ground.position.y = -size * .02
    box.update()
    box.visible = !valid
    const targetY = portrait ? model.position.y + (bounds.min.y + bounds.max.y) / 2 : model.position.y * .6
    camera.position.set(portrait ? .65 : 1.2, portrait ? .34 : .9, 1.5).multiplyScalar(size * 3)
    if (portrait) camera.position.y += targetY
    camera.far = size * 30
    camera.near = size * .001
    camera.lookAt(0, targetY, 0)
    const width = Math.max(1, host.clientWidth)
    const height = Math.max(1, host.clientHeight)
    const aspect = width / height
    camera.left = -size * (portrait ? .67 : 1.15) * aspect
    camera.right = -camera.left
    camera.top = size * (portrait ? .67 : 1.15)
    camera.bottom = -camera.top
    camera.updateProjectionMatrix()
    renderer.setSize(width, height)
    renderer.render(scene, camera)
  }
  return {
    render,
    dispose() {
      groundEdge.geometry.dispose()
      groundEdge.material.dispose()
      ground.geometry.dispose()
      ground.material.dispose()
      box.dispose()
      renderer.dispose()
      renderer.domElement.remove()
    },
  }
}
