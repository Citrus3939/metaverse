import * as T from 'three'

export type Character = { object: T.Object3D; clips: T.AnimationClip[]; dispose?: () => void }
const times = [0, .25, .5, .75, 1]

export function blockCharacter(): Character {
  const object = new T.Group()
  const body = new T.MeshStandardMaterial({ color: '#e7ac51' })
  const metal = new T.MeshStandardMaterial({ color: '#344959' })
  const ceramic = new T.MeshStandardMaterial({ color: '#e8e7da' })
  const glow = new T.MeshStandardMaterial({ color: '#71dde4', emissive: '#176276' })
  function block(parent: T.Object3D, size: number[], at: number[], material: T.Material) {
    const mesh = new T.Mesh(new T.BoxGeometry(...size), material)
    mesh.position.fromArray(at)
    parent.add(mesh)
  }
  function bone(name: string, x: number, y: number, parent: T.Object3D = object) {
    const joint = new T.Bone()
    joint.name = name
    joint.position.set(x, y, 0)
    parent.add(joint)
    return joint
  }
  const chest = bone('Chest', 0, .9)
  block(chest, [.49, .59, .31], [0, .30, 0], body)
  block(chest, [.25, .075, .024], [0, .38, .166], glow)
  const head = bone('Head', 0, .65, chest)
  block(head, [.43, .38, .37], [0, .14, 0], ceramic)
  block(head, [.36, .11, .038], [0, .16, .19], metal)
  block(head, [.22, .036, .008], [0, .16, .214], glow)
  block(head, [.075, .10, .077], [-.14, .38, 0], body)
  const walk: T.KeyframeTrack[] = []
  for (const [index, sign] of [-1, 1].entries()) {
    const arm = bone(`Arm${index}`, sign * .3, .49, chest)
    const leg = bone(`Leg${index}`, sign * .13, .87)
    block(arm, [.14, .39, .18], [0, -.17, 0], ceramic)
    block(arm, [.15, .13, .18], [0, -.38, 0], metal)
    block(leg, [.19, .67, .20], [0, -.34, 0], metal)
    block(leg, [.20, .15, .31], [0, -.79, .04], body)
    const swing = [0, sign * .48, 0, -sign * .48, 0]
    walk.push(new T.NumberKeyframeTrack(`${leg.name}.rotation[x]`, times, swing))
    walk.push(new T.NumberKeyframeTrack(`${arm.name}.rotation[x]`, times, swing.map(x => -x * .8)))
  }
  return {
    object,
    clips: [
      new T.AnimationClip('Idle', 2, [new T.NumberKeyframeTrack('Head.rotation[z]', [0, 1, 2], [0, .035, 0])]),
      new T.AnimationClip('Walk', 1, walk),
    ],
  }
}

export function animationPair(clips: T.AnimationClip[]) {
  const idle = clips.find(clip => /idle|stand|待机|站立/i.test(clip.name))
  const walk = clips.find(clip => /walk|run|走|行走|跑/i.test(clip.name) && clip !== idle)
  return idle && walk ? { idle, walk } : undefined
}

export class CharacterAnimation {
  private mixer: T.AnimationMixer
  private actions: T.AnimationAction[]
  private active = 0

  constructor(private character: Character) {
    const pair = animationPair(character.clips)!
    this.mixer = new T.AnimationMixer(character.object)
    this.actions = [this.mixer.clipAction(pair.idle), this.mixer.clipAction(pair.walk)]
    this.actions[0].play()
  }

  update(dt: number, moving: boolean, speed: number) {
    const next = Number(moving)
    if (next !== this.active) {
      this.actions[this.active].fadeOut(.13)
      this.actions[next].reset().fadeIn(.13).play()
      this.active = next
    }
    this.actions[1].timeScale = T.MathUtils.clamp(speed / 4.2, .35, 2.2)
    this.mixer.update(dt)
  }

  dispose() {
    this.mixer.stopAllAction()
    this.mixer.uncacheRoot(this.character.object)
  }
}

export function addDefaultHumanoidClips(character: Character) {
  if (animationPair(character.clips)) return
  const bones: T.Bone[] = []
  character.object.traverse(node => { if (node instanceof T.Bone) bones.push(node) })
  const name = (bone: T.Bone) => bone.name.toLowerCase().replace(/mixamorig|[^a-z]/g, '')
  const keys = (parts: string[], side: string, short: string) =>
    new Set(parts.flatMap(part => [side + part, part + side, short + part, part + short]))
  function find(parts: string[], left: boolean) {
    const aliases = keys(parts, left ? 'left' : 'right', left ? 'l' : 'r')
    return bones.find(bone => aliases.has(name(bone)))
  }
  function track(bone: T.Bone, axis: T.Vector3, samples: number[], t: number[]) {
    const values = samples.flatMap(angle => bone.quaternion.clone()
      .multiply(new T.Quaternion().setFromAxisAngle(axis, angle)).toArray())
    return new T.QuaternionKeyframeTrack(`${bone.uuid}.quaternion`, t, values)
  }
  const hasWalk = character.clips.some(clip => /walk|run|走|跑/i.test(clip.name))
  if (!hasWalk) {
    const legs = [find(['upperleg', 'upleg', 'leg', 'thigh'], true), find(['upperleg', 'upleg', 'leg', 'thigh'], false)]
    if (!legs[0] || !legs[1]) return
    const arms = [find(['upperarm', 'arm'], true), find(['upperarm', 'arm'], false)]
    const axis = new T.Vector3(1, 0, 0)
    const swing = [0, .42, 0, -.42, 0]
    const tracks = legs.map((bone, i) => track(bone!, axis, swing.map(value => i ? -value : value), times))
    arms.forEach((bone, i) => { if (bone) tracks.push(track(bone, axis, swing.map(value => i ? value * .75 : -value * .75), times)) })
    character.clips.push(new T.AnimationClip('Walk', 1, tracks))
  }
  if (!character.clips.some(clip => /idle|stand|待机|站立/i.test(clip.name))) {
    const anchor = bones.find(bone => name(bone) === 'head') ?? bones[0]
    if (anchor) character.clips.push(new T.AnimationClip('Idle', 2,
      [track(anchor, new T.Vector3(0, 0, 1), [0, .025, 0], [0, 1, 2])]))
  }
}
