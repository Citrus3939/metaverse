import type { Presence, RegionView } from './collab-types'
import type { RegionClient } from './region'
import { $, icons, escapeHtml } from './ui'

export const memberActions: Record<Presence['mode'], string> = { overview: '查看总览', edit: '编辑中', walk: '行走中', view: '观赏中' }

export function memberList(view?: RegionView) {
  return view?.people.map(person => `<li><span class="member-dot"></span><span><strong>${escapeHtml(person.name)}${person.id === view.member ? '（你）' : ''}</strong><small>${memberActions[person.mode]}${person.cell ? ' · ' + escapeHtml(person.cell) : ''}</small></span></li>`).join('') ?? ''
}

export function bindRegionPanel(client: RegionClient, signal: AbortSignal) {
  const dialog = $('region-invite-dialog') as HTMLDialogElement
  const input = $('region-invite-link') as HTMLInputElement
  const status = $('region-invite-status')
  $('region-invite').addEventListener('click', () => dialog.showModal(), { signal })
  $('region-invite-close').addEventListener('click', () => dialog.close(), { signal })
  async function invite(grant: 'view' | 'edit') {
    try {
      input.value = await client.invite(grant)
      $('region-link-row').hidden = false
      input.select()
      status.textContent = '已生成邀请链接。'
    } catch (error) { status.textContent = error instanceof Error ? error.message : '邀请生成失败。' }
  }
  $('region-invite-view').addEventListener('click', () => void invite('view'), { signal })
  $('region-invite-edit').addEventListener('click', () => void invite('edit'), { signal })
  $('region-invite-copy').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(input.value); status.textContent = '已复制链接。' }
    catch { input.select(); status.textContent = '按 Ctrl/Cmd+C 复制链接。' }
  }, { signal })
  $('region-revoke').addEventListener('click', async () => {
    try {
      await client.revokeEditing()
      $('region-link-row').hidden = true
      status.textContent = '已撤销成员编辑权限，成员仍可进入共建区。'
    } catch (error) { status.textContent = error instanceof Error ? error.message : '权限修改失败。' }
  }, { signal })
}

export function inviteDialog() {
  return `<dialog id="region-invite-dialog" class="app-dialog">
    <div class="dialog-heading"><span class="dialog-icon">${icons.group}</span>
      <div><h2>邀请好友加入共建区</h2><p>编辑权限可由共建区主人撤销。</p></div></div>
    <div class="room-options">
      <button class="secondary" id="region-invite-view">允许进入</button>
      <button class="primary" id="region-invite-edit">允许编辑</button>
    </div>
    <div class="scale-row" id="region-link-row" hidden>
      <input class="text-field" id="region-invite-link" aria-label="共建邀请链接" readonly>
      <button class="secondary" id="region-invite-copy">复制</button>
    </div>
    <p class="import-warning" id="region-invite-status" aria-live="polite"></p>
    <div class="dialog-actions"><button class="subtle" id="region-revoke">撤销成员编辑权限</button>
      <button class="secondary" id="region-invite-close">关闭</button></div>
  </dialog>`
}
