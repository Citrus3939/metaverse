import { DatabaseSync } from 'node:sqlite'
import { existsSync, mkdirSync, readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { base, HttpError, roomId } from './collab-http.ts'
import type { MemberRole, RegionTile } from '../src/collab-types.ts'

export type RegionMember = { id: string; name: string; role: MemberRole }
export type Region = {
  name: string
  members: Record<string, RegionMember>
  invites: Record<string, 'view' | 'edit'>
  tiles: Record<string, RegionTile>
}
let connection: DatabaseSync | undefined
export function database() {
  if (connection) return connection
  mkdirSync(base, { recursive: true })
  const db = new DatabaseSync(join(base, 'world.sqlite'))
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS regions(id TEXT PRIMARY KEY,data TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS plots(room TEXT PRIMARY KEY, cell TEXT NOT NULL, region TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS plot_cell ON plots(cell);
    CREATE TABLE IF NOT EXISTS economy(id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS business_edits(room TEXT, player TEXT, name TEXT NOT NULL, time INTEGER NOT NULL, PRIMARY KEY(room,player));
    CREATE TABLE IF NOT EXISTS passports(hash TEXT PRIMARY KEY, player TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS receipts(player TEXT, nonce TEXT, result TEXT NOT NULL, PRIMARY KEY(player,nonce));`)
  // Import v4 regions once. Their room files, bearer credentials and GLBs stay in place.
  const old = join(base, 'regions')
  db.exec('BEGIN IMMEDIATE')
  try {
    if (existsSync(old))
      for (const id of readdirSync(old)) {
        const filename = join(old, id, 'region.json')
        if (!roomId.test(id) || !existsSync(filename) || db.prepare('SELECT id FROM regions WHERE id=?').get(id))
          continue
        const raw = readFileSync(filename, 'utf8')
        const region: Region = JSON.parse(raw)
        db.prepare('INSERT INTO regions VALUES(?,?)').run(id, raw)
        for (const tile of Object.values(region.tiles))
          db.prepare('INSERT INTO plots VALUES(?,?,?)').run(tile.room, tile.key, id)
      }
    db.exec('COMMIT')
  } catch (error) {
    db.exec('ROLLBACK')
    db.close()
    throw error
  }
  connection = db
  return db
}
export function transaction<T>(run: () => T): T {
  const db = database()
  db.exec('BEGIN IMMEDIATE')
  try {
    const result = run()
    db.exec('COMMIT')
    return result
  } catch (error) {
    db.exec('ROLLBACK')
    throw error
  }
}
export function readRegion(id: string): Region {
  const row = roomId.test(id) && database().prepare('SELECT data FROM regions WHERE id=?').get(id)
  if (!row) throw new HttpError(404, '找不到这个共建区。')
  return JSON.parse(String(row.data))
}
export function writeRegion(id: string, region: Region) {
  database()
    .prepare('INSERT INTO regions VALUES(?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data')
    .run(id, JSON.stringify(region))
}
export function indexPlot(id: string, tile: RegionTile) {
  database()
    .prepare('INSERT INTO plots VALUES(?,?,?) ON CONFLICT(room) DO UPDATE SET region=excluded.region')
    .run(tile.room, tile.key, id)
}
export function plotHome(room: string) {
  return database().prepare('SELECT region FROM plots WHERE room=?').get(room)?.region as string | undefined
}
export function existingPlots(cell: string) {
  return database().prepare('SELECT region,room FROM plots WHERE cell=?').all(cell) as {
    region: string
    room: string
  }[]
}
