import { randomBytes } from 'node:crypto'
import { mkdirSync, renameSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'

export const base = resolve(process.env.FANGCUN_ROOM_DIR || '.fangcun-rooms')
export const roomId = /^[a-f0-9]{24}$/
export const tokenPattern = /^[a-f0-9]{64}$/
export const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i
export const key = (bytes = 32) => randomBytes(bytes).toString('hex')
export const tokenOf = (request: IncomingMessage) => request.headers.authorization?.replace(/^Bearer /, '') ?? ''
export const readableName = (value: unknown, max: number) => typeof value === 'string'
  ? value.trim().replace(/[\x00-\x1f\x7f]/g, '').slice(0, max)
  : ''

export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message) }
}
export function json(response: ServerResponse, status: number, data: unknown) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' })
  response.end(JSON.stringify(data))
}
export async function bytes(request: IncomingMessage, limit: number) {
  const claimed = Number(request.headers['content-length'] ?? 0)
  if (claimed > limit) throw new HttpError(413, '文件或场景超过房间大小限制。')
  const parts: Buffer[] = []
  let length = 0
  for await (const chunk of request) {
    length += chunk.length
    if (length > limit) throw new HttpError(413, '文件或场景超过房间大小限制。')
    parts.push(chunk)
  }
  return Buffer.concat(parts)
}
export async function body<T>(request: IncomingMessage) {
  let result
  try { result = JSON.parse((await bytes(request, 2_000_000)).toString('utf8')) }
  catch (error) {
    if (error instanceof HttpError) throw error
    throw new HttpError(400, '请求格式无效。')
  }
  if (!result || typeof result !== 'object' || Array.isArray(result)) throw new HttpError(400, '请求格式无效。')
  return result as T
}
export function writeJson(dir: string, name: string, data: unknown) {
  mkdirSync(dir, { recursive: true, mode: 0o700 })
  const path = join(dir, name)
  writeFileSync(path + '.tmp', JSON.stringify(data), { mode: 0o600 })
  renameSync(path + '.tmp', path)
}
