import type { IncomingMessage, ServerResponse } from 'node:http'
import { validNpc } from '../src/skin-format.ts'
import type { NpcSettings } from '../src/data.ts'
import { body, HttpError, json, readableName } from './collab-http.ts'

type Message = { role: 'user' | 'assistant'; content: string }
const recent = new Map<string, { time: number; count: number }>()
let pending = 0

export async function npcChat(request: IncomingMessage, response: ServerResponse, find?: (id: string) => { name: string; npc?: NpcSettings }) {
  if (request.headers['content-type']?.split(';')[0] !== 'application/json') throw new HttpError(415, '请使用对话面板提交消息。')
  const input = await body<{ id: string; name: string; npc: NpcSettings; messages: Message[] }>(request)
  const target = find ? find(input.id) : { name: readableName(input.name, 60), npc: input.npc }
  if (!validNpc(target.npc)) throw new HttpError(400, 'NPC 对话配置无效。')
  const messages = input.messages
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 10 || messages.at(-1)?.role !== 'user' ||
      !messages.every(message => message && (message.role === 'user' || message.role === 'assistant') &&
        typeof message.content === 'string' && message.content.trim().length > 0 && message.content.length <= 600)) {
    throw new HttpError(400, '请输入 1 到 600 字的消息。')
  }
  const endpoint = process.env.FANGCUN_NPC_AI_URL
  const model = process.env.FANGCUN_NPC_AI_MODEL
  if (!target.npc.ai || !endpoint || !model) { json(response, 200, { available: false }); return }
  const now = Date.now()
  for (const [address, value] of recent) if (now - value.time > 60_000) recent.delete(address)
  const address = request.socket.remoteAddress ?? 'local'
  const usage = recent.get(address) ?? { time: now, count: 0 }
  if (usage.count >= 12 || pending >= 4) throw new HttpError(429, '对话有点忙，请稍后再试。')
  usage.count++
  recent.set(address, usage)
  pending++
  try {
    const key = process.env.FANGCUN_NPC_AI_KEY
    const result = await fetch(endpoint, {
      method: 'POST', redirect: 'error', signal: AbortSignal.timeout(12_000),
      headers: { 'Content-Type': 'application/json', ...(key ? { Authorization: `Bearer ${key}` } : {}) },
      body: JSON.stringify({ model, max_tokens: 220, messages: [
        { role: 'system', content: `你是地块里的游戏角色「${target.name}」。请按角色口吻用简短文字对话。地块资料未知时直说。
角色设定：${target.npc.persona}
开场白：${target.npc.greeting}
地块资料：${target.npc.knowledge}` },
        ...messages,
      ] }),
    })
    if (!result.ok) throw new Error()
    const value = await result.json() as { choices?: Array<{ message?: { content?: unknown } }> }
    const reply = value.choices?.[0]?.message?.content
    if (typeof reply !== 'string' || !reply.trim()) throw new Error()
    json(response, 200, { available: true, reply: reply.trim().slice(0, 600) })
  } catch {
    throw new HttpError(502, 'AI 暂时无法回复。')
  } finally { pending-- }
}
