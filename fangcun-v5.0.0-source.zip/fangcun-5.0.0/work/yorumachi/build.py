from collections import defaultdict
from io import BytesIO
from itertools import cycle
from math import cos, sin, pi, sqrt
from pathlib import Path
import json
import random
import struct
import sys

from PIL import Image, ImageDraw, ImageFont
import numpy as np

OUT = Path(sys.argv[1])
RNG = random.Random(29)
JA = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
JP_SERIF = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc'
EN = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
GROUP = '01 · Square plinth and streets'
batches = defaultdict(lambda: [[], [], [], []])
materials = {}
images = {}
WHITE = '#ffffff'

def rgb(value):
    value = value.lstrip('#')
    return tuple(int(value[i:i+2],16)/255 for i in (0,2,4))

def linear(c):
    return c/12.92 if c <= .04045 else ((c+.055)/1.055)**2.4

def strength(col, factor):
    return tuple(min(1, x*factor) for x in rgb(col))

def mix(a, b, t):
    a, b = rgb(a), rgb(b)
    return tuple(x*(1-t)+y*t for x,y in zip(a,b))

def mat(name, image=None, alpha='OPAQUE', factor=(1,1,1,1), double=False):
    materials[name] = (factor, image, alpha, double)
    return name

SOLID = mat('Cel shaded · baked face colours')
GLASS = mat('Glass · faint blue tint', alpha='BLEND', factor=(*map(linear,rgb('#a9d9e4')), .095), double=True)
GLINT = mat('Glass · soft highlight', alpha='BLEND', factor=(*map(linear,rgb('#c8ecf0')), .19), double=True)
DARK_GLASS = mat('Glass · refrigerated cabinets', alpha='BLEND', factor=(*map(linear,rgb('#cbeeff')), .13), double=True)

def vect(a, b):
    return tuple(y-x for x,y in zip(a,b))

def cross(a,b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def unit(a):
    length = sqrt(sum(x*x for x in a))
    return tuple(x/length for x in a)

def muladd(origin, direction, scale):
    return tuple(a+b*scale for a,b in zip(origin,direction))

def color(col, n, shade):
    if isinstance(col,str):
        col = rgb(col)
    if shade:
        nx, ny, nz = n
        # Three broad tones, with a small cool cast in the dark faces.
        level = .72 + max(nz, 0)*.28 + max(-ny,0)*.17 + max(nx,0)*.10
        col = tuple(min(1, c*level+(1-level)*t) for c,t in zip(col, (.028,.042,.083)))
    return tuple(map(linear,col))

def poly(vertices, col=WHITE, material=SOLID, uv=None, shade=True):
    global GROUP
    n = unit(cross(vect(vertices[0],vertices[1]),vect(vertices[0],vertices[2])))
    ps, ns, cs, ts = batches[(GROUP,material)]
    c = color(col, n, shade)
    n = (n[0],n[2],-n[1])
    for i in range(1,len(vertices)-1):
        for index in (0,i,i+1):
            x,y,h = vertices[index]
            ps.append((x,h,-y))
            ns.append(n)
            cs.append(c)
            if uv is not None:
                ts.append(uv[index])

def top(x,y,h,w,d,col,material=SOLID):
    poly([(x-w/2,y-d/2,h),(x+w/2,y-d/2,h),(x+w/2,y+d/2,h),(x-w/2,y+d/2,h)],
         col,material,[(0,1),(1,1),(1,0),(0,0)] if material!=SOLID else None,material==SOLID)

def front(x,y,h,w,ht,col=WHITE,material=SOLID):
    poly([(x-w/2,y,h-ht/2),(x+w/2,y,h-ht/2),(x+w/2,y,h+ht/2),(x-w/2,y,h+ht/2)],
         col,material,[(0,1),(1,1),(1,0),(0,0)] if materials[material][1] else None,material==SOLID)

def right(x,y,h,d,ht,col=WHITE,material=SOLID):
    poly([(x,y-d/2,h-ht/2),(x,y+d/2,h-ht/2),(x,y+d/2,h+ht/2),(x,y-d/2,h+ht/2)],
         col,material,[(0,1),(1,1),(1,0),(0,0)] if materials[material][1] else None,material==SOLID)

def prism(points, lower, upper, col, sides=None):
    poly([(a,b,upper) for a,b in points],col)
    poly([(a,b,lower) for a,b in reversed(points)],col)
    for (x,y),(u,v) in zip(points,points[1:]+points[:1]):
        poly([(x,y,lower),(u,v,lower),(u,v,upper),(x,y,upper)],sides or col)

def box(x,y,h,w,d,ht,col, angle=0, side=None):
    a,b = cos(angle),sin(angle)
    corners = [(-w/2,-d/2),(w/2,-d/2),(w/2,d/2),(-w/2,d/2)]
    prism([(x+u*a-v*b,y+u*b+v*a) for u,v in corners],h-ht/2,h+ht/2,col,side)

def basebox(z1,z2,r,corner,col,side=None):
    points = [(-r+corner,-r),(r-corner,-r),(r,-r+corner),(r,r-corner),
              (r-corner,r),(-r+corner,r),(-r,r-corner),(-r,-r+corner)]
    prism(points,z1,z2,col,side)

def beam(a,b,r,col,steps=8, end_radius=None, capped=True):
    axis = unit(vect(a,b))
    other = (0,0,1) if abs(axis[2])<.95 else (0,1,0)
    u = unit(cross(other,axis))
    v = cross(axis,u)
    rings = []
    for point,rad in ((a,r),(b,r if end_radius is None else end_radius)):
        rings.append([muladd(muladd(point,u,rad*cos(2*pi*i/steps)),v,rad*sin(2*pi*i/steps)) for i in range(steps)])
    lower,upper = rings
    if capped:
        poly(lower[::-1],col)
        poly(upper,col)
    for i in range(steps):
        j = (i+1)%steps
        poly([lower[i],lower[j],upper[j],upper[i]],col)

def rod(x,y,z0,z1,r,col,steps=12,end_radius=None):
    beam((x,y,z0),(x,y,z1),r,col,steps,end_radius)

def wire(points,r,col,steps=5):
    for a,b in zip(points,points[1:]):
        beam(a,b,r,col,steps,capped=False)

def torus_wheel(cx,y,cz,r,t,col,n=24):
    for i in range(n):
        p,q=2*pi*i/n,2*pi*(i+1)/n
        rings = [[(cx+(r+t*cos(s))*cos(a),y+t*sin(s),cz+(r+t*cos(s))*sin(a))
                  for s in (2*pi*j/6 for j in range(6))] for a in (p,q)]
        for j in range(6):
            k=(j+1)%6
            poly([rings[0][j],rings[0][k],rings[1][k],rings[1][j]],col)

def font(size, family='en'):
    return ImageFont.truetype({'en':EN,'ja':JA,'serif':JP_SERIF}[family], size, index=0)

def label(draw,xy,words,size,fill,font_name='en',anchor='lt'):
    draw.text(xy,words,font=font(size,font_name),fill=fill,anchor=anchor)

def picture(name, size, back, paint, alpha='OPAQUE', jpeg=False):
    im=Image.new('RGBA' if alpha=='BLEND' else 'RGB',size,back)
    paint(ImageDraw.Draw(im),im)
    stream=BytesIO()
    im.save(stream,'JPEG' if jpeg else 'PNG',quality=89,optimize=True)
    images[name] = (stream.getvalue(),'image/jpeg' if jpeg else 'image/png')
    return mat(name,image=name,alpha=alpha,double=True)

def shadow(name,x,y,z,w,d,shade='#252637'):
    if name not in materials:
        def paint(_,im):
            yy,xx=np.mgrid[-1:1:128j,-1:1:128j]
            falloff=np.clip(1-(xx*xx+yy*yy),0,1)**1.8
            pixels=np.zeros((128,128,4),dtype=np.uint8)
            pixels[:,:,:3]=[int(k*255) for k in rgb(shade)]
            pixels[:,:,3]=(falloff*94).astype('uint8')
            im.paste(Image.fromarray(pixels,'RGBA'))
        picture(name,(128,128),(0,0,0,0),paint,'BLEND')
    top(x,y,z,w,d,WHITE,name)

# ── Presentation base and exterior floor ─────────────────────────────────
INK='#20203c'
FRAME='#30394a'
CREAM='#e6decd'
ROSE='#ec8074'
MINT='#71c3b0'
basebox(0,.095,6.89,.21,'#282944')
basebox(.095,.17,6.96,.17,'#726377','#4f455f')
basebox(.17,.268,6.987,.14,'#504c68','#3b3957')
basebox(.268,.284,7,.14,'#817086','#61546e')
basebox(.284,.62,6.987,.14,'#504c68','#3b3957')
box(0,0,.66,14,14,.08,'#666781',side='#5b536e')

def road_paint(d, im):
    yy,xx=np.mgrid[-7:7:1024j,-7:7:1024j]
    broad=np.exp(-((xx+.25)**2/26+(yy-4.1)**2/8))
    blue=np.exp(-((xx-5)**2/7+(yy-1.0)**2/25))
    noise=np.random.default_rng(44).normal(0,1.45,xx.shape)
    a=np.zeros((1024,1024,3))
    for i,c in enumerate((53,56,79)):
        a[:,:,i]=c+noise+broad*(22,14,13)[i]+blue*(0,11,17)[i]
    im.paste(Image.fromarray(np.clip(a,0,255).astype('uint8'),'RGB'))
    r=random.Random(24)
    for i in range(430):
        x,y=r.randrange(1024),r.randrange(1024)
        rr=r.choices([1,2,3,5],[8,6,3,1])[0]
        if r.random()>.53:
            d.line((x,y,x+rr,y+(rr>3)),fill=(68,70,93),width=1)
        else:
            d.line((x,y,x+rr,y),fill=(46,50,71),width=1)
ROAD=picture('Dry blue asphalt',(1024,1024),'#3a3c56',road_paint,jpeg=True)
poly([(-6.98,-6.98,.702),(6.98,-6.98,.702),(6.98,6.98,.702),(-6.98,6.98,.702)],
     WHITE,ROAD,[(0,1),(1,1),(1,0),(0,0)],False)
# A thin band around the face reads as a solid model plinth.


arc=[(3.24+1.10*cos(-pi/2+i*pi/20),-3.06+1.10*sin(-pi/2+i*pi/20)) for i in range(11)]
curb_outline=[(-6.98,-4.16)]+arc+[(4.34,6.98),(-6.98,6.98)]
prism(curb_outline,.701,.865,'#828297','#a1a0b0')
arc2=[(3.24+.97*cos(-pi/2+i*pi/20),-3.06+.97*sin(-pi/2+i*pi/20)) for i in range(11)]
prism([(-6.975,-4.03)]+arc2+[(4.211,6.97),(-6.975,6.97)],.863,.879,'#64677e')
# Individual pavement blocks, with warm falloff from the shop windows.
for i in range(30):
    x=-6.77+i*.372
    for j in range(30):
        y=-3.845+j*.372
        if y>6.8 or (x>3.14 and y<-3.05 and (x+.175-3.24)**2+(y-.175+3.06)**2>.94**2):
            continue
        f1=max(0,1-abs(y+2.61)/2)*max(0,1-abs(x+1.1)/5)*.80
        f2=max(0,1-abs(x-2.75)/1.8)*max(0,1-abs(y-.25)/3.3)*.65
        t=min(1,f1+f2)
        cool=RNG.choice(['#777c94','#777a90','#72788f','#7d8097','#7a7d94','#6f758d'])
        warm=RNG.choice(['#bab0a1','#b7aaa0','#b2a398'])
        top(x,y,.882,.353,.352,mix(cool,warm,t))
# Asphalt arrows, lane-edge paint, zebra crossing and curb drains.
def marking(x,y,w,d,col='#d5d1ce',h=.705):
    top(x,y,h,w,d,col)

for i in range(7):
    marking(4.63+i*.305,-5.15,.172,1.38,RNG.choice(['#d7cfd0','#dad4d3','#bdbdc6']))
# Dashed parking outline and P.
for x in (-5.6,-2.48):
    marking(x,-5.12,.043,1.57,'#b4b7c6')
marking(-4.04,-5.905,3.17,.041,'#b4b7c6')
marking(-5.15,-5.479,.05,.49,'#bfc3cf')
marking(-5.00,-5.237,.26,.05,'#bfc3cf')
marking(-5.00,-5.435,.26,.05,'#bfc3cf')
marking(-4.89,-5.344,.046,.212,'#bfc3cf')
for y in (-2.82,-.52,1.75,4.04,6.33):
    marking(6.40,y,.045,1.02,'#939ab2')

for i in range(39):
    x=-6.85+i*.257
    marking(x,-4.177,.232,.081,'#4b506b')
for i in range(37):
    y=-2.92+i*.266
    marking(4.356,y,.078,.238,'#48516a')
for x,y,side in [(-3.9,-4.232,False),(2.78,-4.232,False),(4.428,.77,True),(4.428,5.70,True)]:
    if side:
        box(x,y,.724,.18,.58,.026,'#29344b')
        for i in range(7):
            box(x,y-.234+i*.078,.740,.139,.02,.01,'#757f93')
    else:
        box(x,y,.724,.58,.18,.026,'#29344b')
        for i in range(7):
            box(x-.234+i*.078,y,.740,.02,.139,.01,'#757f93')
for x,y,col in [(5.57,2.2,'#454c65'),(-.07,-5.31,'#4b4b65')]:
    rod(x,y,.699,.711,.245,'#272c44',20)
    rod(x,y,.711,.714,.202,col,20)
    for i in range(5):
        for j in range(4):
            top(x-.115+i*.055,y-.09+j*.055,.715,.030,.020,'#686e84')
# Yellow guide tiles.
for i in range(7):
    for j in range(2):
        x,y=-1.61+i*.227,-3.08-j*.227
        box(x,y,.888,.218,.216,.013,'#b5a374')
        for u in (-.066,0,.066):
            for v in (-.063,0,.063):
                rod(x+u,y+v,.894,.904,.011,'#d5bd7e',6)

# ── Retail shell, windows and fascia ─────────────────────────────────────
GROUP='02 · Yorumachi Mart | architecture'
L,R,F,B=-4.77,2.42,-2.54,4.0
CX,CY=(L+R)/2,(F+B)/2
W,D=R-L,B-F
FLOOR=.989
box(CX,CY,.945,W,D,.13,'#a39893',side='#756b75')
box(CX,F-.083,.913,W+.08,.21,.058,'#bbb3a4')
for i in range(15):
    for j in range(13):
        x=L+.24+i*.476
        y=F+.25+j*.50
        top(x,y,1.012,.469,.493,RNG.choice(['#dcd0b4','#e4d5b5','#dfd3ba','#e8d7b6','#d8cbb4']))
# Back and left wall. Interior-facing colour is separated from exterior.
box(CX,B-.055,2.42,W,.17,2.83,'#b2a9a8',side='#888695')
box(L+.065,CY,2.42,.18,D,2.83,'#b3a6a5',side='#878393')
box(CX,B-.15,2.38,W-.32,.016,2.67,'#e5d4b4')
box(L+.164,CY,2.38,.016,D-.27,2.67,'#ddc6aa')
box(CX,B+.039,1.43,W,.016,.80,'#78788e')
box(L-.032,CY,1.43,.016,D,.80,'#78768b')
for h in (1.07,1.65):
    box(CX,B-.166,h,W-.32,.030,.070,'#a57c6e')
    box(L+.185,CY,h,.027,D-.27,.070,'#af7d6b')
for x in (L+.12,R-.065):
    box(x,F+.025,2.34,.21,.25,2.74,'#a59d9d')
box(R-.084,B-.544,2.43,.16,1.088,2.86,'#a9a4a4')
box(R+.005,B-.544,1.35,.022,1.088,.81,'#747b89')

def mullion_front(x,z,w,h,col=FRAME,thickness=.083):
    box(x,F-.021,z,w,thickness,h,col)
def mullion_side(y,z,w,h,col=FRAME,thickness=.083):
    box(R+.012,y,z,thickness,w,h,col)

panel_rects=[(L+.22,-3.19),(-3.19,-1.77),(-1.77,-.84),(-.84,.065),(.065,1.22),(1.22,R-.12)]
for a,b in panel_rects:
    x=(a+b)/2
    door=a>=-1.78 and b<=.07
    low=1.095 if door else 1.31
    mullion_front(x,low,b-a,.081)
    mullion_front(a,2.12,.069,2.22)
    if not door:
        box(x,F-.026,1.161,b-a,.113,.244,'#777586')
        mullion_front(x,1.675,b-a,.027,'#556072',.058)
    else:
        xx=x+(.32 if a<-1 else -.32)
        mullion_front(xx,1.98,.039,.30,'#84848e',.114)
    front(x,F-.066,(low+3.20)/2,b-a-.064,3.20-low,WHITE,GLASS)
    # Small diagonal reflection strips, well away from the central view.
    strip=b-.16
    poly([(strip-.30,F-.069,2.76),(strip-.24,F-.069,2.76),(strip+.07,F-.069,3.14),(strip+.01,F-.069,3.14)],WHITE,GLINT,shade=False)
mullion_front(R-.12,2.12,.080,2.23)
mullion_front(CX,3.18,W-.25,.104)
mullion_front(-.851,3.089,1.83,.174,'#757279',.135)
mullion_front(-.851,3.036,.184,.083,'#2b293d',.162)
mullion_front(-.851,1.037,1.82,.022,'#a0938a',.24)
# Matching corner glazing on the east side.
for a,b in [(-2.39,-1.14),(-1.14,.17),(.17,1.52),(1.52,2.91)]:
    y=(a+b)/2
    mullion_side(a,2.13,.072,2.21)
    mullion_side(y,1.315,b-a,.083)
    box(R-.015,y,1.148,.112,b-a,.230,'#747783')
    mullion_side(y,1.674,b-a,.028,'#566479')
    right(R+.058,y,2.252,b-a-.055,1.882,WHITE,GLASS)
    d=b-.14
    poly([(R+.061,d-.29,2.75),(R+.061,d-.23,2.75),(R+.061,d+.05,3.13),(R+.061,d-.018,3.13)],WHITE,GLINT,shade=False)
mullion_side(2.9,2.11,.078,2.24)
mullion_side(.254,3.18,5.36,.107)
for x,y in [(L,F),(R,F),(R,B),(L,B)]:
    box(x,y,2.31,.23,.23,2.88,'#555369')
# Solid roof with a banded anime-style silhouette.
box(CX,CY,3.40,W+.12,D+.11,.55,'#b5adb2',side='#777384')
box(CX,CY,3.625,W+.40,D+.36,.19,'#858297',side='#64647e')
box(CX,CY,3.73,W+.51,D+.45,.087,'#666581',side='#454863')
box(CX,CY,3.806,W+.38,D+.31,.069,'#827c98',side='#6b6684')
box(CX,CY,3.844,W-.08,D-.14,.018,'#6f6d86')
for x in (L-.145,R+.145):
    box(x,CY,3.902,.109,D+.30,.133,'#9690a5')
for y in (F-.138,B+.138):
    box(CX,y,3.902,W+.31,.106,.133,'#9b91a2')
for i in range(8):
    box(L+.57+i*.88,CY,3.858,.024,D-.26,.017,'#7f7c94')
for y in (F+.35, B-.36):
    box(CX,y,3.861,W-.48,.021,.020,'#9288a0')

GROUP='03 · Original shop identity and canopy'
def emblem(d,x,y,s,color):
    d.ellipse((x-s,y-s,x+s,y+s),fill=color)
    d.ellipse((x-s*.35,y-s*1.26,x+s*1.09,y+s*.18),fill='#fff0d1')
    d.polygon([(x+s*.72,y-s*.87),(x+s*.79,y-s*.64),(x+s*1.02,y-s*.60),(x+s*.80,y-s*.48),(x+s*.76,y-s*.24),
               (x+s*.65,y-s*.48),(x+s*.41,y-s*.53),(x+s*.65,y-s*.65)],fill=color)

def sign_paint(d,im):
    d.rounded_rectangle((12,12,1587,371),radius=32,fill='#fff0d1',outline='#9f5857',width=8)
    emblem(d,208,191,92,'#465a74')
    label(d,(358,151),'よるまち',179,'#222c43','ja','lm')
    label(d,(375,294),'YORUMACHI MART',59,'#394e64','en','lm')
    d.line((1172,54,1172,330),fill='#aa726e',width=8)
    label(d,(1377,144),'24',151,'#913f49','en','mm')
    label(d,(1377,285),'HOURS',49,'#354e5b','en','mm')

SIGN=picture('Fascia · Yorumachi Mart',(1600,384),'#b37478',sign_paint)
for x in (-2.19,.96):
    box(x,F-.99,3.33,.14,.31,.19,INK)
box(-.61,F-1.075,3.67,4.84,.18,.77,INK)
box(-.61,F-1.172,3.67,4.73,.046,.705,'#f9dabe')
front(-.61,F-1.199,3.67,4.66,.663,WHITE,SIGN)
# Stripe band wraps the glass frontage and the side elevation.
for x,w in [(L+.88,1.49),(R-.40,.45)]:
    box(x,F-.118,3.473,w,.061,.213,'#ccc2b6')
    box(x,F-.155,3.517,w,.017,.055,MINT)
    box(x,F-.155,3.447,w,.017,.048,ROSE)
for z,ht,col in [(3.515,.115,'#c4bbb5'),(3.534,.043,MINT),(3.462,.036,ROSE)]:
    box(R+.102,CY, z,.038,D-.16,ht,col)
# Canopy floats over the shop paving, with warm downlights.
box(CX,F-.551,3.193,W+.06,1.13,.129,'#686a82',side='#55546e')
box(CX,F-.563,3.253,W+.12,1.18,.043,'#8f859d',side='#7d738d')
box(CX,F-1.141,3.194,W+.12,.045,.109,'#444963')
box(CX,F-1.166,3.209,W+.03,.015,.034,'#ed9b8d')
for i in range(7):
    x=L+.50+i*1.02
    rod(x,F-.767,3.093,3.128,.104,'#363b55',16)
    rod(x,F-.767,3.081,3.101,.076,'#ffe6b9',16)
# Blade sign with a small moon logo next to the street.
def blade_paint(d,im):
    emblem(d,96,52,30,'#587a80')
    label(d,(96,113),'よるまち',32,'#2e3d58','ja','mm')
    label(d,(96,152),'M A R T',16,'#78525f','en','mm')
BLADE=picture('Blade sign · moon mark',(192,172),'#fff1d8',blade_paint)
box(R+.29,F+.36,3.19,.65,.073,.055,'#33364e')
box(R+.59,F+.36,3.16,.44,.135,.47,'#45425a')
front(R+.59,F+.286,3.16,.406,.434,WHITE,BLADE)
poly([(R+.79,F+.431,2.943),(R+.388,F+.431,2.943),(R+.388,F+.431,3.377),(R+.79,F+.431,3.377)],
     WHITE,BLADE,[(0,1),(1,1),(1,0),(0,0)],False)

# ── The illuminated interior: shelves, ready meals and refrigerated stock ──
GROUP='04 · Interior | shelves and packaged goods'
SHELF='#ddd1b7'
EDGE='#816e72'
PALETTE=['#e58b71','#92b7a0','#84aeb2','#d2a97c','#e7c485','#c3abc4','#e4d5aa','#a1a9cb','#dfabb1']
BOTTLES=['#669779','#cba05a','#b46f60','#7c9cae','#d8c9a4','#b496b5']

def pack(x,y,z,w,d,h,body,code,is_side=False):
    if code==0:
        rod(x,y,z,z+h*.74,w*.43,body,7)
        rod(x,y,z+h*.72,z+h*.91,w*.41,body,7,w*.22)
        rod(x,y,z+h*.88,z+h,w*.23,'#e5dcc1',7)
        return
    box(x,y,z+h*.5,w,d,h,body)
    accent=RNG.choice(['#fbebc3','#f6dfb1','#c87369','#8fa99f','#8d95ad'])
    if is_side:
        box(x+w*.501,y,z+h*.58,.007,d*.75,h*.21,accent)
        box(x+w*.504,y,z+h*.34,.008,d*.38,.015,'#76606f')
    else:
        box(x,y-d*.501,z+h*.59,w*.78,.007,h*.20,accent)
        box(x,y-d*.504,z+h*.35,w*.38,.008,.014,'#78646a')

def gondola(x,y,length,levels,typical,accent,frontward=True):
    d=.53 if frontward else length
    w=length if frontward else .53
    for height in (1.047,1.106):
        box(x,y,height,w+.10,d+.12,.095,EDGE)
    box(x,y,1.10+levels*.205,w if frontward else .076,.076 if frontward else d,levels*.42,'#b8a695')
    for dx,dy in (((-w/2,0),(w/2,0)) if frontward else ((0,-d/2),(0,d/2))):
        box(x+dx,y+dy,1.10+levels*.201,.052 if frontward else d*.91,.40 if frontward else .055,levels*.406,EDGE)
    for lev in range(levels):
        h=1.176+lev*.332
        box(x,y,h,w,d,.058,SHELF)
        for orient in (-1,1):
            if frontward:
                box(x,y+orient*d*.508,h+.009,w,.022,.034,accent)
            else:
                box(x+orient*w*.508,y,h+.009,.022,d,.034,accent)
        count=int(length/.148)
        for i in range(count):
            offset=-length/2+(i+.50)*length/count
            c=PALETTE[(i//2+lev*2+typical)%len(PALETTE)]
            for side in (-1,1):
                if RNG.random()<.075:
                    continue
                pos=(x+offset,y+side*.159) if frontward else (x+side*.15,y+offset)
                ht=RNG.uniform(.128,.225)
                pack(*pos,h+.032,.110,.110,ht,c,(i+typical+lev)%5,not frontward)
    h=1.177+levels*.332
    box(x,y,h,w,.077 if frontward else d,.090,SHELF)

gondola(-2.82,.65,2.12,3,3,'#7da696')
gondola(-.14,.65,2.05,3,1,'#c77b73')
gondola(-1.75,2.07,2.45,3,6,'#799eaa')
gondola(1.28,1.53,1.91,3,4,'#ca9b76',False)
# Two low display units stay below the main window sightline.
gondola(-3.71,-1.93,1.08,2,6,'#aa7977')
gondola(1.53,-.66,.91,2,2,'#799c9b',False)

# A low bento island beside the entrance makes the foreground window readable.
dx,dy=.98,-1.94
box(dx,dy,1.163,1.16,.534,.303,'#af928b')
for h in (1.393,1.668):
    box(dx,dy,h,1.17,.49,.052,'#dfc9ae')
    box(dx,dy-.249,h+.009,1.18,.022,.042,'#c78079')
    for i in range(5):
        x=dx-.46+i*.231
        box(x,dy-.071,h+.050,.188,.153,.047,'#6c6376')
        box(x,dy-.071,h+.079,.171,.134,.027,'#e7c6a4')
        box(x-.032,dy-.093,h+.093,.076,.069,.011,['#cf8c75','#6d9b82','#d3ad62'][i%3],.03)
        box(x+.043,dy-.083,h+.099,.049,.085,.012,'#edddad',-.08)
        box(x,dy-.082,h+.111,.04,.154,.008,'#f6dfba')
for x in (dx-.58,dx+.58):
    box(x,dy+.003,1.499,.037,.482,.424,'#bba392')
box(dx,dy+.233,1.558,1.146,.030,.428,'#c2ad94')

GROUP='05 · Interior | chillers and service counter'
for idx,x in enumerate([-3.82,-2.52,-1.22,.08,1.40]):
    box(x,3.57,2.039,1.28,.59,2.03,'#a19f9c',side='#7e8191')
    box(x,3.290,2.026,1.13,.019,1.78,'#717d87')
    box(x,3.263,2.907,1.14,.056,.075,'#e9faf0')
    box(x,3.298,1.167,1.18,.071,.177,'#595b70')
    for j in range(8):
        box(x-.48+j*.136,3.255,1.168,.063,.013,.041,'#767788')
    for lev in range(5):
        h=1.29+lev*.315
        box(x,3.47,h,1.13,.384,.040,'#d5ddd1')
        box(x,3.266,h,1.12,.016,.029,'#dedccf')
        for j in range(8):
            pack(x-.493+j*.141,3.387,h+.020,.095,.102,RNG.uniform(.12,.224),
                 BOTTLES[(idx+lev+j//2)%len(BOTTLES)],lev%3)
    for dx in (-.616,0,.616):
        box(x+dx,3.252,2.04,.035,.049,1.80,'#a7afb1')
    for dx in (-.509,.509):
        box(x+dx,3.206,1.96,.025,.028,.173,'#d6d9cd')
    front(x,3.229,2.06,1.20,1.71,WHITE,DARK_GLASS)
# Counter, activity details, warm deli cabinet.
box(-2.91,-.96,1.453,2.48,.65,.89,'#987b79',side='#7f656e')
box(-2.91,-.96,1.926,2.55,.77,.085,'#dbc7a5')
box(-2.91,-1.305,1.417,2.26,.064,.57,'#b49c88')
for ix in range(18):
    box(-3.97+ix*.125,-1.343,1.414,.063,.019,.531,'#ceb191')
for x in (-3.74,-2.99):
    box(x,-1.02,2.01,.347,.266,.077,'#585064')
    box(x,-1.06,2.22,.302,.096,.239,'#5e596c')
    front(x,-1.111,2.227,.232,.152,'#a1ddd0')
    for i in range(3):
        box(x-.075+i*.059,-1.113,2.218,.031,.005,.049,'#649d9c')
    box(x+.19,-1.217,2.006,.102,.142,.069,'#474458')
box(-2.02,-1.004,2.107,.57,.464,.341,'#bc9a7d')
front(-2.02,-1.24,2.14,.49,.212,'#f4db91')
for i in range(4):
    for j in range(2):
        box(-2.195+i*.116,-1.153,2.10+j*.093,.065,.018,.049,
            RNG.choice(['#ae725c','#f5bc6f','#c78963']))
for x in (-4.13,1.95):
    box(x,-.49,1.306,.28,.40,.575,'#6d686e')
    box(x,-.49,1.613,.33,.44,.075,'#776f78')

def advert(d,im):
    d.rounded_rectangle((9,9,247,342),radius=16,fill='#f8deb2',outline='#d48272',width=5)
    label(d,(128,54),'ほっと',35,'#694b63','ja','mm')
    label(d,(128,98),'おでん',48,'#ab5e60','ja','mm')
    d.ellipse((54,162,204,263),fill='#e9ac79')
    d.ellipse((66,159,193,242),fill='#aa655f')
    for x,y,c in [(100,185,'#f1c879'),(142,187,'#e9ab7f'),(169,207,'#d99879'),(112,218,'#f4d9a0')]:
        d.rounded_rectangle((x-18,y-11,x+18,y+11),radius=8,fill=c)
    label(d,(128,296),'HOT & FRESH',22,'#714d60','en','mm')
AD=picture('Window poster · hot oden',(256,352),'#6e596e',advert)
front(-4.20,F-.075,2.27,.61,.836,WHITE,AD)
front(-1.01,-1.44,1.42,.282,.388,WHITE,AD)

GROUP='06 · Interior | ceiling lights and retail signs'
def signs_paint(d,im):
    d.rectangle((0,0,511,383),fill='#e9d4ac')
    for i,(ja,en,col) in enumerate([('お弁当','BENTO','#a75d62'),('お飲み物','DRINKS','#487f7e'),('お菓子','SNACKS','#706788')]):
        top_y=i*128
        d.rectangle((6,top_y+7,505,top_y+120),fill=col)
        label(d,(24,top_y+61),ja,49,'#fff1d1','ja','lm')
        label(d,(477,top_y+61),en,26,'#ffe5c0','en','rm')
SIGNSET=picture('Hanging aisle signs',(512,384),'#e9d4ac',signs_paint)
for i,(x,y) in enumerate([(-3.08,.69),(-.68,1.56),(1.18,1.94)]):
    box(x,y,2.809,1.17,.11,.254,'#74636d')
    for dx in [-.46,.46]:
        beam((x+dx,y,2.92),(x+dx,y,3.169),.012,'#817580',6)
    ya=i/3
    yb=(i+1)/3
    poly([(x-.56,y-.056,2.693),(x+.56,y-.056,2.693),(x+.56,y-.056,2.926),(x-.56,y-.056,2.926)],
         WHITE,SIGNSET,[(0,yb),(1,yb),(1,ya),(0,ya)],False)
for x in (-3.67,-1.19,1.24):
    for y in (-1.02,.95,2.83):
        box(x,y,3.154,1.66,.216,.073,'#a48d80')
        box(x,y,3.11,1.54,.169,.024,'#fff1c3')

# ── Curbside equipment, street furniture and a parked bicycle ───────────
GROUP='07 · Shopfront props'
# Doormat and entry decals.
box(-.862,-2.811,.904,1.436,.449,.049,'#3b3b56')
for i in range(5):
    box(-.862,-2.979+i*.083,.933,1.33,.018,.010,'#57556a')
for x in (-1.20,-.50):
    front(x,F-.078,1.94,.219,.075,'#e9e4cf')
    front(x,F-.081,1.94,.088,.021,'#6ca493')
# Waste station, sorting labels and dark openings.
for x,col in [(1.53,'#757990'),(1.943,'#6e8490')]:
    box(x,-2.927,1.172,.365,.332,.566,col)
    box(x,-2.928,1.462,.382,.352,.073,'#a5a0ad')
    box(x,-3.106,1.376,.238,.023,.079,'#393e56')
    box(x,-3.121,1.187,.121,.006,.075,'#b5bdc1')
    box(x,-3.125,1.186,.032,.008,.041,'#7f8ba1')
shadow('Pavement contacts',1.72,-2.94,.885,.98,.59,'#38394e')
# Empty umbrella stand, plus two folded umbrellas stored at the entrance.
for x in (-2.14,-2.52):
    for y in (-2.76,-3.02):
        rod(x,y,.889,1.424,.017,'#565869',8)
for z in (.926,1.374,1.423):
    for x in (-2.14,-2.52):
        beam((x,-2.76,z),(x,-3.02,z),.018,'#a2a0ac')
    for y in (-2.76,-3.02):
        beam((-2.14,y,z),(-2.52,y,z),.018,'#b2abb3')
box(-2.33,-2.89,.942,.37,.23,.04,'#524e65')
for x,y,c in [(-2.29,-2.92,'#c57a79'),(-2.43,-2.84,'#778ba5')]:
    rod(x,y,.949,1.385,.020,c,8,.050)
    rod(x,y,1.385,1.571,.015,'#c2b8ad',8)
    wire([(x+.041*cos(a),y,1.558+.041*sin(a)) for a in (pi-pi*i/12 for i in range(13))],.014,'#654d61',6)

def notices(d,im):
    label(d,(128,33),'町内のお知らせ',23,'#fcf0d3','ja','mm')
    for l,t,r,b,col in [(22,60,126,169,'#f7d3a5'),(137,65,225,153,'#cde0be'),
                         (29,179,97,254,'#dfc0c7'),(107,166,230,259,'#f2e2be')]:
        d.rectangle((l,t,r,b),fill=col,outline='#7d6e74',width=2)
        d.rectangle((l+8,t+11,r-8,t+25),fill='#a66370')
        for j in range(4):
            d.line((l+9,t+34+j*8,r-12-(j%2)*8,t+34+j*8),fill='#96858a',width=2)
        d.ellipse(((l+r)//2-3,t+3,(l+r)//2+3,t+9),fill='#6a526a')
NOTICE=picture('Noticeboard · neighborhood flyers',(256,285),'#7b686e',notices)
box(-5.18,-2.34,1.97,.66,.099,.782,'#4a4b61')
box(-5.18,-2.34,2.396,.726,.175,.084,'#7c7387')
for x in (-5.47,-4.90):
    box(x,-2.337,1.387,.044,.061,1.0,'#5a5266')
front(-5.18,-2.392,1.967,.592,.714,WHITE,NOTICE)

GROUP='08 · Vending machine and east alley'
def vending(d,im):
    d.rounded_rectangle((5,5,441,759),radius=28,fill='#d98283',outline='#f2b0a1',width=5)
    d.rounded_rectangle((32,38,415,145),radius=22,fill='#ffefca')
    label(d,(224,76),'小さな飲料店',43,'#875264','ja','mm')
    label(d,(224,121),'M I L K   &   S O D A',19,'#588682','en','mm')
    d.rounded_rectangle((31,176,416,496),radius=15,fill='#484965',outline='#ffdebd',width=6)
    for row in range(3):
        y=183+row*102
        d.rounded_rectangle((43,y+6,404,y+79),radius=7,fill='#d8dfcf')
        for i in range(7):
            x=52+i*50
            p=['#90799e','#c77b77','#8caf97','#d6ad76','#86adb6','#e1c493','#b9a9c1'][(i+2*row)%7]
            d.rounded_rectangle((x+7,y+21,x+34,y+65),radius=7,fill=p,outline='#776778',width=2)
            d.rectangle((x+11,y+34,x+30,y+43),fill='#f6edcb')
            d.rounded_rectangle((x+13,y+80,x+28,y+87),radius=3,fill='#a4d3ba')
    d.rounded_rectangle((34,603,313,692),radius=11,fill='#915c71')
    d.rounded_rectangle((43,614,303,680),radius=10,fill='#424761')
    d.rounded_rectangle((329,518,410,667),radius=10,fill='#696383')
    d.rectangle((341,529,396,562),fill='#bfe1ca')
    d.rectangle((344,590,391,601),fill='#38394e')
    for i in range(3):
        d.ellipse((365,619+10*i,373,627+10*i),fill='#f6bd97')
VEND=picture('Vending machine · milk and soda',(448,768),'#b97380',vending)
vx,vy=3.03,2.935
shadow('Pavement contacts',vx,vy,.886,.93,1.23)
box(vx,vy,1.63,.558,.845,1.44,'#ca7980',side='#ae6479')
box(vx,vy,2.366,.569,.862,.095,'#e5a19e')
box(vx,vy,1.030,.60,.820,.196,'#786682')
right(vx+.284,vy,1.655,.811,1.381,WHITE,VEND)
for i in range(8):
    box(vx+.13-i*.036,vy+.43,1.23,.017,.011,.096,'#9d697d')
rod(vx-.08,vy-.43,.885,1.468,.035,'#7e899b',10)
box(vx-.08,vy-.43,1.446,.083,.071,.111,'#b88a78')
# Outdoor unit and condenser behind the glass wall.
for x,y,h in [(2.56,3.65,1.47),(L-.29,2.98,1.55)]:
    box(x,y,h,.419,.662,.445,'#a7a3ad')
    box(x+.216,y,h,.021,.544,.37,'#b7b0b7')
    beam((x+.23,y,h),(x+.25,y,h),.144,'#625e75',20)
    beam((x+.253,y,h),(x+.259,y,h),.124,'#878598',20)
    for i in range(7):
        box(x+.265,y,h-.093+i*.031,.014,.198,.009,'#b1a7b3')
wire([(2.47,3.779,1.91),(2.50,3.779,1.68),(2.62,3.779,1.68)],.026,'#777b91',8)
# Back service door, light, stair and delivery crates mark the alley entrance.
box(.45,B+.073,2.121,.95,.065,2.265,'#746b7c')
box(.45,B+.113,2.088,.799,.043,2.136,'#656b86')
box(.705,B+.156,2.073,.118,.04,.040,'#c3b8b0')
box(.447,B+.346,.928,1.18,.624,.093,'#8a879a')
box(.452,B+.09,3.307,.449,.205,.137,'#52566d')
box(.452,B+.14,3.225,.328,.166,.035,'#f9cfab')
for x,y,ht in [(1.84,4.37,.27),(2.00,4.62,.27),(1.97,4.62,.535)]:
    box(x,y,.876+ht,.508,.442,.247,'#779e95')
    for i in range(5):
        box(x-.176+i*.087,y-.227,.877+ht,.033,.012,.138,'#4f7480')
for x in (-1.73,-1.17):
    box(x,B+.488,1.204,.47,.54,.634,'#6a7f89')
    box(x,B+.488,1.512,.50,.558,.105,'#9fa5a6')

GROUP='09 · Roadside bicycle'
# Hand-built city bike: spoked wheels, diamond frame, kickstand, rack and basket.
bx,by,bh=3.11,-.89,1.197
shadow('Pavement contacts',bx,by,.886,1.96,.64)
for x in (bx-.537,bx+.537):
    torus_wheel(x,by,bh,.288,.028,'#33384f')
    torus_wheel(x,by,bh,.258,.014,'#c4bac0')
    beam((x,by-.048,bh),(x,by+.048,bh),.047,'#a7a8b6',10)
    for i in range(12):
        a=2*pi*i/12
        beam((x,by+(.015 if i%2 else -.015),bh),
             (x+.245*cos(a),by,bh+.245*sin(a)),.006,'#aeb1ba',5,capped=False)
    wire([(x+.319*cos(i*pi/16),by,bh+.319*sin(i*pi/16)) for i in range(17)],.017,'#667c8d',6)
bike_col='#91a9a5'
seat=(bx-.249,by,1.632)
crank=(bx-.095,by,1.225)
stem=(bx+.389,by,1.680)
back=(bx-.537,by,bh)
fwd=(bx+.537,by,bh)
for a,b,r in [(seat,crank,.032),(crank,stem,.038),(seat,stem,.023),(crank,back,.025),(seat,back,.023),(stem,fwd,.026)]:
    beam(a,b,r,bike_col)
beam(seat,(bx-.28,by,1.754),.018,'#9ea0ae')
box(bx-.30,by,1.768,.218,.123,.041,'#524b60',-.08)
beam(stem,(bx+.356,by,1.877),.022,'#b2b0ba')
wire([(bx+.303,by-.173,1.856),(bx+.320,by-.096,1.881),(bx+.356,by,1.877),
      (bx+.320,by+.096,1.881),(bx+.303,by+.173,1.856)],.017,'#abb1b8',8)
for dy in (-.15,.15):
    beam((bx+.308,by+dy*.72,1.875),(bx+.300,by+dy*1.25,1.854),.025,'#5f576a')
beam((crank[0],by-.042,crank[2]),(crank[0],by+.045,crank[2]),.090,'#778092',16)
beam(crank,(bx+.006,by-.16,1.142),.017,'#b2afb6')
box(bx+.047,by-.179,1.138,.105,.078,.022,'#524d60')
beam((bx-.31,by,1.246),(bx-.442,by-.273,.888),.012,'#6c6579')
for y in (by-.104,by+.104):
    beam((bx-.72,y,1.537),(bx-.34,y,1.537),.015,'#b0aeb8')
    beam((bx-.537,y,1.203),(bx-.56,y,1.534),.013,'#9296a4')
box(bx-.72,by,1.516,.041,.11,.031,'#e18c8c')
box(bx+.55,by,1.691,.264,.290,.019,'#776b7f')
for z in (1.70,1.771,1.843):
    for x in (bx+.419,bx+.681):
        beam((x,by-.145,z),(x,by+.145,z),.010,'#9e8d98',6)
    for y in (by-.145,by+.145):
        beam((bx+.419,y,z),(bx+.681,y,z),.010,'#ad99a1',6)
for dx in (-.131,-.067,0,.067,.131):
    for dy in (-.145,.145):
        rod(bx+.55+dx,by+dy,1.688,1.846,.008,'#a898a1',6)

GROUP='10 · Corner railing, street light and utility pole'
# Powder-coated railing, yellow reflector panels and curb bollards.
for x,y in [(3.43,-3.83),(3.78,-3.53),(3.93,-3.14)]:
    rod(x,y,.887,.1+.887,.092,'#6d687e',12)
    rod(x,y,.953,1.516,.033,'#9a9ead')
    rod(x,y,1.499,1.527,.035,'#d0bcae')
wire([(3.43,-3.83,1.45),(3.78,-3.53,1.45),(3.93,-3.14,1.45)],.029,'#adb5bd',8)
wire([(3.43,-3.83,1.206),(3.78,-3.53,1.206),(3.93,-3.14,1.206)],.023,'#939bac',8)
for x,y in [(4.03,-2.73),(4.05,1.70),(4.05,2.16)]:
    rod(x,y,.882,1.303,.045,'#555d77',10)
    rod(x,y,1.241,1.284,.047,'#e6b88c',10)
    rod(x,y,1.285,1.322,.050,'#8992a7',10)

# Compact pool of warm illumination around the lamp on the dry ground.
def lamp_pool(d,im):
    yy,xx=np.mgrid[-1:1:128j,-1:1:128j]
    a=np.clip(1-(xx**2+yy**2),0,1)**2
    pixels=np.zeros((128,128,4),dtype=np.uint8)
    pixels[:,:,:3]=(228,169,138)
    pixels[:,:,3]=(a*65).astype('uint8')
    im.paste(Image.fromarray(pixels,'RGBA'))
POOL=picture('Diffuse streetlamp light on dry asphalt',(128,128),(0,0,0,0),lamp_pool,'BLEND')
top(5.34,-3.04,.706,2.76,3.09,WHITE,POOL)
lx,ly=3.82,-2.62
shadow('Pavement contacts',lx,ly,.886,.70,.57)
rod(lx,ly,.885,1.013,.119,'#565c76',12)
rod(lx,ly,.952,1.206,.082,'#5e637b',12)
rod(lx,ly,1.169,4.185,.046,'#77818f',12,.041)
wire([(lx,ly,4.154),(lx,ly,4.296),(lx+.089,ly,4.412),(lx+.256,ly,4.477),(lx+.591,ly,4.468)],.046,'#87919e',10)
box(lx+.692,ly,4.446,.507,.217,.090,'#757689')
box(lx+.734,ly,4.394,.314,.163,.028,'#ffdead')
box(lx+.747,ly,4.375,.229,.123,.016,'#fff4c7')

def traffic_paint(d,im):
    d.ellipse((9,9,183,183),fill='#e8ddd3',outline='#535875',width=3)
    d.ellipse((19,19,173,173),fill='#c7757c')
    d.rounded_rectangle((45,80,147,112),radius=4,fill='#f8e5cc')
TRAFFIC=picture('Road sign · no entry',(192,192),(0,0,0,0),traffic_paint,'BLEND')
rod(3.43,-3.48,.884,2.329,.027,'#8c94a5',8)
# A thin round, physical sign behind the printed face.
beam((3.43,-3.479,2.126),(3.43,-3.501,2.126),.216,'#696d84',28)
front(3.43,-3.504,2.126,.451,.451,WHITE,TRAFFIC)
box(3.43,-3.495,1.817,.404,.032,.114,'#e8d9cd')
front(3.43,-3.516,1.816,.294,.022,'#786a7e')

def alley_sign(d,im):
    d.rounded_rectangle((4,4,380,119),radius=13,outline='#e4d7be',width=4)
    label(d,(191,54),'月見通り',48,'#f0e7d4','ja','mm')
    label(d,(191,99),'T S U K I M I   S T .',13,'#e7d9c3','en','mm')
ALLEY=picture('Street plate · Tsukimi Street',(384,124),'#5e8091',alley_sign)
box(2.516,3.539,2.544,.041,.739,.244,'#566d84')
right(2.538,3.539,2.544,.716,.231,WHITE,ALLEY)

GROUP='11 · Utility wires, service roofs and street details'
ux,uy=-5.70,-3.10
vx,vy=-5.69,5.39
for x,y,h in [(ux,uy,5.50),(vx,vy,5.24)]:
    shadow('Pavement contacts',x,y,.885,.60,.55)
    rod(x,y,.886,1.382,.145,'#716e83',12,.130)
    rod(x,y,1.319,h,.104,'#87777f',12,.061)
    rod(x,y,h-.079,h+.045,.077,'#646579',12)
    for i in range(6):
        box(x,y-.094,1.039+i*.045,.198,.013,.023,'#c89b7a')
    box(x,y,h-.291,1.008,.094,.083,'#6d6278')
    box(x,y,h-.524,.761,.081,.067,'#746b80')
    for o in (-.419,-.24,.25,.41):
        rod(x+o,y,h-.294,h-.144,.038,'#555773',10)
        rod(x+o,y,h-.205,h-.185,.057,'#a3a2b1',10)
for i,o in enumerate((-.419,-.24,.25,.41)):
    points=[(ux+o+(vx-ux)*j/24,uy+(vy-uy)*j/24,5.356+(5.096-5.356)*j/24-(.47+i*.026)*sin(pi*j/24))
            for j in range(25)]
    wire(points,.013,'#48455c',6)
# Cable spur ends at the building attachment.
wire([(ux+.255+(L-ux-.247)*j/12,uy+(F+.36-uy)*j/12,5.005+(3.733-5.005)*j/12-.105*sin(pi*j/12))
      for j in range(13)],.014,'#4c4661',6)
rod(ux,uy,3.84,4.445,.151,'#7b7186',16)
rod(ux,uy,4.447,4.518,.178,'#938696',16)
# Roof machinery: ducts, raised service hatch, vents, skids and conduit.
for x,y,wide,d in [(-3.55,2.44,1.48,.93),(-1.54,2.62,.88,.685)]:
    for dx in (-wide*.32,wide*.32):
        box(x+dx,y,3.906,.10,d+.14,.123,'#50546e')
    box(x,y,4.214,wide,d,.572,'#958b9c',side='#787b92')
    box(x,y,4.514,wide+.047,d+.057,.055,'#b2a1aa')
    for dx in ([-wide*.244,wide*.244] if wide>1 else [0]):
        rod(x+dx,y,4.537,4.548,d*.348,'#544f67',20)
        rod(x+dx,y,4.550,4.559,d*.28,'#767488',20)
        rod(x+dx,y,4.559,4.571,.066,'#b5abb4',12)
        for i in range(7):
            a=i*2*pi/7
            box(x+dx+.116*cos(a),y+.116*sin(a),4.561,.173,.039,.019,'#9990a4',a+.31)
    for i in range(11):
        box(x-wide*.422+i*wide*.0844,y-d*.5-.014,4.224,.028,.022,.353,'#a298a7')
wire([(-3.37,2.91,4.07),(-3.37,3.24,3.98),(-1.77,3.24,3.98),(-1.77,2.97,4.06)],.046,'#8c8097',8)
box(.86,2.74,3.949,.87,.72,.177,'#78748c')
box(.86,2.74,4.062,.939,.786,.059,'#a195a9')
box(1.10,2.74,4.10,.193,.031,.031,'#615b72')
for x,y in [(-3.51,-1.03),(1.64,-.31)]:
    rod(x,y,3.851,4.009,.168,'#777589',12)
    rod(x,y,4.008,4.09,.234,'#a296a3',12,.204)
    rod(x,y,4.084,4.101,.182,'#b0a2aa',12)
# Low alley wall, a service grate and a pair of small planters on the far pavement.
box(-5.93,4.15,1.16,1.37,.18,.57,'#777389')
box(-5.93,4.15,1.461,1.40,.226,.059,'#9b8d9a')
for i in range(6):
    box(-6.51+i*.232,4.148,1.477,.013,.207,.01,'#6e657c')
for x,y in [(-5.28,-1.48),(1.35,4.94)]:
    shadow('Pavement contacts',x,y,.884,.82,.72)
    rod(x,y,.881,1.181,.207,'#7a6277',10,.274)
    rod(x,y,1.178,1.242,.278,'#ae8289',10)
    rod(x,y,1.242,1.246,.234,'#555269',10)
    for i in range(13):
        a=i*2.399
        root=(x+RNG.uniform(-.098,.098),y+RNG.uniform(-.079,.079),1.245)
        end=(x+cos(a)*RNG.uniform(.09,.28),y+sin(a)*RNG.uniform(.085,.27),1.25+RNG.uniform(.16,.48))
        mid=muladd(root,vect(root,end),.63)
        beam(root,mid,.016,'#526b73',6)
        beam(mid,end,.058,RNG.choice(['#8da59a','#77928e','#668987','#a0afa1']),5,.009)

# ── Export a self-contained, static binary glTF ──────────────────────────
document = {
    'asset': {'version':'2.0','generator':'Yorumachi Mart | authored miniature'},
    'extensionsUsed':['KHR_materials_unlit'],
    'scene':0,'scenes':[{'name':'Yorumachi Mart · Japanese night street corner','nodes':[0]}],
    'nodes':[{'name':'Yorumachi Mart · 14 m square diorama','children':[]}],
    'meshes':[], 'materials':[], 'accessors':[], 'bufferViews':[],
    'buffers':[], 'images':[], 'textures':[],
    'samplers':[{'magFilter':9729,'minFilter':9987,'wrapS':33071,'wrapT':33071}],
}
binary = bytearray()

def append(collection, item):
    index = len(document[collection])
    document[collection].append(item)
    return index

def view(payload,target=None):
    binary.extend(bytes((-len(binary))%4))
    item = {'buffer':0,'byteOffset':len(binary),'byteLength':len(payload)}
    if target:
        item['target']=target
    binary.extend(payload)
    return append('bufferViews',item)

def accessor(values,code,kind,target,bounds=False):
    types={'<f4':5126,'<u2':5123,'<u4':5125}
    a = np.asarray(values,dtype=code)
    item = {'bufferView':view(a.tobytes(),target),'componentType':types[code],'count':len(a),'type':kind}
    if bounds:
        item.update(min=np.min(a,axis=0).tolist(),max=np.max(a,axis=0).tolist())
    return append('accessors',item)

mat_ids={}
for name,(factor,image,alpha,double) in materials.items():
    if not any(material==name for _,material in batches):
        continue
    item={'name':name,'pbrMetallicRoughness':{'baseColorFactor':factor,'metallicFactor':0,'roughnessFactor':1},
          'extensions':{'KHR_materials_unlit':{}},'alphaMode':alpha,'doubleSided':double}
    if image:
        data,mime=images[image]
        src=append('images',{'bufferView':view(data),'mimeType':mime,'name':name})
        tx=append('textures',{'source':src,'sampler':0})
        item['pbrMetallicRoughness']['baseColorTexture']={'index':tx}
    mat_ids[name]=append('materials',item)

by_group = defaultdict(list)
for (group,material),(positions,normals,colors,uvs) in batches.items():
    textured = bool(uvs)
    assert not textured or len(uvs)==len(positions), (group,material)
    rows = {}
    indices = []
    for i,row in enumerate(zip(positions,normals,colors)):
        if textured:
            row = (*row,uvs[i])
        if row not in rows:
            rows[row] = len(rows)
        indices.append(rows[row])
    positions,normals,colors,*uv = zip(*rows)
    attr={'POSITION':accessor(positions,'<f4','VEC3',34962,True),
          'NORMAL':accessor(normals,'<f4','VEC3',34962)}
    if material==SOLID:
        attr['COLOR_0']=accessor(colors,'<f4','VEC3',34962)
    if textured:
        attr['TEXCOORD_0']=accessor(uv[0],'<f4','VEC2',34962)
    primitive={'attributes':attr,'indices':accessor(indices,'<u2' if len(rows)<=65536 else '<u4','SCALAR',34963),
               'material':mat_ids[material],'mode':4}
    by_group[group].append(primitive)

for group,primitives in by_group.items():
    mesh=append('meshes',{'name':group,'primitives':primitives})
    node=append('nodes',{'name':group,'mesh':mesh})
    document['nodes'][0]['children'].append(node)
binary.extend(bytes((-len(binary))%4))
document['buffers'].append({'byteLength':len(binary)})
data=json.dumps(document,ensure_ascii=False,separators=(',',':')).encode('utf-8')
data+=b' '*((-len(data))%4)
with OUT.open('wb') as dst:
    dst.write(struct.pack('<4sII',b'glTF',2,12+8+len(data)+8+len(binary)))
    dst.write(struct.pack('<I4s',len(data),b'JSON'))
    dst.write(data)
    dst.write(struct.pack('<I4s',len(binary),b'BIN\0'))
    dst.write(binary)
print(OUT, OUT.stat().st_size, 'bytes', sum(len(ps)//3 for ps,_,_,_ in batches.values()), 'triangles')
