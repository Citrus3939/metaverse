"""Rebuild Fangcun's metric street kit. Requires NumPy and Pillow."""
from pathlib import Path

import json
import struct
import uuid

import numpy as np
from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parents[1] / 'public/street'
OUT.mkdir(exist_ok=True)
N = 512
i, j = np.meshgrid(np.arange(N), np.arange(N))
x, z = (i + .5) * 10 / N - 5, (j + .5) * 10 / N - 5
rng = np.random.default_rng(3939)
# Muted enamel-like colours with a bevel only one texel wide.
grain = rng.normal(0, 1.35, (N, N))
asphalt = np.uint8(np.array([59, 62, 79]) + grain[:, :, None])
row = j // 16
col = (i + (row % 2) * 16) // 32
tones = rng.choice([-3, -1, 0, 2, 3], (32, 16))[row, col % 16]
brick = np.uint8(np.array([177, 168, 160]) + (tones + grain * .4)[:, :, None])
bx = (i + (row % 2) * 16) % 32
bz = j % 16
brick[(bz == 0) | (bx == 0)] = [157, 151, 150]
brick[(bz == 1) & (bx > 1)] += 5
paint = [231, 223, 201]
entries = []


def export(slug, name, tags, image, width=10, depth=10, overlay=False):
    file = 'road-' + slug
    image.save(OUT / (file + '.png'), optimize=True)
    bg = Image.new('RGB', image.size, (56, 62, 76))
    bg.paste(image, mask=image.getchannel('A') if image.mode == 'RGBA' else None)
    bg.thumbnail((280, 280))
    bg.save(OUT / (file + '.webp'), quality=92)
    binary = bytearray()
    views = []

    def view(data):
        binary.extend(bytes(-len(binary) % 4))
        views.append(dict(buffer=0, byteOffset=len(binary), byteLength=len(data)))
        binary.extend(data)
        return len(views)-1

    w, d = width / 2, depth / 2
    pos = view(struct.pack('<12f', -w,0,-d, w,0,-d, -w,0,d, w,0,d))
    uv = view(struct.pack('<8f', 0,0, 1,0, 0,1, 1,1))
    idx = view(bytes([0,2,1, 1,2,3]))
    tex = view((OUT / (file+'.png')).read_bytes())
    binary.extend(bytes(-len(binary) % 4))
    material = dict(pbrMetallicRoughness=dict(baseColorTexture=dict(index=0),metallicFactor=0,roughnessFactor=1),
                    extensions={'KHR_materials_unlit':{}},alphaMode='MASK' if overlay else 'OPAQUE')
    doc = dict(asset=dict(version='2.0'), extensionsUsed=['KHR_materials_unlit'], scene=0, scenes=[dict(nodes=[0])],
               nodes=[dict(mesh=0,extras=dict(skipCollision=True,streetLayer=2 if overlay else 1))],
               meshes=[dict(primitives=[dict(attributes=dict(POSITION=0,TEXCOORD_0=1),indices=2,material=0)])],
               materials=[material],textures=[dict(source=0)],images=[dict(bufferView=tex,mimeType='image/png')],
               buffers=[dict(byteLength=len(binary))], bufferViews=views,
               accessors=[dict(bufferView=pos,componentType=5126,count=4,type='VEC3',min=[-w,0,-d],max=[w,0,d]),
                          dict(bufferView=uv,componentType=5126,count=4,type='VEC2'),
                          dict(bufferView=idx,componentType=5121,count=6,type='SCALAR')])
    header=json.dumps(doc,separators=(',',':')).encode()
    header+=b' '*(-len(header)%4)
    (OUT/(file+'.glb')).write_bytes(struct.pack('<4sIII4s',b'glTF',2,28+len(header)+len(binary),len(header),b'JSON')+header+struct.pack('<I4s',len(binary),b'BIN\0')+binary)
    entries.append(dict(name=name, tags=tags, file=file, assetId=str(uuid.uuid5(uuid.NAMESPACE_URL,'fangcun/streets/v2/'+slug))))


for slug, name in [('straight','直路'),('end','道路尽头'),('bend','直角弯道'),('tee','丁字路口'),('cross','十字路口')]:
    # Reference orientations: NS, N, NE, NEW, NESW. Every port is 6 m wide.
    if slug == 'straight':
        dist = abs(x)
        dash = (abs(x)<.085) & (abs(z)%5<1.35)
    elif slug == 'end':
        dist = np.hypot(x,np.maximum(z,0))
        dash = (abs(x)<.085) & (z < -3)
    elif slug == 'bend':
        dist = abs(np.hypot(x-5,z+5)-5)
        angle = np.arctan2(z+5,5-x)
        dash = (dist<.085) & (np.cos(angle*8)>0)
    else:
        dist = np.minimum(abs(z), np.where(z<=0,abs(x),10) if slug=='tee' else abs(x))
        # Round the inner sidewalk corners near junctions.
        radius = 1.05
        corner = 3 + radius
        arc = corner - np.hypot(np.minimum(abs(x)-corner,0), np.minimum(abs(z)-corner,0))
        dist = np.where(z<=0, arc, abs(z)) if slug=='tee' else arc
        dash=((abs(x)<.085)&((z < -4) | ((slug=='cross')&(z>4)))) | ((abs(z)<.085)&(abs(x)>4))
    # Identical marking phase on the approach to every open port.
    edge = np.maximum(abs(x),abs(z))
    dash = np.where(edge>4.15, (dist<.085) & (edge>4.45), dash)
    im=brick.copy()
    # Narrow precast curb and inset gutter share the same rounded contour.
    im[dist<3.26]=[147,144,147]
    im[dist<3.23]=[194,187,178]
    im[(dist>3.04)&(dist<3.08)]=[213,204,188]
    im[dist<3.04]=[128,128,139]
    im[dist<3]=asphalt[dist<3]
    gutter=(dist<3)&(dist>2.85)
    im[gutter]=[83,85,98]
    joints=(np.floor((x+5)*2)!=np.floor((x+5+10/N)*2)) | (np.floor((z+5)*2)!=np.floor((z+5+10/N)*2))
    im[gutter & joints]=[69,72,85]
    im[(dist>2.79)&(dist<2.86)]=paint
    im[dash]=paint
    export(slug,name,['公路','双向两车道','10 米拼接'],Image.fromarray(im))

export('asphalt','干燥柏油',['车道','连续铺装'],Image.fromarray(asphalt))
export('pavers','人行道砖',['步道','连续铺装'],Image.fromarray(brick))
for slug,name,width,depth in [('crosswalk','斑马线',6,2.4),('stop','停止线',2.8,.25),('parking','停车线',2.5,5),('drain','排水口',.65,.32),('manhole','井盖',.7,.7)]:
    im=Image.new('RGBA',(max(16,round(width*85)),max(16,round(depth*85))))
    draw=ImageDraw.Draw(im); w,h=im.size
    if slug=='crosswalk':
        for n in range(8):
            draw.rectangle((int((n+.18)*w/8),0,int((n+.73)*w/8),h-1),fill=tuple(paint))
    elif slug=='stop': draw.rectangle((0,0,w,h),fill=tuple(paint))
    elif slug=='parking': draw.line([(0,0),(0,h-3),(w-3,h-3),(w-3,0)],fill=tuple(paint),width=7)
    elif slug=='drain':
        draw.rectangle((0,0,w,h),fill='#767b80',outline='#353c43',width=2)
        for n in range(4,w-3,5): draw.line((n,4,n,h-4),fill='#343b42',width=2)
    else:
        draw.ellipse((1,1,w-2,h-2),fill='#59616b',outline='#373e47',width=3)
        for r in (.18,.31,.41):
            draw.ellipse(((.5-r)*w,(.5-r)*h,(.5+r)*w,(.5+r)*h),outline='#85868a',width=2)
    if slug=='manhole':
        # Five cast petals on a dark iron lid, readable at street scale.
        for angle in np.arange(5)*2*np.pi/5:
            cx,cy=w*(.5+.12*np.sin(angle)),h*(.5+.12*np.cos(angle))
            draw.ellipse((cx-3,cy-3,cx+3,cy+3),fill='#a5a0a0')
    if slug=='drain':
        for px in (2,w-3):
            for py in (2,h-3): draw.point((px,py), fill='#c1b9ac')
    export(slug,name,['路面贴花','街道细节'],im,width,depth,True)
(Path(__file__).resolve().parents[1]/'src/street-assets.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n')

# Ship the same resources the editor loads, including directly usable PNGs.
from zipfile import ZipFile, ZIP_DEFLATED

downloads = OUT.parent / 'downloads'
downloads.mkdir(exist_ok=True)
with ZipFile(downloads / 'fangcun-streets-v2.zip', 'w', ZIP_DEFLATED) as archive:
    for entry in entries:
        for ext in ['png','glb','webp']:
            file = OUT / (entry['file'] + '.' + ext)
            archive.write(file, file.name)
    archive.writestr('catalog.json', json.dumps(entries, ensure_ascii=False, indent=2))
    archive.writestr('使用说明.txt', '日式社区街道 v2\n长度单位为米，GLB 采用 Y 向上。路形均为 10 × 10 米，车行面总宽 6 米。\n默认接口：直路南北、尽头向北、弯道东北、丁字东西北、十字四向。可绕 Y 轴旋转 90° 的整数倍拼接。\nPNG 上方为北。斑马线、停止线、停车线、排水口和井盖带透明通道。\n')
