@echo off
setlocal
cd /d "%~dp0"
if not exist package.json goto missing_project
where node.exe >nul 2>&1
if errorlevel 1 goto missing_node
where npm.cmd >nul 2>&1
if errorlevel 1 goto missing_node

echo Starting Fangcun from "%CD%"
node.exe -p "'Fangcun ' + require('./package.json').version"
call npm.cmd ci --no-audit --no-fund
if errorlevel 1 goto failed
call npm.cmd run dev -- --port 5187 --open
if errorlevel 1 goto failed
exit /b 0

:missing_project
echo Please extract the whole ZIP, then double-click start-fangcun.cmd in the project folder.
goto failed

:missing_node
echo Install Node.js 24 LTS from https://nodejs.org/ and run this file again.
goto failed

:failed
echo Fangcun could not start. See the message above.
pause
exit /b 1
