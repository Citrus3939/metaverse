import { database as landDatabase } from './estate-store.ts'
import { PLOT_SIZE } from '../src/plot-grid.ts'
import { existsSync, mkdirSync, readFileSync, writeFileSync, createReadStream } from 'node:fs'
import { join } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { cellKey, neighborsOf, parseCell, plotForCell, type Plot } from '../src/plot-grid.ts'
import type { MemberRole, Presence, PresenceUpdate, RegionTile, RegionView, Role } from '../src/collab-types.ts'
import { base, body, bytes, HttpError, json, key, readableName, roomId, tokenOf, tokenPattern, uuid } from './collab-http.ts'
import { existingPlots, indexPlot, readRegion, transaction, writeRegion, type Region, type RegionMember } from './estate-store.ts'
import { command, editable, estateView, identity, landCost, landQuote, migrateMemberIdentity, mapContext, register, releasePlotOnMove, revision, settleBeforeLandChange } from './economy.ts'
import type { EstateCommand } from '../src/estate.ts'
import { isSkinPng, skinFileLimit } from '../src/skin-format.ts'

type Grant = 'view' | 'edit'
const presence = new Map<string, Map<string, { value: Presence; time: number }>>()
const directory = (id: string) => join(base, 'regions', id)
const avatarPath = (id: string, asset: string) => join(directory(id), `avatar-${asset}.png`)

function pickMember(region: Region, token: string) {
  return tokenPattern.test(token) ? region.members[token] : undefined
}

export function regionMember(id: string, token: string) { return pickMember(readRegion(id), token) }
export function regionName(id: string) { return readRegion(id).name }
export function tileRole(id: string, cell: string, token: string): Role | undefined {
  const region = readRegion(id)
  const member = pickMember(region, token)
  const tile = region.tiles[cell]
  if (!member || !tile) return undefined
  if (tile.owner === member.id) return 'owner'
  return editable(member,tile) ? 'edit' : 'view'
}
export function updateTile(id: string, cell: string, version: number, listed: boolean, pixel?:string) {
  const region = readRegion(id)
  const tile = region.tiles[cell]
  if (!tile) return
  tile.version = version
  tile.listed = listed
  tile.pixel=pixel
  writeRegion(id, region)
}
function online(id: string) {
  const entries = presence.get(id)
  if (!entries) return []
  const cutoff = Date.now() - 8000
  for (const [person, data] of entries) if (data.time < cutoff) entries.delete(person)
  if (!entries.size) presence.delete(id)
  const members = new Map<string, { value: Presence; time: number }>()
  for (const entry of entries.values()) {
    if (entry.time >= (members.get(entry.value.id)?.time ?? 0)) members.set(entry.value.id, entry)
  }
  return [...members.values()].map(entry => entry.value)
}
function view(id: string, region: Region, member: RegionMember): RegionView {
  return { id, name: region.name, member: member.id, role: member.role, estateRevision: revision(), tiles: Object.values(region.tiles), people: online(id) }
}
function markPresence(id: string, region: Region, member: RegionMember, peer: string, update: PresenceUpdate) {
  const { cell, mode, selection, pose, skin } = update
  if (!['overview', 'edit', 'walk', 'view'].includes(mode) || (!cell && mode !== 'overview') || (cell && !region.tiles[cell])) {
    throw new HttpError(400, '在线位置无效。')
  }
  const tile = cell ? region.tiles[cell] : undefined
  const canEdit = editable(member,tile)
  const value: Presence = { id: member.id, name: member.name, role: member.role, cell, mode: !canEdit && mode === 'edit' ? 'view' : mode }
  if (value.mode === 'edit' && selection && uuid.test(selection)) value.selection = selection
  if (mode === 'walk' && pose && [pose.x, pose.z, pose.yaw].every(Number.isFinite) && Math.abs(pose.x) <= PLOT_SIZE / 2 && Math.abs(pose.z) <= PLOT_SIZE / 2) {
    value.pose = { x: pose.x, z: pose.z, yaw: pose.yaw }
    if (skin && uuid.test(skin.asset) && (skin.body === 'classic' || skin.body === 'slim') && existsSync(avatarPath(id, skin.asset))) {
      value.skin = { asset: skin.asset, body: skin.body }
    }
  }
  const entries = presence.get(id) ?? new Map()
  entries.set(peer, { value, time: Date.now() })
  presence.set(id, entries)
}
function guest(name: unknown, role: MemberRole, id: string) {
  const label = readableName(name, 24)
  if (!label) throw new HttpError(400, '请填写建造昵称。')
  return { id, name: label, role }
}

type CreateTile = (room: string, token: string, plot: Plot, region: string) => void
export async function handleRegion(parts: string[], request: IncomingMessage, response: ServerResponse, createTile: CreateTile) {
  const [id, action, asset, extra] = parts
  if (extra !== undefined || (asset !== undefined && action !== 'avatar' && action !== 'worker-skin')) throw new HttpError(404, '请求地址无效。')
  const method = request.method
  if(id==='holdings' && !action && method==='GET'){
    const owner=identity(request,undefined,false)
    const rows=owner ? landDatabase().prepare(`SELECT json_extract(t.value,'$.key') AS cell,json_extract(t.value,'$.pixel') AS pixel
      FROM regions,json_each(regions.data,'$.tiles') t WHERE json_extract(t.value,'$.owner')=?`).all(owner):[]
    json(response,200,rows);return
  }
  if (id==='availability' && !action && method==='POST') {
    const input=await body<{cell:string}>(request)
    const cell=parseCell(input.cell)
    if(!cell)throw new HttpError(400,'地块编号无效。')
    json(response,200,landQuote(cellKey(cell),identity(request,undefined,false))); return
  }
  if (id === 'create' && !action && method === 'POST') {
    const input = await body<{ cell: string; name: string; nickname: string }>(request)
    const cell = parseCell(input.cell)
    const name = readableName(input.name, 50)
    if (!name || !cell) throw new HttpError(400, '请选择起始地块并填写共建区名称。')
    const region = key(12), room = key(12), token = key()
    transaction(() => {
      if (existingPlots(cellKey(cell)).length) throw new HttpError(409, '这一格已有主人，请选择空地或使用共建邀请。')
      const member = guest(input.nickname, 'owner', identity(request))
      const quote=landQuote(cellKey(cell),member.id)
      if(!quote.canSeed)throw new HttpError(409,'已有地块后，请在自有地边缘选格，或加入好友的共建区扩展。')
      landCost(member,quote.seedPrice===0)
      const tile: RegionTile = { key: cellKey(cell), room, owner: member.id, write: true, version: 0, listed: false }
      createTile(room, token, plotForCell(cell), region)
      writeRegion(region, { name, members: { [token]: member }, tiles: { [tile.key]: tile }, invites: {} })
      indexPlot(region,tile)
    })
    json(response, 201, { room: region, token })
    return
  }
  if (action === 'join' && method === 'POST') {
    const input = await body<{ invite: string; nickname: string }>(request)
    const region = readRegion(id)
    const grant = tokenPattern.test(input.invite) ? region.invites[input.invite] : undefined
    if (!grant) throw new HttpError(403, '共建区邀请已失效。')
    const existingToken = tokenOf(request)
    const existing = pickMember(region, existingToken)
    if (existing) {
      if (grant === 'edit' && existing.role === 'view') {
        existing.role = 'edit'
        writeRegion(id, region)
      }
      json(response, 200, { room: id, token: existingToken })
      return
    }
    const person = identity(request)
    const prior = Object.entries(region.members).find(([,m]) => m.id === person)
    if (prior) {
      if (prior[1].role === 'view' && grant === 'edit') { prior[1].role = 'edit'; writeRegion(id,region) }
      json(response,200,{room:id,token:prior[0]}); return
    }
    const token = key()
    const newcomer = guest(input.nickname, grant, person)
    region.members[token] = newcomer
    transaction(() => { register(newcomer); writeRegion(id, region) })
    json(response, 201, { room: id, token })
    return
  }
  const token = tokenOf(request)
  const client = request.headers['x-fangcun-peer']
  const peerKey = (member: RegionMember) => typeof client === 'string' && uuid.test(client) ? `${member.id}:${client}` : member.id
  function authorize() {
    const region = readRegion(id)
    const member = pickMember(region, token)
    if (!member) throw new HttpError(403, '请通过邀请加入这个共建区。')
    migrateMemberIdentity(id,region,member,identity(request,member))
    return { region, member }
  }
  if (action === 'state') {
    const input = method === 'POST' ? await body<PresenceUpdate>(request) : undefined
    const { region, member } = authorize()
    if (input) markPresence(id, region, member, peerKey(member), input)
    if (method !== 'GET' && !input) throw new HttpError(404, '请求地址无效。')
    json(response, 200, view(id, region, member))
    return
  }
  if (action === 'estate' && method === 'GET') {
    const {region,member} = authorize()
    json(response,200,estateView(id,region,member)); return
  }
  if (action === 'estate' && method === 'POST') {
    const input = await body<{nonce:string;command:EstateCommand}>(request)
    const result = transaction(() => {
      const {region,member} = authorize()
      return command(id,region,member,input.nonce,input.command)
    })
    json(response,200,result); return
  }
  if (action === 'map-context' && method === 'POST') {
    const input = await body<{cell:string}>(request)
    const {region,member} = authorize()
    json(response,200,mapContext(id,region,member,input.cell)); return
  }
  if (action === 'quote' && method === 'POST') {
    const input = await body<{cell:string}>(request)
    const {member} = authorize()
    const cell = parseCell(input.cell)
    if (!cell) throw new HttpError(400,'地块编号无效。')
    const matches = existingPlots(cellKey(cell))
    const mine = matches.find(match => readRegion(match.region).tiles[cellKey(cell)]?.owner === member.id)
    json(response,200,{kind:mine ? 'mine' : matches.length ? 'occupied' : 'vacant'}); return
  }
  if (action === 'leave' && method === 'POST') {
    const { member } = authorize()
    presence.get(id)?.delete(peerKey(member))
    json(response, 200, { ok: true })
    return
  }
  if (action === 'worker-skin' && method==='GET' && asset && /^[a-f0-9]{64}$/.test(asset)) {
    const {region,member}=authorize()
    const visible=estateView(id,region,member).crew.some(w=>w.appearance?.skin===asset)
    const path=join(base,'employee-skins',asset+'.png')
    if(!visible || !existsSync(path)) throw new HttpError(404,'角色皮肤不可见。')
    response.writeHead(200,{'Content-Type':'image/png','Cache-Control':'private, max-age=300'})
    createReadStream(path).pipe(response); return
  }
  if (action === 'avatar' && typeof asset === 'string' && uuid.test(asset)) {
    authorize()
    const path = avatarPath(id, asset)
    if (method === 'GET' && existsSync(path)) {
      response.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'private, max-age=300', 'X-Content-Type-Options': 'nosniff' })
      createReadStream(path).pipe(response)
      return
    }
    if (method === 'PUT') {
      const data = await bytes(request, skinFileLimit)
      authorize()
      if (!isSkinPng(data)) throw new HttpError(400, '请选择 64 × 64 PNG 角色皮肤。')
      if (existsSync(path)) {
        if (!readFileSync(path).equals(data)) throw new HttpError(409, '皮肤文件标识已被使用。')
      } else { mkdirSync(directory(id),{recursive:true}); writeFileSync(path, data, { flag: 'wx', mode: 0o600 }) }
      json(response, 200, { ok: true })
      return
    }
    throw new HttpError(404, '找不到这个角色的皮肤。')
  }
  if ((action === 'add' || action === 'attach') && method === 'POST') {
    const input = await body<{ cell: string }>(request)
    const { region, member } = authorize()
    if (member.role === 'view') throw new HttpError(403, '访客无法扩展共建区。')
    const cell = parseCell(input.cell)
    if (!cell) throw new HttpError(400, '地块编号无效。')
    const cellId = cellKey(cell)
    if(region.tiles[cellId] && region.tiles[cellId].owner!==member.id) throw new HttpError(409,'这块地已由其他成员购入。')
    if (!region.tiles[cellId]) {
      if (Object.keys(region.tiles).length && !neighborsOf(cell).some(border => region.tiles[cellKey(border)])) throw new HttpError(409, '请选择与共建区共边的地块。')
      transaction(() => {
        const matches = existingPlots(cellId)
        let tile: RegionTile
        if (action === 'attach') {
          const home = matches.find(match => match.region !== id && readRegion(match.region).tiles[cellId]?.owner === member.id)
          if (!home) throw new HttpError(403,'只能拼入自己已持有的相邻地块。')
          const source = readRegion(home.region)
          const rest = new Set(Object.keys(source.tiles).filter(key => key !== cellId))
          const first = rest.values().next().value
          const frontier = first ? [first] : []
          if (first) rest.delete(first)
          for (const current of frontier) for (const side of neighborsOf(parseCell(current)!)) {
            const key = cellKey(side)
            if (rest.delete(key)) frontier.push(key)
          }
          if (rest.size) throw new HttpError(409,'移出这一格会把原共建区分断。请先连接两侧，或从边缘拼地。')
          releasePlotOnMove(home.room)
          tile = source.tiles[cellId]
          tile.write = true
          delete source.tiles[cellId]
          writeRegion(home.region,source)
        } else {
          if (matches.length) throw new HttpError(409,'这一格已有主人。自己的地块可以拼入，其他地块需要主人同意出售。')
          settleBeforeLandChange()
          landCost(member,false)
          const room = key(12)
          createTile(room, token, plotForCell(cell), id)
          tile = { key: cellId, room, owner: member.id, write: true, version: 0, listed: false }
        }
        region.tiles[cellId] = tile
        indexPlot(id,tile)
        writeRegion(id,region)
      })
    }
    json(response, 200, view(id, region, member))
    return
  }
  if (action === 'write' && method === 'POST') {
    const input = await body<{ cell: string; enabled: boolean }>(request)
    const { region, member } = authorize()
    const tile = parseCell(input.cell) ? region.tiles[input.cell] : undefined
    if (!tile || typeof input.enabled !== 'boolean') throw new HttpError(400, '地块权限无效。')
    if (member.id !== tile.owner) throw new HttpError(403, '只有地块主人可以管理编辑权限。')
    tile.write = input.enabled
    writeRegion(id, region)
    json(response, 200, view(id, region, member))
    return
  }
  if ((action === 'invite' || action === 'revoke-edit') && method === 'POST') {
    const input = action === 'invite' ? await body<{ grant: Grant }>(request) : undefined
    const { region, member } = authorize()
    if (member.role !== 'owner') throw new HttpError(403, '只有共建区主人可以管理区域邀请。')
    if (input) {
      if (input.grant !== 'edit' && input.grant !== 'view') throw new HttpError(400, '邀请权限无效。')
      const invite = key()
      region.invites[invite] = input.grant
      writeRegion(id, region)
      json(response, 201, { invite })
    } else {
      for (const [invite, grant] of Object.entries(region.invites)) if (grant === 'edit') delete region.invites[invite]
      for (const other of Object.values(region.members)) {
        if (other.role !== 'edit') continue
        other.role = 'view'
        for (const peer of presence.get(id)?.values() ?? []) {
          if (peer.value.id !== other.id) continue
          peer.value.role = 'view'
          peer.value.selection = undefined
          if (peer.value.mode === 'edit') peer.value.mode = 'view'
        }
      }
      writeRegion(id, region)
      json(response, 200, view(id, region, member))
    }
    return
  }
  throw new HttpError(404, '请求地址无效。')
}
