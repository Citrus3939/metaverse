import { roomData } from './room-storage.ts'
import { PLOT_SIZE } from '../src/plot-grid.ts'
import type { Item } from '../src/data.ts'
import { createHash, randomInt } from 'node:crypto'
import type { IncomingMessage } from 'node:http'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { base, HttpError, key, readableName, uuid } from './collab-http.ts'
import {
  database,
  existingPlots,
  plotHome,
  readRegion,
  writeRegion,
  type Region,
  type RegionMember,
} from './estate-store.ts'
import { cellKey, neighborsOf, parseCell } from '../src/plot-grid.ts'
import type { RegionTile } from '../src/collab-types.ts'
import {
  blueprints,
  buildingRate,
  catalog,
  crewNames,
  DRAW_PRICE,
  GOOD_PRICE,
  goodsNames,
  LAND_PRICE,
  profileTags,
  SHOP_LIMIT,
  STAFF_LIMIT,
  START_COINS,
  type Building,
  type ChatLine,
  type Crew,
  type EstateCommand,
  type EstateView,
  type Goods,
  type Offer,
  type Profile,
  type Sector,
} from '../src/estate.ts'

type Account = Profile & { coins: number; goods: Goods; misses: number; started: boolean }
type Game = {
  revision: number
  at: number
  players: Record<string, Account>
  buildings: Building[]
  crew: Crew[]
  offers: Offer[]
  chat: Record<string, ChatLine[]>
}
const fail = (message: string, status = 409): never => {
  throw new HttpError(status, message)
}
function integer(value: unknown, max = 1_000_000) {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 1 || value > max)
    return fail('请输入有效的正整数。', 400)
  return value
}
function validSector(value: unknown): Sector {
  if (value !== 'commerce' && value !== 'farming' && value !== 'craft') return fail('货物种类无效。', 400)
  return value
}
function spend(p: Account, cost: number) {
  if (p.coins < cost) fail('方币余额不足。')
  p.coins -= cost
}
export function identity(req: IncomingMessage, member?: RegionMember, remember = true) {
  const secret = req.headers['x-fangcun-passport']
  if (typeof secret !== 'string' || !/^[a-f0-9]{64}$/.test(secret)) return member?.id ?? (remember ? key(8) : '')
  const hash = createHash('sha256').update(secret).digest('hex')
  const db = database()
  const known = db.prepare('SELECT player FROM passports WHERE hash=?').get(hash)
  if (known) return String(known.player)
  if (!remember) return member?.id ?? ''
  const id = member?.id ?? key(8)
  db.prepare('INSERT INTO passports VALUES(?,?)').run(hash, id)
  return id
}
function game(): Game {
  const row = database().prepare('SELECT data FROM economy WHERE id=1').get()
  return row
    ? JSON.parse(String(row.data))
    : { revision: 0, at: Date.now(), players: {}, buildings: [], crew: [], offers: [], chat: {} }
}
function save(g: Game) {
  g.revision++
  database()
    .prepare('INSERT INTO economy VALUES(1,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data')
    .run(JSON.stringify(g))
}
export function landQuote(cell: string, player: string) {
  const matches = existingPlots(cell)
  const memberships = (key: string) =>
    existingPlots(key).flatMap((home) => {
      const region = readRegion(home.region)
      const entry = Object.entries(region.members).find(([, m]) => m.id === player)
      return entry ? [{ room: home.region, token: entry[0], name: region.name, role: entry[1].role, owns:region.tiles[key]?.owner===player }] : []
    })
  const owned =
    !!player &&
    !!database()
      .prepare(
        "SELECT 1 AS found FROM regions, json_each(regions.data,'$.tiles') t WHERE json_extract(t.value,'$.owner')=? LIMIT 1"
      )
      .get(player)
  const neighbors = neighborsOf(parseCell(cell)!).map(cellKey)
  const adjacent = neighbors.flatMap(memberships).filter(a=>a.owns)
  const adjacentOwned = neighbors.some((c) =>
    existingPlots(c).some((match) => readRegion(match.region).tiles[c]?.owner === player)
  )
  const g = game()
  return {
    occupied: !!matches.length,
    joined: memberships(cell),
    adjacent: [...new Map(adjacent.map((a) => [a.room, a])).values()],
    canSeed: !owned || adjacentOwned,
    seedPrice: g.players[player]?.started || owned ? LAND_PRICE : 0,
  }
}
export function migrateMemberIdentity(id: string, region: Region, m: RegionMember, player: string) {
  if (m.id === player || !player || game().players[m.id] || Object.values(region.members).some((p) => p.id === player))
    return
  // Only pre-economy v4 memberships are unified after authenticating their original bearer.
  const former = m.id
  m.id = player
  for (const tile of Object.values(region.tiles)) if (tile.owner === former) tile.owner = player
  writeRegion(id, region)
}
function init(g: Game, m: RegionMember) {
  if (g.players[m.id]) return g.players[m.id]
  g.players[m.id] = {
    id: m.id,
    name: m.name,
    tags: [],
    coins: START_COINS,
    goods: { commerce: 0, farming: 0, craft: 0 },
    misses: 0,
    started: false,
  }
  for (const name of crewNames) g.crew.push({ id: key(8), owner: m.id, name })
  return g.players[m.id]
}
export function register(m: RegionMember) {
  const g = game()
  if (g.players[m.id]) return
  init(g, m)
  save(g)
}
export function landCost(m: RegionMember, first: boolean) {
  const g = game(),
    p = init(g, m)
  if (!first || p.started) spend(p, LAND_PRICE)
  p.started = true
  save(g)
}
export function revision() {
  return Number(
    database().prepare("SELECT json_extract(data,'$.revision') AS rev FROM economy WHERE id=1").get()?.rev ?? 0
  )
}
export function editable(member: RegionMember, tile?: RegionTile) {
  return !!tile && (tile.owner === member.id || (member.role !== 'view' && tile.write))
}
function accrue(g: Game, now: number) {
  const minutes = Math.max(0, now - g.at) / 60000
  if (!minutes) return
  const neighbors = new Map<string, Set<string>>(),
    regions = new Map<string, Region>()
  for (const b of g.buildings) {
    if (!b.site) continue
    const { room, cell } = b.site
    let nearby = neighbors.get(room)
    if (!nearby) {
      const home = plotHome(room)!
      let region = regions.get(home)
      if (!region) {
        region = readRegion(home)
        regions.set(home, region)
      }
      nearby = new Set(
        neighborsOf(parseCell(cell)!)
          .map((c) => region.tiles[cellKey(c)]?.room)
          .filter(Boolean)
      )
      neighbors.set(room, nearby)
    }
    const rate = buildingRate(b, g.buildings, g.crew, nearby)
    g.players[b.owner].goods[blueprints.get(b.kind)!.sector] += minutes * rate
  }
  g.at = now
}
export function settleBeforeLandChange() {
  const g = game()
  accrue(g, Date.now())
  save(g)
}
function projection(g: Game, regionId: string, region: Region, m: RegionMember): EstateView {
  const p = g.players[m.id]
  const homes = new Set(Object.values(region.tiles).map((t) => t.room))
  const buildings = g.buildings.filter((b) => b.site && homes.has(b.site.room))
  const ids = new Set(buildings.map((b) => b.id))
  const offers = g.offers.filter((o) => !o.region || o.region === regionId)
  const visible = new Set([
    ...Object.values(region.members).map((p) => p.id),
    ...offers.map((o) => o.seller),
    ...buildings.map((b) => b.owner),
  ])
  const profiles = Object.values(g.players)
    .filter((p) => visible.has(p.id))
    .map(({ id, name, tags }) => ({ id, name, tags }))
  const integerGoods = Object.fromEntries(Object.entries(p.goods).map(([k, v]) => [k, Math.floor(v)])) as Goods
  return {
    revision: g.revision,
    coins: p.coins,
    tags: p.tags,
    misses: p.misses,
    goods: integerGoods,
    profiles,
    inventory: g.buildings.filter((b) => b.owner === m.id && !b.site),
    buildings,
    crew: g.crew.filter((c) => c.owner === m.id || (c.job && ids.has(c.job.building))),
    offers,
    chat: g.chat[regionId] ?? [],
  }
}
export function estateView(id: string, region: Region, m: RegionMember) {
  register(m)
  const g = game()
  accrue(g, Date.now())
  return projection(g, id, region, m)
}
function line(g: Game, region: string, by: string, name: string, text: string, ai?: boolean) {
  const lines = (g.chat[region] ??= [])
  lines.push({ id: key(8), by, name, text, at: Date.now(), ai })
  if (lines.length > 100) lines.shift()
}
function localTile(region: Region, room?: string) {
  return Object.values(region.tiles).find((t) => t.room === room)
}
function validateId(value: unknown) {
  return typeof value === 'string' && /^[a-f0-9]{16}$/.test(value)
}
function agent(g: Game, owner: string, staff: string) {
  return g.crew.find((w) => w.id === staff && w.owner === owner) ?? fail('只能指挥自己的员工。', 403)
}
function assign(g: Game, region: Region, m: RegionMember, staff: string, id?: string) {
  const employee = agent(g, m.id, staff)
  if (!id) {
    delete employee.job
    return '已收工，随时可以再叫我。'
  }
  const b = g.buildings.find((b) => b.id === id)
  if (!b?.site || b.site.active === false || !editable(m, localTile(region, b.site.room)))
    return fail('请选择有编辑权地块上的营业建筑。', 403)
  if (employee.job?.building === id) return '我已经在这里工作了。'
  const colleagues = new Set(g.buildings.filter((a) => a.site?.room === b.site!.room).map((a) => a.id))
  if (g.crew.filter((w) => w.id !== staff && w.job && colleagues.has(w.job.building)).length >= STAFF_LIMIT)
    fail('这一格的两个员工岗位都已占用。')
  employee.job = { building: id, since: Date.now() }
  return '我去' + blueprints.get(b.kind)!.name + '上班了。'
}
function unplace(g: Game, b: Building) {
  delete b.site
  for (const c of g.crew) if (c.job?.building === b.id) delete c.job
}
function activeList(g: Game, type: Offer['type'], ref: string) {
  return g.offers.find((o) => o.type === type && o.ref === ref)
}
function stock(g: Game, owner: string, kind: string) {
  const b = { id: key(8), kind, owner }
  g.buildings.push(b)
  return b
}
function checkSite(g: Game, region: Region, m: RegionMember, c: Extract<EstateCommand, { type: 'place' }>) {
  const b = g.buildings.find((b) => b.id === c.id)
  const tile = parseCell(c.cell) && region.tiles[c.cell]
  if (!tile || !editable(m, tile)) return fail('你没有这块地的编辑权限。', 403)
  if (
    !b ||
    (!b.site && b.owner !== m.id) ||
    (b.site && (!editable(m, localTile(region, b.site.room)) || (b.site.room !== tile.room && b.owner !== m.id)))
  )
    return fail('无法摆放这座建筑。', 403)
  if (activeList(g, 'asset', b.id) || activeList(g, 'land', tile.room)) fail('请先撤下交易中的资产。')
  const { x, z, angle } = c
  if (
    ![x, z, angle].every((v) => typeof v === 'number' && Number.isFinite(v)) ||
    !Number.isInteger(angle) ||
    angle % 90 !== 0
  )
    return fail('建筑位置或朝向无效。', 400)
  const dimensions = (kind: string, rotation: number) => {
    const d = blueprints.get(kind)!
    return rotation % 180 === 0 ? [d.width, d.depth] : [d.depth, d.width]
  }
  const [w, h] = dimensions(b.kind, angle)
  if (Math.abs(x) + w / 2 > PLOT_SIZE / 2 || Math.abs(z) + h / 2 > PLOT_SIZE / 2) fail('建筑边缘超出了地块。')
  const others = g.buildings.filter((a) => a.site?.room === tile.room && a.id !== b.id)
  const active = c.active ?? b.site?.active !== false
  if (typeof active !== 'boolean') return fail('营业状态无效。', 400)
  if (active && others.filter((a) => a.site!.active !== false).length >= SHOP_LIMIT)
    fail('每格最多可启用三座经营建筑。')
  for (const other of others) {
    const site = other.site!,
      [ww, hh] = dimensions(other.kind, site.angle)
    if (Math.abs(x - site.x) < (w + ww) / 2 && Math.abs(z - site.z) < (h + hh) / 2)
      fail('这个位置与另一座营业建筑重叠。')
  }
  if (b.site && (b.site.room !== tile.room || !active)) unplace(g, b)
  b.site = { room: tile.room, cell: tile.key, x, z, active, angle: ((angle % 360) + 360) % 360 }
  return '建筑已就位。'
}
export function mapContext(id: string, region: Region, m: RegionMember, cell: string) {
  const tile = parseCell(cell) && region.tiles[cell]
  if (!tile) return fail('请选择本区地块。', 400)
  const e = estateView(id, region, m)
  const near = [
    tile,
    ...neighborsOf(parseCell(cell)!)
      .map((c) => region.tiles[cellKey(c)])
      .filter(Boolean),
  ]
  return {
    currentCell: cell,
    tiles: near.map((t) => {
      const raw = JSON.parse(roomData(t.room))
      return {
        cell: t.key,
        editable: editable(m, t),
        buildings: e.buildings
          .filter((b) => b.site!.room === t.room)
          .map((b) => ({
            id: b.id,
            name: blueprints.get(b.kind)!.name,
            open: b.site!.active !== false,
            x: b.site!.x,
            z: b.site!.z,
            staff: e.crew.filter((c) => c.job?.building === b.id).map((c) => c.name),
          })),
        items: raw.save.scene.items
          .slice(0, 80)
          .map((o: { name: string; kind: string; position: number[] }) => ({
            name: o.name,
            kind: o.kind,
            position: o.position,
          })),
      }
    }),
  }
}
function execute(g: Game, id: string, region: Region, m: RegionMember, c: EstateCommand) {
  const p = g.players[m.id]
  const ownedTile = Object.values(region.tiles).some((t) => t.owner === m.id)
  if (
    m.role === 'view' &&
    !ownedTile &&
    !['chat', 'profile', 'store'].includes(c.type) &&
    !(c.type === 'work' && !c.building)
  )
    fail('访客可以参观和聊天，经营需要成员权限。', 403)
  switch (c.type) {
    case 'buy-place': {
      const def=blueprints.get(c.kind)
      if(!def?.price)return fail('此建筑不能直接购买。',400)
      spend(p,def.price)
      const building=stock(g,m.id,def.id)
      checkSite(g,region,m,{type:'place',id:building.id,cell:c.cell,x:c.x,z:c.z,angle:c.angle,active:false})
      return def.name+'已购买并放置。'
    }
    case 'buy': {
      const d = blueprints.get(c.kind)
      if (!d?.price) return fail('请选择商店出售的建筑。', 400)
      spend(p, d.price)
      stock(g, m.id, d.id)
      return d.name + '已收入仓库。'
    }
    case 'draw': {
      spend(p, DRAW_PRICE)
      const rare = p.misses >= 9 || randomInt(100) < 10
      const pool = catalog.filter((b) => b.rare === rare),
        d = pool[randomInt(pool.length)]
      stock(g, m.id, d.id)
      p.misses = rare ? 0 : p.misses + 1
      return '开出' + (rare ? '稀有建筑' : '建筑') + '「' + d.name + '」。'
    }
    case 'position': {
      const site=g.buildings.find(b=>b.id===c.id)?.site
      if (site ? !c.before || site.cell!==c.before.cell || site.x!==c.before.x || site.z!==c.before.z || site.angle!==c.before.angle : c.before!==null)
        return fail('建筑位置已改变，请按最新位置重试。')
      return checkSite(g,region,m,{...c,type:'place',active:site ? site.active!==false : false})
    }
    case 'operate': {
      const site=g.buildings.find(b=>b.id===c.id)?.site
      if(!site || site.cell!==c.cell || site.room!==region.tiles[c.cell]?.room)return fail('建筑已移出当前地块。')
      if(typeof c.active!=='boolean')return fail('营业状态无效。',400)
      return checkSite(g,region,m,{...site,type:'place',id:c.id,active:c.active})
    }
    case 'place':
      return checkSite(g, region, m, c)
    case 'store': {
      const b = g.buildings.find((a) => a.id === c.id)
      const ground = localTile(region, b?.site?.room)
      if (!b?.site || !ground || (b.owner !== m.id && ground.owner !== m.id))
        return fail('只有建筑或地块所有者可以退回建筑。', 403)
      unplace(g, b)
      return '建筑已退回所有者的仓库，员工已收工。'
    }
    case 'work':
      return assign(g, region, m, c.staff, c.building)
    case 'chat': {
      const text = readableName(c.text, 400)
      if (!text) return fail('请输入消息。', 400)
      let answer = ''
      if (c.staff) {
        const who = agent(g, m.id, c.staff)
        if (!c.cell || !region.tiles[c.cell]) return fail('当前地块无效。', 400)
        const buildings = g.buildings.filter(
          (b) => b.site?.room === region.tiles[c.cell!].room && b.site?.active !== false
        )
        if (c.work !== undefined || /休息|收工|下班/.test(text)) {
          if (m.role === 'view' && !ownedTile) return fail('访客不能派工。', 403)
          answer = assign(g, region, m, c.staff, c.work ?? undefined)
        } else if (/上班|工作|派工|开工|经营|种地|种田/.test(text)) {
          const named = buildings.filter((b) => text.includes(blueprints.get(b.kind)!.name))
          const target = named.length === 1 ? named[0] : buildings.length === 1 ? buildings[0] : undefined
          answer =
            target && editable(m, region.tiles[c.cell])
              ? assign(g, region, m, c.staff, target.id)
              : '请在消息里写出一家有空位的建筑名称，或从经营面板选择岗位。'
        } else if (readableName(c.reply, 600)) answer = readableName(c.reply, 600)
        else {
          const data = mapContext(id, region, m, c.cell)
          answer =
            '我在 ' +
            c.cell +
            '。此格有' +
            (buildings.map((b) => blueprints.get(b.kind)!.name).join('、') || '空闲营业位') +
            '，' +
            data.tiles[0].items.length +
            ' 件可见物件。相邻已接入 ' +
            (data.tiles.length - 1) +
            ' 格。'
        }
        line(g, id, m.id, m.name, '@' + who.name + ' ' + text)
        line(g, id, who.id, who.name, answer, true)
      } else line(g, id, m.id, m.name, text)
      return answer || '消息已发送。'
    }
    case 'recruit': {
      const t = parseCell(c.cell) && region.tiles[c.cell]
      if (!t || !editable(m, t) || !uuid.test(c.npc)) return fail('需要本格编辑权限。', 403)
      const w = agent(g, m.id, c.staff)
      const scene = JSON.parse(roomData(t.room)).save.scene
      const npc = (scene.items as Item[]).find((o) => o.id === c.npc && o.kind === 'npc')
      if (!npc?.npc) return fail('请先保存这个地块里的 NPC。')
      const appearance: NonNullable<Crew['appearance']> = { body: npc.npc.body, persona: npc.npc.persona }
      if (npc.asset && uuid.test(npc.asset)) {
        const bytes = readFileSync(join(base, t.room, npc.asset + '.png'))
        const hash = createHash('sha256').update(bytes).digest('hex')
        const dir = join(base, 'employee-skins'),
          filename = join(dir, hash + '.png')
        mkdirSync(dir, { recursive: true })
        if (!existsSync(filename)) writeFileSync(filename, bytes, { flag: 'wx', mode: 0o600 })
        appearance.skin = hash
      }
      w.name = readableName(npc.name, 24)
      w.appearance = appearance
      return '员工已采用这名 NPC 的名字、外观和人设。'
    }
    case 'profile': {
      if (!Array.isArray(c.tags) || c.tags.length > 3 || c.tags.some((t) => !profileTags.includes(t)))
        return fail('请选择最多三个名片标签。', 400)
      p.tags = [...new Set(c.tags)]
      return '标签已保存。'
    }
    case 'pay': {
      const to = validateId(c.to) && g.players[c.to]
      if (!to || to.id === m.id) return fail('请选择另一名玩家。', 400)
      const qty = integer(c.amount)
      spend(p, qty)
      to.coins += qty
      return '转账成功。'
    }
    case 'redeem': {
      const s = validSector(c.kind),
        n = integer(c.qty)
      if (p.goods[s] < n) fail('货物库存不足。')
      p.goods[s] -= n
      p.coins += GOOD_PRICE * n
      return '已交货，收入 ' + GOOD_PRICE * n + ' 方币。'
    }
    case 'list': {
      const qty = c.assetType === 'goods' ? integer(c.qty) : 1
      const offer: Offer = {
        id: key(8),
        seller: m.id,
        label: '',
        price: integer(c.price),
        type: c.assetType,
        ref: c.ref,
        qty,
      }
      if (c.assetType === 'asset') {
        const b = g.buildings.find((b) => b.id === c.ref && b.owner === m.id && !b.site)
        if (!b || activeList(g, 'asset', c.ref)) return fail('只能挂牌仓库中尚未出售的建筑。')
        offer.label = blueprints.get(b.kind)!.name
      } else if (c.assetType === 'land') {
        const tile = localTile(region, c.ref)
        if (!tile || tile.owner !== m.id || activeList(g, 'land', c.ref))
          return fail('只能挂牌自己持有且尚未出售的地块。')
        offer.label = tile.key
        offer.region = id
      } else if (c.assetType === 'goods') {
        const s = validSector(c.ref)
        if (p.goods[s] < qty) fail('货物库存不足。')
        p.goods[s] -= qty
        offer.label = goodsNames[s]
      } else return fail('资产类型无效。', 400)
      g.offers.push(offer)
      return '已挂牌。'
    }
    case 'cancel':
    case 'take': {
      const o = g.offers.find((o) => o.id === c.id)
      if (!o || (o.region && o.region !== id)) return fail('这笔挂牌已结束。')
      if (c.type === 'cancel') {
        if (o.seller !== m.id) return fail('只能撤回自己的挂牌。', 403)
        if (o.type === 'goods') p.goods[validSector(o.ref)] += o.qty
      } else {
        if (o.seller === m.id) return fail('这是你自己的挂牌。')
        if (o.type === 'asset') {
          const b = g.buildings.find((b) => b.id === o.ref && !b.site && b.owner === o.seller)
          if (!b) return fail('建筑状态已改变。')
          b.owner = m.id
        } else if (o.type === 'land') {
          const tile = localTile(region, o.ref)
          if (!tile || tile.owner !== o.seller) return fail('地块归属已改变。')
          tile.owner = m.id
          tile.write = false
          for (const b of g.buildings.filter((b) => b.site?.room === tile.room)) unplace(g, b)
          writeRegion(id, region)
        } else p.goods[validSector(o.ref)] += o.qty
        spend(p, o.price)
        g.players[o.seller].coins += o.price
      }
      g.offers = g.offers.filter((item) => item.id !== o.id)
      return c.type === 'take' ? '成交，资产与方币已交割。' : '挂牌已撤回。'
    }
    default:
      return fail('未知操作。', 400)
  }
}
export function command(id: string, region: Region, m: RegionMember, nonce: string, c: EstateCommand) {
  if (!uuid.test(nonce) || !c || typeof c !== 'object') return fail('操作编号或内容无效。', 400)
  const db = database()
  const previous = db.prepare('SELECT result FROM receipts WHERE player=? AND nonce=?').get(m.id, nonce)
  const g = game()
  init(g, m)
  accrue(g, Date.now())
  let result: string
  if (previous) result = String(previous.result)
  else {
    const touched = new Set<string>()
    const building = c.type === 'place' || c.type === 'position' || c.type === 'operate' || c.type === 'store' ? g.buildings.find((b) => b.id === c.id) : undefined
    if (building?.site) touched.add(building.site.room)
    result = execute(g, id, region, m, c)
    if(c.type==='buy-place')touched.add(region.tiles[c.cell].room)
    if (building?.site) touched.add(building.site.room)
    for (const room of touched)
      db.prepare(
        'INSERT INTO business_edits VALUES(?,?,?,?) ON CONFLICT(room,player) DO UPDATE SET name=excluded.name,time=excluded.time'
      ).run(room, m.id, m.name, Date.now())
    save(g)
    db.prepare('INSERT INTO receipts VALUES(?,?,?)').run(m.id, nonce, result)
  }
  return { result, estate: projection(g, id, region, m) }
}
export function releasePlotOnMove(room: string) {
  const g = game()
  if (activeList(g, 'land', room)) fail('请先撤下地块挂牌。')
  accrue(g, Date.now())
  // Co-builders retain their buildings and staff when a plot leaves their community.
  const tileRegion = plotHome(room)!,
    tile = localTile(readRegion(tileRegion), room)!
  for (const b of g.buildings.filter((b) => b.site?.room === room)) {
    if (b.owner !== tile.owner) unplace(g, b)
    else for (const c of g.crew) if (c.owner !== tile.owner && c.job?.building === b.id) delete c.job
  }
  save(g)
}
