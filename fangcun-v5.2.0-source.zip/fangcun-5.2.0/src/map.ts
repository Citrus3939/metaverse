import { LAND_PRICE } from './estate'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { exportLegacySave, getPlotSave } from './data'
import { cellAt, cellKey, DEFAULT_LOCATION, gridLatitude, gridLongitude, neighborsOf, parseCell, plotCenter, plotForCell, plotKey, type Plot, type PlotCell } from './plot-grid'
import { $, button, escapeHtml, icons } from './ui'
import { activityLayer } from './map-activity'
import { bindRegionPanel, inviteDialog, memberList } from './region-controls'
import type { ActivityDestination, RegionView } from './collab-types'
import { myHoldings,landAvailability, type RegionClient } from './region'

const startZoom = 12
const gridZoom = 17
const lastViews = new Map<string, { center: L.LatLng; zoom: number }>()

export function mapPage(root: HTMLElement, options: {
  onClaim:(plot:Plot,price:number)=>void; colors:Record<string,string>; saved: Plot[]; recent?: Plot; guest?: Plot; onGuest?: () => void; region?: RegionClient; seed?: string; onEnter: (plot: Plot) => void
  canOpenActivity: (destination: ActivityDestination, plot: Plot) => boolean
  openActivity: (destination: ActivityDestination, plot: Plot) => void
}) {
  const { region, seed } = options
  const key = region?.access.room ?? 'solo'
  const lastView = lastViews.get(key)
  const regionName = region?.latest?.name
  const listeners = new AbortController()
  root.innerHTML = `
    <aside class="map-sidebar">
      <div class="stage-label"><span>${icons.map}</span> ${region ? '区域总览' : seed ? '创建共建区' : '地图选址'}</div>
      <h1>${regionName ? escapeHtml(regionName) : seed ? escapeHtml(seed) : '为你的世界<br>选一块地<span class="headline-dot">。</span>'}</h1>
      <p class="sidebar-intro">${region ? '点击已接入的地块，或沿共边扩展。'
        : seed ? '放大地图后，选一格作为共建区的起点。' : '放大地图查看预划分的地块，<br>点击一个方格观看街区。'}</p>
      <div class="sidebar-divider"></div>
      <section id="selection-panel">
        <div class="panel-caption">固定地块</div>
        <div class="selection-card in-progress">
          <span class="selection-mini-icon">${icons.grid}</span>
          <strong>50 × 50 米</strong>
          <p id="map-instruction"></p>
          <small class="plot-area" id="map-cell"></small>
        </div>
        <button class="primary full" id="focus-grid">${icons.plus}<span>显示地块网格</span>${icons.arrow}</button>
        <button class="secondary full map-secondary" id="open-center-cell" hidden>${icons.box} 打开中心地块</button>
        <button class="secondary full map-secondary" id="locate-last-plot" ${options.recent ? '' : 'hidden'}>${icons.locate} 定位上次地块</button>
        <button class="secondary full map-secondary" id="return-guest" ${options.guest ? '' : 'hidden'}>${icons.group} 返回受邀地块</button>
        <button class="primary full" id="region-add-cell" hidden>${icons.plus}<span>接入这一格</span>${icons.check}</button>
        <small class="plot-area" id="region-cell-note"></small>
        <span class="saved-badge map-saved-count" ${options.saved.length ? '' : 'hidden'}>${icons.check} 已保存 ${options.saved.length} 块</span>
      </section>
      ${region ? `<section class="region-members">
        <div class="panel-caption"><span id="region-online">连接中…</span><small id="region-tile-count"></small></div>
        <ul id="region-member-list" class="members-list"></ul>
        <button class="secondary full map-secondary" id="region-fit">${icons.focus} 查看共建区</button>
        <button class="primary full map-secondary" id="region-invite" hidden>${icons.group} 邀请好友</button>
      </section>
    ${region ? inviteDialog() : ''}` : ''}
      <div class="sidebar-spacer"></div>
      <div class="map-tip">
        <div class="tip-icon">${icons.mouse}</div>
        <div><strong>地图操作</strong><p>拖动平移 · 滚轮缩放</p></div>
      </div>
    </aside>
    <section class="map-workspace" aria-label="真实地图">
      <div id="real-map"></div>
      <div class="map-top">
        <div class="location-tag"><span class="location-icon">${icons.pin}</span><div><strong id="map-place">中国 · 成都市</strong><small>真实地理底图</small></div></div>
        <div class="map-live"><span></span><b>地图视图</b></div>
      </div>
      <div class="map-actions">
        <div class="north" aria-label="上方为北"><span>N</span><svg viewBox="0 0 20 20" aria-hidden="true"><path fill="#315944" d="M10 2 15.5 16 10 12.7Z"/><path fill="#a0afa2" d="M10 2 4.5 16 10 12.7Z"/></svg></div>
        <div class="zoom-controls">${button('plus', '放大', 'zoom-in')}${button('minus', '缩小', 'zoom-out')}</div>
        ${button('locate', '返回成都', 'center-map', 'icon-button center-map')}
      </div>
      <div id="tile-status" class="tile-status" hidden>底图暂时无法加载，请检查网络连接。</div>
      <div id="map-coords" class="map-coords">30.6570° N &nbsp; 104.0660° E</div>
    </section>`

  const map = L.map('real-map', {
    zoomControl: false, minZoom: 3, maxZoom: 20, worldCopyJump: true,
    maxBounds: [[-85, -540], [85, 540]], maxBoundsViscosity: 1,
  }).setView(lastView?.center ?? (options.recent ? plotCenter(options.recent) : DEFAULT_LOCATION),
    lastView?.zoom ?? (options.recent ? gridZoom : startZoom))

  const streetCopyright = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> · HOT · <a href="https://openstreetmap.fr/">OSM France</a>'
  const esriCopyright = 'Tiles &copy; <a href="https://www.esri.com/">Esri</a> · HERE · Garmin · USGS · Intermap and the GIS community'
  const sources = [
    { url: '/map-tiles/hot/{z}/{x}/{y}', attribution: streetCopyright, native: 19 },
    { url: 'https://a.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', attribution: streetCopyright, native: 19 },
    { url: '/map-tiles/esri/{z}/{x}/{y}', attribution: esriCopyright, native: 19 },
    { url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', attribution: esriCopyright, native: 19 },
  ]
  function addTiles(index: number) {
    const source = sources[index]
    const layer = L.tileLayer(source.url, { maxNativeZoom: source.native, maxZoom: 20, attribution: source.attribution })
    let errors = 0
    layer.on('tileload', () => { errors = 0; $('tile-status').hidden = true })
    layer.on('tileerror', () => {
      if (++errors !== 3) return
      if (index === sources.length - 1) { $('tile-status').hidden = false; return }
      layer.remove()
      addTiles(index + 1)
    })
    layer.addTo(map)
  }
  addTiles(0)
  L.control.scale({ position: 'bottomleft', imperial: false }).addTo(map)
  const city = L.marker(DEFAULT_LOCATION, {
    icon: L.divIcon({ className: 'city-pin', iconSize: [19, 19], iconAnchor: [9, 9], html: '<span></span>' }),
    interactive: false,
  }).addTo(map)
  city.bindTooltip('成都', { permanent: true, direction: 'right', className: 'city-label', offset: [12, 0] })

  const lines = L.layerGroup().addTo(map)
  const savedOutlines = L.layerGroup().addTo(map)
  const gridStyle = { color: '#527d90', weight: 1, opacity: .65, className: 'map-plot-lines', interactive: false }
  const savedStyle = { color: '#007aa6', weight: 1.6, fill: false, className: 'saved-plot', interactive: false }
  const hover = L.rectangle([[0, 0], [0, 0]], { ...savedStyle, className: 'hover-plot', weight: 2, fill: true, fillColor: '#00aeec', fillOpacity: .16 })
  let lastHovered: PlotCell | undefined
  let lastGridBounds = ''
  let disposed = false
  const keys = new Set(options.saved.map(plotKey))
  const regionLines = L.layerGroup().addTo(map)
  const regionPeople = L.layerGroup().addTo(map)
  let candidate: Plot | undefined
  let adding = false
  let attach = false
  let quoteRevision=0
  let previousRegion = ''
  let previousPeople = ''
  function enter(plot: Plot) {
    const revision=++quoteRevision
    if (disposed) return
    if(!region && !seed){
      const center=plotCenter(plot)
      const content=document.createElement('div')
      const preview=document.createElement('button')
      preview.className='secondary'
      preview.textContent='观看街区'
      preview.onclick=()=>options.onEnter(plot)
      content.append(preview)
      const popup=L.popup({autoPan:false}).setLatLng(center).setContent(content).openOn(map)
      void landAvailability(plotKey(plot)).then(q=>{
        if(disposed || revision!==quoteRevision || !popup.isOpen())return
        if(q.occupied){preview.textContent=q.joined.length?'进入我的街区':'已认领 · 需要邀请';return}
        if(!q.canSeed && !q.adjacent.length)return
        const price=q.adjacent.length?LAND_PRICE:q.seedPrice
        const claim=document.createElement('button')
        claim.className='primary';claim.id='map-claim'
        claim.textContent=price?'扩张此格 · '+price+' 方币':'免费领取此格'
        claim.onclick=()=>options.onClaim(plot,price)
        content.append(' ',claim);popup.update()
      }).catch(()=>{})
      return
    }
    if (!region || region.tile(plotKey(plot))) {
      options.onEnter(plot)
      return
    }
    const nearby = region.latest?.tiles.length===0 || neighborsOf(plot.cell!).some(cell => region.tile(cellKey(cell)))
    const eligible = nearby && region.latest?.role !== 'view'
    candidate = undefined
    $('region-add-cell').hidden = true
    $('region-cell-note').textContent = eligible ? `待接入 ${plotKey(plot)}`
      : nearby ? '请由共建成员接入这一格。' : '请选择与共建区共边的方格。'
    if(eligible)void region.quote(plotKey(plot)).then(result=>{
      if(disposed || revision!==quoteRevision)return
      attach=result.kind==='mine'
      const available=result.kind!=='occupied'
      candidate=available?plot:undefined
      $('region-add-cell').hidden=!available
      $('region-add-cell').querySelector('span')!.textContent=attach?'将自有地拼入此区':'购买此格 · '+LAND_PRICE+' 方币'
      $('region-cell-note').textContent=attach?'已持有。拼入后将和本区成员共建。':available?'购入后由你持有，可管理共建权限。':'这块地已有主人。'
    }).catch(error=>{if(!disposed&&revision===quoteRevision)$('region-cell-note').textContent=error.message})
  }
  $('region-add-cell').onclick = async () => {
    if (!candidate || !region || adding) return
    adding = true
    const plot = candidate
    ;($('region-add-cell') as HTMLButtonElement).disabled = true
    try {
      if(attach && !confirm('将这块地从原共建区移入当前共建区，并允许成员编辑？其他人的营业建筑和员工将收回。'))return
      await region.add(plotKey(plot),attach)
      if (!disposed) options.onEnter(plot)
    } catch (error) {
      if (!disposed) $('region-cell-note').textContent = error instanceof Error ? error.message : '无法接入地块。'
    } finally {
      adding = false
      if (!disposed) ($('region-add-cell') as HTMLButtonElement).disabled = false
    }
  }
  const stopActivity = activityLayer(map, (destination, cell) => {
    const coordinate = parseCell(cell)
    return !!coordinate && options.canOpenActivity(destination, plotForCell(coordinate))
  }, (destination, cell) => {
    const coordinate = parseCell(cell)
    if (coordinate) options.openActivity(destination, plotForCell(coordinate))
  })
  const isGridVisible = () => map.getZoom() >= gridZoom

  function showHover(cell?: PlotCell) {
    if (!isGridVisible() || !cell) {
      hover.remove()
      lastHovered = undefined
      $('map-cell').textContent = ''
      return
    }
    if (lastHovered?.column === cell.column && lastHovered.row === cell.row && map.hasLayer(hover)) return
    lastHovered = cell
    hover.setBounds([
      [gridLatitude(cell.row + 1), gridLongitude(cell.column)],
      [gridLatitude(cell.row), gridLongitude(cell.column + 1)],
    ])
    if (!map.hasLayer(hover)) hover.addTo(map)
    const plot = plotForCell(cell)
    $('map-cell').textContent = `列 ${plot.cell!.column} · 行 ${plot.cell!.row}${keys.has(plotKey(plot)) ? ' · 已保存' : ''}`
  }

  function renderGrid() {
    const visible = isGridVisible()
    $('real-map').classList.toggle('show-plot-grid', visible)
    $('focus-grid').hidden = visible
    $('open-center-cell').hidden = !visible
    $('map-instruction').textContent = visible
      ? region ? '点击已接入的方格进入工作台。' : seed ? '点击方格创建共建区。' : '点击方格观看街区，继续放大可直接进入。'
      : '放大地图查看可以建造的地块。'
    const zoom=map.getZoom()
    $('real-map').closest('.map-workspace')!.querySelector('.map-live b')!.textContent=zoom>=13?'地块像素图':'世界地图'
    if (!visible) {
      lastGridBounds = ''
      lines.clearLayers()
      savedOutlines.clearLayers()
      if(zoom>=13)for(const plot of options.saved)L.rectangle([[plot.south,plot.west],[plot.north,plot.east]],{...savedStyle,stroke:false,fill:true,fillColor:options.colors[plotKey(plot)]??getPlotSave(plot)?.scene.pixel??'#60a9b4',fillOpacity:.75}).addTo(savedOutlines)
      showHover()
      return
    }
    const view = map.getBounds()
    const start = cellAt(view.getNorth(), view.getWest())
    const end = cellAt(view.getSouth(), view.getEast())
    const range = `${start.column}:${start.row}:${end.column}:${end.row}`
    if (lastGridBounds === range) return
    lastGridBounds = range
    lines.clearLayers()
    savedOutlines.clearLayers()
    showHover()
    const north = gridLatitude(start.row), south = gridLatitude(end.row + 1)
    const west = gridLongitude(start.column), east = gridLongitude(end.column + 1)
    const segments: L.LatLngTuple[][] = []
    for (let column = start.column; column <= end.column + 1; column++) {
      const lon = gridLongitude(column)
      segments.push([[north, lon], [south, lon]])
    }
    for (let row = start.row; row <= end.row + 1; row++) {
      const lat = gridLatitude(row)
      segments.push([[lat, west], [lat, east]])
    }
    L.polyline(segments, gridStyle).addTo(lines)
    const longitude = map.getCenter().lng
    for (const plot of options.saved) {
      const offset = Math.round((longitude - plotCenter(plot)[1]) / 360) * 360
      const bounds = L.latLngBounds([plot.south, plot.west + offset], [plot.north, plot.east + offset])
      if (!view.intersects(bounds)) continue
      L.rectangle(bounds, {...savedStyle,fill:true,fillColor:options.colors[plotKey(plot)]??getPlotSave(plot)?.scene.pixel??'#60a9b4',fillOpacity:.65}).addTo(savedOutlines)
      L.marker([plot.north - (plot.north - plot.south) * .12, plot.east + offset - (plot.east - plot.west) * .12], {
        interactive: false, icon: L.divIcon({ className: 'saved-plot-pin', iconSize: [7, 7] }),
      }).addTo(savedOutlines)
    }
  }

  function updateCoords(location: L.LatLng) {
    const { lat, lng } = location.wrap()
    $('map-coords').textContent = `${Math.abs(lat).toFixed(4)}° ${lat >= 0 ? 'N' : 'S'}  ·  ${Math.abs(lng).toFixed(4)}° ${lng >= 0 ? 'E' : 'W'}`
  }
  map.on('mousemove', event => {
    updateCoords(event.latlng)
    if (isGridVisible()) showHover(cellAt(event.latlng.lat, event.latlng.lng))
  })
  map.on('mouseout movestart', () => showHover())
  map.on('click', event => {
    if (isGridVisible()) enter(plotForCell(cellAt(event.latlng.lat, event.latlng.lng)))
  })
  let lastZoom=map.getZoom()
  map.on('zoomend',()=>{
    const zoom=map.getZoom(),before=lastZoom;lastZoom=zoom
    if(seed || before>=19 || zoom<19)return
    const {lat,lng}=map.getCenter(),plot=plotForCell(cellAt(lat,lng))
    if(!region||region.tile(plotKey(plot)))options.onEnter(plot)
  })
  map.on('zoomend moveend resize', renderGrid)
  map.on('moveend', () => {
    updateCoords(map.getCenter())
    $('map-place').textContent = map.getCenter().distanceTo(DEFAULT_LOCATION) < 21000 ? '中国 · 成都市' : '当前地图位置'
  })
  $('zoom-in').onclick = () => { map.zoomIn() }
  $('zoom-out').onclick = () => { map.zoomOut() }
  $('center-map').onclick = () => { map.setView(DEFAULT_LOCATION, startZoom) }
  $('focus-grid').onclick = () => { map.setZoom(gridZoom) }
  $('open-center-cell').onclick = () => {
    const { lat, lng } = map.getCenter()
    enter(plotForCell(cellAt(lat, lng)))
  }
  $('locate-last-plot').onclick = () => {
    if (options.recent) map.setView(plotCenter(options.recent), gridZoom + 1)
  }
  $('return-guest').onclick = () => options.onGuest?.()
  function renderRegion(view?: RegionView) {
    if (!region || disposed) return
    $('region-online').textContent = view ? `${view.people.length} 人在线` : '区域连接中断'
    if (!view) return
    if(!view.tiles.length && !candidate)$('region-cell-note').textContent='本区现为空，可购买一格作为新起点或拼入自有地。'
    $('region-tile-count').textContent = `${view.tiles.length} 块地`
    $('region-invite').hidden = view.role !== 'owner'
    $('region-member-list').innerHTML = memberList(view)
    const tileSignature = JSON.stringify(view.tiles.map(tile => [tile.key,tile.pixel,map.getZoom()>=13]))
    if (tileSignature !== previousRegion) {
      previousRegion = tileSignature
      regionLines.clearLayers()
      const longitude = map.getCenter().lng
      for (const tile of view.tiles) {
        const plot = plotForCell(parseCell(tile.key)!)
        const shift = 360 * Math.round((longitude - plotCenter(plot)[1]) / 360)
        const bounds: L.LatLngBoundsExpression = [[plot.south, plot.west + shift], [plot.north, plot.east + shift]]
        L.rectangle(bounds, { ...savedStyle, fill: true, fillOpacity: map.getZoom()>=13?.68:.10, fillColor: tile.pixel??'#60a9b4', className: 'region-plot', interactive: true, bubblingMouseEvents: false })
          .on('click', () => enter(plot)).addTo(regionLines)
      }
    }
    const signature = JSON.stringify(view.people.map(person => [person.id, person.cell, person.mode]))
    if (signature === previousPeople) return
    regionPeople.clearLayers()
    previousPeople = signature
    const peopleByCell = new Map<string, string[]>()
    for (const person of view.people) {
      if (!person.cell) continue
      const names = peopleByCell.get(person.cell) ?? []
      names.push(person.name)
      peopleByCell.set(person.cell, names)
    }
    for (const [key, names] of peopleByCell) {
      const cell = parseCell(key)!
      const plot = plotForCell(cell)
      const [lat, lng] = plotCenter(plot)
      const shift = 360 * Math.round((map.getCenter().lng - lng) / 360)
      const label = names.length > 2 ? `${names[0]} +${names.length - 1}` : names.join('、')
      const icon = L.divIcon({ className: 'region-person-pin',
        html: `<span>${escapeHtml(label)}</span>`, iconSize: [0, 0] })
      L.marker([lat, lng + shift], { icon, interactive: false }).addTo(regionPeople)
    }
  }
  const fitRegion = () => {
    const items = region?.latest?.tiles ?? []
    if (!items.length) return
    const plots = items.map(tile => plotForCell(parseCell(tile.key)!))
    const longitude = plotCenter(plots[0])[1]
    const bounds = L.latLngBounds([])
    for (const plot of plots) {
      const shift = 360 * Math.round((longitude - plotCenter(plot)[1]) / 360)
      bounds.extend([plot.south, plot.west + shift]).extend([plot.north, plot.east + shift])
    }
    map.fitBounds(bounds.pad(.22), { maxZoom: 18, animate: false })
  }
  let stopRegion: (() => void) | undefined
  if (region) {
    bindRegionPanel(region, listeners.signal)
    if (!lastView) fitRegion()
    renderRegion(region.latest)
    $('region-fit').onclick = fitRegion
    stopRegion = region.watch(() => ({ mode: 'overview' }), renderRegion)
  }
  const legacy = exportLegacySave()
  if (legacy) {
    const download = document.createElement('button')
    download.className = 'subtle'
    download.textContent = '下载旧矩形存档'
    download.onclick = () => {
      const url = URL.createObjectURL(new Blob([legacy], { type: 'application/json' }))
      const link = document.createElement('a')
      link.href = url
      link.download = 'fangcun-legacy.json'
      link.click()
      setTimeout(() => URL.revokeObjectURL(url), 1000)
    }
    $('selection-panel').append(download)
  }
  if(!region && !seed)void myHoldings().then(rows=>{
    if(disposed)return
    for(const row of rows){
      const c=parseCell(row.cell)
      if(!c)continue
      if(!keys.has(row.cell)){keys.add(row.cell);options.saved.push(plotForCell(c))}
      if(row.pixel)options.colors[row.cell]=row.pixel
    }
    lastGridBounds='';renderGrid()
  }).catch(()=>{})
  updateCoords(map.getCenter())
  renderGrid()
  return () => {
    disposed = true
    lastViews.set(key, { center: map.getCenter(), zoom: Math.min(18,map.getZoom()) })
    listeners.abort()
    stopRegion?.()
    stopActivity()
    map.remove()
  }
}
