import { existsSync, readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { parseCell, plotCenter, plotForCell } from '../src/plot-grid.ts'
import type { PublicActivity } from '../src/collab-types.ts'
import { base, roomId, writeJson } from './collab-http.ts'

export type Activity = { last: number; latest: string; contributors: Record<string, string> }
type Entry = Activity & { cell: string }
const directory = join(base, 'activity')
let index: Map<string, Entry> | undefined

function entries() {
  if (!index) {
    index = new Map()
    if (existsSync(directory)) for (const name of readdirSync(directory)) {
      if (!name.endsWith('.json') || !roomId.test(name.slice(0, -5))) continue
      const data: Entry | null = JSON.parse(readFileSync(join(directory, name), 'utf8'))
      if (data) index.set(name.slice(0, -5), data)
    }
  }
  return index
}

export function updateActivity(id: string, cell: string, activity?: Activity) {
  const all = entries()
  const value = activity ? { ...activity, cell } : null
  writeJson(directory, id + '.json', value)
  if (value) all.set(id, value)
  else all.delete(id)
}

export function publicActivity(search: URLSearchParams): PublicActivity[] {
  const number = (name: string, initial: number) => {
    const raw = search.get(name)
    return raw && Number.isFinite(Number(raw)) ? Number(raw) : initial
  }
  const zoom = Math.max(0, Math.min(20, Math.floor(number('zoom', 12))))
  const size = 2 ** Math.max(0, 17 - zoom)
  const west = number('west', -180), east = number('east', 180)
  const south = number('south', -90), north = number('north', 90)
  const clusters = new Map<string, { plots: Set<string>; builders: Map<string, string>; item: PublicActivity }>()
  for (const entry of entries().values()) {
    const cell = parseCell(entry.cell)
    if (!cell) continue
    const [latitude, lng] = plotCenter(plotForCell(cell))
    const longitude = lng + 360 * Math.round(((west + east) / 2 - lng) / 360)
    if (latitude < south || latitude > north || longitude < west || longitude > east) continue
    const id = `${Math.floor(cell.column / size)}:${Math.floor(cell.row / size)}`
    let group = clusters.get(id)
    if (!group) {
      group = { plots: new Set(), builders: new Map(), item: { key: entry.cell, latitude: 0, longitude: 0, plots: 0, builders: 0, last: 0, latest: '', names: [] } }
      clusters.set(id, group)
    }
    if (!group.plots.has(entry.cell)) {
      group.plots.add(entry.cell)
      group.item.latitude += latitude
      group.item.longitude += longitude
    }
    for (const [person, name] of Object.entries(entry.contributors)) group.builders.set(person, name)
    if (entry.last >= group.item.last) {
      group.item.last = entry.last
      group.item.latest = entry.latest
    }
  }
  return [...clusters.values()].map(({ plots, builders, item }) => ({
    ...item, plots: plots.size, builders: builders.size,
    latitude: item.latitude / plots.size, longitude: item.longitude / plots.size,
    names: [...new Set([item.latest, ...builders.values()])].slice(0, 5),
  }))
}
