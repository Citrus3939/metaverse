import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { cellKey, neighborsOf, parseCell, plotForCell, type Plot } from '../src/plot-grid.ts'
import type { MemberRole, Presence, PresenceUpdate, RegionTile, RegionView, Role } from '../src/collab-types.ts'
import { base, body, HttpError, json, key, readableName, roomId, tokenOf, tokenPattern, uuid, writeJson } from './collab-http.ts'

type Grant = 'view' | 'edit'
type RegionMember = { id: string; name: string; role: MemberRole }
type Region = { name: string; members: Record<string, RegionMember>; invites: Record<string, Grant>; tiles: Record<string, RegionTile> }
const presence = new Map<string, Map<string, { value: Presence; time: number }>>()
const directory = (id: string) => join(base, 'regions', id)

function readRegion(id: string): Region {
  if (!roomId.test(id)) throw new HttpError(404, '找不到这个共建区。')
  const path = join(directory(id), 'region.json')
  if (!existsSync(path)) throw new HttpError(404, '找不到这个共建区。')
  return JSON.parse(readFileSync(path, 'utf8'))
}
function writeRegion(id: string, region: Region) { writeJson(directory(id), 'region.json', region) }
function pickMember(region: Region, token: string) {
  return tokenPattern.test(token) ? region.members[token] : undefined
}

export function regionMember(id: string, token: string) { return pickMember(readRegion(id), token) }
export function tileRole(id: string, cell: string, token: string): Role | undefined {
  const region = readRegion(id)
  const member = pickMember(region, token)
  const tile = region.tiles[cell]
  if (!member || !tile) return undefined
  if (member.role === 'owner') return 'owner'
  if (member.role === 'view') return 'view'
  if (tile.owner === member.id) return 'owner'
  return tile.write ? 'edit' : 'view'
}
export function updateTile(id: string, cell: string, version: number, listed: boolean) {
  const region = readRegion(id)
  const tile = region.tiles[cell]
  if (!tile) return
  tile.version = version
  tile.listed = listed
  writeRegion(id, region)
}
function online(id: string) {
  const entries = presence.get(id)
  if (!entries) return []
  const cutoff = Date.now() - 8000
  for (const [person, data] of entries) if (data.time < cutoff) entries.delete(person)
  if (!entries.size) presence.delete(id)
  return [...entries.values()].map(entry => entry.value)
}
function view(id: string, region: Region, member: RegionMember): RegionView {
  return { id, name: region.name, member: member.id, role: member.role, tiles: Object.values(region.tiles), people: online(id) }
}
function markPresence(id: string, region: Region, member: RegionMember, update: PresenceUpdate) {
  const { cell, mode, selection, pose } = update
  if (!['overview', 'edit', 'walk', 'view'].includes(mode) || (!cell && mode !== 'overview') || (cell && !region.tiles[cell])) {
    throw new HttpError(400, '在线位置无效。')
  }
  const tile = cell ? region.tiles[cell] : undefined
  const canEdit = member.role === 'owner' || member.role === 'edit' && (tile?.write || tile?.owner === member.id)
  const value: Presence = { id: member.id, name: member.name, role: member.role, cell, mode: !canEdit && mode === 'edit' ? 'view' : mode }
  if (value.mode === 'edit' && selection && uuid.test(selection)) value.selection = selection
  if (mode === 'walk' && pose && [pose.x, pose.z, pose.yaw].every(Number.isFinite) && Math.abs(pose.x) <= 50 && Math.abs(pose.z) <= 50) {
    value.pose = { x: pose.x, z: pose.z, yaw: pose.yaw }
  }
  const entries = presence.get(id) ?? new Map()
  entries.set(member.id, { value, time: Date.now() })
  presence.set(id, entries)
}
function guest(name: unknown, role: MemberRole) {
  const label = readableName(name, 24)
  if (!label) throw new HttpError(400, '请填写建造昵称。')
  return { id: key(8), name: label, role }
}

type CreateTile = (room: string, token: string, plot: Plot, region: string) => void
export async function handleRegion(parts: string[], request: IncomingMessage, response: ServerResponse, createTile: CreateTile) {
  const [id, action, extra] = parts
  if (extra !== undefined) throw new HttpError(404, '请求地址无效。')
  const method = request.method
  if (id === 'create' && !action && method === 'POST') {
    const input = await body<{ cell: string; name: string; nickname: string }>(request)
    const cell = parseCell(input.cell)
    const name = readableName(input.name, 50)
    if (!name || !cell) throw new HttpError(400, '请选择起始地块并填写共建区名称。')
    const region = key(12), room = key(12), token = key()
    const member = guest(input.nickname, 'owner')
    const tile: RegionTile = { key: cellKey(cell), room, owner: member.id, write: true, version: 0, listed: false }
    createTile(room, token, plotForCell(cell), region)
    writeRegion(region, { name, members: { [token]: member }, tiles: { [tile.key]: tile }, invites: {} })
    json(response, 201, { room: region, token })
    return
  }
  if (action === 'join' && method === 'POST') {
    const input = await body<{ invite: string; nickname: string }>(request)
    const region = readRegion(id)
    const grant = tokenPattern.test(input.invite) ? region.invites[input.invite] : undefined
    if (!grant) throw new HttpError(403, '共建区邀请已失效。')
    const token = key()
    region.members[token] = guest(input.nickname, grant)
    writeRegion(id, region)
    json(response, 201, { room: id, token })
    return
  }
  const token = tokenOf(request)
  function authorize() {
    const region = readRegion(id)
    const member = pickMember(region, token)
    if (!member) throw new HttpError(403, '请通过邀请加入这个共建区。')
    return { region, member }
  }
  if (action === 'state') {
    const input = method === 'POST' ? await body<PresenceUpdate>(request) : undefined
    const { region, member } = authorize()
    if (input) markPresence(id, region, member, input)
    if (method !== 'GET' && !input) throw new HttpError(404, '请求地址无效。')
    json(response, 200, view(id, region, member))
    return
  }
  if (action === 'leave' && method === 'POST') {
    const { member } = authorize()
    presence.get(id)?.delete(member.id)
    json(response, 200, { ok: true })
    return
  }
  if (action === 'add' && method === 'POST') {
    const input = await body<{ cell: string }>(request)
    const { region, member } = authorize()
    if (member.role === 'view') throw new HttpError(403, '访客无法扩展共建区。')
    const cell = parseCell(input.cell)
    if (!cell) throw new HttpError(400, '地块编号无效。')
    const cellId = cellKey(cell)
    if (!region.tiles[cellId]) {
      if (!neighborsOf(cell).some(border => region.tiles[cellKey(border)])) throw new HttpError(409, '请选择与共建区共边的地块。')
      const room = key(12)
      createTile(room, token, plotForCell(cell), id)
      region.tiles[cellId] = { key: cellId, room, owner: member.id, write: true, version: 0, listed: false }
      writeRegion(id, region)
    }
    json(response, 200, view(id, region, member))
    return
  }
  if (action === 'write' && method === 'POST') {
    const input = await body<{ cell: string; enabled: boolean }>(request)
    const { region, member } = authorize()
    const tile = parseCell(input.cell) ? region.tiles[input.cell] : undefined
    if (!tile || typeof input.enabled !== 'boolean') throw new HttpError(400, '地块权限无效。')
    if (member.role !== 'owner' && (member.role !== 'edit' || member.id !== tile.owner)) throw new HttpError(403, '只有地块主人可以管理编辑权限。')
    tile.write = input.enabled
    writeRegion(id, region)
    json(response, 200, view(id, region, member))
    return
  }
  if ((action === 'invite' || action === 'revoke-edit') && method === 'POST') {
    const input = action === 'invite' ? await body<{ grant: Grant }>(request) : undefined
    const { region, member } = authorize()
    if (member.role !== 'owner') throw new HttpError(403, '只有共建区主人可以管理区域邀请。')
    if (input) {
      if (input.grant !== 'edit' && input.grant !== 'view') throw new HttpError(400, '邀请权限无效。')
      const invite = key()
      region.invites[invite] = input.grant
      writeRegion(id, region)
      json(response, 201, { invite })
    } else {
      for (const [invite, grant] of Object.entries(region.invites)) if (grant === 'edit') delete region.invites[invite]
      for (const other of Object.values(region.members)) {
        if (other.role !== 'edit') continue
        other.role = 'view'
        const peer = presence.get(id)?.get(other.id)
        if (peer) { peer.value.role = 'view'; peer.value.selection = undefined; if (peer.value.mode === 'edit') peer.value.mode = 'view' }
      }
      writeRegion(id, region)
      json(response, 200, view(id, region, member))
    }
    return
  }
  throw new HttpError(404, '请求地址无效。')
}
