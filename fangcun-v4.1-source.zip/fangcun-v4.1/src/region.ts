import { payload, request, RoomClient } from './room'
import type { PresenceUpdate, RegionTile, RegionView, RoomAccess } from './collab-types'

export async function createRegion(name: string, nickname: string, cell: string) {
  return new RegionClient(await request<RoomAccess>('region/create', payload({ name, nickname, cell })))
}
export async function joinRegion(region: string, invite: string, nickname: string) {
  return new RegionClient(await request<RoomAccess>(`region/${region}/join`, payload({ invite, nickname })))
}

export class RegionClient {
  latest?: RegionView
  private byCell = new Map<string, RegionTile>()
  private heartbeat?: Promise<RegionView>

  constructor(readonly access: RoomAccess) {}

  private async call<T>(action: string, init: RequestInit = {}) {
    const headers = new Headers(init.headers)
    headers.set('Authorization', `Bearer ${this.access.token}`)
    return request<T>(`region/${this.access.room}/${action}`, { ...init, headers })
  }

  private apply(view: RegionView) {
    this.latest = view
    this.byCell = new Map(view.tiles.map(tile => [tile.key, tile]))
    return view
  }
  async read(presence?: PresenceUpdate) {
    return this.apply(await this.call<RegionView>('state', presence ? payload(presence) : undefined))
  }
  tile(cell: string) { return this.byCell.get(cell) }
  room(cell: string) {
    const tile = this.tile(cell)
    return tile ? new RoomClient({ room: tile.room, token: this.access.token }) : undefined
  }
  async add(cell: string) { return this.apply(await this.call<RegionView>('add', payload({ cell }))) }
  async allowEditing(cell: string, enabled: boolean) {
    return this.apply(await this.call<RegionView>('write', payload({ cell, enabled })))
  }
  async invite(grant: 'view' | 'edit') {
    const { invite } = await this.call<{ invite: string }>('invite', payload({ grant }))
    const url = new URL(location.pathname, location.origin)
    url.hash = new URLSearchParams({ region: this.access.room, invite }).toString()
    return url.href
  }
  async revokeEditing() { return this.apply(await this.call<RegionView>('revoke-edit', { method: 'POST' })) }
  async leave() {
    await this.heartbeat?.catch(() => {})
    await this.call('leave', { method: 'POST' })
  }

  watch(presence: () => PresenceUpdate, listener: (view?: RegionView) => void) {
    let cancelled = false
    let timer = 0
    const tick = async () => {
      const pending = this.read(presence())
      this.heartbeat = pending
      try {
        const view = await pending
        if (!cancelled) listener(view)
      } catch {
        if (!cancelled) listener()
      } finally {
        if (this.heartbeat === pending) this.heartbeat = undefined
        if (!cancelled) timer = window.setTimeout(tick, 430)
      }
    }
    void tick()
    return () => { cancelled = true; window.clearTimeout(timer) }
  }
}
