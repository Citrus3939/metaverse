import { assetStorageKey, newId, newItem, putAsset, type Item, type NpcBody, type NpcSettings, type Plot } from './data'
import { previewModel } from './import-preview'
import { cacheSkin, decodeSkin, npcVisual, type NpcVisual } from './npc'
import { npcTextLimits, skinFileLimit } from './skin-format'
import { $, button, icons } from './ui'

type Skin = { id: string; image: ImageBitmap; bytes?: ArrayBuffer; label: string }

export function mountNpcEditor(root: HTMLElement, plot: Plot, options: {
  canEdit: () => boolean
  load: (id: string) => Promise<ImageBitmap>
  save: (item: Item, source: NpcVisual['object'], editing: boolean) => boolean
}) {
  root.insertAdjacentHTML('beforeend', `<dialog id="npc-dialog" class="app-dialog npc-editor">
    <form id="npc-form">
      <div class="dialog-heading"><span class="dialog-icon">${icons.person}</span><div><h2 id="npc-heading">添加 NPC</h2></div>${button('close', '关闭', 'close-npc')}</div>
      <div class="npc-layout">
        <div>
          <div id="npc-preview" class="import-preview" aria-label="NPC 三维预览"></div>
          <span class="field-label" id="npc-skin-label">Minecraft 皮肤 (64 × 64 PNG)</span>
          <button id="npc-pick-skin" type="button" class="secondary full">${icons.upload} 选择 PNG 文件</button>
          <input id="npc-skin" type="file" aria-labelledby="npc-skin-label" accept="image/png,.png" hidden>
          <p id="npc-skin-status" class="npc-skin-status" aria-live="polite"></p>
          <label class="field-label" for="npc-body">体型</label>
          <select class="text-field" id="npc-body"><option value="classic">Classic 宽臂</option><option value="slim">Slim 细臂</option></select>
        </div>
        <div>
          <label class="field-label" for="npc-name">NPC 名称</label>
          <input id="npc-name" class="text-field" maxlength="60" required>
          <label class="field-label" for="npc-greeting">开场白</label>
          <input id="npc-greeting" class="text-field" maxlength="${npcTextLimits.greeting}">
          <label class="setting-row npc-ai-setting"><input type="checkbox" id="npc-ai"> 使用服务端 AI 对话</label>
          <div id="npc-ai-fields" hidden>
            <label class="field-label" for="npc-persona">角色设定</label>
            <textarea id="npc-persona" class="text-field" rows="2" maxlength="${npcTextLimits.persona}" placeholder="例如：爱讲故事的导览员"></textarea>
            <label class="field-label" for="npc-knowledge">地块资料</label>
            <textarea id="npc-knowledge" class="text-field" rows="3" maxlength="${npcTextLimits.knowledge}" placeholder="例如：入口旁的红色屋顶是访客中心"></textarea>
          </div>
        </div>
      </div>
      <p id="npc-error" class="import-warning" aria-live="polite"></p>
      <div class="dialog-actions"><button type="button" id="cancel-npc" class="secondary">取消</button><button id="submit-npc" type="submit" class="primary">放置 NPC ${icons.check}</button></div>
    </form>
  </dialog>`)
  const dialog = $('npc-dialog') as HTMLDialogElement
  const field = (key: string) => $(`npc-${key}`) as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
  const skinInput = $('npc-skin') as HTMLInputElement
  const pick = $('npc-pick-skin') as HTMLButtonElement
  const ai = $('npc-ai') as HTMLInputElement
  const submit = $('submit-npc') as HTMLButtonElement
  let draft: Item | undefined
  let skin: Skin | undefined
  let visual: NpcVisual | undefined
  let preview: ReturnType<typeof previewModel> | undefined
  let edit = false
  let loading = false
  let saving = false
  let revision = 0

  function refresh() {
    preview?.dispose()
    visual?.dispose()
    visual = npcVisual(field('body').value as NpcBody)
    if (skin) visual.setSkin(skin.image)
    preview = previewModel($('npc-preview'), visual.object, plot, 'portrait')
    preview.render(1, true, true)
    $('npc-skin-status').textContent = loading ? '正在读取皮肤…' : skin?.label ?? '请选择一张皮肤。'
    submit.disabled = loading || saving || !skin
    pick.disabled = saving
  }
  function cleanup() {
    revision++
    preview?.dispose()
    visual?.dispose()
    if (skin?.bytes) skin.image.close()
    draft = skin = visual = preview = undefined
  }
  function updateAiFields() { $('npc-ai-fields').hidden = !ai.checked }
  function close() { if (dialog.open) dialog.close() }
  async function open(item?: Item) {
    if (!options.canEdit() || dialog.open) return
    cleanup()
    edit = !!item
    draft = item ? structuredClone(item) : newItem('npc', '新 NPC')
    const settings = draft.npc
    field('name').value = draft.name
    field('body').value = settings?.body ?? 'classic'
    field('greeting').value = settings?.greeting ?? '你好，欢迎来到这里！'
    field('persona').value = settings?.persona ?? ''
    field('knowledge').value = settings?.knowledge ?? ''
    ai.checked = settings?.ai ?? false
    skinInput.value = ''
    $('npc-error').textContent = ''
    $('npc-heading').textContent = edit ? '编辑 NPC' : '添加 NPC'
    submit.textContent = edit ? '保存修改' : '放置 NPC'
    updateAiFields()
    dialog.showModal()
    loading = !!draft.asset
    saving = false
    refresh()
    if (!draft.asset) return
    const id = draft.asset
    const current = ++revision
    try {
      const image = await options.load(id)
      if (current === revision) skin = { id, image, label: '当前皮肤' }
    } catch {
      if (current === revision) $('npc-error').textContent = '当前皮肤无法读取，请重新选择 PNG。'
    } finally {
      if (current === revision) { loading = false; refresh() }
    }
  }
  field('body').onchange = refresh
  ai.onchange = updateAiFields
  pick.onclick = () => skinInput.click()
  skinInput.onchange = async () => {
    const file = skinInput.files?.[0]
    skinInput.value = ''
    if (!file || !dialog.open) return
    const current = ++revision
    loading = true
    submit.disabled = true
    $('npc-error').textContent = ''
    $('npc-skin-status').textContent = '正在读取皮肤…'
    try {
      if (file.size > skinFileLimit) throw new Error('皮肤文件超过 128 KB。')
      const bytes = await file.arrayBuffer()
      const image = await decodeSkin(bytes)
      if (current !== revision) { image.close(); return }
      if (skin?.bytes) skin.image.close()
      skin = { id: newId(), image, bytes, label: file.name }
    } catch (error) {
      if (current === revision) $('npc-error').textContent = error instanceof Error ? error.message : '无法读取这张皮肤。'
    } finally {
      if (current === revision) { loading = false; refresh() }
    }
  }
  $('npc-form').onsubmit = async event => {
    event.preventDefault()
    if (!draft || !skin || !visual || saving || loading || !options.canEdit()) return
    const name = field('name').value.trim()
    if (!name) { field('name').focus(); return }
    const settings: NpcSettings = {
      body: field('body').value as NpcBody, greeting: field('greeting').value.trim(),
      persona: field('persona').value.trim(), knowledge: field('knowledge').value.trim(), ai: ai.checked,
    }
    const item = { ...draft, name, asset: skin.id, npc: settings }
    const selected = skin
    const current = revision
    saving = submit.disabled = pick.disabled = true
    try {
      if (selected.bytes) await putAsset(assetStorageKey(selected.id, 'png'), selected.bytes)
      if (current !== revision || !dialog.open || !options.canEdit() || !visual) return
      if (options.save(item, visual.object, edit)) {
        if (selected.bytes) cacheSkin(selected.id, Promise.resolve(selected.image))
        selected.bytes = undefined
        close()
      } else $('npc-error').textContent = '当前位置放不下这个 NPC。请把它移到地块内再试。'
    } catch {
      if (current === revision) $('npc-error').textContent = '浏览器无法保存这张皮肤。'
    } finally {
      if (current === revision) {
        saving = loading = false
        pick.disabled = false
        submit.disabled = !skin
      }
    }
  }
  $('close-npc').onclick = $('cancel-npc').onclick = close
  dialog.onclose = cleanup
  return { dialog, open, close, dispose: cleanup }
}
