import * as T from 'three'
import { assetStorageKey, getAsset, type NpcBody } from './data'
import { isSkinPng } from './skin-format'

const pixel = 1.86 / 32
const imageCache = new Map<string, Promise<ImageBitmap>>()

export async function decodeSkin(bytes: ArrayBuffer) {
  if (!isSkinPng(new Uint8Array(bytes))) throw new Error('请选择 64 × 64 像素的 Minecraft PNG 皮肤。')
  try {
    return await createImageBitmap(new Blob([bytes], { type: 'image/png' }))
  } catch {
    throw new Error('无法读取这张 PNG，请重新保存皮肤文件。')
  }
}

export function loadSkin(id: string, download?: () => Promise<ArrayBuffer | undefined>) {
  let image = imageCache.get(id)
  if (!image) {
    image = getAsset(assetStorageKey(id, 'png')).then(local => local ?? download?.()).then(bytes => {
      if (!bytes) throw new Error('找不到 NPC 皮肤文件。')
      return decodeSkin(bytes)
    })
    cacheSkin(id, image)
  }
  return image
}

export function cacheSkin(id: string, image: Promise<ImageBitmap>) {
  imageCache.set(id, image)
  void image.catch(() => { if (imageCache.get(id) === image) imageCache.delete(id) })
  if (imageCache.size > 160) imageCache.delete(imageCache.keys().next().value!)
}

type Rect = [number, number, number, number]
const geometries = new Map<string, T.BoxGeometry>()
function skinBox(width: number, height: number, depth: number, u: number, v: number, inflate: number) {
  const key = [width, height, depth, u, v, inflate].join(':')
  const known = geometries.get(key)
  if (known) return known
  const mesh = new T.BoxGeometry(...[width, height, depth].map(size => (size + 2 * inflate) * pixel))
  const uv = mesh.getAttribute('uv')
  const rect = (x: number, y: number, w: number, h: number): Rect => [x, y, x + w, y + h]
  // BoxGeometry emits +X, -X, +Y, -Y, +Z, -Z, with each face viewed from outside.
  const faces = [rect(u + depth + width, v + depth, depth, height), rect(u, v + depth, depth, height),
    rect(u + depth, v, width, depth), rect(u + depth + width, v, width, depth),
    rect(u + depth, v + depth, width, height), rect(u + depth * 2 + width, v + depth, width, height)]
  faces.forEach(([left, top, right, bottom], index) => {
    const rows = index === 3 ? [bottom, top] : [top, bottom]
    uv.setXY(index * 4, left / 64, rows[0] / 64)
    uv.setXY(index * 4 + 1, right / 64, rows[0] / 64)
    uv.setXY(index * 4 + 2, left / 64, rows[1] / 64)
    uv.setXY(index * 4 + 3, right / 64, rows[1] / 64)
  })
  geometries.set(key, mesh)
  return mesh
}

export function npcVisual(body: NpcBody) {
  const object = new T.Group()
  const material = new T.MeshStandardMaterial({ color: '#d9e1e4', roughness: .95, alphaTest: .5 })
  const hat = new T.MeshStandardMaterial({ visible: false, roughness: .95, alphaTest: .5 })
  let closed = false
  let texture: T.Texture | undefined
  const part = (x: number, y: number, w: number, h: number, d: number, offsetY: number, base: [number, number], layer: [number, number], inflate = .25) => {
    const joint = new T.Group()
    joint.position.set(x * pixel, y * pixel, 0)
    const main = new T.Mesh(skinBox(w, h, d, ...base, 0), material)
    const shell = new T.Mesh(skinBox(w, h, d, ...layer, inflate), hat)
    main.position.y = shell.position.y = offsetY * pixel
    shell.userData.skipCollision = true
    joint.add(main, shell)
    object.add(joint)
    return joint
  }
  const armWidth = body === 'slim' ? 3 : 4
  const head = part(0, 24, 8, 8, 8, 4, [0, 0], [32, 0], .5)
  part(0, 24, 8, 12, 4, -6, [16, 16], [16, 32])
  const arm = part(-4 - armWidth / 2, 22, armWidth, 12, 4, -4, [40, 16], [40, 32])
  part(4 + armWidth / 2, 22, armWidth, 12, 4, -4, [32, 48], [48, 48])
  part(-2, 12, 4, 12, 4, -6, [0, 16], [0, 32])
  part(2, 12, 4, 12, 4, -6, [16, 48], [0, 48])
  // Keep the soles of the character on the ground when an outer layer is enabled.
  object.position.y = .25 * pixel
  return {
    object, head, arm,
    setSkin(image: ImageBitmap) {
      if (closed) return false
      texture?.dispose()
      texture = new T.Texture(image)
      texture.colorSpace = T.SRGBColorSpace
      texture.flipY = false
      texture.magFilter = texture.minFilter = T.NearestFilter
      texture.generateMipmaps = false
      texture.needsUpdate = true
      material.color.set('#ffffff')
      material.map = hat.map = texture
      material.needsUpdate = hat.needsUpdate = true
      hat.visible = true
      return true
    },
    dispose() {
      closed = true
      texture?.dispose()
      material.dispose()
      hat.dispose()
    },
  }
}
export type NpcVisual = ReturnType<typeof npcVisual>
