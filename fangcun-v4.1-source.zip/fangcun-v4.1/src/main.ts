import './styles.css'
import { getPlotSave, lastPlot, migratePreviousSave, ownerRoomKey, savedPlots, setSave, EMPTY, type Save } from './data'
import { parseCell, plotForCell, plotKey, type Plot } from './plot-grid'
import { mapPage } from './map'
import { setupTheme } from './theme'
import { joinRoom, RoomClient, RoomRequestError } from './room'
import { createRegion, joinRegion, RegionClient } from './region'
import type { RoomAccess } from './collab-types'
import { $, icons, logo, escapeHtml } from './ui'

const app = $('app')
migratePreviousSave()
let recent = lastPlot()
let regionRecent: Plot | undefined
let dispose: (() => void) | undefined
let active: 'map' | 'editor' | 'lobby' = 'map'
let section: 'solo' | 'multi' = 'solo'
let loading = false
let guest: RoomClient | undefined
let region: RegionClient | undefined
let seed: { name: string; nickname: string } | undefined
type RegionInvite = { id: string; invite: string }
const guestKey = 'fangcun.guest-room'
const guestOpenKey = 'fangcun.guest-open'
const regionOwnerKey = 'fangcun.region-owner'
const regionGuestKey = 'fangcun.region-guest'
const sectionKey = 'fangcun.world'
const previousSection = sessionStorage.getItem(sectionKey)

function restoreAccess(storage: Storage, key: string) {
  try {
    const raw = storage.getItem(key)
    return raw ? JSON.parse(raw) as RoomAccess : undefined
  } catch { return undefined }
}
let announceTimer = 0
function announce(text: string) {
  const message = $('app-message')
  message.textContent = text
  message.hidden = false
  window.clearTimeout(announceTimer)
  announceTimer = window.setTimeout(() => { message.hidden = true }, 5500)
}

app.innerHTML = `
  <header class="topbar">
    <button class="brand" id="brand" aria-label="方寸，返回地图" title="方寸 4.1.0">
      ${logo()}<div><strong>方寸</strong><small>地块工作室</small></div>
    </button>
    <nav class="workflow" aria-label="世界入口">
      <button id="map-tab">${icons.map}<span>单人世界</span></button>
      <button id="multiplayer-tab">${icons.group}<span>多人共建</span></button>
      <span class="workflow-arrow">${icons.chevron}</span>
      <button id="editor-tab">${icons.box}<span>3D 工作台</span></button>
    </nav>
    <div class="header-actions"><label for="theme-picker" class="theme-control">主题 <select id="theme-picker"><option value="sky">天蓝白</option><option value="github-light">GitHub Light</option><option value="vscode-dark">VS Code Dark+</option><option value="nord">Nord</option><option value="pine">松绿</option><option value="night">深海夜色</option></select></label></div>
  </header>
  <main id="page"></main>
  <footer id="map-footer" class="map-footer"><div>${icons.globe}<span id="map-storage">地块和模型保存在此浏览器</span></div><div>地图格网按成都纬度校准</div></footer>
  <p id="app-message" class="app-message" role="alert" hidden></p>`

function navigation() {
  sessionStorage.setItem(sectionKey, section)
  document.querySelector('.workflow [aria-current]')?.removeAttribute('aria-current')
  $(active === 'editor' ? 'editor-tab' : section === 'multi' ? 'multiplayer-tab' : 'map-tab').setAttribute('aria-current', 'step')
  ;($('editor-tab') as HTMLButtonElement).disabled = section === 'multi' ? !regionRecent : !recent && !guest
  $('map-footer').hidden = active !== 'map'
  $('map-storage').textContent = section === 'multi' ? '建造内容保存在共建服务' : '地块和模型保存在此浏览器'
}

function clearPage() {
  dispose?.()
  dispose = undefined
}
function showMap() {
  clearPage()
  active = 'map'
  $('page').className = 'map-page'
  navigation()
  const solo = section === 'solo'
  dispose = mapPage($('page'), {
    saved: solo ? savedPlots() : [],
    recent: solo ? lastPlot() : regionRecent,
    guest: solo ? guest?.latest?.save.plot : undefined,
    region: solo ? undefined : region,
    seed: solo ? undefined : seed?.name,
    onEnter: plot => { void selectPlot(plot) },
  })
}
async function selectPlot(plot: Plot) {
  if (loading) return
  if (!seed || section === 'solo') { await enterEditor(plot); return }
  const draft = seed
  loading = true
  try {
    const client = await createRegion(draft.name, draft.nickname, plotKey(plot))
    await client.read()
    region = client
    seed = undefined
    sessionStorage.removeItem(regionGuestKey)
    localStorage.setItem(regionOwnerKey, JSON.stringify(client.access))
    localStorage.setItem('fangcun.builder-name', draft.nickname)
  } catch (error) {
    announce(error instanceof Error ? error.message : '共建区创建失败。')
    return
  } finally { loading = false }
  await enterEditor(plot)
}

async function enterEditor(plot: Plot) {
  if (active === 'editor' || loading) return
  loading = true
  try {
    const currentRegion = section === 'multi' ? region : undefined
    const ownerKey = ownerRoomKey(plot)
    const existing = currentRegion ? null : getPlotSave(plot)
    const guestPlot = guest?.latest?.save.plot
    const inGuestRoom = !currentRegion && !!guestPlot && plotKey(guestPlot) === plotKey(plot)
    let client = currentRegion?.room(plotKey(plot)) ?? (inGuestRoom ? guest : undefined)
    if (currentRegion && !client) throw new Error('请选择共建区内已经接入的地块。')
    if (client && (currentRegion || !client.latest)) await client.read()
    if (!client && existing) {
      const access = restoreAccess(localStorage, ownerKey)
      if (access) {
        client = new RoomClient(access)
        try { await client.read() }
        catch (error) {
          if (!(error instanceof RoomRequestError) || ![403, 404].includes(error.status)) throw error
          localStorage.removeItem(ownerKey)
          client = undefined
          announce('共建房间已失效，已打开此浏览器内的存档。')
        }
      }
    }
    const initial: Save = client?.latest?.save ?? existing ?? { plot, scene: structuredClone(EMPTY) }
    sessionStorage.setItem(guestOpenKey, String(inGuestRoom))
    const { editorPage } = await import('./editor')
    clearPage()
    active = 'editor'
    if (currentRegion) regionRecent = initial.plot
    else recent = initial.plot
    $('page').className = 'editor-page'
    navigation()
    dispose = editorPage($('page'), initial, value => {
      if (inGuestRoom || currentRegion) return
      setSave(value)
      recent = value.plot
    }, {
      client, region: currentRegion, overview: showMap,
      ownerRoom: room => localStorage.setItem(ownerKey, JSON.stringify(room.access)),
    })
  } catch (error) {
    showMap()
    announce(error instanceof Error ? error.message : '无法打开 3D 工作台。')
  } finally {
    loading = false
  }
}

function invitedRegion(hash: URLSearchParams): RegionInvite | undefined {
  const id = hash.get('region'), invite = hash.get('invite')
  return id && /^[a-f0-9]{24}$/.test(id) && invite && /^[a-f0-9]{64}$/.test(invite) ? { id, invite } : undefined
}
function invitationFromInput(value: string) {
  try {
    const url = new URL(value.trim(), location.href)
    return url.origin === location.origin ? invitedRegion(new URLSearchParams(url.hash.slice(1))) : undefined
  } catch { return undefined }
}
function showLobby(invitation?: RegionInvite) {
  clearPage()
  seed = undefined
  active = 'lobby'
  section = 'multi'
  const nickname = escapeHtml(localStorage.getItem('fangcun.builder-name') ?? '')
  $('page').className = 'region-landing'
  $('page').innerHTML = `<section class="region-entry${invitation ? ' invite-only' : ''}">
    <header><h1>多人共建</h1><p>和朋友一起建造，沿相邻地块扩展。</p></header>
    ${invitation ? '' : `<form id="create-region-form">
      <h2>创建共建区</h2>
      <label class="field-label" for="region-title">共建区名称</label><input class="text-field" id="region-title" required maxlength="50">
      <label class="field-label" for="region-owner-nickname">建造昵称</label><input class="text-field" id="region-owner-nickname" required maxlength="24" value="${nickname}">
      <button class="primary full" type="submit">选择起始地块 ${icons.arrow}</button>
    </form>`}
    <form id="join-region-form">
      <h2>加入共建区</h2>
      ${invitation ? '' : '<label class="field-label" for="region-join-link">邀请链接</label><input class="text-field" id="region-join-link" required>'}
      <label class="field-label" for="region-guest-nickname">建造昵称</label><input class="text-field" id="region-guest-nickname" required maxlength="24" value="${nickname}">
      <button class="primary full" id="join-region-submit" type="submit">进入共建区 ${icons.arrow}</button>
    </form>
  </section>`
  navigation()
  if (!invitation) $('create-region-form').onsubmit = event => {
    event.preventDefault()
    const name = ($('region-title') as HTMLInputElement).value.trim()
    const nickname = ($('region-owner-nickname') as HTMLInputElement).value.trim()
    if (!name || !nickname) { announce('请填写共建区名称和建造昵称。'); return }
    region = undefined
    regionRecent = undefined
    seed = { name, nickname }
    showMap()
  }
  $('join-region-form').onsubmit = async event => {
    event.preventDefault()
    if (loading) return
    const target = invitation ?? invitationFromInput(($('region-join-link') as HTMLInputElement).value)
    const nickname = ($('region-guest-nickname') as HTMLInputElement).value.trim()
    if (!target || !nickname) { announce('请填写有效的同站邀请链接和建造昵称。'); return }
    loading = true
    ;($('join-region-submit') as HTMLButtonElement).disabled = true
    try {
      const client = await joinRegion(target.id, target.invite, nickname)
      const value = await client.read()
      region = client
      regionRecent = value.tiles.length ? plotForCell(parseCell(value.tiles[0].key)!) : undefined
      sessionStorage.setItem(regionGuestKey, JSON.stringify(client.access))
      localStorage.setItem('fangcun.builder-name', nickname)
      history.replaceState(null, '', location.pathname + location.search)
      showMap()
    } catch (error) {
      announce(error instanceof Error ? error.message : '无法加入共建区。')
      ;(document.getElementById('join-region-submit') as HTMLButtonElement | null)?.removeAttribute('disabled')
    } finally { loading = false }
  }
}

function openSolo() {
  if (loading) return
  const leaving = section === 'multi' ? region : undefined
  section = 'solo'
  showMap()
  void leaving?.leave().catch(() => {})
}
async function openMultiplayer() {
  if (loading) return
  section = 'multi'
  if (region || seed) { showMap(); return }
  const access = restoreAccess(sessionStorage, regionGuestKey) ?? restoreAccess(localStorage, regionOwnerKey)
  if (!access) { showLobby(); return }
  loading = true
  try {
    const client = new RegionClient(access)
    const value = await client.read()
    region = client
    regionRecent = value.tiles.length ? plotForCell(parseCell(value.tiles[0].key)!) : undefined
    showMap()
  } catch (error) {
    showLobby()
    announce(error instanceof Error ? error.message : '无法读取上次加入的共建区。')
  } finally { loading = false }
}
$('brand').onclick = () => { if (!loading) section === 'multi' ? void openMultiplayer() : openSolo() }
$('map-tab').onclick = openSolo
$('multiplayer-tab').onclick = () => void openMultiplayer()
$('editor-tab').onclick = () => {
  const plot = section === 'multi' ? regionRecent : recent ?? guest?.latest?.save.plot
  if (plot) void enterEditor(plot)
}

async function readInvitation(restore: boolean) {
  const hash = new URLSearchParams(location.hash.slice(1))
  const regionInvite = invitedRegion(hash)
  if (regionInvite) {
    if (region) void region.leave().catch(() => {})
    showLobby(regionInvite)
    return
  }
  const room = hash.get('room'), invite = hash.get('invite')
  if (!room && !invite && !restore) return
  try {
    const access = restoreAccess(sessionStorage, guestKey)
    const client = room && invite ? await joinRoom(room, invite) : access ? new RoomClient(access) : undefined
    if (!client) return
    const view = await client.read()
    sessionStorage.setItem(guestKey, JSON.stringify(client.access))
    if (room && invite) history.replaceState(null, '', location.pathname + location.search)
    guest = client
    if (!invite && sessionStorage.getItem(guestOpenKey) === 'false') {
      if (active === 'map' && section === 'solo') showMap()
      return
    }
    openSolo()
    await enterEditor(view.save.plot)
  } catch (error) { announce(error instanceof Error ? error.message : '无法加入地块。') }
}

setupTheme()
showMap()
if (!location.hash && previousSection === 'multi') void openMultiplayer()
else void readInvitation(true)
window.addEventListener('hashchange', () => void readInvitation(false))
