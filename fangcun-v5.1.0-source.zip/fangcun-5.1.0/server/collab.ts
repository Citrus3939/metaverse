import { catalog } from '../src/estate.ts'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { createReadStream } from 'node:fs'
import { join } from 'node:path'
import type { Connect } from 'vite'
import type { AssetKind, Item, Save, SceneData } from '../src/data.ts'
import { cellAt, placeOnGrid, plotCenter, plotForCell, plotKey } from '../src/plot-grid.ts'
import { applyChanges, sceneAssets, sceneChanges, type Role, type RoomView, type SceneChange } from '../src/collab-types.ts'
import { isSkinPng, skinFileLimit, validNpc } from '../src/skin-format.ts'

import { base, body, bytes, HttpError, json, key, readableName, roomId, tokenOf, tokenPattern, uuid, writeJson } from './collab-http.ts'
import { handleRegion, regionMember, tileRole, updateTile } from './regions.ts'
import { plotHome } from './estate-store.ts'
import { publicActivity, updateActivity, type Activity } from './activity.ts'
import { npcChat } from './npc-chat.ts'

type Room = { owner: string; members: Record<string, 'view' | 'edit'>; invites: Record<string, 'view' | 'edit'>; save: Save; version: number; region?: string; listed?: boolean; activity?: Activity }
type Peer = { token: string; seen: number }
const peers = new Map<string, Map<string, Peer>>()
const assetPath = (id: string, asset: string, kind: AssetKind) => join(base, id, `${asset}.${kind}`)

function writeRoom(id: string, room: Room) { writeJson(join(base, id), 'room.json', room) }
function createTile(room: string, token: string, plot: Save['plot'], region?: string) {
  writeRoom(room, { owner: token, members: {}, invites: {}, save: { plot, scene: { items: [], models: [] } }, version: 0, region })
}
function indexRoom(id: string, room: Room, listingChanged = false) {
  const cell = plotKey(room.save.plot)
  if (room.region) updateTile(room.region, cell, room.version, !!room.listed, room.save.scene.pixel)
  if (room.listed || listingChanged) updateActivity(id, cell, room.listed ? room.activity : undefined, room.region)
}

function readRoom(id: string): Room {
  const path = join(base, id, 'room.json')
  if (!existsSync(path)) throw new HttpError(404, '找不到这个地块。')
  const room: Room = JSON.parse(readFileSync(path, 'utf8'))
  if (room.region) {
    const home = plotHome(id)
    if (!home) throw new HttpError(410, '地块已经拆分，请从区域总览重新进入。')
    room.region = home
  }
  if (!room.save.plot.cell) {
    room.save.plot = placeOnGrid(room.save.plot)
    writeRoom(id, room)
  }
  return room
}
function roleOf(room: Room, token: string): Role | undefined {
  if (room.region) return tileRole(room.region, plotKey(room.save.plot), token)
  if (tokenPattern.test(token)) return token === room.owner ? 'owner' : room.members[token]
  return undefined
}
function view(id: string, room: Room, role: Role): RoomView {
  const active = peers.get(id)
  if (active) for (const [client, peer] of active) if (Date.now() - peer.seen > 8000) active.delete(client)
  return { role, save: room.save, version: room.version, online: active?.size ?? 0, listed: !!room.listed }
}
function validItem(item: Item, depth = 0): boolean {
  if (!item || depth > 12 || !uuid.test(item.id) || typeof item.name !== 'string' || item.name.length > 250) return false
  if (!['box', 'sphere', 'cylinder', 'group', 'glb', 'npc'].includes(item.kind)) return false
  if (item.kind === 'npc' && (depth > 0 || !validNpc(item.npc))) return false
  const vec = (v: number[]) => Array.isArray(v) && v.length === 3 && v.every(x => Number.isFinite(x) && Math.abs(x) < 1e9)
  return vec(item.position) && vec(item.rotation) && vec(item.scale) && item.scale.every(x => x > 0)
    && (item.color === undefined || /^#[0-9a-f]{6}$/i.test(item.color))
    && (item.kind !== 'glb' && item.kind !== 'npc' || typeof item.asset === 'string' && uuid.test(item.asset))
    && (item.kind === 'group' ? Array.isArray(item.children) && item.children.length <= 250 && item.children.every(x => validItem(x, depth + 1))
      : item.children === undefined)
}
function validScene(scene: SceneData): boolean {
  return !!scene && (scene.streets === undefined || Array.isArray(scene.streets) && scene.streets.length <= 2 && scene.streets.every(s => s === 'east' || s === 'south') && new Set(scene.streets).size === scene.streets.length) && [scene.items, scene.models].every(items => Array.isArray(items) && items.every(item => validItem(item)) && new Set(items.map(item => item.id)).size === items.length)
}
function checkAssets(id: string, scene: SceneData) {
  for (const asset of sceneAssets(scene)) {
    if (!existsSync(assetPath(id, asset.id, asset.kind))) throw new HttpError(422, '场景引用了尚未上传的 GLB 或 NPC 皮肤。')
  }
}
function checkGlb(bin: Buffer) {
  if (bin.length < 20 || bin.readUInt32LE(0) !== 0x46546c67 || bin.readUInt32LE(4) !== 2
    || bin.readUInt32LE(8) !== bin.length || bin.readUInt32LE(16) !== 0x4e4f534a) throw new HttpError(400, '请选择有效的 GLB。')
  try {
    const length = bin.readUInt32LE(12)
    if (length + 20 > bin.length) throw new Error()
    const value = JSON.parse(bin.subarray(20, 20 + length).toString('utf8'))
    if ([...(value.buffers ?? []), ...(value.images ?? [])].some(resource => resource.uri && !/^data:/i.test(resource.uri))) throw new Error()
  } catch { throw new HttpError(400, '房间只接受自包含 GLB。') }
}

export const collaboration: Connect.NextHandleFunction = async (request, response, next) => {
  const url = new URL(request.url ?? '/', 'http://fangcun.local')
  const pathname = url.pathname
  if (!pathname.startsWith('/collab/')) { next(); return }
  try {
    const [, , id, action, asset, extra] = pathname.split('/')
    const method = request.method
    if (id === 'region') {
      await handleRegion(pathname.split('/').slice(3), request, response, createTile)
      return
    }
    if (id==='catalog' && !action && method==='GET') {
      const {searchParams:q}=url
      const contains=(name:string,value:string)=>!q.has(name)||q.get(name)===value
      json(response,200,catalog.filter(b=>contains('theme',b.theme)&&contains('sector',b.sector)&&contains('rarity',b.rare?'rare':'standard')&&(!q.has('tag')||b.tags.includes(q.get('tag')!))))
      return
    }
    if (id === 'activity' && !action && method === 'GET') {
      json(response, 200, publicActivity(url.searchParams))
      return
    }
    if (id === 'npc-chat' && !action && method === 'POST') {
      await npcChat(request, response)
      return
    }
    if (id === 'create' && !action && method === 'POST') {
      const input = await body<{ plot: Save['plot'] }>(request)
      const plot = input.plot
      if (!plot || ![plot.north, plot.south, plot.east, plot.west].every(Number.isFinite)) throw new HttpError(400, '地块坐标无效。')
      // The centre determines the cell even for requests from older clients.
      const center = plotCenter({ ...plot, cell: undefined })
      const fixed = plotForCell(cellAt(...center))
      const room = key(12), token = key()
      createTile(room, token, fixed)
      json(response, 201, { room, token })
      return
    }
    if (!roomId.test(id) || extra !== undefined) throw new HttpError(404, '找不到这个地块。')
    if (action === 'join' && method === 'POST') {
      const { invite } = await body<{ invite: string }>(request)
      const room = readRoom(id)
      if (room.region) throw new HttpError(403, '请使用共建区邀请。')
      const grant = tokenPattern.test(invite) ? room.invites[invite] : undefined
      if (!grant) throw new HttpError(403, '邀请链接已失效。')
      const token = key()
      room.members[token] = grant
      writeRoom(id, room)
      json(response, 200, { room: id, token })
      return
    }
    const token = tokenOf(request)
    const authorize = () => {
      const room = readRoom(id)
      const role = roleOf(room, token)
      if (!role) throw new HttpError(403, '当前账号没有进入地块的权限。')
      return { room, role }
    }
    const { room, role } = authorize()
    if (action === 'npc-chat' && !asset && method === 'POST') {
      await npcChat(request, response, npcId => {
        const npc = authorize().room.save.scene.items.find(item => item.kind === 'npc' && item.id === npcId)
        if (!npc) throw new HttpError(404, '这里已经没有这个 NPC。')
        return npc
      })
      return
    }
    if (action === 'state' && method === 'GET') {
      const client = request.headers['x-fangcun-peer']
      if (typeof client === 'string' && uuid.test(client)) {
        const active = peers.get(id) ?? new Map()
        active.set(client, { token, seen: Date.now() })
        peers.set(id, active)
      }
      json(response, 200, view(id, room, role))
      return
    }
    if (action === 'state' && method === 'POST') {
      if (role === 'view') throw new HttpError(403, '当前访客没有编辑权限。')
      const input = await body<{ changes: SceneChange[]; expectEmpty?: boolean }>(request)
      const current = authorize()
      if (current.role === 'view') throw new HttpError(403, '编辑权限已撤销。')
      if (input.expectEmpty === true && (current.room.save.scene.items.length || current.room.save.scene.models.length || current.room.save.scene.streets?.length)) {
        throw new HttpError(409, '此格已有共建内容，单人存档未复制。')
      }
      if (!Array.isArray(input.changes) || input.changes.length > 1000 || !input.changes.every(change => change &&
        (change.collection === 'pixel' ? change.id==='color' && [change.before,change.after].every(v=>v===null || typeof v==='string' && /^#[0-9a-f]{6}$/i.test(v)) : change.collection === 'streets' ? ['east','south'].includes(change.id) && typeof change.before === 'boolean' && typeof change.after === 'boolean' : ['items', 'models'].includes(change.collection) && uuid.test(change.id)
        && (change.before === null || validItem(change.before) && change.before.id === change.id)
        && (change.after === null || validItem(change.after) && change.after.id === change.id)))) throw new HttpError(400, '物件修改格式无效。')
      const scene = applyChanges(current.room.save.scene, input.changes)
      if (!scene) { json(response, 409, view(id, current.room, current.role)); return }
      if (!validScene(scene)) throw new HttpError(422, '房间场景达到容量限制。')
      checkAssets(id, scene)
      const actual = sceneChanges(current.room.save.scene, scene)
      if (actual.length) {
        current.room.save.scene = scene
        current.room.version++
        const member = current.room.region ? regionMember(current.room.region, token) : undefined
        const idForActivity = member?.id ?? createHash('sha256').update(token).digest('hex').slice(0, 20)
        let label = ''
        try { label = readableName(decodeURIComponent(String(request.headers['x-fangcun-name'] ?? '')), 24) } catch { /* An invalid optional nickname is ignored. */ }
        const name = member?.name ?? (label || (current.role === 'owner' ? '地块主人' : '共建成员'))
        const activity = current.room.activity ?? { last: 0, latest: '', contributors: {} }
        activity.last = Date.now()
        activity.latest = name
        activity.contributors[idForActivity] = name
        current.room.activity = activity
        writeRoom(id, current.room)
        if (current.room.region || current.room.listed) indexRoom(id, current.room)
      }
      json(response, 200, view(id, current.room, current.role))
      return
    }
    if (action === 'listing' && method === 'POST') {
      const { enabled } = await body<{ enabled: boolean }>(request)
      const current = authorize()
      if (current.role !== 'owner') throw new HttpError(403, '只有地块主人可以管理地图标记。')
      if (typeof enabled !== 'boolean') throw new HttpError(400, '地图标记状态无效。')
      current.room.listed = enabled
      writeRoom(id, current.room)
      indexRoom(id, current.room, true)
      json(response, 200, view(id, current.room, current.role))
      return
    }
    if (action === 'invite' && method === 'POST') {
      if (room.region) throw new HttpError(403, '请从共建区管理邀请。')
      if (role !== 'owner') throw new HttpError(403, '仅地块主人可以管理邀请。')
      const { grant } = await body<{ grant: string }>(request)
      const current = authorize().room
      if (grant !== 'edit' && grant !== 'view') throw new HttpError(400, '邀请权限无效。')
      const invite = key()
      current.invites[invite] = grant
      writeRoom(id, current)
      json(response, 201, { invite })
      return
    }
    if (action === 'revoke-edit' && method === 'POST') {
      if (room.region) throw new HttpError(403, '请从共建区管理邀请。')
      if (role !== 'owner') throw new HttpError(403, '仅地块主人可以撤销权限。')
      for (const [invite, grant] of Object.entries(room.invites)) if (grant === 'edit') delete room.invites[invite]
      for (const member of Object.keys(room.members)) room.members[member] = 'view'
      room.version++
      writeRoom(id, room)
      json(response, 200, view(id, room, role))
      return
    }
    if ((action === 'asset' || action === 'skin') && uuid.test(asset)) {
      const kind = action === 'skin' ? 'png' : 'glb'
      const path = assetPath(id, asset, kind)
      if (method === 'GET') {
        if (!existsSync(path)) throw new HttpError(404, '房间内找不到该模型。')
        response.writeHead(200, { 'Content-Type': kind === 'png' ? 'image/png' : 'model/gltf-binary', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' })
        createReadStream(path).pipe(response)
        return
      }
      if (method === 'PUT') {
        if (role === 'view') throw new HttpError(403, '当前访客没有上传权限。')
        const bin = await bytes(request, kind === 'png' ? skinFileLimit : 24 * 1024 * 1024)
        if (authorize().role === 'view') throw new HttpError(403, '编辑权限已撤销。')
        if (kind === 'glb') checkGlb(bin)
        else if (!isSkinPng(bin)) throw new HttpError(400, '请上传 64 × 64 像素的 Minecraft PNG 皮肤。')
        if (existsSync(path) && !readFileSync(path).equals(bin)) throw new HttpError(409, '模型标识冲突。')
        if (!existsSync(path)) writeFileSync(path, bin, { flag: 'wx', mode: 0o600 })
        json(response, 200, { stored: true })
        return
      }
    }
    throw new HttpError(404, '请求地址无效。')
  } catch (error) {
    if (!(error instanceof HttpError)) console.error(error)
    if (!response.headersSent) json(response, error instanceof HttpError ? error.status : 500, { error: error instanceof HttpError ? error.message : '房间服务暂时不可用。' })
  }
}
