import { PLOT_SIZE } from './plot-grid'
import * as T from 'three'
import { blueprints, type Building, type Crew, type EstateView } from './estate'
import { estateModel } from './estate-models'
import { cellOffset, cellKey, parseCell, type PlotCell } from './plot-grid'
import { npcVisual } from './npc'

const shadowMap = () => {
  const c = document.createElement('canvas')
  c.width = c.height = 96
  const ctx = c.getContext('2d')!,
    gradient = ctx.createRadialGradient(48, 48, 9, 48, 48, 48)
  gradient.addColorStop(0, 'rgba(47,38,40,.45)')
  gradient.addColorStop(1, 'rgba(47,38,40,0)')
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, 96, 96)
  return new T.CanvasTexture(c)
}
function meadowPaper() {
  const surface = document.createElement('canvas')
  surface.width = surface.height = 512
  const ctx = surface.getContext('2d')!
  ctx.fillStyle = '#cecfb9'
  ctx.fillRect(0, 0, 512, 512)
  let seed = 9631
  const random = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296
  for (let i = 0; i < 2400; i++) {
    const x = random() * 512,
      y = random() * 512
    ctx.fillStyle = i % 3 ? '#626e5b10' : '#ffffe936'
    ctx.fillRect(x, y, 1 + random() * 2, 1)
  }
  for (let i = 0; i < 64; i++) {
    const x = random() * 512,
      y = random() * 512
    ctx.strokeStyle = '#78826a37'
    ctx.lineWidth = 0.8
    ctx.beginPath()
    ctx.moveTo(x - 1.2, y - 1.1)
    ctx.lineTo(x, y)
    ctx.lineTo(x + 1.8, y - 2)
    ctx.stroke()
  }
  const tex = new T.CanvasTexture(surface)
  tex.colorSpace = T.SRGBColorSpace
  tex.wrapS = tex.wrapT = T.RepeatWrapping
  tex.repeat.set(3, 3)
  tex.anisotropy = 4
  return tex
}
async function uniform(index: number) {
  const c = document.createElement('canvas')
  c.width = c.height = 64
  const ctx = c.getContext('2d')!,
    coat = ['#648875', '#8c728d', '#5b8199', '#9a7055', '#9d8160'][index % 5]
  ctx.fillStyle = '#edc093'
  ctx.fillRect(0, 0, 32, 16)
  ctx.fillStyle = '#59463f'
  ctx.fillRect(0, 0, 32, 8)
  ctx.fillRect(8, 8, 8, 2)
  ctx.fillRect(24, 8, 8, 8)
  ctx.fillRect(9, 11, 1, 1)
  ctx.fillRect(14, 11, 1, 1)
  ctx.fillStyle = coat
  ctx.fillRect(16, 16, 24, 16)
  ctx.fillRect(40, 16, 16, 16)
  ctx.fillRect(32, 48, 16, 16)
  ctx.fillStyle = '#e7d6b5'
  ctx.fillRect(20, 23, 7, 8)
  for (const [x, y] of [
    [0, 16],
    [16, 48],
  ]) {
    ctx.fillStyle = '#53616a'
    ctx.fillRect(x, y, 16, 16)
    ctx.fillStyle = '#594841'
    ctx.fillRect(x, y + 13, 16, 3)
  }
  ctx.fillStyle = '#edc093'
  ctx.fillRect(40, 28, 16, 4)
  ctx.fillRect(32, 60, 16, 4)
  return createImageBitmap(c)
}
const uniforms = new Map<number, Promise<ImageBitmap>>()
function employee(w: Crew, load?: (id: string) => Promise<ImageBitmap>) {
  const npc = npcVisual(w.appearance?.body ?? 'classic'),
    variation = parseInt(w.id.slice(-2), 16) % 5
  let img = uniforms.get(variation)
  if (!img) {
    img = uniform(variation)
    uniforms.set(variation, img)
  }
  const custom = w.appearance?.skin && load
  if (custom)
    void load!(w.appearance!.skin!)
      .then((image) => {
        if (!npc.setSkin(image)) image.close()
        else owned = image
      })
      .catch(() => img!.then((image) => npc.setSkin(image)))
  else void img.then((image) => npc.setSkin(image)).catch(() => {})
  let owned: ImageBitmap | undefined
  const release = () => {
    npc.dispose()
    owned?.close()
  }
  return {
    npc,
    release,
    look: JSON.stringify(w.appearance),
    x: 0,
    z: 0,
    angle: 0,
    since: 0,
    cellX: 0,
    cellZ: 0,
    side: 1,
    legs: [npc.object.getObjectByName('RightLeg')!, npc.object.getObjectByName('LeftLeg')!],
    other: npc.object.getObjectByName('LeftArm')!,
    sector: 'commerce',
  }
}

export class EstateScene {
  readonly structures = new T.Group()
  readonly people = new T.Group()
  readonly studio = new T.Group()
  private shadow = shadowMap()
  private shade = new T.MeshBasicMaterial({ map: this.shadow, transparent: true, depthWrite: false })
  private floorGeometry = new T.BoxGeometry(PLOT_SIZE, 1.1, PLOT_SIZE)
  private paper = meadowPaper()
  private floor = new T.MeshStandardMaterial({ map: this.paper, color: '#e0dfd6', roughness: 1 })
  private floors = new Map<string, T.Mesh>()
  private objects = new Map<string, { signature: string; object: T.Group }>()
  private workers = new Map<string, ReturnType<typeof employee>>()
  loadSkin?: (id: string) => Promise<ImageBitmap>
  constructor(private origin: PlotCell) {}
  display(data: EstateView | undefined, tiles: string[], focus: PlotCell) {
    const keys = new Set([
      cellKey(this.origin),
      ...tiles.filter((k) => {
        const [x, z] = cellOffset(focus, parseCell(k)!)
        return Math.max(Math.abs(x), Math.abs(z)) <= PLOT_SIZE
      }),
    ])
    for (const [key, plane] of this.floors)
      if (!keys.has(key)) {
        this.studio.remove(plane)
        this.floors.delete(key)
      }
    for (const key of keys)
      if (!this.floors.has(key)) {
        const [x, z] = cellOffset(this.origin, parseCell(key)!),
          plane = new T.Mesh(this.floorGeometry, this.floor)
        plane.position.set(x, -0.56, z)
        this.studio.add(plane)
        this.floors.set(key, plane)
      }
    const visible = new Map(
      (data?.buildings ?? []).filter((b) => b.site && keys.has(b.site.cell)).map((b) => [b.id, b])
    )
    let changed = false
    for (const [id, record] of this.objects)
      if (!visible.has(id)) {
        this.structures.remove(record.object)
        this.objects.delete(id)
        changed = true
      }
    for (const b of visible.values()) {
      const site = b.site!,
        signature = JSON.stringify(site),
        record = this.objects.get(b.id)
      if (record?.signature === signature) continue
      const root = record?.object ?? estateModel(b.kind)
      if (!record) {
        const def = blueprints.get(b.kind)!,
          s = new T.Mesh(this.floorShadow, this.shade)
        s.scale.set(def.width * 1.4, def.depth * 1.45, 1)
        s.rotation.x = -Math.PI / 2
        s.position.y = 0.022
        s.userData.skipCollision = true
        root.add(s)
        this.structures.add(root)
      }
      const [x, z] = cellOffset(this.origin, parseCell(site.cell)!)
      root.position.set(x + site.x, 0, z + site.z)
      root.rotation.y = T.MathUtils.degToRad(site.angle)
      root.userData.business = b.id
      root.userData.cell=site.cell
      this.objects.set(b.id, { signature, object: root })
      changed = true
    }
    const working = (data?.crew ?? []).filter((w) => w.job && visible.has(w.job.building)),
      ids = new Set(working.map((w) => w.id))
    for (const [id, actor] of this.workers)
      if (!ids.has(id)) {
        actor.release()
        this.people.remove(actor.npc.object)
        this.workers.delete(id)
      }
    const counts = new Map<string, number>()
    for (const w of working) {
      const b: Building = visible.get(w.job!.building)!,
        site = b.site!,
        def = blueprints.get(b.kind)!
      const old = this.workers.get(w.id)
      if (old && old.look !== JSON.stringify(w.appearance)) {
        old.release()
        this.people.remove(old.npc.object)
        this.workers.delete(w.id)
      }
      const actor = this.workers.get(w.id) ?? employee(w, this.loadSkin)
      if (!this.workers.has(w.id)) {
        this.workers.set(w.id, actor)
        this.people.add(actor.npc.object)
      }
      const [x, z] = cellOffset(this.origin, parseCell(site.cell)!)
      const angle = T.MathUtils.degToRad(site.angle),
        side = (counts.get(b.id) ?? 0) === 0 ? -1 : 1
      counts.set(b.id, (counts.get(b.id) ?? 0) + 1)
      Object.assign(actor, {
        x: site.x + Math.sin(angle) * (def.depth / 2 + 1.4) + Math.cos(angle) * side * 1.7,
        z: site.z + Math.cos(angle) * (def.depth / 2 + 1.4) - Math.sin(angle) * side * 1.7,
        cellX: x,
        cellZ: z,
        side,
        angle,
        since: w.job!.since,
        sector: def.sector,
      })
    }
    return changed
  }
  private floorShadow = new T.PlaneGeometry(1, 1)
  tick(now: number) {
    for (const a of this.workers.values()) {
      const age = Math.max(0, (now - a.since) / 1000),
        approach = Math.max(0, 1 - age / 3),
        t = age % 12
      const pace = t > 8 ? Math.sin(((t - 8) * Math.PI) / 2) * 0.8 : 0,
        walking = approach > 0 || t > 8
      const x = a.x + Math.sin(a.angle) * approach * 4 + Math.cos(a.angle) * pace
      const z = a.z + Math.cos(a.angle) * approach * 4 - Math.sin(a.angle) * pace
      a.npc.object.position.set(
        a.cellX + T.MathUtils.clamp(x, -49.5, 49.5),
        0.025,
        a.cellZ + T.MathUtils.clamp(z, -49.5, 49.5)
      )
      a.npc.object.rotation.y = a.angle + Math.PI + (walking ? Math.sin(t) * 0.18 : 0)
      const swing = walking ? Math.sin(age * 8) * 0.57 : 0
      a.legs[0].rotation.x = swing
      a.legs[1].rotation.x = -swing
      const work = a.sector === 'farming' ? 0.8 : a.sector === 'craft' ? 0.6 : 0.3
      a.npc.arm.rotation.x = walking ? -swing : -0.52 + Math.sin(age * 3) * work
      a.other.rotation.x = walking ? swing : -0.38 - Math.sin(age * 3) * work * 0.55
      a.npc.head.rotation.z = Math.sin(age * 1.4) * 0.06
    }
  }
  dispose() {
    for (const w of this.workers.values()) w.release()
    this.shadow.dispose()
    this.shade.dispose()
    this.floorGeometry.dispose()
    this.floorShadow.dispose()
    this.floor.dispose()
    this.paper.dispose()
  }
}
