import L from 'leaflet'
import { request } from './room'
import type { ActivityDestination, PublicActivity } from './collab-types'
import { escapeHtml } from './ui'
import { gridLatitude, gridLongitude, parseCell } from './plot-grid'

export function activityLayer(map: L.Map, canOpen: (destination: ActivityDestination, cell: string) => boolean,
    open: (destination: ActivityDestination, cell: string) => void) {
  const group = L.layerGroup().addTo(map)
  let requestId = 0
  let timer = 0
  let closed = false
  let last = ''
  const aging = (when: number) => {
    const minutes = Math.max(0, Math.floor((Date.now() - when) / 60000))
    if (!minutes) return '刚刚'
    if (minutes < 60) return `${minutes} 分钟前`
    if (minutes < 1440) return `${Math.floor(minutes / 60)} 小时前`
    return `${Math.floor(minutes / 1440)} 天前`
  }
  async function render() {
    window.clearTimeout(timer)
    const id = ++requestId
    const bounds = map.getBounds()
    const zoom = map.getZoom()
    const search = new URLSearchParams({ zoom: String(zoom), west: String(bounds.getWest()), east: String(bounds.getEast()),
      north: String(bounds.getNorth()), south: String(bounds.getSouth()) })
    try {
      const entries = await request<PublicActivity[]>(`activity?${search}`)
      if (closed || id !== requestId) return
      const signature = JSON.stringify([zoom, Math.floor(Date.now() / 60_000), entries])
      if (signature === last) return
      last = signature
      group.clearLayers()
      for (const entry of entries) {
        const cell = parseCell(entry.key)
        if (!cell) continue
        const detail = zoom >= 17
        const offset = Math.round((entry.longitude - gridLongitude(cell.column)) / 360) * 360
        const position: L.LatLngTuple = detail
          ? [gridLatitude(cell.row + .19), gridLongitude(cell.column + .81) + offset]
          : [entry.latitude, entry.longitude]
        if(zoom>=15 && zoom<=18){
          L.rectangle([[gridLatitude(cell.row+1),gridLongitude(cell.column)+offset],[gridLatitude(cell.row),gridLongitude(cell.column+1)+offset]],{stroke:false,interactive:false,fillColor:entry.pixel??'#60a9b4',fillOpacity:.78}).addTo(group)
          if(!detail)continue
        }
        const count = detail ? '' : String(entry.plots)
        const tone = Date.now() - entry.last < 30 * 60_000 ? 'recent' : 'older'
        const size = detail ? 14 : Math.min(50, 24 + Math.log2(Math.max(1, entry.plots)) * 5)
        const icon = L.divIcon({
          className: 'activity-pin', iconSize: [size, size], iconAnchor: [size / 2, size / 2],
          html: `<span class="activity-marker ${tone}" style="--pin-size:${size}px">${count}</span>`,
        })
        const label = detail
          ? `${escapeHtml(entry.latest)} · ${aging(entry.last)}更新`
          : `${entry.plots} 块地 · ${entry.builders} 位建造者`
        const marker = L.marker(position, { icon, title: label }).addTo(group)
        marker.bindTooltip(label)
        marker.on('click', () => {
          if (!detail) { map.setView(position, Math.min(17, zoom + 2)); return }
          const popup = document.createElement('div')
          const title = document.createElement('strong')
          title.textContent = '这个坐标的公开地块'
          popup.append(title)
          for (const destination of entry.destinations ?? []) {
            const line = document.createElement('p')
            line.textContent = `${destination.name} · ${destination.latest} · ${aging(destination.last)}更新`
            if (canOpen(destination, entry.key)) {
              const enter = document.createElement('button')
              enter.type = 'button'
              enter.className = 'secondary activity-open'
              enter.textContent = `进入${destination.name}`
              enter.onclick = () => open(destination, entry.key)
              line.append(' ', enter)
            } else line.append(' · 需要邀请')
            popup.append(line)
          }
          marker.bindPopup(popup).openPopup()
        })
      }
    } catch {
      // Keep the last public map markers while the server reconnects.
    } finally {
      if (!closed && id === requestId) timer = window.setTimeout(render, 4500)
    }
  }
  map.on('moveend zoomend', render)
  void render()
  return () => {
    closed = true
    window.clearTimeout(timer)
    map.off('moveend zoomend', render)
    group.remove()
  }
}
