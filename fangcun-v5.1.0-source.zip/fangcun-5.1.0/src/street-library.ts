import roadEntries from './street-assets.json'
import { icons } from './ui'

const categories = ['小摆件', '地板底图', '整体建筑', '功能性道具'] as const
type Entry = { name: string; category: typeof categories[number]; tags: string[]; file?: string; assetId?: string }

const entries: Entry[] = [
  { name: '夜町便利店', category: '整体建筑', tags: ['商店', '带内装', '独立建筑'], file: 'mart', assetId: '439629f2-b466-5b77-b5c3-49b1d433c526' },
  { name: '通勤自行车', category: '小摆件', tags: ['街边', '交通', '金属'], file: 'bicycle', assetId: '4d844284-75a7-5840-aa19-d44bc8232d2a' },
  { name: '分类垃圾桶', category: '小摆件', tags: ['店前', '环卫'], file: 'bins', assetId: '19b07bb1-8c5c-5493-b5ae-2659bc0b2797' },
  { name: '门口伞架', category: '小摆件', tags: ['店前', '金属'], file: 'umbrellas', assetId: 'a1560efb-42bf-5ec1-92c1-1b4e1813a8ce' },
  { name: '社区公告栏', category: '小摆件', tags: ['街边', '标识'], file: 'board', assetId: '671fc8b4-470f-54db-bfd7-ff6f4d5fa8f5' },
  ...roadEntries.map(entry => ({ ...entry, category: '地板底图' as const })),
  { name: '街角路灯', category: '功能性道具', tags: ['街边', '可开关', '照明'] },
  { name: '饮料售货机', category: '功能性道具', tags: ['店前', '购买饮料'] },
]

export const freeAssetIds = new Set(entries.map(entry => entry.assetId).filter(Boolean))
export const libraryMarkup = `<dialog id="street-library" class="app-dialog street-library" aria-labelledby="street-title">
<header class="dialog-heading"><span class="dialog-icon">${icons.layers}</span><div><small>素材库</small><h2 id="street-title">日式街区</h2></div><button type="button" class="icon-button" data-close aria-label="关闭素材库">${icons.close}</button></header>
<input type="search" placeholder="搜索名称或标签" aria-label="搜索名称或标签">
<nav aria-label="素材分类">${['全部', ...categories].map(c => `<button data-category="${c}" aria-pressed="${c === '全部'}">${c}</button>`).join('')}</nav>
<div class="street-library-meta"><p data-count aria-live="polite"></p><a data-road-download href="${import.meta.env.BASE_URL}downloads/fangcun-streets-v2.zip" download hidden>下载街道素材包</a></div><div class="street-results"></div></dialog>`

export function mountStreetLibrary(dialog: HTMLDialogElement, choose: (file: string, name: string, assetId: string) => void) {
  let category = '全部'
  const search = dialog.querySelector('input')!
  const results = dialog.querySelector<HTMLElement>('.street-results')!
  function render() {
    const words = search.value.trim().toLowerCase().split(/\s+/)
    const filtered = entries.filter(e => (category === '全部' || e.category === category) &&
      words.every(word => [e.name, e.category, ...e.tags].join(' ').toLowerCase().includes(word)))
    dialog.querySelector('[data-count]')!.textContent = `${filtered.length} 项素材 · ${filtered.filter(e => e.file).length} 项可放置`
    dialog.querySelector<HTMLAnchorElement>('[data-road-download]')!.hidden = category !== '地板底图'
    results.innerHTML = filtered.map(e => `<article class="street-card">
      ${e.file ? `<img src="${import.meta.env.BASE_URL}street/${e.file}.webp" alt="${e.name}模型预览">` : ''}
      <div><small>${e.category}</small><h3>${e.name}</h3><p>${e.tags.join(' · ')}</p>
      ${e.file ? `<button class="secondary" data-file="${e.file}">连续放置</button>` : '<small class="street-planned">待制作</small>'}</div></article>`).join('') || '<p>未找到匹配素材，试试其他名称或标签。</p>'
  }
  search.oninput = render
  dialog.onclick = event => {
    const button = (event.target as Element).closest('button')
    if (!button) return
    if (button.hasAttribute('data-close')) dialog.close()
    if (button.dataset.category) {
      category = button.dataset.category
      dialog.querySelectorAll('[data-category]').forEach(b => b.setAttribute('aria-pressed', String(b === button)))
      render()
    }
    const entry = entries.find(e => e.file && e.file === button.dataset.file)
    if (entry?.file && entry.assetId) { dialog.close(); choose(entry.file, entry.name, entry.assetId) }
  }
  return () => { render(); dialog.showModal(); search.focus() }
}
