import { assetStorageKey, getAsset, putAsset, newId, type AssetKind, type Plot, type SceneData } from './data'
import { sceneAssets, type Role, type RoomAccess, type RoomView, type SceneChange } from './collab-types'

export const roleNames: Record<Role, string> = { owner: '地块主人', edit: '共建成员', view: '访客' }

export class RoomRequestError extends Error {
  constructor(message: string, public status: number) { super(message) }
}

export async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`/collab/${path}`, { cache: 'no-store', signal: AbortSignal.timeout(25000), ...init })
  const value = await response.json().catch(() => null)
  if (!response.ok) throw new RoomRequestError(value?.error ?? '房间服务暂时不可用。', response.status)
  if (!value) throw new Error('房间服务暂时不可用。')
  return value as T
}
export const payload = (value: unknown): RequestInit => ({
  method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(value),
})

export async function createRoom(plot: Plot) {
  return new RoomClient(await request<RoomAccess>('create', payload({ plot })))
}
export async function joinRoom(room: string, invite: string) {
  return new RoomClient(await request<RoomAccess>(`${room}/join`, payload({ invite })))
}

export class RoomClient {
  latest?: RoomView
  private peer = newId()
  private available = new Set<string>()

  constructor(readonly access: RoomAccess) {}

  private headers(headers: HeadersInit = {}) {
    const result = new Headers(headers)
    result.set('Authorization', `Bearer ${this.access.token}`)
    result.set('X-Fangcun-Peer', this.peer)
    const nickname = localStorage.getItem('fangcun.builder-name')
    if (nickname) result.set('X-Fangcun-Name', encodeURIComponent(nickname.slice(0, 24)))
    return result
  }
  private call<T>(action: string, init: RequestInit = {}) {
    return request<T>(`${this.access.room}/${action}`, { ...init, headers: this.headers(init.headers) })
  }
  async read(trackOnline = true) {
    const headers = this.headers()
    if (!trackOnline) headers.delete('X-Fangcun-Peer')
    const view = await request<RoomView>(`${this.access.room}/state`, { headers })
    if (!this.latest || view.version >= this.latest.version) this.latest = view
    return this.latest
  }
  observe(listener: (value: RoomView | undefined) => void) {
    let stop = false
    let timer = 0
    const poll = async () => {
      try {
        const value = await this.read()
        if (!stop) listener(value)
      } catch {
        if (!stop) listener(undefined)
      } finally {
        if (!stop) timer = window.setTimeout(poll, 550)
      }
    }
    void poll()
    return () => { stop = true; window.clearTimeout(timer) }
  }

  async publish(changes: SceneChange[], expectEmpty = false) {
    if (!changes.length) return
    const combined: SceneData = { items: changes.flatMap(change => (change.collection === 'items' || change.collection === 'models') && change.after ? [change.after] : []), models: [] }
    for (const { id, kind } of sceneAssets(combined)) {
      const localKey = assetStorageKey(id, kind)
      if (this.available.has(localKey)) continue
      const data = await this.downloadAsset(id, kind)
      if (!data) {
        const local = await getAsset(localKey)
        if (!local) throw new Error(kind === 'png' ? '有一张 NPC 皮肤不在本机，无法提交。' : '有一个 GLB 文件不在本机，无法提交。')
        await this.call(`${kind === 'png' ? 'skin' : 'asset'}/${id}`, { method: 'PUT', body: local })
      }
      this.available.add(localKey)
    }
    const view = await this.call<RoomView>('state', payload({ changes, expectEmpty }))
    if (!this.latest || view.version >= this.latest.version) this.latest = view
  }

  async downloadAsset(id: string, kind: AssetKind = 'glb') {
    const response = await fetch(`/collab/${this.access.room}/${kind === 'png' ? 'skin' : 'asset'}/${id}`, { headers: this.headers(), cache: 'no-store' })
    if (response.status === 404) return undefined
    if (!response.ok) throw new RoomRequestError(kind === 'png' ? '无法读取房间皮肤。' : '无法读取房间模型。', response.status)
    const data = await response.arrayBuffer()
    const localKey = assetStorageKey(id, kind)
    this.available.add(localKey)
    try { await putAsset(localKey, data) } catch { /* Can still render with the in-memory copy. */ }
    return data
  }

  async listing(enabled: boolean) {
    const updated = await this.call<RoomView>('listing', payload({ enabled }))
    this.latest = updated
    return updated
  }

  async invite(grant: 'view' | 'edit') {
    const { invite } = await this.call<{ invite: string }>('invite', payload({ grant }))
    const url = new URL(location.pathname, location.origin)
    url.hash = new URLSearchParams({ room: this.access.room, invite }).toString()
    return url.href
  }
  async revokeEditing() {
    await this.call('revoke-edit', { method: 'POST' })
  }
}
