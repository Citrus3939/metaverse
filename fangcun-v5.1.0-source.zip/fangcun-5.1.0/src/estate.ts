export type Sector = 'commerce' | 'farming' | 'craft'
export const sectorNames = { commerce: '商业', farming: '农业', craft: '手工业' }
export const goodsNames = { commerce: '街市货品', farming: '鲜收作物', craft: '工艺制品' }
export const GOOD_PRICE = 8
export const LAND_PRICE = 240
export const DRAW_PRICE = 100
export const START_COINS = 800
export const STAFF_LIMIT = 2
export const SHOP_LIMIT = 3
export const profileTags = ['街区建筑师', '农场主', '商人', '收藏家', '摄影师']
export const crewNames = ['小禾', '阿青', '铃音', '阿洛', '小满']
export type Blueprint = {
  id: string
  name: string
  theme: string
  tags: string[]
  sector: Sector
  rare: boolean
  price: number
  rate: number
  width: number
  depth: number
  ink: string
  paper: string
}
export const catalog: Blueprint[] = [
  {
    id: 'kissaten',
    tags: ['咖啡', '街角店铺', '餐饮'],
    name: '灯街喫茶店',
    theme: '日式街角',
    sector: 'commerce',
    rare: false,
    price: 120,
    rate: 2,
    width: 13,
    depth: 10,
    ink: '#73554e',
    paper: '#efd6b5',
  },
  {
    id: 'teagarden',
    tags: ['茶园', '种植', '户外'],
    name: '南山茶圃',
    theme: '中式古镇',
    sector: 'farming',
    rare: false,
    price: 100,
    rate: 2,
    width: 15,
    depth: 12,
    ink: '#48695e',
    paper: '#cee2c3',
  },
  {
    id: 'atelier',
    tags: ['钟表', '工匠', '临街工坊'],
    name: '钟巷工坊',
    theme: '欧式小镇',
    sector: 'craft',
    rare: false,
    price: 140,
    rate: 2,
    width: 13,
    depth: 11,
    ink: '#45576c',
    paper: '#ccdae4',
  },
  {
    id: 'onsen',
    tags: ['温泉', '旅宿', '双层'],
    name: '月见汤屋',
    theme: '日式街角',
    sector: 'commerce',
    rare: true,
    price: 0,
    rate: 3,
    width: 16,
    depth: 12,
    ink: '#624d68',
    paper: '#e6cddd',
  },
  {
    id: 'pavilion',
    tags: ['陶瓷', '窑炉', '庭院'],
    name: '青瓷窑坊',
    theme: '中式古镇',
    sector: 'craft',
    rare: true,
    price: 0,
    rate: 3,
    width: 16,
    depth: 12,
    ink: '#356a6c',
    paper: '#c3dfd7',
  },
  {
    id: 'windmill',
    tags: ['磨坊', '谷物', '风车'],
    name: '金穗风车磨坊',
    theme: '欧式小镇',
    sector: 'farming',
    rare: true,
    price: 0,
    rate: 3,
    width: 15,
    depth: 13,
    ink: '#806147',
    paper: '#eeddb4',
  },
]
export const blueprints = new Map(catalog.map((item) => [item.id, item]))
export type Site = { room: string; cell: string; x: number; z: number; angle: number; active?: boolean }
export type Building = { id: string; kind: string; owner: string; site?: Site }
export type AgentJob = { building: string; since: number }
export type Crew = {
  id: string
  owner: string
  name: string
  job?: AgentJob
  appearance?: { body: 'classic' | 'slim'; skin?: string; persona: string }
}
export type Profile = { id: string; name: string; tags: string[] }
export type Goods = Record<Sector, number>
export type Offer = {
  id: string
  seller: string
  label: string
  price: number
  type: 'asset' | 'land' | 'goods'
  ref: string
  qty: number
  region?: string
}
export type ChatLine = { id: string; by: string; name: string; text: string; at: number; ai?: boolean }
export type EstateView = {
  revision: number
  coins: number
  goods: Goods
  misses: number
  tags: string[]
  profiles: Profile[]
  inventory: Building[]
  buildings: Building[]
  crew: Crew[]
  offers: Offer[]
  chat: ChatLine[]
}
export type EstateCommand =
  | { type: 'buy'; kind: string }
  | { type: 'draw' }
  | { type: 'position'; id:string; cell:string; x:number; z:number; angle:number; before: Pick<Site,'cell'|'x'|'z'|'angle'> | null }
  | { type:'operate'; id:string; cell:string; active:boolean }
  | { type: 'place'; id: string; cell: string; x: number; z: number; angle: number; active?: boolean }
  | { type: 'store'; id: string }
  | { type: 'work'; staff: string; building?: string }
  | { type: 'chat'; text: string; staff?: string; reply?: string; cell?: string; work?: string | null }
  | { type: 'recruit'; staff: string; cell: string; npc: string }
  | { type: 'profile'; tags: string[] }
  | { type: 'pay'; to: string; amount: number }
  | { type: 'redeem'; kind: Sector; qty: number }
  | { type: 'list'; assetType: Offer['type']; ref: string; price: number; qty?: number }
  | { type: 'cancel' | 'take'; id: string }

export function buildingRate(building: Building, buildings: Building[], crew: Crew[], neighbors: Set<string>) {
  if (building.site?.active === false) return 0
  const base = blueprints.get(building.kind)!
  const peers = buildings.filter(
    (b) => b.id !== building.id && b.site && b.site.active !== false && blueprints.get(b.kind)?.sector === base.sector
  )
  const local = Math.min(2, peers.filter((b) => b.site!.room === building.site!.room).length)
  const adjacent = new Set(peers.filter((b) => neighbors.has(b.site!.room)).map((b) => b.site!.room)).size
  const staff = crew.filter((w) => w.job?.building === building.id).length
  return base.rate * (1 + local * 0.25 + adjacent * 0.15 + staff * 0.5)
}
