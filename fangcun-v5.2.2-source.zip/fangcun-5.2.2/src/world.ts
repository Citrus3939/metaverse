import { estateModel } from './estate-models'
import { nearestBuildingSite } from './building-site'
import type { WorkbenchView, WorkspaceMode } from './workbench'
import { EstateScene } from './estate-scene'
import { blueprints, type EstateView } from './estate'
import * as T from 'three'
import { StreetNetwork } from './street-network'
import type { StreetSide } from './data'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
import { TransformControls } from 'three/addons/controls/TransformControls.js'
import { DRACOLoader, DRACO_GLTF_CONFIG } from 'three/addons/loaders/DRACOLoader.js'
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js'
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js'
import { clone } from 'three/addons/utils/SkeletonUtils.js'
import { getAsset, type AssetKind, type Item, type Plot, type Primitive, type Vec, type Save } from './data'
import { WalkCollision, loadPhysics } from './collision'
import { addDefaultHumanoidClips, animationPair, blockCharacter, CharacterAnimation, type Character } from './character'

import { BUILD_GRID_STEP, cellAtLocal, cellKey, cellOffset, parseCell, type PlotCell } from './plot-grid'
import { ContextGround } from './context-ground'
import type { Presence, PresenceUpdate, RegionView } from './collab-types'
import type { RegionClient } from './region'
import { loadSkin, npcVisual, skinCharacter, type NpcVisual } from './npc'

const FRONT_ELEVATION = T.MathUtils.degToRad(30)
const FRONT_POLAR = Math.PI / 2 - FRONT_ELEVATION
const FRONT_SWAY = Math.PI / 18

const geometry: Record<Primitive, T.BufferGeometry> = {
  box: new T.BoxGeometry(1, 1, 1),
  cylinder: new T.CylinderGeometry(.5, .5, 1, 32),
  sphere: new T.SphereGeometry(.5, 32, 24),
}
const assets = new Map<string, Promise<T.Object3D>>()
const resolvedAssets = new Map<string, T.Object3D>()
let remoteAsset: ((id: string, kind: AssetKind) => Promise<ArrayBuffer | undefined>) | undefined
export function setAssetProvider(provider?: typeof remoteAsset) { remoteAsset = provider }

export async function prepareItemAssets(item: Item, fallback?: typeof remoteAsset): Promise<void> {
  if (item.kind === 'glb') { await asset(item.asset!, fallback); return }
  if (item.kind === 'npc') {
    const provider = fallback ?? remoteAsset
    await loadSkin(item.asset!, provider ? () => provider(item.asset!, 'png') : undefined)
    return
  }
  if (item.children) await Promise.all(item.children.map(child => prepareItemAssets(child, fallback)))
}

async function readGlb(data: ArrayBuffer) {
  if (data.byteLength < 20) throw new Error('文件不是有效的 GLB。')
  const header = new DataView(data)
  if (header.getUint32(0, true) !== 0x46546c67 || header.getUint32(4, true) !== 2 || header.getUint32(8, true) !== data.byteLength || header.getUint32(16, true) !== 0x4e4f534a) {
    throw new Error('请选择有效的 GLB 2.0 文件。')
  }
  const json = JSON.parse(new TextDecoder().decode(new Uint8Array(data, 20, header.getUint32(12, true))))
  const resources: { uri?: string }[] = [...(json.buffers ?? []), ...(json.images ?? [])]
  if (resources.some(resource => resource.uri && !/^data:/i.test(resource.uri))) throw new Error('此 GLB 引用了外部资源，请重新导出为自包含文件。')
  const draco = new DRACOLoader().setDecoderPath(DRACO_GLTF_CONFIG)
  const loader = new GLTFLoader().setDRACOLoader(draco).setMeshoptDecoder(MeshoptDecoder)
  const result = await loader.parseAsync(data, '').finally(() => draco.dispose())
  result.scene.traverse(node => {
    if (!(node instanceof T.Mesh) || ![1, 2].includes(node.userData.streetLayer)) return
    const layer = node.userData.streetLayer
    node.renderOrder = layer
    for (const material of Array.isArray(node.material) ? node.material : [node.material]) {
      material.polygonOffset = true
      material.polygonOffsetFactor = -layer
      material.polygonOffsetUnits = -layer * 4
    }
  })
  const bounds = new T.Box3().setFromObject(result.scene, true)
  if (bounds.isEmpty() || ![...bounds.min, ...bounds.max].every(Number.isFinite)) throw new Error('GLB 中没有可显示的有效几何体。')
  const center = bounds.getCenter(new T.Vector3())
  const normalized = new T.Group()
  const offset = new T.Group()
  offset.position.copy(center).negate()
  offset.add(result.scene)
  normalized.add(offset)
  normalized.updateMatrixWorld(true)
  return { object: normalized, clips: result.animations }
}

export async function parseGlb(data: ArrayBuffer) {
  return (await readGlb(data)).object
}

export async function parseCharacter(data: ArrayBuffer): Promise<Character> {
  const character = await readGlb(data)
  let skinned = false
  character.object.traverse(node => { if (node instanceof T.SkinnedMesh && node.skeleton.bones.length) skinned = true })
  if (!skinned) throw new Error('角色 GLB 需要绑定骨骼与蒙皮。')
  addDefaultHumanoidClips(character)
  if (!animationPair(character.clips)) throw new Error('未识别出左右腿骨。请添加 Idle 和 Walk 原地动画后再导入。')
  const bounds = boundsOf(character.object)
  const height = bounds.max.y - bounds.min.y
  if (height <= .001) throw new Error('角色模型高度无效。')
  const scale = 1.86 / height
  character.object.scale.setScalar(scale)
  character.object.position.y = -bounds.min.y * scale
  return character
}

export function rememberAsset(id: string, object: T.Object3D) {
  resolvedAssets.set(id, object)
  assets.set(id, Promise.resolve(object))
}
async function asset(id: string, fallback = remoteAsset) {
  let result = assets.get(id)
  if (!result) {
    result = getAsset(id).then(local => local ?? fallback?.(id, 'glb')).then(async data => {
      if (!data) throw new Error('GLB 文件缺失。')
      const object = await parseGlb(data)
      resolvedAssets.set(id, object)
      return object
    })
    assets.set(id, result)
    result.catch(() => assets.delete(id))
  }
  return result
}

export function applyItem(object: T.Object3D, item: Item) {
  object.position.fromArray(item.position)
  object.rotation.set(...item.rotation)
  object.scale.fromArray(item.scale)
  if (item.color && object instanceof T.Mesh) object.material.color.set(item.color)
  object.updateWorldMatrix(true, true)
}

export function buildItem(item: Item, onLoaded: () => void, onError: (error: unknown) => void, fallback?: typeof remoteAsset): T.Object3D {
  let object: T.Object3D
  if (item.kind === 'group') {
    object = new T.Group()
    object.add(...(item.children ?? []).map(child => buildItem(child, onLoaded, onError, fallback)))
  } else if (item.kind === 'glb') {
    const root = new T.Group()
    object = root
    const cached = resolvedAssets.get(item.asset!)
    if (cached) root.add(clone(cached))
    else void asset(item.asset!, fallback).then(source => {
      root.add(clone(source))
      onLoaded()
    }).catch(onError)
  } else if (item.kind === 'npc') {
    object = new T.Group()
    const visual = npcVisual(item.npc!.body)
    object.add(visual.object)
    object.userData.npc = { item, visual, waveUntil: 0 } satisfies NpcActor
    const provider = fallback ?? remoteAsset
    void loadSkin(item.asset!, provider ? () => provider(item.asset!, 'png') : undefined).then(image => {
      if (visual.setSkin(image)) onLoaded()
    }).catch(onError)
  } else {
    object = new T.Mesh(geometry[item.kind], new T.MeshStandardMaterial({ color: item.color ?? '#6ea98b', roughness: .82 }))
    object.userData.ownMaterial = true
  }
  object.userData.itemId = item.id
  applyItem(object, item)
  return object
}

type NpcActor = { item: Item; visual: NpcVisual; waveUntil: number }

function releaseItem(root: T.Object3D) {
  root.traverse(node => {
    const npc = node.userData.npc as NpcActor | undefined
    npc?.visual.dispose()
    if (node instanceof T.Mesh && node.userData.ownMaterial) node.material.dispose()
  })
}

export function boundsOf(object: T.Object3D) {
  return new T.Box3().setFromObject(object, true)
}
export function fits(bounds: T.Box3, plot: Plot) {
  const tolerance = 1e-6
  return !bounds.isEmpty() && bounds.min.x >= -plot.width / 2 - tolerance && bounds.max.x <= plot.width / 2 + tolerance
    && bounds.min.z >= -plot.depth / 2 - tolerance && bounds.max.z <= plot.depth / 2 + tolerance
}

const MOVEMENT = new Set(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowLeft', 'ArrowDown', 'ArrowRight', 'ShiftLeft', 'ShiftRight'])

type WorldCallbacks = {
  moveBusiness:(id:string,x:number,z:number)=>void
  cell:(key:string)=>void
  moveItem:(source:string,item:Item,to:{cell:string;x:number;z:number})=>void
  business:(id:string)=>void
  select: (id: string | undefined, multiple: boolean) => void
  preview: (id: string, values: Pick<Item, 'position' | 'rotation' | 'scale'>, valid: boolean) => void
  commit: (id: string) => void
  loaded: () => void
  error: (message: string) => void
  walking: (position: T.Vector3, blocked: boolean) => void
  level: (enabled: boolean) => void
  mapContext: (provider?: 'hot' | 'esri' | 'osm') => void
}

export class World {
  private renderer: T.WebGLRenderer
  private scene = new T.Scene()
  private camera = new T.OrthographicCamera(-1, 1, 1, -1, .001, 1000)
  private orbit: OrbitControls
  private transform: TransformControls
  private boundary: T.LineLoop<T.BufferGeometry, T.LineBasicMaterial>
  private neighboringGrids=new T.Group()
  private gridSignature=''
  private plan=false
  private pickedShop=''
  selectBusiness(id:string){this.pickedShop=id}
  private neighborDrag?:{object:T.Object3D;point:T.Vector3;origin:T.Vector3;source:string;item:Item}
  private brush?:{x:number;z:number;first:boolean}
  private shopDrag?:{root:T.Object3D;origin:T.Vector3;point:T.Vector3}
  private groundGrid: T.LineSegments<T.BufferGeometry, T.LineBasicMaterial>
  private streets = new StreetNetwork()
  private streetSides: StreetSide[] = []
  private models = new T.Group()
  private items = new Map<string, T.Object3D>()
  private selected: string[] = []
  private selectionBox = new T.Box3()
  private outlineDirty = true
  private outline = new T.Box3Helper(this.selectionBox, '#3b8c62')
  private player = new T.Group()
  private character = blockCharacter()
  private animator = new CharacterAnimation(this.character)
  private collision?: WalkCollision
  private collisionDirty = true
  private closed = false
  private observe = false
  private editable = true
  private ground: ContextGround
  private origin: PlotCell
  private region?: { view: RegionView; client: RegionClient }
  private incoming = new Map<string, { version: number; root: T.Group; streets?: StreetSide[] }>()
  private loadingNeighbors = new Map<string, number>()
  private wantedNeighbors = new Set<string>()
  private estateScene: EstateScene
  private economy?: EstateView
  private atmosphere: 'dawn' | 'dusk' | 'map' = 'dawn'
  private regionObjects = new T.Group()
  private markers = new Map<string, ReturnType<World['makeMarker']>>()
  private people = new T.Group()
  private contextCell: PlotCell
  private corners: T.Points<T.BufferGeometry, T.PointsMaterial>
  private level?: { id: string; yaw: number; bank: number; x: number; y: number }
  private viewBeforeObserve?: { camera: T.Vector3; target: T.Vector3; zoom: number; frustum: number }
  private playerScale
  private keys = new Set<string>()
  private frame = 0
  private time = 0
  private fitSize = 1
  private frustum = 1
  private observer: ResizeObserver
  private listeners = new AbortController()
  private walk = false
  private placement?: { territory:boolean; paving: boolean; rotatable:boolean; object: T.Object3D; confirm: (position: Vec, yaw: number,first?:boolean) => void }
  private ray = new T.Raycaster()
  private direct?: { id: string; x: number; y: number; offset: T.Vector3; pickY: number; moved: boolean }
  private startClick?: { x: number; y: number; business?:string; item?:string }
  private savedView?: { camera: T.Vector3; target: T.Vector3; zoom: number }
  private size: number

  constructor(private host: HTMLElement, readonly plot: Plot, private callbacks: WorldCallbacks) {
    this.renderer = new T.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' })
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
    this.renderer.setClearColor(0x000000, 0)
    host.append(this.renderer.domElement)
    this.renderer.domElement.setAttribute('aria-label', '3D 地块视口')
    this.size = Math.max(plot.width, plot.depth)
    this.playerScale = Math.min(1, Math.min(plot.width, plot.depth) / 2.6)
    this.player.scale.setScalar(this.playerScale)
    this.player.add(this.character.object)
    this.player.visible = false
    this.scene.add(this.player, this.models, this.streets.root)
    this.scene.add(new T.HemisphereLight('#fffdf3', '#9aaea0', 2.15))
    const sun = new T.DirectionalLight('#fff6d8', 2.1)
    sun.position.set(4, 9, 5)
    this.scene.add(sun)
    this.origin = this.contextCell = plot.cell!
    this.estateScene=new EstateScene(this.origin)
    this.scene.add(this.estateScene.structures,this.estateScene.people,this.estateScene.studio)
    this.estateScene.studio.visible=false
    this.estateScene.display(undefined,[])
    this.ground = new ContextGround(callbacks.mapContext, this.renderer.capabilities.getMaxAnisotropy())
    this.scene.add(this.ground.object, this.regionObjects, this.people)
    if(host.classList.contains('unclaimed'))this.setSharedGround()
    void this.ground.show(this.origin, 0, 0)

    const x = plot.width / 2, z = plot.depth / 2, lineY = Math.min(x, z) * .00055
    const vertices = [new T.Vector3(-x, lineY, -z), new T.Vector3(x, lineY, -z), new T.Vector3(x, lineY, z), new T.Vector3(-x, lineY, z)]
    this.boundary = new T.LineLoop(new T.BufferGeometry().setFromPoints(vertices), new T.LineBasicMaterial({ color: '#285b45' }))
    this.scene.add(this.boundary)
    this.corners = new T.Points(new T.BufferGeometry().setFromPoints(vertices), new T.PointsMaterial({ color: '#285b45', size: 5, sizeAttenuation: false }))
    this.scene.add(this.corners)
    const gridPoints: number[] = []
    for (let i = -x + BUILD_GRID_STEP; i < x; i += BUILD_GRID_STEP) gridPoints.push(i, lineY, -z, i, lineY, z)
    for (let i = -z + BUILD_GRID_STEP; i < z; i += BUILD_GRID_STEP) gridPoints.push(-x, lineY, i, x, lineY, i)
    const grid = new T.BufferGeometry().setAttribute('position', new T.Float32BufferAttribute(gridPoints, 3))
    this.groundGrid = new T.LineSegments(grid, new T.LineBasicMaterial({ color: '#567160' }))
    this.scene.add(this.groundGrid,this.neighboringGrids)
    this.applyTheme()

    this.outline.visible = false
    this.scene.add(this.outline)
    const canvas = this.renderer.domElement
    this.orbit = new OrbitControls(this.camera, canvas)
    this.orbit.addEventListener('change', () => this.updateGroundDetail())
    this.orbit.enableDamping = true
    this.orbit.maxPolarAngle = Math.PI * .49
    this.orbit.mouseButtons = { LEFT: T.MOUSE.PAN, MIDDLE: T.MOUSE.PAN, RIGHT: T.MOUSE.ROTATE }
    this.orbit.minZoom = .06
    this.orbit.maxZoom = Math.max(60, this.size / Math.max(.05, this.playerScale))
    this.transform = new TransformControls(this.camera, canvas)
    this.transform.setSize(.82)
    this.transform.setSpace('local')
    this.scene.add(this.transform.getHelper())
    this.transform.addEventListener('dragging-changed', event => { this.orbit.enabled = !event.value })
    this.transform.addEventListener('objectChange', () => { if (this.activeId) this.publishPreview(this.activeId) })
    this.transform.addEventListener('mouseUp', () => { if (this.activeId) this.callbacks.commit(this.activeId) })

    const { signal } = this.listeners
    canvas.addEventListener('mousedown', this.levelDown, { signal })
    window.addEventListener('mouseup', this.levelUp, { signal })
    window.addEventListener('fangcun-theme', () => this.applyTheme(), { signal })
    canvas.addEventListener('contextmenu', event => event.preventDefault(), { signal })
    canvas.addEventListener('pointerdown', this.pointerDown, { signal,capture:true })
    canvas.addEventListener('pointermove', this.pointerMove, { signal })
    canvas.addEventListener('pointerup', this.pointerUp, { signal })
    canvas.addEventListener('pointercancel', this.cancelPointer, { signal })
    window.addEventListener('keydown', this.keyDown, { signal })
    window.addEventListener('keyup', this.keyUp, { signal })
    window.addEventListener('blur', () => { this.keys.clear(); this.finishLevel() }, { signal })

    this.resize()
    this.observer = new ResizeObserver(() => this.resize())
    this.observer.observe(host)
    this.fit()
    this.frame = requestAnimationFrame(this.tick)
  }

  get snapStep() { return BUILD_GRID_STEP }
  private get activeId() { return this.selected.length === 1 ? this.selected[0] : undefined }

  private updateGroundDetail() {
    this.ground.detail(this.host.clientHeight * this.renderer.getPixelRatio() * this.camera.zoom / this.frustum)
  }

  private resize() {
    const width = Math.max(1, this.host.clientWidth), height = Math.max(1, this.host.clientHeight)
    this.renderer.setSize(width, height)
    const aspect = width / height
    this.camera.left = -this.frustum * aspect / 2
    this.camera.right = -this.camera.left
    this.camera.top = this.frustum / 2
    this.camera.bottom = -this.camera.top
    this.camera.updateProjectionMatrix()
    this.updateGroundDetail()
  }

  fit() {
    this.resetOrbitDamping()
    const bottom = 0
    const content = this.observe ? boundsOf(this.models) : undefined
    const top = content ? Math.max(0, content.max.y) : 0
    const footprint=new T.Box3(new T.Vector3(-this.plot.width/2,0,-this.plot.depth/2),new T.Vector3(this.plot.width/2,0,this.plot.depth/2))
    if(!this.observe && this.region)for(const tile of this.region.view.tiles){
      if(tile.owner!==this.region.view.member)continue
      const [x,z]=cellOffset(this.origin,parseCell(tile.key)!)
      footprint.expandByPoint(new T.Vector3(x-this.plot.width/2,0,z-this.plot.depth/2))
      footprint.expandByPoint(new T.Vector3(x+this.plot.width/2,0,z+this.plot.depth/2))
    }
    footprint.getCenter(this.orbit.target)
    this.orbit.target.y=content?(bottom+top)/2:0
    if (this.observe) this.camera.position.set(0, Math.sin(FRONT_ELEVATION), Math.cos(FRONT_ELEVATION)).multiplyScalar(this.size * 2)
    else this.camera.position.set(.9, .86, 1.12).multiplyScalar(this.size * 2)
    this.camera.position.add(this.orbit.target)
    this.camera.near = Math.max(.00001, this.size * .000002)
    this.camera.far = this.size * 28
    this.camera.zoom = 1
    this.orbit.update()
    this.camera.updateMatrixWorld(true)
    const v = new T.Vector3()
    let horizontal = 0, vertical = 0
    for (const x of [footprint.min.x,footprint.max.x]) {
      for (const z of [footprint.min.z,footprint.max.z]) {
        for (const y of [bottom, top]) {
          v.set(x, y, z).applyMatrix4(this.camera.matrixWorldInverse)
          horizontal = Math.max(horizontal, Math.abs(v.x))
          vertical = Math.max(vertical, Math.abs(v.y))
        }
      }
    }
    const aspect = Math.max(.25, this.host.clientWidth / Math.max(1, this.host.clientHeight))
    this.frustum = 2.65 * Math.max(vertical, horizontal / aspect)
    this.fitSize = this.frustum
    this.resize()
  }

  private refreshStreets() {
    this.streets.refresh([{ x: 0, z: 0, streets: this.streetSides }, ...Array.from(this.incoming.values(),
      block => ({ x: block.root.position.x, z: block.root.position.z, streets: block.streets }))])
  }
  streetConflict(side: StreetSide) {
    if (this.loadingNeighbors.size || [...this.wantedNeighbors].some(key => !this.incoming.has(key))) return '正在读取相邻地块，请稍后再试。'
    const band = new T.Box3(new T.Vector3(side === 'east' ? 45 : -55, -1, side === 'south' ? 45 : -55),
      new T.Vector3(55, 10, 55))
    for (const root of [this.models, ...Array.from(this.incoming.values(), item => item.root)]) {
      for (const obj of root.children) {
        const box = boundsOf(obj)
        if (box.isEmpty()) return '物件尚未加载完成，暂时无法检查路带。'
        if (!box.intersectsBox(band)) continue
        let solid = false
        obj.traverse(node => { if (node instanceof T.Mesh && !node.userData.skipCollision) solid = true })
        if (solid) return '预定路带内有场景物件，请先移动物件。'
      }
    }
    return ''
  }
  sync(items: Item[], streets: StreetSide[] = []) {
    this.streetSides = streets
    this.refreshStreets()
    this.collisionDirty = true
    this.transform.detach()
    for (const object of this.items.values()) releaseItem(object)
    this.items.clear()
    this.models.clear()
    for (const item of items) {
      const object = buildItem(item, () => { this.outlineDirty = true; this.collisionDirty = true; this.callbacks.loaded() }, () => {
        if (!this.closed && this.items.has(item.id)) this.callbacks.error(item.kind === 'npc' ? '有一张 NPC 皮肤无法读取。' : '有一个 GLB 无法从本地存档读取。')
      })
      this.items.set(item.id, object)
      this.models.add(object)
    }
    this.select(this.selected)
  }
  select(ids: string[]) {
    this.selected = ids
    const active = this.activeId ? this.items.get(this.activeId) : undefined
    if (active && !this.walk && !this.observe && this.editable) this.transform.attach(active)
    else this.transform.detach()
    if(this.placement)this.transform.detach()
    this.setInvalid(false)
  }
  get(id: string) { return this.items.get(id) }
  getBounds(id: string) {
    const object = this.get(id)
    return object ? boundsOf(object) : new T.Box3()
  }
  setGrid(enabled: boolean) { this.groundGrid.visible = this.neighboringGrids.visible = enabled }
  viewAt(cell: PlotCell, mode: WorkspaceMode): WorkbenchView {
    const [dx,dz] = cellOffset(this.origin,cell)
    const shift = new T.Vector3(dx,0,dz)
    return {mode, camera:this.camera.position.clone().sub(shift).toArray(), target:this.orbit.target.clone().sub(shift).toArray(), zoom:this.camera.zoom, frustum:this.frustum}
  }
  restoreView(view: WorkbenchView) {
    this.camera.position.fromArray(view.camera)
    this.orbit.target.fromArray(view.target)
    this.frustum=view.frustum
    this.camera.zoom=view.zoom
    this.resize()
    this.orbit.update()
  }
  setPlan(enabled:boolean){
    this.plan=enabled
    this.setMode(this.transform.mode)
    this.orbit.enableRotate=true
    this.orbit.update()
  }
  parcelPosition(x:number,z:number) {
    const cell=cellAtLocal(this.origin,x,z)
    const [dx,dz]=cellOffset(this.origin,cell)
    return {cell:cellKey(cell),x:x-dx,z:z-dz}
  }
  private parcelFits(object:T.Object3D) {
    const pos=object.getWorldPosition(new T.Vector3())
    const site=this.parcelPosition(pos.x,pos.z)
    if(site.cell===cellKey(this.origin))return fits(boundsOf(object),this.plot)
    const region=this.region, tile=region?.client.tile(site.cell)
    if(!region || !tile || tile.owner!==region.view.member && (!tile.write || region.view.role==='view'))return false
    const [dx,dz]=cellOffset(this.origin,parseCell(site.cell)!)
    return fits(boundsOf(object).translate(new T.Vector3(-dx,0,-dz)),this.plot)
  }
  private claimOutline?:T.Box3Helper
  highlightClaim(key?:string){
    const cell=key && parseCell(key)
    if(!cell){if(this.claimOutline)this.claimOutline.visible=false;return}
    const [x,z]=cellOffset(this.origin,cell),h=this.plot.width/2
    const box=new T.Box3(new T.Vector3(x-h,.14,z-h),new T.Vector3(x+h,.27,z+h))
    if(!this.claimOutline){this.claimOutline=new T.Box3Helper(box,0xf09a22);this.scene.add(this.claimOutline)}
    this.claimOutline.box.copy(box);this.claimOutline.visible=!this.observe
  }
  private dropGuide?:T.Box3Helper
  private ghost?:T.Group
  private ghostMaterials=new Map<T.Material,T.Material>()
  private dropFace=new T.Mesh(new T.PlaneGeometry(1,1),new T.MeshBasicMaterial({color:0x38cfa9,transparent:true,opacity:.34,depthWrite:false}))
  private edgeInk=new T.MeshBasicMaterial({color:0xffac28,depthWrite:false})
  private snapEdges=Array.from({length:4},()=>new T.Mesh(this.dropFace.geometry,this.edgeInk))
  clearDropGuide(){
    if(this.dropGuide)this.dropGuide.visible=false
    if(this.ghost)this.ghost.visible=false
    this.dropFace.visible=false
    for(const edge of this.snapEdges)edge.visible=false
  }
  resolveSite(site:{cell:string;x:number;z:number},kind:string,angle=0,ignore?:string) {
    const def=blueprints.get(kind),region=this.region,tile=region?.client.tile(site.cell)
    if(!region || !def || !tile || this.economy?.offers.some(o=>o.type==='land' && o.ref===tile.room) ||
      (tile.owner!==region.view.member && (!tile.write || region.view.role==='view')))return
    const obstacles=(this.economy?.buildings??[]).filter(b=>b.id!==ignore && b.site?.cell===site.cell).map(b=>{
      const other=blueprints.get(b.kind)!,loc=b.site!,turned=loc.angle%180!==0
      return {x:loc.x,z:loc.z,width:turned?other.depth:other.width,depth:turned?other.width:other.depth}
    })
    const turned=angle%180!==0
    const legal=nearestBuildingSite(site.x,site.z,turned?def.depth:def.width,turned?def.width:def.depth,
      this.plot.width,this.transform.translationSnap??0,obstacles)
    if(legal)return {site:{...site,...legal},obstacles}
  }
  dropPosition(event:MouseEvent,kind:string) {
    const p=this.onGround(event),def=blueprints.get(kind)
    const result=p && this.resolveSite(this.parcelPosition(p.x,p.z),kind)
    if(!result || !def){this.clearDropGuide();return}
    const {site,obstacles}=result
    const [dx,dz]=cellOffset(this.origin,parseCell(site.cell)!),x=dx+site.x,z=dz+site.z
    if(this.ghost?.name!==kind){
      this.ghost?.removeFromParent()
      this.ghost=estateModel(kind);this.ghost.name=kind
      this.ghost.traverse(o=>{
        if(!(o instanceof T.Mesh))return
        const original=o.material as T.Material
        let ghost=this.ghostMaterials.get(original)
        if(!ghost){ghost=original.clone();ghost.transparent=true;ghost.opacity=.55;ghost.depthWrite=false;this.ghostMaterials.set(original,ghost)}
        o.material=ghost
      })
      this.scene.add(this.ghost)
    }
    this.ghost.visible=true;this.ghost.position.set(x,.14,z)
    this.dropFace.rotation.x=-Math.PI/2;this.dropFace.scale.set(def.width,def.depth,1)
    this.dropFace.position.set(x,.08,z);this.dropFace.visible=true
    if(!this.dropFace.parent)this.scene.add(this.dropFace)
    const sides=[
      {axis:'x',sign:-1},{axis:'x',sign:1},{axis:'z',sign:-1},{axis:'z',sign:1}
    ] as const
    sides.forEach(({axis,sign},i)=>{
      const onX=axis==='x',length=onX?def.depth:def.width,across=onX?def.width:def.depth
      const coordinate=site[axis]+sign*across/2,along=onX?'z':'x'
      const touch=Math.abs(coordinate-sign*this.plot.width/2)<.001 || obstacles.some(o=>
        Math.abs(coordinate-o[axis]+sign*(onX?o.width:o.depth)/2)<.001 &&
        Math.abs(site[along]-o[along])<(length+(onX?o.depth:o.width))/2)
      const edge=this.snapEdges[i]
      edge.visible=touch
      if(!touch)return
      if(!edge.parent)this.scene.add(edge)
      edge.rotation.x=-Math.PI/2;edge.scale.set(onX?.36:length,onX?length:.36,1)
      edge.position.set(x+(onX?sign*across/2:0),.18,z+(onX?0:sign*across/2))
    })
    const box=new T.Box3(new T.Vector3(x-def.width/2,.1,z-def.depth/2),new T.Vector3(x+def.width/2,.16,z+def.depth/2))
    if(!this.dropGuide){this.dropGuide=new T.Box3Helper(box,0x079e81);this.scene.add(this.dropGuide)}
    this.dropGuide.box.copy(box);this.dropGuide.visible=true
    return site
  }
  private onGround(event:MouseEvent){
    this.useRay(event)
    return this.ray.ray.intersectPlane(new T.Plane(new T.Vector3(0,1,0),0),new T.Vector3())
  }
  setMode(mode: 'translate' | 'rotate' | 'scale') {
    this.transform.setMode(mode)
    this.transform.showX=this.transform.showZ=!this.plan || mode!=='rotate'
    this.transform.showY=!this.plan || mode==='rotate'
  }
  setSnap(enabled: boolean) {
    this.transform.setTranslationSnap(enabled ? this.snapStep : null)
    this.transform.setRotationSnap(enabled ? Math.PI / 12 : null)
    this.transform.setScaleSnap(enabled ? .1 : null)
  }
  private themeColor(name: string, fallback: string) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback
  }
  private applyTheme() {
    this.ground.theme(this.host.classList.contains('unclaimed')?'#fafafa':this.themeColor('--ground', '#a1bb9f'), this.themeColor('--ground-edge', '#527d90'))
    this.groundGrid.material.color.set(this.themeColor('--grid-color', '#90a88e'))
    this.corners.material.color.set(this.themeColor('--ground-edge', '#285b45'))
    this.setInvalid(this.host.classList.contains('invalid'))
  }
  setInvalid(invalid: boolean) {
    this.outlineDirty = true
    const danger = invalid ? this.themeColor('--warning', '#b42318') : undefined
    ;(this.outline.material as T.LineBasicMaterial).color.set(danger ?? this.themeColor('--green', '#3b8c62'))
    this.boundary.material.color.set(danger ?? this.themeColor('--ground-edge', '#285b45'))
    this.host.classList.toggle('invalid', invalid)
  }

  setEditable(enabled: boolean) {
    this.editable = enabled
    this.transform.enabled = enabled
    if (!enabled) {
      if (this.transform.dragging) { this.transform.dragging = false; this.transform.axis = null }
      this.finishLevel(false)
      this.direct = this.startClick = undefined
      this.endPlacement()
    }
    this.select(this.selected)
  }
  get interacting() { return !!(this.direct || this.level || this.transform.dragging || this.placement) }

  private resetOrbitDamping() {
    const damping = this.orbit.enableDamping
    this.orbit.enableDamping = false
    this.orbit.update()
    this.orbit.enableDamping = damping
  }

  setObserve(enabled: boolean) {
    if (enabled === this.observe) return
    this.resetOrbitDamping()
    this.orbit.enableRotate=true
    this.observe = enabled
    if(this.claimOutline)this.claimOutline.visible=!enabled
    this.setAtmosphere(this.atmosphere)
    this.orbit.minPolarAngle = enabled ? FRONT_POLAR - FRONT_SWAY : 0
    this.orbit.maxPolarAngle = enabled ? FRONT_POLAR + FRONT_SWAY : Math.PI * .49
    this.orbit.minAzimuthAngle = enabled ? -FRONT_SWAY : -Infinity
    this.orbit.maxAzimuthAngle = enabled ? FRONT_SWAY : Infinity
    this.orbit.enablePan = !enabled
    this.orbit.mouseButtons.LEFT = enabled ? T.MOUSE.ROTATE : T.MOUSE.PAN
    if (enabled) {
      this.viewBeforeObserve = { camera: this.camera.position.clone(), target: this.orbit.target.clone(), zoom: this.camera.zoom, frustum: this.frustum }
      this.setInvalid(false)
      this.fit()
    } else if (this.viewBeforeObserve) {
      const view = this.viewBeforeObserve
      this.camera.position.copy(view.camera)
      this.orbit.target.copy(view.target)
      this.camera.zoom = view.zoom
      this.frustum = this.fitSize = view.frustum
      this.orbit.update()
      this.resize()
      this.viewBeforeObserve = undefined
    }
    this.select(this.selected)
  }

  setCharacter(character: Character) {
    this.animator.dispose()
    this.player.remove(this.character.object)
    this.releaseCharacter(this.character)
    this.character = character
    this.player.add(character.object)
    this.animator = new CharacterAnimation(character)
  }
  private releaseCharacter(character: Character) {
    if (character.dispose) { character.dispose(); return }
    character.object.traverse(node => {
      if (!(node instanceof T.Mesh)) return
      node.geometry.dispose()
      const materials = Array.isArray(node.material) ? node.material : [node.material]
      for (const material of materials) material.dispose()
      if (node instanceof T.SkinnedMesh) node.skeleton.dispose()
    })
  }

  async setWalk(enabled: boolean) {
    if (enabled) {
      const engine = await loadPhysics()
      if (this.closed) return false
      this.collision ??= new WalkCollision(engine, this.plot, this.playerScale)
      this.rebuildCollision()
      this.collisionDirty = false
      const spawn = this.collision.spawn(this.player.position)
      if (!spawn) throw new Error('地块内没有可用的行走起点。')
      this.player.position.copy(spawn)
    }
    this.walk = enabled
    if (!enabled) this.recenterContext(this.origin)
    this.keys.clear()
    this.player.visible = enabled
    if (enabled) {
      this.transform.detach()
      this.setInvalid(false)
      this.savedView = { camera: this.camera.position.clone(), target: this.orbit.target.clone(), zoom: this.camera.zoom }
      this.camera.position.add(this.player.position.clone().sub(this.orbit.target))
      this.orbit.target.copy(this.player.position)
      this.camera.zoom = Math.max(1, this.fitSize / (this.playerScale * 15))
      this.camera.updateProjectionMatrix()
      this.callbacks.walking(this.player.position, false)
    } else if (this.savedView) {
      this.camera.position.copy(this.savedView.camera)
      this.orbit.target.copy(this.savedView.target)
      this.camera.zoom = this.savedView.zoom
      this.camera.updateProjectionMatrix()
      this.select(this.selected)
    }
    this.orbit.update()
    return true
  }

  private tick = (now: number) => {
    const dt = this.time ? Math.min(.04, (now - this.time) / 1000) : 0
    this.time = now
    if (this.walk) this.stepPlayer(dt)
    this.orbit.update()
    this.animateNpcs(now)
    this.estateScene.tick(Date.now())
    const labelHeight = 19 * this.frustum / (Math.max(this.host.clientHeight, 1) * this.camera.zoom)
    for (const marker of this.markers.values()) {
      const distance = marker.group.position.distanceTo(marker.target)
      marker.group.position.lerp(marker.target, Math.min(1, dt * 10))
      marker.avatar?.animator.update(dt, distance > .06, Math.min(8, distance * 10))
      marker.label.position.y = 2 + labelHeight * .65
      marker.label.scale.set(labelHeight * marker.labelAspect, labelHeight, 1)
    }
    if (this.outlineDirty) {
      this.selectionBox.makeEmpty()
      if (this.placement) this.selectionBox.copy(boundsOf(this.placement.object))
      else if (!this.walk && !this.observe && this.editable) this.selected.forEach(id => this.selectionBox.union(this.getBounds(id)))
      this.outline.visible = !this.selectionBox.isEmpty()
      this.outlineDirty = false
    }
    this.renderer.render(this.scene, this.camera)
    this.frame = requestAnimationFrame(this.tick)
  }

  private keyDown = (event: KeyboardEvent) => {
    if (!this.walk || !MOVEMENT.has(event.code) || (event.target as HTMLElement | null)?.closest('input,textarea,select,dialog')) return
    this.keys.add(event.code)
    event.preventDefault()
  }
  private keyUp = (event: KeyboardEvent) => { this.keys.delete(event.code) }

  private stepPlayer(dt: number) {
    const position = this.player.position
    if (this.collisionDirty && this.collision) {
      this.rebuildCollision()
      const spawn = this.collision.spawn(position)
      if (spawn) this.translatePlayer(spawn.sub(position))
      this.collisionDirty = false
    }
    const held = (primary: string, alternate: string) => Number(this.keys.has(primary) || this.keys.has(alternate))
    const forward = held('KeyW', 'ArrowUp') - held('KeyS', 'ArrowDown')
    const side = held('KeyD', 'ArrowRight') - held('KeyA', 'ArrowLeft')
    if ((!forward && !side) || !this.collision) {
      this.animator.update(dt, false, 0)
      return
    }
    const front = new T.Vector3()
    this.camera.getWorldDirection(front)
    front.y = 0
    front.normalize()
    const right = new T.Vector3(-front.z, 0, front.x)
    const direction = front.multiplyScalar(forward).addScaledVector(right, side).normalize()
    const speed = (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') ? 10 : 4.2) * this.playerScale
    const step = direction.multiplyScalar(speed * dt)
    const delta = this.collision.move(position, step)
    if (!this.region) {
      const limitX = this.plot.width / 2 - .36 * this.playerScale
      const limitZ = this.plot.depth / 2 - .36 * this.playerScale
      delta.x = T.MathUtils.clamp(position.x + delta.x, -limitX, limitX) - position.x
      delta.z = T.MathUtils.clamp(position.z + delta.z, -limitZ, limitZ) - position.z
    }
    const blocked = delta.distanceToSquared(step) > 1e-7
    this.translatePlayer(delta)
    if (this.region) this.recenterContext(cellAtLocal(this.origin, position.x, position.z))
    const motionSpeed = delta.length() / Math.max(dt, .001)
    if (motionSpeed > .08) this.player.rotation.y = Math.atan2(delta.x, delta.z)
    this.animator.update(dt, motionSpeed > .08, motionSpeed / this.playerScale)
    this.callbacks.walking(position, blocked)
  }

  private translatePlayer(delta: T.Vector3) {
    this.player.position.add(delta)
    this.camera.position.add(delta)
    this.orbit.target.add(delta)
  }

  setLocalNeighbors(saves:Save[]) {
    const keys=[cellKey(this.origin)]
    for(const save of saves) {
      if(!save.plot.cell)continue
      const key=cellKey(save.plot.cell), [x,z]=cellOffset(this.origin,save.plot.cell)
      if(key===keys[0] || Math.max(Math.abs(x),Math.abs(z))>this.plot.width)continue
      keys.push(key)
      const lines=this.groundGrid.clone()
      lines.visible=true;lines.position.set(x,0,z);this.neighboringGrids.add(lines)
      const root=new T.Group()
      root.position.set(x,0,z)
      for(const item of save.scene.items)root.add(buildItem(item,()=>{},()=>{}))
      this.regionObjects.add(root)
      this.incoming.set(key,{root,version:0,streets:save.scene.streets})
    }
    this.ground.setRegionCells(keys)
    this.estateScene.display(undefined,keys)
    this.refreshStreets()
  }
  setRegion(client: RegionClient, view: RegionView) {
    if(this.region?.client!==client)this.estateScene.loadSkin=id=>client.employeeSkin(id)
    const signature=view.tiles.map(t=>t.key).join(',')
    if(signature!==this.gridSignature){
      this.gridSignature=signature;this.neighboringGrids.clear()
      for(const tile of view.tiles){
        const [x,z]=cellOffset(this.origin,parseCell(tile.key)!)
        if(!x&&!z)continue
        const lines=this.groundGrid.clone();lines.visible=true;lines.position.set(x,0,z);this.neighboringGrids.add(lines)
      }
    }
    this.region = { client, view }
    this.ground.setRegionCells(view.tiles.map(tile => tile.key))
    this.refreshNeighbors()
    this.refreshEstate()
    this.refreshPeople(view.people.filter(person => person.id !== view.member))
  }

  setEstate(data:EstateView) {
    this.economy=data
    this.refreshEstate()
  }
  private refreshEstate() {
    if (this.estateScene.display(this.economy,this.region?.view.tiles.map(t=>t.key)??[])) this.collisionDirty=true
  }
  setAtmosphere(choice:'dawn'|'dusk'|'map') {
    this.atmosphere=choice
    const studio=this.observe && choice!=='map'
    this.ground.object.visible=!studio
    this.estateScene.studio.visible=studio
    this.host.dataset.atmosphere=studio?choice:'map'
    const source=this.host.querySelector<HTMLElement>('.map-context-source')
    if(source) source.hidden=studio
  }
  frameStreet() {
    const box=new T.Box3()
    const selected=this.selected.map(id=>this.items.get(id)).filter((o):o is T.Object3D=>!!o)
    const local=this.economy?.buildings.filter(b=>b.site?.cell===cellKey(this.origin)).map(b=>b.id)??[]
    const buildings=this.estateScene.structures.children.filter(o=>local.includes(o.userData.business))
    const objects=selected.length ? selected : buildings.length ? buildings : this.models.children
    for(const o of objects)box.expandByObject(o,true)
    if(box.isEmpty()){this.fit();return}
    this.resetOrbitDamping()
    const focus=box.getCenter(new T.Vector3()),offset=this.camera.position.clone().sub(this.orbit.target)
    this.orbit.target.copy(focus);this.camera.position.copy(focus).add(offset)
    this.orbit.update();this.camera.updateMatrixWorld()
    const projection=new T.Box3()
    for(const x of [box.min.x,box.max.x]) for(const z of [box.min.z,box.max.z]) for(const y of [box.min.y,box.max.y]) {
      projection.expandByPoint(new T.Vector3(x,y,z).applyMatrix4(this.camera.matrixWorldInverse))
    }
    const size=projection.getSize(new T.Vector3())
    this.camera.zoom=T.MathUtils.clamp(.85*Math.min((this.camera.right-this.camera.left)/Math.max(.2,size.x),this.frustum/Math.max(.2,size.y)),this.orbit.minZoom,this.orbit.maxZoom)
    this.camera.updateProjectionMatrix();this.updateGroundDetail()
  }

  async photograph(credit:string):Promise<Blob> {
    const helpers=[...(this.claimOutline?[this.claimOutline]:[]),this.outline,this.groundGrid,this.neighboringGrids,this.corners,this.boundary,this.transform.getHelper(),...Array.from(this.markers.values()).flatMap(m=>[m.label,m.outline])]
    const visibility=helpers.map(o=>o.visible)
    const old=this.renderer.getSize(new T.Vector2()),ratio=this.renderer.getPixelRatio()
    const canvas=document.createElement('canvas')
    const scale=Math.min(3,2560/Math.max(old.x,old.y))
    canvas.width=Math.max(1,Math.round(old.x*scale));canvas.height=Math.max(1,Math.round(old.y*scale))
    const ctx=canvas.getContext('2d')!
    try {
      helpers.forEach(o=>o.visible=false)
      this.renderer.setPixelRatio(1)
      this.renderer.setSize(canvas.width,canvas.height,false)
      this.renderer.render(this.scene,this.camera)
      const dusk=this.observe&&this.atmosphere==='dusk',grad=ctx.createLinearGradient(0,0,0,canvas.height)
      grad.addColorStop(0,dusk?'#8889aa':'#dce9e4');grad.addColorStop(.58,dusk?'#d6a99c':'#f4ead4');grad.addColorStop(1,dusk?'#f1ceae':'#d3dfca')
      ctx.fillStyle=grad;ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(this.renderer.domElement,0,0)
      if(this.ground.object.visible && credit){ctx.font='18px sans-serif';ctx.fillStyle='#fffffff0';ctx.fillRect(0,canvas.height-31,ctx.measureText(credit).width+22,31);ctx.fillStyle='#263e44';ctx.fillText(credit,10,canvas.height-9)}
    } finally {
      helpers.forEach((o,i)=>o.visible=visibility[i]);this.renderer.setPixelRatio(ratio);this.renderer.setSize(old.x,old.y,false)
      this.renderer.render(this.scene,this.camera)
    }
    return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('无法生成照片。')),'image/png'))
  }

  setSharedGround() { this.ground.setRegionCells([cellKey(this.origin)]) }

  walkingPresence(): Pick<PresenceUpdate, 'cell' | 'pose'> {
    const { x, z } = this.player.position
    const here = cellAtLocal(this.origin, x, z)
    const [dx, dz] = cellOffset(this.origin, here)
    return { cell: cellKey(here), pose: { x: x - dx, z: z - dz, yaw: this.player.rotation.y } }
  }

  nearbyNpc() {
    let nearest: { item: Item; cell: string; greet: () => void } | undefined
    let range = 3 ** 2
    const inspect = (root: T.Object3D, cell: string) => {
      for (const object of root.children) {
        const npc = object.userData.npc as NpcActor | undefined
        if (!npc) continue
        const position = object.getWorldPosition(new T.Vector3())
        const distance = position.distanceToSquared(this.player.position)
        if (distance >= range) continue
        range = distance
        nearest = { item: npc.item, cell, greet: () => { npc.waveUntil = performance.now() + 1450 } }
      }
    }
    if (this.walk) {
      inspect(this.models, cellKey(this.origin))
      for (const [cell, value] of this.incoming) inspect(value.root, cell)
    }
    return nearest
  }

  private animateNpcs(now: number) {
    const animate = (root: T.Object3D) => {
      for (const object of root.children) {
        const npc = object.userData.npc as NpcActor | undefined
        if (!npc) continue
        const waving = now < npc.waveUntil
        npc.visual.arm.rotation.x = waving ? -1.55 + Math.sin(now * .014) * .27 : 0
        npc.visual.head.rotation.z = Math.sin(now * .0017 + object.id) * .025
        if (waving) {
          const local = object.worldToLocal(this.player.position.clone())
          npc.visual.head.rotation.y = T.MathUtils.clamp(Math.atan2(local.x, local.z), -.9, .9)
        }
      }
    }
    animate(this.models)
    for (const neighbor of this.incoming.values()) animate(neighbor.root)
  }

  private recenterContext(cell: PlotCell) {
    if (cellKey(cell) === cellKey(this.contextCell)) return
    this.contextCell = cell
    this.refreshEstate()
    const [x, z] = cellOffset(this.origin, cell)
    void this.ground.show(cell, x, z)
    this.refreshNeighbors()
  }

  private refreshNeighbors() {
    const region = this.region
    if (!region) return
    const wanted = new Set<string>()
    const origin = cellKey(this.origin)
    for (const tile of region.view.tiles) {
      if (tile.key === origin) continue
      const cell = parseCell(tile.key)!
      const [dx, dz] = cellOffset(this.contextCell, cell)
      // Keep one ring of neighbouring scenes loaded, even while crossing seams.
      if (tile.owner!==region.view.member && Math.max(Math.abs(dx), Math.abs(dz)) > this.plot.width) continue
      wanted.add(tile.key)
    }
    this.wantedNeighbors = wanted
    for (const [key, resident] of this.incoming) {
      if (!wanted.has(key)) {
        this.removeNeighbor(resident.root)
        this.incoming.delete(key)
        this.refreshStreets()
      }
    }
    for (const tile of region.view.tiles) {
      if (!wanted.has(tile.key) || this.incoming.get(tile.key)?.version === tile.version || this.loadingNeighbors.has(tile.key)) continue
      const neighbor = region.client.room(tile.key)
      if (!neighbor) continue
      this.loadingNeighbors.set(tile.key, tile.version)
      void neighbor.read(false).then(async value => {
        if (this.closed || !this.wantedNeighbors.has(tile.key)) return
        await Promise.all(value.save.scene.items.map(item => prepareItemAssets(item, (id, kind) => neighbor.downloadAsset(id, kind))))
        if (this.closed || !this.wantedNeighbors.has(tile.key)) return
        const root = new T.Group()
        const [x, z] = cellOffset(this.origin, value.save.plot.cell!)
        root.position.set(x, 0, z)
        root.userData.cell=tile.key
        const previous = this.incoming.get(tile.key)
        if (previous) this.removeNeighbor(previous.root)
        for (const item of value.save.scene.items) {
          const obj=buildItem(item, () => { this.collisionDirty = true }, () => {}, (id, kind) => neighbor.downloadAsset(id, kind))
          obj.userData.savedItem=item;root.add(obj)
        }
        this.regionObjects.add(root)
        this.incoming.set(tile.key, { version: value.version, root, streets: value.save.scene.streets })
        this.refreshStreets()
        this.collisionDirty = true
      }).catch(() => { /* We retry the tile on the next region heartbeat. */ })
        .finally(() => this.loadingNeighbors.delete(tile.key))
    }
  }

  private removeNeighbor(root: T.Group) {
    releaseItem(root)
    this.regionObjects.remove(root)
    this.collisionDirty = true
  }

  private rebuildCollision() {
    const cells: [number, number][] = [[0, 0]]
    for (const item of this.incoming.values()) cells.push([item.root.position.x, item.root.position.z])
    this.collision?.rebuild([this.models, this.regionObjects, this.estateScene.structures], cells)
  }

  private refreshPeople(people: Presence[]) {
    const visible = new Set<string>()
    for (const person of people) {
      const cell = parseCell(person.cell)
      if (!cell) continue
      const [nearX, nearZ] = cellOffset(this.contextCell, cell)
      if (Math.max(Math.abs(nearX), Math.abs(nearZ)) > this.plot.width) continue
      visible.add(person.id)
      let marker = this.markers.get(person.id)
      const color = ['#007aa6', '#8f53c6', '#a75b12', '#1a7854'][parseInt(person.id.slice(-2), 16) % 4]
      if (!marker) {
        marker = this.makeMarker(person.name, color)
        this.markers.set(person.id, marker)
      }
      const [x, z] = cellOffset(this.origin, cell)
      const initialized = marker.group.visible
      marker.group.visible = true
      marker.target.set(x + (person.pose?.x ?? 0), 0, z + (person.pose?.z ?? 0))
      marker.outline.visible = false
      if (person.pose) marker.group.rotation.y = person.pose.yaw
      this.updateMarkerSkin(person, marker)
      if (person.selection && person.cell === cellKey(this.origin)) {
        marker.bounds.copy(this.getBounds(person.selection))
        if (!marker.bounds.isEmpty()) {
          marker.outline.visible = true
          marker.bounds.getCenter(marker.target)
          marker.target.y = marker.bounds.max.y
        }
      }
      if (!initialized) marker.group.position.copy(marker.target)
    }
    for (const id of this.markers.keys()) if (!visible.has(id)) this.removeMarker(id)
  }

  private updateMarkerSkin(person: Presence, marker: ReturnType<World['makeMarker']>) {
    const skin = person.mode === 'walk' ? person.skin : undefined
    const key = skin ? `${skin.asset}:${skin.body}` : ''
    if (marker.skin === key) return
    marker.skin = key
    this.releaseMarkerSkin(marker)
    const client = this.region?.client
    if (!skin || !client) return
    void loadSkin(skin.asset, () => client.downloadAvatar(skin.asset)).then(image => {
      if (this.closed || this.markers.get(person.id) !== marker || marker.skin !== key) return
      const character = skinCharacter(skin.body, image)
      marker.avatar = { character, animator: new CharacterAnimation(character) }
      marker.group.add(character.object)
      marker.capsule.visible = false
    }).catch(() => { /* The capsule remains visible while the skin is unavailable. */ })
  }

  private releaseMarkerSkin(marker: ReturnType<World['makeMarker']>) {
    if (!marker.avatar) return
    const { character, animator } = marker.avatar
    animator.dispose()
    marker.group.remove(character.object)
    this.releaseCharacter(character)
    marker.avatar = undefined
    marker.capsule.visible = true
  }

  private makeMarker(name: string, color: string) {
    const group = new T.Group()
    const mesh = new T.Mesh(new T.CapsuleGeometry(.29, .85, 4, 12), new T.MeshBasicMaterial({ color }))
    mesh.position.y = .8
    group.add(mesh)
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')!
    const font = '600 32px system-ui, sans-serif'
    ctx.font = font
    canvas.width = Math.max(68, Math.min(512, Math.ceil(ctx.measureText(name).width) + 30))
    canvas.height = 48
    ctx.fillStyle = color
    ctx.beginPath()
    ctx.roundRect(0, 0, canvas.width, canvas.height, 14)
    ctx.fill()
    ctx.fillStyle = '#fff'
    ctx.font = font
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText(name, canvas.width / 2, canvas.height / 2, canvas.width - 20)
    const texture = new T.CanvasTexture(canvas)
    texture.colorSpace = T.SRGBColorSpace
    const label = new T.Sprite(new T.SpriteMaterial({ map: texture, transparent: true, depthTest: false, depthWrite: false }))
    label.renderOrder = 2
    group.add(label)
    group.visible = false
    const bounds = new T.Box3()
    const outline = new T.Box3Helper(bounds, color)
    outline.visible = false
    this.people.add(group, outline)
    return { group, capsule: mesh, label, labelAspect: canvas.width / canvas.height, outline, bounds,
      target: new T.Vector3(), skin: '', avatar: undefined as { character: Character; animator: CharacterAnimation } | undefined }
  }
  private removeMarker(id: string) {
    const marker = this.markers.get(id)
    if (!marker) return
    this.releaseMarkerSkin(marker)
    marker.label.material.map?.dispose()
    marker.label.material.dispose()
    marker.capsule.material.dispose()
    marker.capsule.geometry.dispose()
    marker.outline.dispose()
    this.people.remove(marker.group, marker.outline)
    this.markers.delete(id)
  }

  private levelDown = (event: MouseEvent) => {
    const id = this.activeId
    if (event.button !== 1 || !(event.buttons & 1) || !id || !this.editable || this.observe || this.walk || this.placement || this.transform.dragging) return
    const object = this.get(id)
    if (!object) return
    event.preventDefault()
    if (this.direct?.moved) this.callbacks.commit(id)
    this.direct = this.startClick = undefined
    const z = new T.Vector3(0, 0, 1).applyQuaternion(object.quaternion)
    const yaw = Math.atan2(z.x, z.z)
    const x = new T.Vector3(1, 0, 0).applyQuaternion(object.quaternion)
      .applyAxisAngle(new T.Vector3(0, 1, 0), -yaw)
    this.level = { id, yaw, bank: Math.atan2(x.y, x.x), x: event.clientX, y: event.clientY }
    this.orbit.enabled = false
    this.callbacks.level(true)
    this.updateLevel(event)
  }
  private updateLevel(event: MouseEvent) {
    const level = this.level
    if (!level) return
    const object = this.get(level.id)
    if (!object) return
    const yaw = level.yaw + (event.clientX - level.x) * .012
    const bank = level.bank + (event.clientY - level.y) * .012
    object.quaternion.setFromEuler(new T.Euler(0, yaw, bank, 'YZX'))
    this.publishPreview(level.id)
  }
  private levelUp = (event: MouseEvent) => {
    if (event.button === 0 || event.button === 1) this.finishLevel()
  }
  private finishLevel(commit = true) {
    const gesture = this.level
    if (!gesture) return
    this.level = undefined
    this.orbit.enabled = true
    this.callbacks.level(false)
    if (commit) this.callbacks.commit(gesture.id)
  }

  private useRay(event: MouseEvent) {
    const rect = this.renderer.domElement.getBoundingClientRect()
    this.ray.setFromCamera(new T.Vector2((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1), this.camera)
  }
  private pointerDown = (event: PointerEvent) => {
    if (event.button !== 0 || this.observe || this.walk || this.transform.dragging) return
    if (this.placement) {
      event.stopImmediatePropagation()
      this.updatePlacement(event)
      const { object, confirm } = this.placement
      if(this.placement.paving){
        this.brush={x:object.position.x,z:object.position.z,first:true}
        this.renderer.domElement.setPointerCapture(event.pointerId)
        this.paintRoad()
      } else if (this.placementFits()) confirm(object.position.toArray(), object.rotation.y)
      return
    }
    this.startClick = { x: event.clientX, y: event.clientY }
    this.useRay(event)
    const hits = this.ray.intersectObjects([...this.models.children,...this.regionObjects.children,...this.estateScene.structures.children],true)
    if (!hits.length) return
    let target: T.Object3D = hits[0].object
    while (target.parent && target.parent !== this.models && target.parent !== this.estateScene.structures && target.parent.parent !== this.regionObjects) target = target.parent
    if(target.parent?.parent===this.regionObjects){
      const source=target.parent.userData.cell as string, point=this.onGround(event), tile=this.region?.client.tile(source)
      if(!tile || !this.editable || !point || tile.owner!==this.region?.view.member && (!tile.write || this.region?.view.role==='view'))return
      if(!target.userData.savedItem)return
      this.neighborDrag={object:target,origin:target.position.clone(),point,source,item:target.userData.savedItem}
      this.startClick=undefined
      event.stopImmediatePropagation();this.renderer.domElement.setPointerCapture(event.pointerId);return
    }
    if(target.userData.business){
      this.startClick.business=target.userData.business
      const point=this.onGround(event)
      if(this.editable && this.pickedShop===target.userData.business && point){
        this.shopDrag={root:target,origin:target.position.clone(),point};event.stopImmediatePropagation();this.renderer.domElement.setPointerCapture(event.pointerId)
      }
      return
    }
    const id: string = target.userData.itemId
    this.startClick.item=id
    if(!this.editable || !this.selected.includes(id))return
    if (event.shiftKey || this.transform.mode !== 'translate') return
    event.stopImmediatePropagation()
    this.startClick = undefined
    this.direct = { id, x: event.clientX, y: event.clientY, pickY: hits[0].point.y, offset: target.position.clone().sub(hits[0].point), moved: false }
    this.renderer.domElement.setPointerCapture(event.pointerId)
  }
  private pointerMove = (event: PointerEvent) => {
    const neighbor=this.neighborDrag
    if(neighbor){
      const point=this.onGround(event)
      if(point){
        const p=neighbor.object.position.copy(neighbor.origin).add(point.sub(neighbor.point)),step=this.transform.translationSnap
        if(step){p.x=Math.round(p.x/step)*step;p.z=Math.round(p.z/step)*step}
        this.setInvalid(!this.parcelFits(neighbor.object))
      }
      return
    }
    if(this.shopDrag){
      const p=this.onGround(event),drag=this.shopDrag
      const shop=this.economy?.buildings.find(b=>b.id===drag.root.userData.business)
      if(p && shop?.site){
        const at=drag.origin.clone().add(p.sub(drag.point))
        const result=this.resolveSite(this.parcelPosition(at.x,at.z),shop.kind,shop.site.angle,shop.id)
        if(result && (result.site.cell===shop.site.cell || shop.owner===this.region?.view.member)){
          const [dx,dz]=cellOffset(this.origin,parseCell(result.site.cell)!)
          drag.root.position.set(dx+result.site.x,0,dz+result.site.z)
        }
      }
      return
    }
    if (this.level) { this.updateLevel(event); return }
    if (this.placement) { this.updatePlacement(event); if(this.brush)this.paintRoad();return }
    const drag = this.direct
    if (!drag) return
    if (!drag.moved && Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < 3) return
    const object = this.get(drag.id)
    if (!object) return
    this.useRay(event)
    const point = this.ray.ray.intersectPlane(new T.Plane(new T.Vector3(0, 1, 0), -drag.pickY), new T.Vector3())
    if (!point) return
    drag.moved = true
    const snap = this.transform.translationSnap
    object.position.x = snap ? Math.round((point.x + drag.offset.x) / snap) * snap : point.x + drag.offset.x
    object.position.z = snap ? Math.round((point.z + drag.offset.z) / snap) * snap : point.z + drag.offset.z
    this.publishPreview(drag.id)
  }
  private pointerUp = (event: PointerEvent) => {
    if (event.button !== 0) return
    this.brush=undefined
    if(this.neighborDrag){
      const drag=this.neighborDrag,pos=drag.object.getWorldPosition(new T.Vector3())
      const valid=this.parcelFits(drag.object), moved=drag.origin.distanceTo(drag.object.position)>.001
      drag.object.position.copy(drag.origin);this.neighborDrag=undefined;this.setInvalid(false)
      if(moved && valid)this.callbacks.moveItem(drag.source,drag.item,this.parcelPosition(pos.x,pos.z))
      else if(moved)this.callbacks.error('落点越界，已恢复原位。')
      return
    }
    if(this.shopDrag){
      const {root,origin}=this.shopDrag,pos=root.position.clone()
      this.shopDrag=undefined;root.position.copy(origin)
      if(pos.distanceTo(origin)>.001){this.callbacks.moveBusiness(root.userData.business,pos.x,pos.z);this.startClick=undefined}
    }
    const drag = this.direct
    this.direct = undefined
    if (drag?.moved) this.callbacks.commit(drag.id)
    if (this.startClick && !this.walk && Math.hypot(event.clientX - this.startClick.x, event.clientY - this.startClick.y) < 4) {
      this.pickedShop=this.startClick.business??''
      if(this.pickedShop)this.callbacks.business(this.pickedShop)
      else if(this.startClick.item)this.callbacks.select(this.startClick.item,event.shiftKey)
      else {this.callbacks.select(undefined,false);const p=this.onGround(event);if(p)this.callbacks.cell(cellKey(cellAtLocal(this.origin,p.x,p.z)))}
    }
    this.startClick = undefined
  }
  private cancelPointer = () => {
    if(this.neighborDrag){this.neighborDrag.object.position.copy(this.neighborDrag.origin);this.neighborDrag=undefined}
    this.brush=undefined
    if(this.shopDrag){this.shopDrag.root.position.copy(this.shopDrag.origin);this.shopDrag=undefined}
    this.finishLevel()
    if (this.direct) this.callbacks.commit(this.direct.id)
    this.direct = this.startClick = undefined
  }

  private placementFits(){
    const p=this.placement
    return !!p && (p.territory ? this.parcelFits(p.object):fits(boundsOf(p.object),this.plot))
  }
  private paintRoad() {
    const brush=this.brush, placement=this.placement
    if(!brush || !placement)return
    const object=placement.object, end=object.position.clone()
    // Ignore off-plot samples. Re-entry starts a new segment at the edge.
    if(!this.placementFits()){brush.x=NaN;return}
    const startX=Number.isFinite(brush.x)?brush.x:end.x, startZ=Number.isFinite(brush.x)?brush.z:end.z
    const steps=Math.max(1,Math.abs(end.x-startX)/10,Math.abs(end.z-startZ)/10)
    for(let i=1;i<=steps;i++){
      object.position.x=startX+10*Math.round((end.x-startX)*i/(steps*10))
      object.position.z=startZ+10*Math.round((end.z-startZ)*i/(steps*10))
      if(this.placementFits()){placement.confirm(object.position.toArray(),object.rotation.y,brush.first);brush.first=false}
    }
    object.position.copy(end);brush.x=end.x;brush.z=end.z
  }
  rotatePaving() {
    if (!this.placement?.rotatable) return false
    this.placement.object.rotation.y += Math.PI / 2
    this.setInvalid(!this.placementFits())
    return true
  }
  beginPlacement(item: Item, source: T.Object3D, confirm: (position: Vec, yaw: number,first?:boolean) => void, paving = false, rotatable = paving,territory=false) {
    this.endPlacement()
    this.transform.detach()
    const object = new T.Group()
    object.add(clone(source))
    applyItem(object, item)
    this.scene.add(object)
    this.placement = { object, confirm, paving, rotatable,territory }
    this.outlineDirty = true
    this.host.classList.add('placing')
  }
  endPlacement() {
    if (this.placement) this.scene.remove(this.placement.object)
    this.brush=undefined
    this.placement = undefined
    this.host.classList.remove('placing')
    this.select(this.selected)
  }
  private updatePlacement(event: PointerEvent) {
    if (!this.placement) return
    this.useRay(event)
    const point = this.ray.ray.intersectPlane(new T.Plane(new T.Vector3(0, 1, 0), 0), new T.Vector3())
    if (!point) return
    const object = this.placement.object
    if (this.placement.paving) {
      object.position.x = Math.floor((point.x + this.plot.width/2) / 10) * 10 + 5 - this.plot.width/2
      object.position.z = Math.floor((point.z + this.plot.depth/2) / 10) * 10 + 5 - this.plot.depth/2
      this.setInvalid(!this.placementFits())
      return
    }
    const snap = this.transform.translationSnap
    object.position.x = snap ? Math.round(point.x / snap) * snap : point.x
    object.position.z = snap ? Math.round(point.z / snap) * snap : point.z
    this.setInvalid(!this.placementFits())
  }

  private publishPreview(id: string) {
    const object = this.get(id)
    if (!object) return
    const valid = this.parcelFits(object) && object.scale.toArray().every(value => Number.isFinite(value) && value > 0)
    this.setInvalid(!valid)
    this.callbacks.preview(id, {
      position: object.position.toArray(),
      rotation: [object.rotation.x, object.rotation.y, object.rotation.z],
      scale: object.scale.toArray() as Vec,
    }, valid)
  }

  dispose() {
    this.closed = true
    for (const id of this.markers.keys()) this.removeMarker(id)
    for (const neighbor of this.incoming.values()) this.removeNeighbor(neighbor.root)
    this.scene.remove(this.estateScene.structures,this.estateScene.people,this.estateScene.studio)
    this.estateScene.dispose()
    this.streets.dispose()
    this.ground.dispose()
    this.scene.remove(this.ground.object)
    this.collision?.dispose()
    this.animator.dispose()
    this.player.remove(this.character.object)
    this.releaseCharacter(this.character)
    cancelAnimationFrame(this.frame)
    this.listeners.abort()
    this.observer.disconnect()
    this.claimOutline?.dispose()
    this.dropGuide?.dispose()
    this.edgeInk.dispose();this.dropFace.geometry.dispose();this.dropFace.material.dispose()
    this.ghostMaterials.forEach(m=>m.dispose())
    this.transform.dispose()
    this.orbit.dispose()
    this.endPlacement()
    releaseItem(this.models)
    const release = (object: T.Object3D) => {
      if (object === this.models) return
      if (object instanceof T.Mesh || object instanceof T.Line || object instanceof T.Points) {
        object.geometry.dispose()
        const materials = Array.isArray(object.material) ? new Set(object.material) : [object.material]
        for (const material of materials) material.dispose()
      }
      object.children.forEach(release)
    }
    this.scene.children.filter(child => child !== this.transform.getHelper()).forEach(release)
    this.renderer.dispose()
    this.renderer.domElement.remove()
  }
}
