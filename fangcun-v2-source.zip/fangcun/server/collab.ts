import { randomBytes } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { createReadStream } from 'node:fs'
import { resolve, join } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Connect } from 'vite'
import type { Item, Save, SceneData } from '../src/data.ts'
import { makePlot } from '../src/data.ts'
import { applyChanges, assetIds, type Role, type RoomView, type SceneChange } from '../src/collab-types.ts'

type Room = { owner: string; members: Record<string, 'view' | 'edit'>; invites: Record<string, 'view' | 'edit'>; save: Save; version: number }
type Peer = { token: string; seen: number }
const base = resolve(process.env.FANGCUN_ROOM_DIR || '.fangcun-rooms')
const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i
const roomId = /^[a-f0-9]{24}$/
const peers = new Map<string, Map<string, Peer>>()
const now = () => Date.now()
const key = (bytes = 32) => randomBytes(bytes).toString('hex')
const assetPath = (id: string, asset: string) => join(base, id, `${asset}.glb`)

class HttpError extends Error {
  constructor(public status: number, message: string) { super(message) }
}
function json(response: ServerResponse, status: number, data: unknown) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' })
  response.end(JSON.stringify(data))
}
async function bytes(request: IncomingMessage, limit: number) {
  const claimed = Number(request.headers['content-length'] ?? 0)
  if (claimed > limit) throw new HttpError(413, '文件或场景超过房间大小限制。')
  const parts: Buffer[] = []
  let length = 0
  for await (const chunk of request) {
    length += chunk.length
    if (length > limit) throw new HttpError(413, '文件或场景超过房间大小限制。')
    parts.push(chunk)
  }
  return Buffer.concat(parts)
}
async function body<T>(request: IncomingMessage) {
  let result
  try { result = JSON.parse((await bytes(request, 2_000_000)).toString('utf8')) }
  catch (error) {
    if (error instanceof HttpError) throw error
    throw new HttpError(400, '请求格式无效。')
  }
  if (!result || typeof result !== 'object' || Array.isArray(result)) throw new HttpError(400, '请求格式无效。')
  return result as T
}
function writeRoom(id: string, room: Room) {
  const dir = join(base, id)
  mkdirSync(dir, { recursive: true, mode: 0o700 })
  writeFileSync(join(dir, 'room.tmp'), JSON.stringify(room), { mode: 0o600 })
  renameSync(join(dir, 'room.tmp'), join(dir, 'room.json'))
}
function readRoom(id: string): Room {
  const path = join(base, id, 'room.json')
  if (!existsSync(path)) throw new HttpError(404, '找不到这个地块。')
  return JSON.parse(readFileSync(path, 'utf8'))
}
function roleOf(room: Room, token: string): Role | undefined {
  if (/^[a-f0-9]{64}$/.test(token)) return token === room.owner ? 'owner' : room.members[token]
  return undefined
}
function view(id: string, room: Room, role: Role): RoomView {
  const active = peers.get(id)
  if (active) for (const [client, peer] of active) if (now() - peer.seen > 8000) active.delete(client)
  return { role, save: room.save, version: room.version, online: active?.size ?? 0 }
}
function validItem(item: Item, depth = 0): boolean {
  if (!item || depth > 12 || !uuid.test(item.id) || typeof item.name !== 'string' || item.name.length > 250) return false
  if (!['box', 'sphere', 'cylinder', 'group', 'glb'].includes(item.kind)) return false
  const vec = (v: number[]) => Array.isArray(v) && v.length === 3 && v.every(x => Number.isFinite(x) && Math.abs(x) < 1e9)
  return vec(item.position) && vec(item.rotation) && vec(item.scale) && item.scale.every(x => x > 0)
    && (item.color === undefined || /^#[0-9a-f]{6}$/i.test(item.color))
    && (item.kind !== 'glb' || typeof item.asset === 'string' && uuid.test(item.asset))
    && (item.kind === 'group' ? Array.isArray(item.children) && item.children.length <= 250 && item.children.every(x => validItem(x, depth + 1))
      : item.children === undefined)
}
function validScene(scene: SceneData): boolean {
  return !!scene && [scene.items, scene.models].every(items => Array.isArray(items) && items.length <= 500
    && items.every(item => validItem(item)) && new Set(items.map(item => item.id)).size === items.length)
}
function checkAssets(id: string, scene: SceneData) {
  if ([...assetIds(scene)].some(asset => !existsSync(assetPath(id, asset)))) throw new HttpError(422, '场景引用了尚未上传的 GLB。')
}
function checkGlb(bin: Buffer) {
  if (bin.length < 20 || bin.readUInt32LE(0) !== 0x46546c67 || bin.readUInt32LE(4) !== 2
    || bin.readUInt32LE(8) !== bin.length || bin.readUInt32LE(16) !== 0x4e4f534a) throw new HttpError(400, '请选择有效的 GLB。')
  try {
    const length = bin.readUInt32LE(12)
    if (length + 20 > bin.length) throw new Error()
    const value = JSON.parse(bin.subarray(20, 20 + length).toString('utf8'))
    if ([...(value.buffers ?? []), ...(value.images ?? [])].some(resource => resource.uri && !/^data:/i.test(resource.uri))) throw new Error()
  } catch { throw new HttpError(400, '房间只接受自包含 GLB。') }
}

export const collaboration: Connect.NextHandleFunction = async (request, response, next) => {
  const pathname = request.url?.split('?')[0] ?? ''
  if (!pathname.startsWith('/collab/')) { next(); return }
  try {
    const [, , id, action, asset, extra] = pathname.split('/')
    const method = request.method
    if (id === 'create' && !action && method === 'POST') {
      const input = await body<{ plot: Save['plot'] }>(request)
      const plot = input.plot
      if (!plot || ![plot.north, plot.south, plot.east, plot.west].every(Number.isFinite)) throw new HttpError(400, '地块坐标无效。')
      const fixed = makePlot([(plot.south + plot.north) / 2, (plot.west + plot.east) / 2])
      const room = key(12), token = key()
      writeRoom(room, { owner: token, members: {}, invites: {}, save: { plot: fixed, scene: { items: [], models: [] } }, version: 0 })
      json(response, 201, { room, token })
      return
    }
    if (!roomId.test(id) || extra !== undefined) throw new HttpError(404, '找不到这个地块。')
    if (action === 'join' && method === 'POST') {
      const { invite } = await body<{ invite: string }>(request)
      const room = readRoom(id)
      const grant = /^[a-f0-9]{64}$/.test(invite) ? room.invites[invite] : undefined
      if (!grant) throw new HttpError(403, '邀请链接已失效。')
      const token = key()
      room.members[token] = grant
      writeRoom(id, room)
      json(response, 200, { room: id, token })
      return
    }
    const token = request.headers.authorization?.replace(/^Bearer /, '') ?? ''
    const authorize = () => {
      const room = readRoom(id)
      const role = roleOf(room, token)
      if (!role) throw new HttpError(403, '当前账号没有进入地块的权限。')
      return { room, role }
    }
    const { room, role } = authorize()
    if (action === 'state' && method === 'GET') {
      const client = request.headers['x-fangcun-peer']
      if (typeof client === 'string' && uuid.test(client)) {
        const active = peers.get(id) ?? new Map()
        active.set(client, { token, seen: now() })
        peers.set(id, active)
      }
      json(response, 200, view(id, room, role))
      return
    }
    if (action === 'state' && method === 'POST') {
      if (role === 'view') throw new HttpError(403, '当前访客没有编辑权限。')
      const input = await body<{ changes: SceneChange[] }>(request)
      const current = authorize()
      if (current.role === 'view') throw new HttpError(403, '编辑权限已撤销。')
      if (!Array.isArray(input.changes) || input.changes.length > 1000 || !input.changes.every(change => change &&
        ['items', 'models'].includes(change.collection) && uuid.test(change.id)
        && (change.before === null || validItem(change.before) && change.before.id === change.id)
        && (change.after === null || validItem(change.after) && change.after.id === change.id))) throw new HttpError(400, '物件修改格式无效。')
      const scene = applyChanges(current.room.save.scene, input.changes)
      if (!scene) { json(response, 409, view(id, current.room, current.role)); return }
      if (!validScene(scene)) throw new HttpError(422, '房间场景达到容量限制。')
      checkAssets(id, scene)
      current.room.save.scene = scene
      current.room.version++
      writeRoom(id, current.room)
      json(response, 200, view(id, current.room, current.role))
      return
    }
    if (action === 'invite' && method === 'POST') {
      if (role !== 'owner') throw new HttpError(403, '仅地块主人可以管理邀请。')
      const { grant } = await body<{ grant: string }>(request)
      const current = authorize().room
      if (grant !== 'edit' && grant !== 'view') throw new HttpError(400, '邀请权限无效。')
      const invite = key()
      current.invites[invite] = grant
      writeRoom(id, current)
      json(response, 201, { invite })
      return
    }
    if (action === 'revoke-edit' && method === 'POST') {
      if (role !== 'owner') throw new HttpError(403, '仅地块主人可以撤销权限。')
      for (const [invite, grant] of Object.entries(room.invites)) if (grant === 'edit') delete room.invites[invite]
      for (const member of Object.keys(room.members)) room.members[member] = 'view'
      room.version++
      writeRoom(id, room)
      json(response, 200, view(id, room, role))
      return
    }
    if (action === 'asset' && uuid.test(asset)) {
      const path = assetPath(id, asset)
      if (method === 'GET') {
        if (!existsSync(path)) throw new HttpError(404, '房间内找不到该模型。')
        response.writeHead(200, { 'Content-Type': 'model/gltf-binary', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' })
        createReadStream(path).pipe(response)
        return
      }
      if (method === 'PUT') {
        if (role === 'view') throw new HttpError(403, '当前访客没有上传权限。')
        const bin = await bytes(request, 24 * 1024 * 1024)
        if (authorize().role === 'view') throw new HttpError(403, '编辑权限已撤销。')
        checkGlb(bin)
        if (existsSync(path) && !readFileSync(path).equals(bin)) throw new HttpError(409, '模型标识冲突。')
        if (!existsSync(path)) writeFileSync(path, bin, { flag: 'wx', mode: 0o600 })
        json(response, 200, { stored: true })
        return
      }
    }
    throw new HttpError(404, '请求地址无效。')
  } catch (error) {
    if (!(error instanceof HttpError)) console.error(error)
    if (!response.headersSent) json(response, error instanceof HttpError ? error.status : 500, { error: error instanceof HttpError ? error.message : '房间服务暂时不可用。' })
  }
}
