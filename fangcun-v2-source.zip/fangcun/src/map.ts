import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { distance, exportLegacySave, makePlot, type Corner, type Plot, type Save } from './data'
import { $, button, icons } from './ui'

const chengdu: Corner = [30.657, 104.066]
const zoom = 12
let lastView: { center: L.LatLng; zoom: number } | undefined

export function mapPage(root: HTMLElement, save: Save | null, onEnter: (plot: Plot) => void) {
  root.innerHTML = `
    <aside class="map-sidebar">
      <div class="stage-label"><span>01</span> 地图选址</div>
      <h1>为你的世界<br>选一块地<span class="headline-dot">。</span></h1>
      <p class="sidebar-intro">在真实地图选定中心，<br>建立一块 100 × 100 米的 3D 地块。</p>
      <div class="sidebar-divider"></div>
      <section id="selection-panel" aria-live="polite"></section>
      <div class="sidebar-spacer"></div>
      <div class="map-tip">
        <div class="tip-icon">${icons.mouse}</div>
        <div><strong>地图操作</strong><p>拖动平移 · 滚轮缩放</p></div>
      </div>
    </aside>
    <section class="map-workspace" aria-label="真实地图">
      <div id="real-map"></div>
      <div class="map-top">
        <div class="location-tag"><span class="location-icon">${icons.pin}</span><div><strong id="map-place">中国 · 成都市</strong><small>真实地理底图</small></div></div>
        <div class="map-live"><span></span><b>地图视图</b></div>
      </div>
      <div class="map-actions">
        <div class="north" aria-label="上方为北"><span>N</span><svg viewBox="0 0 20 20" aria-hidden="true"><path fill="#315944" d="M10 2 15.5 16 10 12.7Z"/><path fill="#a0afa2" d="M10 2 4.5 16 10 12.7Z"/></svg></div>
        <div class="zoom-controls">${button('plus', '放大', 'zoom-in')}${button('minus', '缩小', 'zoom-out')}</div>
        ${button('locate', '返回成都', 'center-map', 'icon-button center-map')}
      </div>
      <div id="tile-status" class="tile-status" hidden>底图暂时无法加载，请检查网络连接。</div>
      <div id="map-coords" class="map-coords">30.6570° N &nbsp; 104.0660° E</div>
    </section>`

  const map = L.map('real-map', {
    zoomControl: false, minZoom: 3, maxZoom: 20, worldCopyJump: true,
    maxBounds: [[-85, -540], [85, 540]], maxBoundsViscosity: 1,
  }).setView(lastView?.center ?? chengdu, lastView?.zoom ?? zoom)

  const streetCopyright = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> · HOT · <a href="https://openstreetmap.fr/">OSM France</a>'
  const esriCopyright = 'Tiles &copy; <a href="https://www.esri.com/">Esri</a> · HERE · Garmin · USGS · Intermap and the GIS community'
  const sources = [
    { url: '/map-tiles/hot/{z}/{x}/{y}', attribution: streetCopyright, native: 19 },
    { url: 'https://a.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', attribution: streetCopyright, native: 19 },
    { url: '/map-tiles/esri/{z}/{x}/{y}', attribution: esriCopyright, native: 19 },
    { url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', attribution: esriCopyright, native: 19 },
  ]
  function addTiles(index: number) {
    const source = sources[index]
    const layer = L.tileLayer(source.url, { maxNativeZoom: source.native, maxZoom: 20, attribution: source.attribution })
    let errors = 0
    layer.on('tileload', () => { errors = 0; $('tile-status').hidden = true })
    layer.on('tileerror', () => {
      if (++errors !== 3) return
      if (index === sources.length - 1) { $('tile-status').hidden = false; return }
      layer.remove()
      addTiles(index + 1)
    })
    layer.addTo(map)
  }
  addTiles(0)
  L.control.scale({ position: 'bottomleft', imperial: false }).addTo(map)
  const city = L.marker(chengdu, {
    icon: L.divIcon({ className: 'city-pin', iconSize: [19, 19], iconAnchor: [9, 9], html: '<span></span>' }),
    interactive: false,
  }).addTo(map)
  city.bindTooltip('成都', { permanent: true, direction: 'right', className: 'city-label', offset: [12, 0] })

  const rectOptions = { color: '#377051', weight: 2, fillColor: '#62a47a', fillOpacity: .21 }
  const bounds = (plot: Plot): L.LatLngBoundsExpression => [[plot.south, plot.west], [plot.north, plot.east]]
  let disposed = false
  const enter = (plot: Plot) => {
    if (!disposed) onEnter(plot)
  }

  if (save) {
    const savedRect = L.rectangle(bounds(save.plot), { ...rectOptions, className: 'saved-plot' }).addTo(map)
    savedRect.bindTooltip('我的地块 · 点击继续编辑', { sticky: true })
    savedRect.on('click', () => enter(save.plot))
    map.fitBounds(savedRect.getBounds(), { padding: [95, 95], maxZoom: 19, animate: false })
  }

  const buildZoom = 18
  let drawing = false
  let rectangle: L.Rectangle | undefined
  function chosenPlot() {
    const center = map.getCenter()
    return makePlot([center.lat, center.lng])
  }
  function refreshDraft() {
    if (!drawing) return
    const plot = chosenPlot()
    const center = map.getCenter()
    const shift = Math.round((center.lng - (plot.east + plot.west) / 2) / 360) * 360
    const draftBounds: L.LatLngBoundsExpression = [[plot.south, plot.west + shift], [plot.north, plot.east + shift]]
    if (!rectangle) rectangle = L.rectangle(draftBounds, { ...rectOptions, dashArray: '6 5', className: 'draft-plot', interactive: false }).addTo(map)
    else rectangle.setBounds(draftBounds)
    $('map-level').textContent = `缩放级别 ${map.getZoom()} / ${buildZoom}`
  }
  function showPanel() {
    const panel = $('selection-panel')
    const legacy = exportLegacySave()
    const legacyButton = legacy ? '<button class="subtle" id="download-legacy">下载旧矩形存档</button>' : ''
    function bindLegacy() {
      if (!legacy) return
      $('download-legacy').onclick = () => {
        const url = URL.createObjectURL(new Blob([legacy], { type: 'application/json' }))
        const link = document.createElement('a')
        link.href = url
        link.download = 'fangcun-legacy.json'
        link.click()
        setTimeout(() => URL.revokeObjectURL(url), 1000)
      }
    }
    if (save) {
      panel.innerHTML = `
        <div class="panel-caption">我的地块 <span class="saved-badge">${icons.check} 已保存</span></div>
        <div class="plot-card"><span class="plot-card-icon">${icons.box}</span><div><strong>本地地块</strong><p>${distance(save.plot.width)} × ${distance(save.plot.depth)}</p></div></div>
        <button class="primary full" id="enter-plot">继续建造 ${icons.arrow}</button>${legacyButton}`
      $('enter-plot').onclick = () => enter(save.plot)
      bindLegacy()
      return
    }
    if (!drawing) {
      panel.innerHTML = `
        <div class="panel-caption">地块选址</div>
        <div class="selection-card">
          <div class="selection-art" aria-hidden="true"><div class="art-rect"><i></i><i></i><i></i><i></i><span>+</span></div></div>
          <strong>100 × 100 米</strong>
          <p>以地图中心为基准选址，<br>放大后自动进入建造。</p>
        </div>
        <button class="primary full select-start" id="start-selection">${icons.scan}<span>开始选地</span>${icons.arrow}</button>
        ${legacyButton}`
      $('start-selection').onclick = () => { drawing = true; showPanel(); refreshDraft() }
      bindLegacy()
      return
    }
    panel.innerHTML = `
      <div class="panel-caption">选址预览</div>
      <div class="selection-card in-progress">
        <span class="selection-mini-icon">${icons.locate}</span>
        <strong>100 × 100 米</strong>
        <p>平移地图调整地块中心。<br>放大到 18 级自动进入建造。</p>
        <small class="plot-area" id="map-level"></small>
      </div>
      <button class="primary full" id="focus-building">${icons.plus}<span>放大至建造级别</span>${icons.arrow}</button>
      <div class="selection-footer"><button class="subtle" id="cancel-selection">取消选址</button></div>`
    $('cancel-selection').onclick = () => {
      drawing = false
      rectangle?.remove()
      rectangle = undefined
      showPanel()
    }
    $('focus-building').onclick = () => {
      if (map.getZoom() >= buildZoom) enter(chosenPlot())
      else map.setZoom(buildZoom, { animate: false })
    }
  }
  map.on('zoomend', () => {
    if (!drawing) return
    refreshDraft()
    if (map.getZoom() >= buildZoom) enter(chosenPlot())
  })
  map.on('move', refreshDraft)
  function updateCoords(location: L.LatLng) {
    const { lat, lng } = location.wrap()
    $('map-coords').textContent = `${Math.abs(lat).toFixed(4)}° ${lat >= 0 ? 'N' : 'S'}  ·  ${Math.abs(lng).toFixed(4)}° ${lng >= 0 ? 'E' : 'W'}`
  }
  map.on('mousemove', event => updateCoords(event.latlng))
  map.on('moveend', () => {
    updateCoords(map.getCenter())
    $('map-place').textContent = map.getCenter().distanceTo(chengdu) < 21000 ? '中国 · 成都市' : '当前地图位置'
  })
  $('zoom-in').onclick = () => { map.zoomIn() }
  $('zoom-out').onclick = () => { map.zoomOut() }
  $('center-map').onclick = () => { map.setView(chengdu, zoom) }
  showPanel()
  return () => {
    disposed = true
    lastView = { center: map.getCenter(), zoom: map.getZoom() }
    map.remove()
  }
}
