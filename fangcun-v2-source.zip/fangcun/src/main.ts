import './styles.css'
import { getSave, setSave, EMPTY, type Plot, type Save } from './data'
import { mapPage } from './map'
import { setupTheme } from './theme'
import { joinRoom, RoomClient, RoomRequestError } from './room'
import type { RoomAccess } from './collab-types'
import { $, icons, logo } from './ui'

const app = $('app')
let saved = getSave()
let dispose: (() => void) | undefined
let active: 'map' | 'editor' = 'map'
let loading = false
let guest: RoomClient | undefined
const ownerKey = 'fangcun.owner-room'
const guestKey = 'fangcun.guest-room'

function restoreAccess(storage: Storage, key: string) {
  try {
    const raw = storage.getItem(key)
    return raw ? JSON.parse(raw) as RoomAccess : undefined
  } catch { return undefined }
}
function announce(text: string) {
  const message = $('app-message')
  message.textContent = text
  message.hidden = false
  window.setTimeout(() => { message.hidden = true }, 6000)
}

app.innerHTML = `
  <header class="topbar">
    <button class="brand" id="brand" aria-label="方寸，返回地图">
      ${logo()}<div><strong>方寸</strong><small>地块工作室</small></div>
    </button>
    <nav class="workflow" aria-label="工作步骤">
      <button id="map-tab">${icons.map}<span>地图选址</span></button>
      <span class="workflow-arrow">${icons.chevron}</span>
      <button id="editor-tab">${icons.box}<span>3D 工作台</span></button>
    </nav>
    <div class="header-actions"><label for="theme-picker" class="theme-control">主题 <select id="theme-picker"><option value="pine">松绿</option><option value="sky">天蓝白</option><option value="night">深海夜色</option></select></label></div>
  </header>
  <main id="page"></main>
  <footer id="map-footer" class="map-footer"><div>${icons.globe}<span>地块和模型保存在此浏览器</span></div><div>地图尺寸为估算值</div></footer>
  <p id="app-message" class="app-message" role="alert" hidden></p>`

function navigation() {
  document.querySelector('.workflow [aria-current]')?.removeAttribute('aria-current')
  $(active === 'map' ? 'map-tab' : 'editor-tab').setAttribute('aria-current', 'step')
  ;($('editor-tab') as HTMLButtonElement).disabled = !saved && !guest
  $('map-footer').hidden = active !== 'map'
}
function showMap() {
  dispose?.()
  active = 'map'
  $('page').className = 'map-page'
  navigation()
  dispose = mapPage($('page'), guest?.latest?.save ?? saved, enterEditor)
}
async function enterEditor(plot: Plot) {
  if (active === 'editor' || loading) return
  loading = true
  try {
    let client = guest
    if (!client && saved) {
      const access = restoreAccess(localStorage, ownerKey)
      if (access) {
        client = new RoomClient(access)
        try { await client.read() }
        catch (error) {
          if (!(error instanceof RoomRequestError) || ![403, 404].includes(error.status)) throw error
          localStorage.removeItem(ownerKey)
          client = undefined
          announce('共建房间已失效，已打开此浏览器内的存档。')
        }
      }
    }
    if (!client && !saved) {
      const next: Save = { plot, scene: structuredClone(EMPTY) }
      setSave(next)
      saved = next
    }
    const initial = client?.latest?.save ?? saved!
    const { editorPage } = await import('./editor')
    dispose?.()
    dispose = undefined
    active = 'editor'
    $('page').className = 'editor-page'
    navigation()
    dispose = editorPage($('page'), initial, value => {
      if (guest) return
      setSave(value)
      saved = value
    }, { client, ownerRoom: room => localStorage.setItem(ownerKey, JSON.stringify(room.access)) })
  } catch (error) {
    console.error(error)
    showMap()
    announce(error instanceof Error ? error.message : '无法打开 3D 工作台。')
  } finally {
    loading = false
  }
}
$('brand').onclick = $('map-tab').onclick = () => { if (active !== 'map') showMap() }
$('editor-tab').onclick = () => {
  const plot = guest?.latest?.save.plot ?? saved?.plot
  if (plot) void enterEditor(plot)
}

async function openInvitationOrRestore(restore: boolean) {
  const hash = new URLSearchParams(location.hash.slice(1))
  const room = hash.get('room')
  const invite = hash.get('invite')
  if (!room && !invite && !restore) return
  try {
    const access = restoreAccess(sessionStorage, guestKey)
    const client = room && invite ? await joinRoom(room, invite) : access ? new RoomClient(access) : undefined
    if (!client) return
    const view = await client.read()
    sessionStorage.setItem(guestKey, JSON.stringify(client.access))
    if (room && invite) history.replaceState(null, '', location.pathname + location.search)
    guest = client
    if (active === 'editor') showMap()
    await enterEditor(view.save.plot)
  } catch (error) {
    announce(error instanceof Error ? error.message : '无法加入地块。')
  }
}

setupTheme()
showMap()
void openInvitationOrRestore(true)
window.addEventListener('hashchange', () => void openInvitationOrRestore(false))

