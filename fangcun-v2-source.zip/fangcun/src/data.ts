export type Vec = [number, number, number]
export type Corner = [number, number]
export type Primitive = 'box' | 'cylinder' | 'sphere'
export type Plot = { south: number; west: number; north: number; east: number; width: number; depth: number }
export type Item = {
  id: string
  name: string
  kind: Primitive | 'group' | 'glb'
  position: Vec
  rotation: Vec
  scale: Vec
  color?: string
  children?: Item[]
  asset?: string
}
export type SceneData = { items: Item[]; models: Item[] }
export type Save = { plot: Plot; scene: SceneData }
export const SHAPES: Record<Primitive, string> = { box: '立方体', cylinder: '圆柱体', sphere: '球体' }
export const EMPTY: SceneData = { items: [], models: [] }
const SAVE_KEY = 'fangcun.v1'
const radius = 6371008.8
const radians = Math.PI / 180

export const PLOT_SIZE = 100

export function makePlot(center: Corner): Plot {
  const lat = Math.max(-85, Math.min(85, center[0]))
  const lng = ((center[1] + 180) % 360 + 360) % 360 - 180
  const halfLatitude = PLOT_SIZE / (2 * radius * radians)
  const halfLongitude = halfLatitude / Math.cos(lat * radians)
  return {
    south: lat - halfLatitude, west: lng - halfLongitude,
    north: lat + halfLatitude, east: lng + halfLongitude,
    width: PLOT_SIZE, depth: PLOT_SIZE,
  }
}

export function isSquarePlot(plot: Plot) {
  return plot.width === PLOT_SIZE && plot.depth === PLOT_SIZE
}

export function distance(meters: number) {
  return meters >= 1000
    ? `${(meters / 1000).toLocaleString('zh-CN', { maximumFractionDigits: 2 })} km`
    : `${meters.toLocaleString('zh-CN', { maximumFractionDigits: 1 })} m`
}

export function area(squareMeters: number) {
  const km = squareMeters >= 1e6
  return `${(km ? squareMeters / 1e6 : squareMeters).toLocaleString('zh-CN', { maximumFractionDigits: 1 })} ${km ? 'km²' : 'm²'}`
}

export function getSave(): Save | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY)
    if (!raw) return null
    const save: Save = JSON.parse(raw)
    if (isSquarePlot(save.plot)) return save
    localStorage.setItem('fangcun.legacy.v1', raw)
    localStorage.removeItem(SAVE_KEY)
    return null
  } catch {
    return null
  }
}

export function exportLegacySave() {
  return localStorage.getItem('fangcun.legacy.v1')
}

export function setSave(save: Save) {
  localStorage.setItem(SAVE_KEY, JSON.stringify(save))
}

export function newId() {
  const bytes = crypto.getRandomValues(new Uint8Array(16))
  bytes[6] = bytes[6] & 15 | 64
  bytes[8] = bytes[8] & 63 | 128
  const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('')
  return [hex.slice(0, 8), hex.slice(8, 12), hex.slice(12, 16), hex.slice(16, 20), hex.slice(20)].join('-')
}

export function newItem(kind: Item['kind'], name: string): Item {
  return { id: newId(), kind, name, position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] }
}

function openAssets(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('fangcun-assets', 1)
    request.onupgradeneeded = () => request.result.createObjectStore('glb')
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

export async function putAsset(id: string, data: ArrayBuffer) {
  const db = await openAssets()
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction('glb', 'readwrite')
      transaction.objectStore('glb').put(data, id)
      transaction.oncomplete = () => resolve()
      transaction.onabort = () => reject(transaction.error)
    })
  } finally {
    db.close()
  }
}

export async function getAsset(id: string): Promise<ArrayBuffer | undefined> {
  const db = await openAssets()
  try {
    return await new Promise((resolve, reject) => {
      const request = db.transaction('glb').objectStore('glb').get(id)
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error)
    })
  } finally {
    db.close()
  }
}
