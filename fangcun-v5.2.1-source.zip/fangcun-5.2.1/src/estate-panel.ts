import { $, escapeHtml as esc, icons, button } from './ui'
import {
  blueprints,
  buildingRate,
  catalog,
  DRAW_PRICE,
  goodsNames,
  GOOD_PRICE,
  profileTags,
  sectorNames,
  type Building,
  type EstateCommand,
  type EstateView,
  type Offer,
  type Sector,
} from './estate'
import { cellKey, neighborsOf, parseCell } from './plot-grid'
import type { RegionClient } from './region'
import { configureModel, personalModel, planReply } from './employee-ai'
import { newId } from './data'
import './estate.css'

const tabs = { overview:'多地块总览', plot:'当前地块', shelf:'建筑库', trade: '交易所', chat: '街坊频道' }
type Tab = keyof typeof tabs
type Placement = (b: Building, complete: (x: number, z: number, angle: number) => void) => void
const choices = (rows: { id: string; name: string }[]) =>
  rows.map((r) => `<option value="${esc(r.id)}">${esc(r.name)}</option>`).join('')
const smallButton = (action: string, label: string, id = '', disabled = false) =>
  `<button type="button" class="secondary" data-action="${action}" data-ref="${esc(id)}" ${disabled ? 'disabled' : ''}>${esc(label)}</button>`
const submit = (label: string, disabled = false) =>
  `<button class="primary" type="submit" ${disabled ? 'disabled' : ''}>${esc(label)}</button>`
const art = (kind: string) =>
  `<img class="estate-art" src="/estate/${kind}.webp" alt="" style="background:${blueprints.get(kind)!.paper}">`

export function mountEstate(
  root: HTMLElement,
  client: RegionClient,
  cell: string,
  changed: (e: EstateView) => void,
  place: Placement,
  toast: (s: string, error?: boolean) => void,
  npcs: () => { id: string; name: string }[],
  openCell:(cell:string)=>void,
  startDrag:()=>boolean,
  dropSite:(event:DragEvent,kind:string)=>{cell:string;x:number;z:number}|undefined,
  clearGuide:()=>void
) {
  root.insertAdjacentHTML(
    'beforeend',
    `<dialog class="app-dialog estate-dialog" id="estate-dialog" aria-labelledby="estate-name">
    <header class="estate-header"><div><span class="estate-location">${icons.map} <span id="estate-location"></span></span><h2 id="estate-name">街坊经营</h2></div><strong id="estate-wallet">— 方币</strong>${button('close', '关闭经营面板', 'estate-close')}</header>
    <nav class="estate-tabs" aria-label="街坊经营">${Object.entries(tabs)
      .map(([id, title]) => `<button data-tab="${id}">${title}</button>`)
      .join('')}</nav>
    <section id="estate-content"></section><p id="estate-note" role="status"></p>
  </dialog>`
  )
  const dialog = $('estate-dialog') as HTMLDialogElement,
    body = $('estate-content'),
    note = $('estate-note')
  let data: EstateView | undefined,
    tab: Tab = 'plot',
    theme = '全部',
    closed = false,
    busy = false,
    reading = false,
    refreshWanted = -1,
    lastRead = 0,
    lastPaint = '',
    generation = 0
  const retryKey = 'fangcun.estate-pending.' + client.access.room + '.' + client.latest!.member
  let uncertain: { serialized: string; nonce: string } | undefined
  try {
    uncertain = JSON.parse(sessionStorage.getItem(retryKey) ?? 'null') ?? undefined
  } catch {}
  const controller = new AbortController()
  const self = () => client.latest!.member
  const tile = () => client.tile(cell)
  const canEdit = () => !!tile() && (tile()!.owner === self() || (client.latest?.role !== 'view' && tile()!.write))
  const participates = () => client.latest?.role !== 'view' || client.latest?.tiles.some((t) => t.owner === self())
  const owner = (id: string) => data?.profiles.find((p) => p.id === id)?.name ?? '街坊'
  const local = () => data!.buildings.filter((b) => b.site!.cell === cell)
  const myCrew = () => data!.crew.filter((w) => w.owner === self())
  const listed = (id: string) => data!.offers.some((o) => o.type === 'asset' && o.ref === id)
  const find = (id: string) => [...data!.inventory, ...data!.buildings].find((b) => b.id === id)
  const formValue = (f: HTMLFormElement, k: string) => String(new FormData(f).get(k) ?? '')
  function apply(e: EstateView) {
    if (closed || (data && data.revision > e.revision)) return
    data = e
    lastRead = Date.now()
    changed(e)
    paint()
  }
  async function refresh(rev: number, force = false) {
    refreshWanted = Math.max(refreshWanted, rev)
    if (
      closed ||
      reading ||
      busy ||
      (!force && data && refreshWanted <= data.revision && (!dialog.open || Date.now() - lastRead < 12000))
    )
      return
    reading = true
    const start = generation
    try {
      const e = await client.estate()
      if (start === generation) apply(e)
    } catch (err) {
      if (dialog.open && !closed) note.textContent = err instanceof Error ? err.message : '读取失败。'
    } finally {
      reading = false
    }
  }
  async function run(c: EstateCommand) {
    if (busy || closed) return false
    busy = true
    generation++
    const serialized = JSON.stringify(c),
      nonce = uncertain?.serialized === serialized ? uncertain.nonce : newId()
    uncertain = { serialized, nonce }
    try {
      sessionStorage.setItem(retryKey, JSON.stringify(uncertain))
    } catch {}
    note.textContent = '正在提交…'
    dialog.setAttribute('aria-busy', 'true')
    try {
      const r = await client.transact(c, nonce)
      if (closed) return false
      uncertain = undefined
      sessionStorage.removeItem(retryKey)
      if (c.type === 'take') await client.read().catch(() => {})
      apply(r.estate)
      note.textContent = r.result
      if (!dialog.open) toast(r.result)
      return true
    } catch (err) {
      if (closed) return false
      uncertain = { serialized, nonce }
      const text = err instanceof Error ? err.message : '暂时无法提交，请重试。'
      note.textContent = text
      if (!dialog.open) toast(text, true)
      return false
    } finally {
      busy = false
      dialog.removeAttribute('aria-busy')
    }
  }
  function plotMarkup() {
    const e = data!,
      here = local(),
      staff = e.crew.filter((w) => here.some((b) => b.id === w.job?.building))
    const adjacent = new Set(neighborsOf(parseCell(cell)!).map((c) => client.tile(cellKey(c))?.room ?? ''))
    const openShops = here.filter((b) => b.site!.active !== false)
    const jobs = openShops.map((b) => ({ id: b.id, name: blueprints.get(b.kind)!.name + ' · ' + b.id.slice(-4) }))
    return `<div class="estate-two"><section><h3>营业地块 <small>${openShops.length} / 3 座 · ${staff.length} / 2 名员工</small></h3>
      <p class="estate-caption">营业建筑自动生产，同业相聚和派工可增产。建筑也可仅作陈列，随时开业。</p>
      ${
        here.length
          ? here
              .map((b) => {
                const d = blueprints.get(b.kind)!,
                  team = staff.filter((w) => w.job?.building === b.id)
                return `<article class="estate-row" data-shop="${b.id}" tabindex="-1">${art(b.kind)}<div><strong>${d.name}</strong><small>${esc(owner(b.owner))} · ${buildingRate(b, e.buildings, e.crew, adjacent).toFixed(1)} 件／分</small><small>${b.site!.active === false ? '仅作陈列' : team.map((w) => esc(w.name)).join('、') || '自动营业'}</small></div><div class="estate-row-actions">${smallButton('place', '移动', b.id, !canEdit())}${smallButton('operate', b.site!.active === false ? '开业' : '歇业', b.id, !canEdit() || (b.site!.active === false && openShops.length >= 3))}${b.owner === self() || tile()?.owner === self() ? smallButton('store', b.owner === self() ? '收回' : '退回主人', b.id) : ''}</div></article>`
              })
              .join('')
          : '<div class="estate-empty">此格有 3 个空位。到建筑图鉴选购第一家店。</div>'
      }
      </section><section><h3>员工排班 <small>${myCrew().length} 人</small></h3>
      ${myCrew()
        .map((w) => {
          const post = e.buildings.find((b) => b.id === w.job?.building)
          return `<div class="estate-worker"><span class="employee-dot"></span><strong>${esc(w.name)}</strong><small>${post ? blueprints.get(post.kind)!.name : w.job ? '在其他街区工作' : '待命'}</small></div>`
        })
        .join('')}
      <form data-form="work" class="estate-form"><label>员工<select name="staff">${choices(myCrew())}</select></label><label>岗位<select name="building"><option value="">收工休息</option>${choices(jobs)}</select></label>${submit('安排员工', !participates())}</form>
      <details class="model-options"><summary>用场景 NPC 作为员工模板</summary><p>复制本格 NPC 的名字、人设和 PNG 外观。上岗后，街坊可以看见这名员工。</p><form data-form="recruit" class="estate-form"><label>员工<select name="staff">${choices(myCrew())}</select></label><label>场景 NPC<select name="npc">${choices(npcs())}</select></label>${submit('采用模板', !canEdit() || !npcs().length)}</form></details>
</section></div>`
  }
  function overviewMarkup() {
    const e=data!, tiles=client.latest?.tiles??[]
    return `<h3>共建区 · ${tiles.length} 块地</h3>`+tiles.map(tile=>{
      const sites=e.buildings.filter(b=>b.site?.room===tile.room)
      const staff=e.crew.filter(w=>sites.some(b=>b.id===w.job?.building))
      return `<article class="estate-row"><div><strong>${esc(tile.key)}</strong><small>${esc(owner(tile.owner))} · 营业 ${sites.filter(b=>b.site!.active!==false).length}/3 · 员工 ${staff.length}/2</small></div>${smallButton('inspect','查看地块',tile.key)}</article>`
    }).join('')
  }
  function catalogMarkup() {
    const e = data!
    return `<div class="estate-bar"><div class="estate-filter">${['全部', '日式街角', '中式古镇', '欧式小镇'].map((t) => `<button data-action="filter" data-ref="${t}" aria-pressed="${theme === t}">${t}</button>`).join('')}</div></div>
      <div class="estate-cards">${catalog
        .filter((d) => theme === '全部' || d.theme === theme)
        .map(d=>{
          const owned=e.inventory.filter(b=>b.kind===d.id && !listed(b.id))
          const available=!!owned.length || !!d.price && e.coins>=d.price
          const draggable=canEdit() && available
          return `<article class="estate-card" draggable="${draggable}" data-kind="${d.id}">${art(d.id)}<div><small>${d.theme} · ${sectorNames[d.sector]}</small><h3>${d.name}</h3><p>库存 ${owned.length} 座 · 每分钟 ${d.rate} 件</p>
            <strong>${owned.length?'拖入地块':d.price?(e.coins<d.price?'余额不足 · ':'拖入购买 · ')+d.price+' 方币':'稀有 · 建筑签或交易'}</strong>
            ${d.price?smallButton('buy','买入仓库',d.id,!participates()||e.coins<d.price):''}
            ${owned.length?smallButton('place','点选放置',owned[0].id,!canEdit()):''}</div></article>`
        })
        .join('')}</div>
      <div class="draw-strip"><div><strong>街坊建筑签</strong><small>常规 90% · 稀有 10% · 同级等概率 · 连续 9 次常规后必出稀有</small><small>距保底最多 ${10 - e.misses} 签</small></div>${smallButton('draw', '抽一签 · ' + DRAW_PRICE + ' 方币', '', !participates() || e.coins < DRAW_PRICE)}</div><details><summary>货物仓库</summary><h3>货物仓库</h3>${(Object.keys(goodsNames) as Sector[]).map((k) => `<div class="estate-stock"><span>${goodsNames[k]}</span><b>${e.goods[k]} 件</b>${smallButton('redeem', '全部交货', k, !participates() || !e.goods[k])}</div>`).join('')}<small class="estate-caption">每件交货可得 ${GOOD_PRICE} 方币，也可自主挂牌。</small></details>`
  }
  function tradeMarkup() {
    const e = data!,
      offers = e.offers
    const assets = e.inventory
      .filter((b) => !listed(b.id))
      .map((b) => ({ id: 'asset/' + b.id, name: '建筑 · ' + blueprints.get(b.kind)!.name + ' ' + b.id.slice(-4) }))
    const land = (client.latest?.tiles ?? [])
      .filter((t) => t.owner === self() && !offers.some((o) => o.type === 'land' && o.ref === t.room))
      .map((t) => ({ id: 'land/' + t.room, name: '地块 · ' + t.key }))
    const goods = (Object.keys(goodsNames) as Sector[])
      .filter((s) => e.goods[s])
      .map((s) => ({ id: 'goods/' + s, name: '货物 · ' + goodsNames[s] + ' × ' + e.goods[s] }))
    const resources = [...assets, ...land, ...goods],
      people = e.profiles.filter((p) => p.id !== self())
    return `<div class="estate-two"><section><h3>玩家挂牌 <small>${offers.length} 笔</small></h3>
    <p class="estate-caption">建筑、货物面向本服务器交易。地块向同一共建区的成员挂牌。</p>
    ${offers.length ? offers.map((o) => `<article class="offer"><div><small>${{ goods: '货物', land: '地块', asset: '建筑' }[o.type]} · ${esc(owner(o.seller))}</small><strong>${esc(o.label)}${o.qty > 1 ? ' × ' + o.qty : ''}</strong></div><b>${o.price} 方币</b>${o.seller === self() ? smallButton('cancel', '撤回', o.id) : smallButton('take', '买入', o.id, !participates() || e.coins < o.price)}</article>`).join('') : '<div class="estate-empty">还没有挂牌。</div>'}</section>
    <section><h3>出售资产</h3><form data-form="list" class="estate-form"><label>资产<select name="ref" required>${choices(resources)}</select></label><label>挂牌总价<input name="price" type="number" min="1" max="1000000" value="100" required></label><label>货物数量<input name="qty" type="number" min="1" max="1000000" value="1" required></label>${submit('挂牌出售', !participates() || !resources.length)}</form>
    <p class="estate-caption">地块成交时，场景装饰随地过户。营业建筑回到各自主人的仓库，员工收工。买家可以重新开放共建。</p>
    <h3>玩家转账</h3><form data-form="pay" class="estate-form"><label>收款人<select name="to" required>${choices(people.map((p) => ({ id: p.id, name: p.name + ' · ' + p.id.slice(-4) })))}</select></label><label>方币<input type="number" name="amount" min="1" max="1000000" value="10" required></label>${submit('确认转账', !participates() || !people.length)}</form></section></div>`
  }
  function chatMarkup() {
    const e = data!
    return `<div class="estate-two chat-layout"><section><h3>共建区聊天 <small>最近 100 条消息</small></h3><ol class="estate-log" aria-live="polite">${e.chat.map((l) => `<li class="${l.ai ? 'agent-line' : ''}"><small>${esc(l.name)}${l.ai ? ' · AI 员工' : ''} <time>${new Date(l.at).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}</time></small><p>${esc(l.text)}</p></li>`).join('') || '<li class="estate-empty">问候街坊，或选择一名员工下达指令。</li>'}</ol>
    <form data-form="chat" class="estate-form"><label>发给<select name="staff"><option value="">所有街坊</option>${choices(myCrew().map((w) => ({ id: w.id, name: '@' + w.name })))}</select></label>
    <label>消息<input name="text" placeholder="例如 去灯街喫茶店工作、查看地图、收工" maxlength="400" autocomplete="off" required></label>${submit('发送')}</form></section>
    <section><h3>街坊名片</h3>${e.profiles
      .filter((p) => Object.values(client.latest?.people ?? []).some((m) => m.id === p.id) || p.id === self())
      .map(
        (p) =>
          `<div class="estate-worker"><span class="employee-dot"></span><strong>${esc(owner(p.id))}</strong><small>${p.tags.map(esc).join(' · ') || '街坊'}</small></div>`
      )
      .join('')}
    <form data-form="profile" class="estate-form"><fieldset><legend>我的标签 · 最多三项</legend>${profileTags.map((t) => `<label><input type="checkbox" name="tag" value="${t}" ${e.tags.includes(t) ? 'checked' : ''}> ${t}</label>`).join('')}</fieldset>${submit('保存名片')}</form>
    <details class="model-options"><summary>个人 AI 接口 · ${personalModel.endpoint ? '已连接配置' : '本地指令'}</summary><p>启用后，本标签页把你的指令和可见地块摘要发送到指定接口，由你的账号或本地模型承担用量。密钥只在本页内存中保留。</p>
    <form data-form="model" class="estate-form"><label>对话接口<input name="endpoint" type="url" placeholder="https://…/v1/chat/completions" value="${esc(personalModel.endpoint)}"></label><label>模型名称<input name="model" value="${esc(personalModel.model)}"></label><label>API 密钥<input name="secret" type="password" autocomplete="off" placeholder="${personalModel.key ? '已设置，可留空保留' : '本地服务可留空'}"></label>${submit('应用设置')}</form></details></section></div>`
  }
  function paint(force = false) {
    if (!dialog.open || !data) return
    $('estate-wallet').textContent = data.coins.toLocaleString() + ' 方币'
    const content =
      tab === 'overview' ? overviewMarkup() : tab === 'plot'
        ? plotMarkup()
        : tab === 'shelf'
          ? catalogMarkup()
          : tab === 'trade'
            ? tradeMarkup()
            : chatMarkup()
    if (content === lastPaint && !force) return
    const forms = [...body.querySelectorAll<HTMLFormElement>('form[data-form]')]
    const fields = forms.flatMap((f) =>
      [...f.elements]
        .filter(
          (el): el is HTMLInputElement | HTMLSelectElement =>
            el instanceof HTMLInputElement || el instanceof HTMLSelectElement
        )
        .filter((el) => el.type !== 'checkbox' && el.name)
        .map((el) => ({
          form: f.dataset.form!,
          name: el.name,
          value: el.value,
          focused: el === document.activeElement,
        }))
    )
    const log = body.querySelector('ol'),
      atEnd = !log || log.scrollTop + log.clientHeight >= log.scrollHeight - 25,
      scroll = log?.scrollTop ?? 0
    const opened = body.querySelector('details')?.open
    const tagDraft = body.querySelector('form[data-dirty]')
      ? new FormData(body.querySelector('form[data-dirty]') as HTMLFormElement).getAll('tag')
      : undefined
    const savedScroll = body.scrollTop
    body.innerHTML = content
    lastPaint = content
    for (const field of fields) {
      const el = body.querySelector<HTMLSelectElement | HTMLInputElement>(
        `form[data-form="${field.form}"] [name="${field.name}"]`
      )
      if (!el || (el instanceof HTMLSelectElement && ![...el.options].some((o) => o.value === field.value))) continue
      el.value = field.value
      if (field.focused) el.focus({ preventScroll: true })
    }
    if (tagDraft) {
      const f = body.querySelector<HTMLFormElement>('[data-form="profile"]')
      if (f) {
        f.dataset.dirty = 'true'
        f.querySelectorAll<HTMLInputElement>('[name="tag"]').forEach((el) => (el.checked = tagDraft.includes(el.value)))
      }
    }
    if (opened) body.querySelector('details')?.setAttribute('open', '')
    const next = body.querySelector('ol')
    if (next) next.scrollTop = atEnd ? next.scrollHeight : scroll
    body.scrollTop = savedScroll
    dialog
      .querySelectorAll<HTMLElement>('[data-tab]')
      .forEach((el) => el.setAttribute('aria-pressed', String(el.dataset.tab === tab)))
  }
  body.addEventListener('change', (event) => {
    const target = event.target as HTMLInputElement
    if (target.name === 'tag' && target.form) target.form.dataset.dirty = 'true'
  })
  function open(which: Tab = (client.latest?.tiles.length??0)>1?'overview':'plot',selected?:string) {
    if (closed) return
    tab = which
    $('estate-location').textContent = (client.latest?.name ?? '') + ' · ' + cell
    const floating=which==='shelf'
    if(dialog.open && floating!==dialog.classList.contains('building-shelf'))dialog.close()
    dialog.classList.toggle('building-shelf',floating)
    $('estate-name').textContent=floating?'建筑库':'街坊经营'
    if(!dialog.open){if(floating)dialog.show();else dialog.showModal()}
    note.textContent = ''
    paint(true)
    if(selected)body.querySelector<HTMLElement>(`[data-shop="${selected}"]`)?.focus()
    void refresh(client.latest?.estateRevision ?? 0, true)
  }
  let dragging:{kind:string;id?:string}|undefined
  const canvas=root.querySelector<HTMLCanvasElement>('#viewport > canvas')!
  const signal=controller.signal
  body.addEventListener('dragstart',event=>{
    const card=(event.target as Element).closest<HTMLElement>('article[data-kind]')
    if(!card || card.draggable!==true || busy || !event.dataTransfer || !startDrag()){event.preventDefault();return}
    const kind=card.dataset.kind!
    dragging={kind,id:data?.inventory.find(b=>b.kind===kind && !listed(b.id))?.id}
    event.dataTransfer.setData('application/x-fangcun-building',kind)
    event.dataTransfer.effectAllowed='copy'
  },{signal})
  body.addEventListener('dragend',()=>{dragging=undefined;clearGuide()},{signal})
  canvas.addEventListener('dragover',event=>{if(dragging){event.preventDefault();dropSite(event,dragging.kind);if(event.dataTransfer)event.dataTransfer.dropEffect='copy'}},{signal})
  canvas.addEventListener('dragleave',clearGuide,{signal})
  canvas.addEventListener('drop',event=>{
    const card=dragging
    if(!card || busy)return
    event.preventDefault()
    dragging=undefined
    const site=dropSite(event,card.kind)
    clearGuide()
    if(!site)return
    void run(card.id?{type:'position',id:card.id,...site,angle:0,before:null}:{type:'buy-place',kind:card.kind,...site,angle:0})
  },{signal})
  $('estate-close').onclick = () => dialog.close()
  dialog.onclick = async (event) => {
    const el = (event.target as HTMLElement).closest<HTMLButtonElement>('button')
    if (!el || busy || el.disabled) return
    if (el.dataset.tab) {
      open(el.dataset.tab as Tab)
      return
    }
    if (!data) return
    const { action, ref = '' } = el.dataset
    switch (action) {
      case 'inspect':
        if(ref===cell)open('plot');else openCell(ref)
        break
      case 'filter':
        theme = ref
        paint(true)
        break
      case 'buy':
        await run({ type: 'buy', kind: ref })
        break
      case 'draw':
        await run({ type: 'draw' })
        break
      case 'store':
        await run({ type: 'store', id: ref })
        break
      case 'redeem':
        await run({ type: 'redeem', kind: ref as Sector, qty: data.goods[ref as Sector] })
        break
      case 'take':
      case 'cancel':
        if (action === 'cancel' || confirm('按挂牌总价买入这项资产？')) await run({ type: action, id: ref })
        break
      case 'operate': {
        const b = find(ref)
        if (b?.site)
          await run({type:'operate',id:ref,cell,active:b.site.active===false})
        break
      }
      case 'display':
      case 'place': {
        const b = find(ref)
        if (!b) return
        dialog.close()
        place(
          b,
          (x, z, angle) =>
            void run({
              type: 'position',
              id: ref,
              cell,
              x,
              z,
              angle,
              before:b.site??null,
            })
        )
        break
      }
    }
  }
  let planning = false
  body.onsubmit = async (event) => {
    event.preventDefault()
    const f = event.target as HTMLFormElement,
      v = (k: string) => formValue(f, k)
    if (busy || planning || !data) return
    try {
      switch (f.dataset.form) {
        case 'recruit':
          await run({ type: 'recruit', staff: v('staff'), cell, npc: v('npc') })
          break
        case 'work':
          await run({ type: 'work', staff: v('staff'), building: v('building') || undefined })
          break
        case 'list': {
          const [assetType, ref] = v('ref').split('/')
          await run({
            type: 'list',
            assetType: assetType as Offer['type'],
            ref,
            price: Number(v('price')),
            qty: Number(v('qty')),
          })
          break
        }
        case 'pay':
          if (confirm('向所选玩家转账 ' + v('amount') + ' 方币？'))
            await run({ type: 'pay', to: v('to'), amount: Number(v('amount')) })
          break
        case 'profile':
          delete f.dataset.dirty
          await run({ type: 'profile', tags: new FormData(f).getAll('tag').map(String) })
          break
        case 'model':
          configureModel(
            v('endpoint'),
            v('model'),
            v('secret') || (v('endpoint').trim() === personalModel.endpoint ? personalModel.key : '')
          )
          note.textContent = personalModel.endpoint ? '已启用个人模型。' : '已切换至本地指令。'
          paint(true)
          {
            const key = body.querySelector<HTMLInputElement>('[name="secret"]')
            if (key) key.value = ''
          }
          break
        case 'chat': {
          const text = v('text').trim(),
            staff = v('staff') || undefined
          const c: Extract<EstateCommand, { type: 'chat' }> = { type: 'chat', text, staff, cell }
          if (staff && personalModel.endpoint) {
            planning = true
            note.textContent = '员工正在读取附近地图…'
            const map = await client.mapContext(cell)
            Object.assign(c, await planReply(myCrew().find((w) => w.id === staff)!, text, map, controller.signal))
            if (closed) return
          }
          if (await run(c)) {
            const field = body.querySelector<HTMLInputElement>('[name="text"]')
            if (field?.value === text) field.value = ''
          }
          break
        }
      }
    } catch (err) {
      if (!closed) note.textContent = err instanceof Error ? err.message : '操作失败。'
    } finally {
      planning = false
    }
  }
  return {
    open,
    refresh,
    dispose() {
      closed = true
      controller.abort()
      dialog.remove()
    },
  }
}
